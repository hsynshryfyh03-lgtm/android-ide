# 🚀 دليل رفع المشروع على GitHub وبناء APK تلقائياً

## الطريقة السريعة (3 خطوات فقط)

### 1️⃣ أنشئ Repository جديد على GitHub
1. افتح [github.com/new](https://github.com/new)
2. اسم المشروع: `AndroidIDE`
3. اجعله **Public** أو **Private** حسب رغبتك
4. لا تضف README أو .gitignore (موجودان بالفعل)
5. اضغط **Create repository**

### 2️⃣ ارفع ملفات المشروع
افتح Terminal واكتب:
```bash
cd AndroidIDE
git init
git add .
git commit -m "Initial commit: AndroidIDE project"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/AndroidIDE.git
git push -u origin main
```

### 3️⃣ انتظر البناء
- افتح الـ Repository على GitHub
- اضغط تبويب **Actions**
- ستجد workflow جاري ⚙️
- بعد ~5 دقائق: APK جاهز للتحميل ✅

---

## 📦 أين أجد APK بعد البناء؟

**طريقتان:**

**أ) Artifacts** (لكل push):
- Actions → اختر الـ workflow → مقطع Artifacts في الأسفل
- حمّل `AndroidIDE-Debug` أو `AndroidIDE-Release`

**ب) Releases** (عند push على main):
- اضغط **Releases** من الشريط الجانبي
- حمّل مباشرة من هناك

---

## 🔐 توقيع Release APK (اختياري)

إذا أردت APK موقعاً رسمياً:

1. أنشئ keystore:
```bash
keytool -genkey -v -keystore my-release-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias my-key-alias
```

2. حوّله إلى base64:
```bash
base64 my-release-key.jks | tr -d '\n' > keystore_b64.txt
```

3. أضف Secrets في GitHub:
   - Settings → Secrets and variables → Actions → New repository secret
   - `SIGNING_KEY` = محتوى keystore_b64.txt
   - `KEY_ALIAS` = اسم الـ alias
   - `KEY_STORE_PASSWORD` = كلمة سر الـ keystore
   - `KEY_PASSWORD` = كلمة سر المفتاح

---

## 🛠️ المشاكل الشائعة

| المشكلة | الحل |
|---------|------|
| `permission denied: ./gradlew` | الـ workflow يعالج هذا تلقائياً |
| `gradle-wrapper.jar not found` | الـ workflow يحمّله تلقائياً من Gradle الرسمي |
| Build فشل بسبب dependencies | تأكد من اتصال الإنترنت في Runner (ubuntu-latest ✓) |

