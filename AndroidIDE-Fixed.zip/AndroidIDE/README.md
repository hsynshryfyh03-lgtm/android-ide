# AndroidIDE 📱

> بيئة تطوير Android احترافية تعمل على هاتفك — بديل حقيقي لـ Android Studio

[![Build APK](https://github.com/YOUR_USERNAME/AndroidIDE/actions/workflows/build.yml/badge.svg)](https://github.com/YOUR_USERNAME/AndroidIDE/actions/workflows/build.yml)

---

## ✨ الميزات

| الميزة | الوصف |
|--------|-------|
| 📝 **Monaco Editor** | نفس محرر VS Code مع syntax highlighting لـ Kotlin/Java/XML/Gradle |
| 🌳 **File Explorer** | شجرة ملفات كاملة مع توسيع/طي المجلدات |
| 📂 **Tabs** | تبويبات ملفات متعددة مع حالة الحفظ |
| 🔨 **Build APK** | بناء APK عبر GitHub Actions تلقائياً عند كل push |
| 💻 **Terminal** | طرفية حقيقية لتنفيذ الأوامر |
| 🔀 **Git Panel** | init, add, commit, push, pull, branch, stash |
| 🔍 **Project Search** | بحث نصي في كل ملفات المشروع |
| 📋 **Logcat** | عارض Logcat حي مع فلاتر |
| ⚙️ **Settings** | حجم الخط، السمة، minimap، word wrap، وأكثر |
| 🆕 **New Project** | 5 قوالب: Empty Activity, Basic Views, Login, RecyclerView, Bottom Nav |

---

## 🚀 طريقة الاستخدام

### 1. Fork أو Clone المشروع
```bash
git clone https://github.com/YOUR_USERNAME/AndroidIDE.git
```

### 2. Push إلى GitHub
```bash
git add .
git commit -m "Initial commit"
git push origin main
```

### 3. GitHub Actions تبني APK تلقائياً
- اذهب إلى تبويب **Actions** في GitHub
- انتظر اكتمال البناء (~5 دقائق)
- حمّل الـ APK من قسم **Releases** أو **Artifacts**

### 4. ثبّت على هاتفك
1. حمّل `AndroidIDE-debug.apk`
2. الإعدادات → الأمان → **مصادر غير معروفة** ✓
3. ثبّت وابدأ البرمجة!

---

## 🔑 إضافة توقيع للـ Release APK (اختياري)

في إعدادات GitHub Repository:
```
Settings → Secrets and variables → Actions → New repository secret
```

| Secret | القيمة |
|--------|--------|
| `SIGNING_KEY` | keystore بصيغة Base64 |
| `KEY_ALIAS` | اسم الـ alias |
| `KEY_STORE_PASSWORD` | كلمة مرور الـ keystore |
| `KEY_PASSWORD` | كلمة مرور الـ key |

---

## 📁 هيكل المشروع

```
AndroidIDE/
├── .github/workflows/build.yml   # GitHub Actions
├── app/
│   ├── src/main/
│   │   ├── assets/editor/        # Monaco Editor (HTML)
│   │   ├── java/.../
│   │   │   ├── SplashActivity.kt
│   │   │   ├── MainActivity.kt   # لوحة المشاريع
│   │   │   ├── NewProjectActivity.kt
│   │   │   ├── GitActivity.kt
│   │   │   ├── LogcatActivity.kt
│   │   │   ├── SearchActivity.kt
│   │   │   ├── SettingsActivity.kt
│   │   │   ├── editor/EditorActivity.kt  # IDE الرئيسي
│   │   │   ├── files/FileTreeAdapter.kt
│   │   │   ├── terminal/TerminalSession.kt
│   │   │   └── utils/
│   │   └── res/
│   └── build.gradle
└── build.gradle
```

---

## 🛠 متطلبات البناء

- Java 17
- Android Gradle Plugin 8.2+
- Kotlin 1.9.22
- compileSdk 34 / minSdk 26

---

## 📄 الترخيص

MIT License — استخدم وعدّل كما تشاء.
