package com.androidide.app.editor

import android.annotation.SuppressLint
import androidx.activity.addCallback
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.androidide.app.GitActivity
import com.androidide.app.LogcatActivity
import com.androidide.app.R
import com.androidide.app.SearchActivity
import com.androidide.app.SettingsActivity
import com.androidide.app.databinding.ActivityEditorBinding
import com.androidide.app.files.FileTreeAdapter
import com.androidide.app.terminal.TerminalSession
import com.androidide.app.utils.FileUtils
import com.androidide.app.utils.SettingsManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class EditorActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PROJECT_PATH = "project_path"
        const val EXTRA_PROJECT_NAME = "project_name"
    }

    private lateinit var binding: ActivityEditorBinding
    private lateinit var projectDir: File
    private lateinit var fileTreeAdapter: FileTreeAdapter
    private lateinit var terminalSession: TerminalSession

    private val openFiles = mutableListOf<File>()
    private var activeFile: File? = null
    private var editorReady = false
    private var pendingFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val path = intent.getStringExtra(EXTRA_PROJECT_PATH) ?: run { finish(); return }
        projectDir = File(path)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = intent.getStringExtra(EXTRA_PROJECT_NAME) ?: projectDir.name

        setupDrawer()
        setupFileTree()
        setupEditorWebView()
        setupTabs()
        setupTerminalPanel()

        intent.getStringExtra("open_file")?.let { pendingFile = File(it) }
        setupBackPressHandler()
    }

    override fun onResume() {
        super.onResume()
        applySettingsToEditor()
    }

    private fun setupDrawer() {
        val toggle = ActionBarDrawerToggle(
            this, binding.drawerLayout, binding.toolbar,
            R.string.open_drawer, R.string.close_drawer
        )
        binding.drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
    }

    private fun setupFileTree() {
        fileTreeAdapter = FileTreeAdapter { file ->
            if (file.isFile) {
                binding.drawerLayout.closeDrawer(GravityCompat.START)
                openFileInEditor(file)
            }
        }
        binding.rvFileTree.layoutManager = LinearLayoutManager(this)
        binding.rvFileTree.adapter = fileTreeAdapter
        fileTreeAdapter.setRoot(projectDir)
        binding.tvProjectName.text = projectDir.name
        binding.btnRefreshTree.setOnClickListener { fileTreeAdapter.setRoot(projectDir) }
        binding.btnNewFile.setOnClickListener { showNewFileDialog() }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupEditorWebView() {
        with(binding.webEditor) {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                allowFileAccessFromFileURLs = true
                allowUniversalAccessFromFileURLs = true
                builtInZoomControls = false
                setSupportZoom(false)
            }
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            addJavascriptInterface(EditorBridge(), "AndroidBridge")
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    editorReady = true
                    applySettingsToEditor()
                    pendingFile?.let { openFileInEditor(it); pendingFile = null }
                }
            }
            webChromeClient = WebChromeClient()
            loadUrl("file:///android_asset/editor/index.html")
        }
    }

    private fun applySettingsToEditor() {
        if (!editorReady) return
        val s = SettingsManager(this)
        val js = "window.applySettings({fontSize:${s.fontSize},theme:'${s.theme}',minimap:${s.minimap},wordWrap:'${if (s.wordWrap) "on" else "off"}',ligatures:${s.ligatures},bracketPair:${s.bracketPair},renderWhitespace:'${if (s.whitespace) "all" else "selection"}'});"
        binding.webEditor.evaluateJavascript(js, null)
    }

    inner class EditorBridge {
        @JavascriptInterface
        fun onContentChanged(content: String) {
            activeFile?.let { file ->
                lifecycleScope.launch(Dispatchers.IO) {
                    file.writeText(content)
                    withContext(Dispatchers.Main) { markTabUnsaved(file) }
                }
            }
        }

        @JavascriptInterface
        fun onSave(content: String) {
            activeFile?.let { file ->
                lifecycleScope.launch(Dispatchers.IO) {
                    file.writeText(content)
                    withContext(Dispatchers.Main) {
                        markTabSaved(file)
                        Snackbar.make(binding.root, "✓ ${file.name}", Snackbar.LENGTH_SHORT).show()
                    }
                }
            }
        }

        @JavascriptInterface
        fun log(msg: String) = appendTerminalOutput("» $msg")
    }

    fun openFileInEditor(file: File) {
        if (!editorReady) { pendingFile = file; return }
        if (!openFiles.contains(file)) { openFiles.add(file); addTab(file) }
        selectTab(file)
        activeFile = file
        val lang = FileUtils.getLanguage(file)
        val content = try { file.readText() } catch (_: Exception) { "" }
        val escaped = content.replace("\\", "\\\\").replace("`", "\\`").replace("$", "\\$")
        binding.webEditor.evaluateJavascript("window.setContent(`$escaped`, '$lang', '${file.name}');", null)
    }

    private fun setupTabs() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                val file = tab.tag as? File ?: return
                if (file != activeFile) openFileInEditor(file)
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
    }

    private fun addTab(file: File) {
        binding.tabLayout.addTab(binding.tabLayout.newTab().apply { text = file.name; tag = file })
    }

    private fun selectTab(file: File) {
        for (i in 0 until binding.tabLayout.tabCount) {
            val t = binding.tabLayout.getTabAt(i)
            if (t?.tag == file) { binding.tabLayout.selectTab(t); break }
        }
    }

    private fun markTabUnsaved(file: File) {
        for (i in 0 until binding.tabLayout.tabCount) {
            val t = binding.tabLayout.getTabAt(i)
            if (t?.tag == file && t.text?.startsWith("●") == false) t.text = "● ${file.name}"
        }
    }

    private fun markTabSaved(file: File) {
        for (i in 0 until binding.tabLayout.tabCount) {
            val t = binding.tabLayout.getTabAt(i)
            if (t?.tag == file) t.text = file.name
        }
    }

    private fun setupTerminalPanel() {
        terminalSession = TerminalSession(projectDir) { appendTerminalOutput(it) }
        binding.btnBuild.setOnClickListener { startBuild() }
        binding.btnRun.setOnClickListener { installLastApk() }
        binding.btnClean.setOnClickListener { terminalSession.execute("./gradlew clean 2>&1") }
        binding.btnClearLog.setOnClickListener { binding.tvTerminal.text = "" }
        binding.etTerminalInput.setOnEditorActionListener { _, _, _ ->
            val cmd = binding.etTerminalInput.text.toString().trim()
            if (cmd.isNotEmpty()) {
                appendTerminalOutput("$ $cmd")
                terminalSession.execute(cmd)
                binding.etTerminalInput.text?.clear()
            }
            true
        }
    }

    private fun startBuild() {
        binding.tvTerminal.text = ""
        binding.progressBuild.visibility = View.VISIBLE
        appendTerminalOutput("▶ Building ${projectDir.name}...")
        lifecycleScope.launch(Dispatchers.IO) {
            val gradlew = File(projectDir, "gradlew")
            if (!gradlew.exists()) {
                withContext(Dispatchers.Main) {
                    appendTerminalOutput("ℹ gradlew not found on device.\n\nFor real APK:\n1. Push to GitHub (Git panel)\n2. GitHub Actions builds APK automatically\n3. Download from Releases tab ✓")
                    binding.progressBuild.visibility = View.GONE
                }
                return@launch
            }
            gradlew.setExecutable(true)
            terminalSession.execute("./gradlew assembleDebug --stacktrace 2>&1")
            withContext(Dispatchers.Main) { binding.progressBuild.visibility = View.GONE }
        }
    }

    private fun installLastApk() {
        val apk = File(projectDir, "app/build/outputs/apk/debug/app-debug.apk")
        if (apk.exists()) { appendTerminalOutput("📦 Installing..."); FileUtils.installApk(this, apk) }
        else appendTerminalOutput("✗ APK not found. Build first or download from GitHub Releases.")
    }

    private fun appendTerminalOutput(text: String) {
        runOnUiThread {
            binding.tvTerminal.append(text + "\n")
            binding.scrollTerminal.post { binding.scrollTerminal.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun showNewFileDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "مثال: app/src/main/java/com/example/NewClass.kt"
            setPadding(48, 24, 48, 24)
            setTextColor(0xFFE6EDF3.toInt())
            setHintTextColor(0xFF484F58.toInt())
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("ملف جديد")
            .setView(input)
            .setPositiveButton("إنشاء") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    val file = File(projectDir, name)
                    file.parentFile?.mkdirs()
                    if (!file.exists()) file.createNewFile()
                    fileTreeAdapter.setRoot(projectDir)
                    openFileInEditor(file)
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_editor, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_save -> {
                binding.webEditor.evaluateJavascript("window.triggerSave();", null); true
            }
            R.id.action_run_build -> { startBuild(); true }
            R.id.action_toggle_terminal -> {
                binding.layoutTerminal.visibility =
                    if (binding.layoutTerminal.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                true
            }
            R.id.action_file_tree -> {
                if (binding.drawerLayout.isDrawerOpen(GravityCompat.START))
                    binding.drawerLayout.closeDrawer(GravityCompat.START)
                else binding.drawerLayout.openDrawer(GravityCompat.START)
                true
            }
            R.id.action_search -> {
                startActivity(Intent(this, SearchActivity::class.java).putExtra("project_path", projectDir.absolutePath)); true
            }
            R.id.action_git -> {
                startActivity(Intent(this, GitActivity::class.java).putExtra("project_path", projectDir.absolutePath)); true
            }
            R.id.action_logcat -> {
                startActivity(Intent(this, LogcatActivity::class.java)); true
            }
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java)); true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun setupBackPressHandler() {
        onBackPressedDispatcher.addCallback(this) {
            if (binding.drawerLayout.isDrawerOpen(GravityCompat.START))
                binding.drawerLayout.closeDrawer(GravityCompat.START)
            else {
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
            }
        }
    }

    override fun onDestroy() {
        terminalSession.destroy()
        super.onDestroy()
    }
}
