package com.androidide.app.utils

import android.content.Context

class SettingsManager(context: Context) {
    private val prefs = context.getSharedPreferences("ide_settings", Context.MODE_PRIVATE)

    val fontSize: Int get() = prefs.getInt("font_size", 14)
    val theme: String get() = prefs.getString("theme", "androidide-dark") ?: "androidide-dark"
    val minimap: Boolean get() = prefs.getBoolean("minimap", true)
    val wordWrap: Boolean get() = prefs.getBoolean("word_wrap", false)
    val ligatures: Boolean get() = prefs.getBoolean("ligatures", true)
    val bracketPair: Boolean get() = prefs.getBoolean("bracket_pair", true)
    val whitespace: Boolean get() = prefs.getBoolean("whitespace", false)
    val autoSave: Boolean get() = prefs.getBoolean("auto_save", false)

    fun setFontSize(v: Int) = prefs.edit().putInt("font_size", v).apply()
    fun setTheme(v: String) = prefs.edit().putString("theme", v).apply()
}
