package com.androidide.app

import android.os.Bundle
import android.view.MenuItem
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import com.androidide.app.databinding.ActivitySettingsBinding
import com.androidide.app.utils.SettingsManager
import com.google.android.material.snackbar.Snackbar

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var settings: SettingsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "الإعدادات"

        settings = SettingsManager(this)
        loadSettings()
        setupControls()
    }

    private fun loadSettings() {
        binding.sbFontSize.progress = settings.fontSize - 10
        binding.tvFontSizeValue.text = "${settings.fontSize}sp"
        binding.switchMinimap.isChecked = settings.minimap
        binding.switchWordWrap.isChecked = settings.wordWrap
        binding.switchLigatures.isChecked = settings.ligatures
        binding.switchAutoSave.isChecked = settings.autoSave
        binding.switchBrackets.isChecked = settings.bracketPair
        binding.switchWhitespace.isChecked = settings.whitespace

        val themeId = when (settings.theme) {
            "androidide-dark" -> R.id.rbThemeDark
            "vs-dark"         -> R.id.rbThemeVsDark
            "vs"              -> R.id.rbThemeVsLight
            "hc-black"        -> R.id.rbThemeHc
            else              -> R.id.rbThemeDark
        }
        binding.radioGroupTheme.check(themeId)
    }

    private fun setupControls() {
        val prefs = getSharedPreferences("ide_settings", MODE_PRIVATE)

        binding.sbFontSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                val size = p + 10
                binding.tvFontSizeValue.text = "${size}sp"
                if (fromUser) prefs.edit().putInt("font_size", size).apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        binding.switchMinimap.setOnCheckedChangeListener   { _, v -> prefs.edit().putBoolean("minimap",      v).apply() }
        binding.switchWordWrap.setOnCheckedChangeListener  { _, v -> prefs.edit().putBoolean("word_wrap",    v).apply() }
        binding.switchLigatures.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean("ligatures",    v).apply() }
        binding.switchAutoSave.setOnCheckedChangeListener  { _, v -> prefs.edit().putBoolean("auto_save",    v).apply() }
        binding.switchBrackets.setOnCheckedChangeListener  { _, v -> prefs.edit().putBoolean("bracket_pair", v).apply() }
        binding.switchWhitespace.setOnCheckedChangeListener{ _, v -> prefs.edit().putBoolean("whitespace",   v).apply() }

        binding.radioGroupTheme.setOnCheckedChangeListener { _, id ->
            val theme = when (id) {
                R.id.rbThemeDark   -> "androidide-dark"
                R.id.rbThemeVsDark -> "vs-dark"
                R.id.rbThemeVsLight-> "vs"
                R.id.rbThemeHc     -> "hc-black"
                else               -> "androidide-dark"
            }
            prefs.edit().putString("theme", theme).apply()
        }

        binding.btnResetSettings.setOnClickListener {
            prefs.edit().clear().apply()
            loadSettings()
            Snackbar.make(binding.root, "تمت إعادة الإعدادات الافتراضية", Snackbar.LENGTH_SHORT).show()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { finish(); return true }
        return super.onOptionsItemSelected(item)
    }
}
