package com.androidide.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.androidide.app.databinding.ItemProjectBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class ProjectsAdapter(
    private val onOpen: (File) -> Unit,
    private val onDelete: (File) -> Unit
) : ListAdapter<File, ProjectsAdapter.VH>(DIFF) {

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<File>() {
            override fun areItemsTheSame(a: File, b: File) = a.absolutePath == b.absolutePath
            override fun areContentsTheSame(a: File, b: File) = a.lastModified() == b.lastModified()
        }
    }

    inner class VH(val binding: ItemProjectBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(project: File) {
            binding.tvName.text = project.name
            val fileCount = project.walkTopDown().filter { it.isFile }.count()
            val lastMod = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
                .format(Date(project.lastModified()))
            binding.tvInfo.text = "$fileCount ملف • آخر تعديل: $lastMod"
            binding.root.setOnClickListener { onOpen(project) }
            binding.btnDelete.setOnClickListener { onDelete(project) }
            val lang = detectLanguage(project)
            binding.tvLang.text = lang
            binding.tvLangBadge.text = lang.take(2).uppercase()
        }

        private fun detectLanguage(dir: File): String {
            return when {
                dir.walkTopDown().any { it.name.endsWith(".kt") } -> "Kotlin"
                dir.walkTopDown().any { it.name.endsWith(".java") } -> "Java"
                else -> "Android"
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemProjectBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) =
        holder.bind(getItem(position))
}
