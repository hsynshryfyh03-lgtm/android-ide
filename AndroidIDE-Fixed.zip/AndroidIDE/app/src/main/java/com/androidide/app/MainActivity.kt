package com.androidide.app

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.androidide.app.databinding.ActivityMainBinding
import com.androidide.app.editor.EditorActivity
import com.androidide.app.utils.ProjectManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var projectManager: ProjectManager
    private lateinit var adapter: ProjectsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        projectManager = ProjectManager(this)
        setupRecyclerView()
        setupFab()
        loadProjects()
    }

    override fun onResume() {
        super.onResume()
        loadProjects()
    }

    private fun setupRecyclerView() {
        adapter = ProjectsAdapter(
            onOpen = { project -> openProject(project) },
            onDelete = { project -> confirmDelete(project) }
        )
        binding.rvProjects.layoutManager = LinearLayoutManager(this)
        binding.rvProjects.adapter = adapter
    }

    private fun setupFab() {
        binding.fabNewProject.setOnClickListener {
            startActivity(Intent(this, NewProjectActivity::class.java))
        }
    }

    private fun loadProjects() {
        val projects = projectManager.getAllProjects()
        if (projects.isEmpty()) {
            binding.rvProjects.visibility = View.GONE
            binding.layoutEmpty.visibility = View.VISIBLE
        } else {
            binding.rvProjects.visibility = View.VISIBLE
            binding.layoutEmpty.visibility = View.GONE
            adapter.submitList(projects)
        }
    }

    private fun openProject(projectDir: File) {
        val intent = Intent(this, EditorActivity::class.java).apply {
            putExtra(EditorActivity.EXTRA_PROJECT_PATH, projectDir.absolutePath)
            putExtra(EditorActivity.EXTRA_PROJECT_NAME, projectDir.name)
        }
        startActivity(intent)
    }

    private fun confirmDelete(project: File) {
        MaterialAlertDialogBuilder(this)
            .setTitle("حذف المشروع")
            .setMessage("هل تريد حذف مشروع \"${project.name}\" نهائياً؟")
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حذف") { _, _ ->
                if (projectManager.deleteProject(project)) {
                    loadProjects()
                    Snackbar.make(binding.root, "تم حذف المشروع", Snackbar.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                Snackbar.make(binding.root, "الإعدادات - قريباً", Snackbar.LENGTH_SHORT).show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
