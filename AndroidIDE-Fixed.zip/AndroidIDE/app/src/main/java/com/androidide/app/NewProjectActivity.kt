package com.androidide.app

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.androidide.app.databinding.ActivityNewProjectBinding
import com.androidide.app.editor.EditorActivity
import com.androidide.app.utils.ProjectManager
import com.androidide.app.utils.ProjectTemplate
import com.google.android.material.snackbar.Snackbar

class NewProjectActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNewProjectBinding
    private lateinit var projectManager: ProjectManager

    private val templates = ProjectTemplate.entries.toTypedArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewProjectBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "مشروع جديد"

        projectManager = ProjectManager(this)
        setupTemplateSpinner()
        setupCreateButton()
    }

    private fun setupTemplateSpinner() {
        val names = templates.map { it.displayName }
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, names)
        binding.spinnerTemplate.setAdapter(adapter)
        binding.spinnerTemplate.setText(names[0], false)
    }

    private fun setupCreateButton() {
        binding.btnCreate.setOnClickListener {
            val name = binding.etProjectName.text?.toString()?.trim() ?: ""
            val pkg = binding.etPackageName.text?.toString()?.trim() ?: ""
            val templateName = binding.spinnerTemplate.text?.toString() ?: ""
            val template = templates.find { it.displayName == templateName } ?: ProjectTemplate.EMPTY_ACTIVITY

            if (name.isEmpty()) {
                binding.tilProjectName.error = "أدخل اسم المشروع"
                return@setOnClickListener
            }
            if (pkg.isEmpty() || !pkg.contains('.')) {
                binding.tilPackageName.error = "مثال: com.example.myapp"
                return@setOnClickListener
            }

            binding.btnCreate.isEnabled = false
            binding.btnCreate.text = "جاري الإنشاء..."

            val safeName = name.replace(Regex("[^A-Za-z0-9_]"), "")
            val project = projectManager.createProject(safeName.ifEmpty { "MyApp" }, pkg, template)

            if (project != null) {
                val intent = Intent(this, EditorActivity::class.java).apply {
                    putExtra(EditorActivity.EXTRA_PROJECT_PATH, project.absolutePath)
                    putExtra(EditorActivity.EXTRA_PROJECT_NAME, project.name)
                }
                startActivity(intent)
                finish()
            } else {
                binding.btnCreate.isEnabled = true
                binding.btnCreate.text = "إنشاء المشروع"
                Snackbar.make(binding.root, "خطأ في إنشاء المشروع", Snackbar.LENGTH_LONG).show()
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { finish(); return true }
        return super.onOptionsItemSelected(item)
    }
}
