package com.androidide.app

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

class GitActivity : AppCompatActivity() {

    private lateinit var tvOutput: TextView
    private lateinit var scrollOutput: ScrollView
    private lateinit var projectDir: File

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_git)

        val path = intent.getStringExtra("project_path") ?: run { finish(); return }
        projectDir = File(path)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Git — ${projectDir.name}"

        tvOutput = findViewById(R.id.tvGitOutput)
        scrollOutput = findViewById(R.id.scrollGitOutput)

        setupButtons()
        runGit("git status") // Show status on open
    }

    private fun setupButtons() {
        findViewById<Chip>(R.id.chipStatus).setOnClickListener { runGit("git status") }
        findViewById<Chip>(R.id.chipLog).setOnClickListener { runGit("git log --oneline -20") }
        findViewById<Chip>(R.id.chipBranches).setOnClickListener { runGit("git branch -a") }
        findViewById<Chip>(R.id.chipDiff).setOnClickListener { runGit("git diff --stat") }

        findViewById<MaterialButton>(R.id.btnGitInit).setOnClickListener { runGit("git init") }

        findViewById<MaterialButton>(R.id.btnGitAddAll).setOnClickListener {
            runGit("git add -A && git status")
        }

        findViewById<MaterialButton>(R.id.btnGitCommit).setOnClickListener {
            showInputDialog("Commit Message", "Initial commit") { msg ->
                runGit("git add -A && git commit -m \"$msg\"")
            }
        }

        findViewById<MaterialButton>(R.id.btnGitPush).setOnClickListener {
            showInputDialog("Remote URL (or leave empty for origin)", "") { remote ->
                val cmd = if (remote.isEmpty()) "git push origin HEAD"
                          else "git remote add origin $remote && git push -u origin main"
                runGit(cmd)
            }
        }

        findViewById<MaterialButton>(R.id.btnGitPull).setOnClickListener {
            runGit("git pull")
        }

        findViewById<MaterialButton>(R.id.btnGitBranch).setOnClickListener {
            showInputDialog("Branch name", "feature/my-feature") { branch ->
                runGit("git checkout -b $branch")
            }
        }

        findViewById<MaterialButton>(R.id.btnGitClone).setOnClickListener {
            showInputDialog("Repository URL", "https://github.com/user/repo.git") { url ->
                val repoName = url.substringAfterLast("/").removeSuffix(".git")
                val targetDir = File(projectDir.parent, repoName)
                runGitInDir(projectDir.parentFile!!, "git clone $url ${targetDir.absolutePath}")
            }
        }

        findViewById<MaterialButton>(R.id.btnGitStash).setOnClickListener {
            runGit("git stash")
        }

        findViewById<MaterialButton>(R.id.btnGitStashPop).setOnClickListener {
            runGit("git stash pop")
        }

        findViewById<MaterialButton>(R.id.btnClearOutput).setOnClickListener {
            tvOutput.text = ""
        }
    }

    private fun runGit(command: String) = runGitInDir(projectDir, command)

    private fun runGitInDir(dir: File, command: String) {
        appendOutput("\n\$ $command\n")
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val pb = ProcessBuilder("sh", "-c", command)
                    .directory(dir)
                    .redirectErrorStream(true)
                val proc = pb.start()
                val reader = BufferedReader(InputStreamReader(proc.inputStream))
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    withContext(Dispatchers.Main) { appendOutput(line!! + "\n") }
                }
                val exit = proc.waitFor()
                withContext(Dispatchers.Main) {
                    appendOutput(if (exit == 0) "\n✓ Done\n" else "\n✗ Exit code: $exit\n")
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { appendOutput("✗ Error: ${e.message}\n") }
            }
        }
    }

    private fun appendOutput(text: String) {
        tvOutput.append(text)
        scrollOutput.post { scrollOutput.fullScroll(View.FOCUS_DOWN) }
    }

    private fun showInputDialog(hint: String, default: String, onConfirm: (String) -> Unit) {
        val input = EditText(this).apply {
            setHint(hint)
            setText(default)
            setPadding(40, 20, 40, 20)
            setTextColor(0xFFE6EDF3.toInt())
            setHintTextColor(0xFF8B949E.toInt())
            setBackgroundColor(0xFF161B22.toInt())
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(hint)
            .setView(input)
            .setPositiveButton("تأكيد") { _, _ -> onConfirm(input.text.toString().trim()) }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { finish(); return true }
        return super.onOptionsItemSelected(item)
    }
}
