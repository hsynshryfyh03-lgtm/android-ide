package com.androidide.app

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import com.google.android.material.chip.Chip
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

class LogcatActivity : AppCompatActivity() {

    private lateinit var tvLogcat: TextView
    private lateinit var scrollLog: ScrollView
    private var logJob: Job? = null
    private var filterTag = ""
    private var filterLevel = "V"
    private val allLogs = StringBuilder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_logcat)

        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Logcat"

        tvLogcat = findViewById(R.id.tvLogcat)
        scrollLog = findViewById(R.id.scrollLogcat)

        setupLevelChips()
        setupSearch()
        setupButtons()
        startLogcat()
    }

    private fun setupLevelChips() {
        val levels = listOf("V" to "Verbose", "D" to "Debug", "I" to "Info", "W" to "Warn", "E" to "Error")
        val chipGroup = findViewById<com.google.android.material.chip.ChipGroup>(R.id.chipGroupLevel)
        levels.forEach { (level, label) ->
            val chip = Chip(this).apply {
                text = label
                isCheckable = true
                isChecked = level == "V"
                setOnCheckedChangeListener { _, checked ->
                    if (checked) { filterLevel = level; applyFilter() }
                }
            }
            chipGroup.addView(chip)
        }
    }

    private fun setupSearch() {
        val searchView = findViewById<SearchView>(R.id.searchViewLogcat)
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean { return false }
            override fun onQueryTextChange(newText: String?): Boolean {
                filterTag = newText?.trim() ?: ""
                applyFilter()
                return true
            }
        })
    }

    private fun setupButtons() {
        findViewById<View>(R.id.btnClearLogcat).setOnClickListener {
            allLogs.clear()
            tvLogcat.text = ""
            try { Runtime.getRuntime().exec("logcat -c") } catch (_: Exception) {}
        }
        findViewById<View>(R.id.btnPauseLogcat).setOnClickListener {
            if (logJob?.isActive == true) {
                logJob?.cancel()
                (it as? com.google.android.material.button.MaterialButton)?.text = "▶ استئناف"
            } else {
                startLogcat()
                (it as? com.google.android.material.button.MaterialButton)?.text = "⏸ إيقاف"
            }
        }
    }

    private fun startLogcat() {
        logJob = lifecycleScope.launch(Dispatchers.IO) {
            try {
                val process = Runtime.getRuntime().exec(arrayOf("logcat", "-v", "time"))
                val reader = BufferedReader(InputStreamReader(process.inputStream))
                var line: String?
                while (isActive && reader.readLine().also { line = it } != null) {
                    val l = line!!
                    allLogs.append(l).append('\n')
                    if (matchesFilter(l)) {
                        withContext(Dispatchers.Main) { appendLog(l) }
                    }
                }
            } catch (_: Exception) {}
        }
    }

    private fun matchesFilter(line: String): Boolean {
        val levelOk = when (filterLevel) {
            "E" -> line.contains(" E/") || line.contains(" E ")
            "W" -> line.contains(" W/") || line.contains(" W ") || line.contains(" E/")
            "I" -> !line.contains(" V/") && !line.contains(" D/")
            "D" -> !line.contains(" V/")
            else -> true
        }
        val tagOk = filterTag.isEmpty() || line.contains(filterTag, ignoreCase = true)
        return levelOk && tagOk
    }

    private fun applyFilter() {
        tvLogcat.text = ""
        allLogs.lines().filter { matchesFilter(it) }.forEach { appendLog(it) }
    }

    private fun appendLog(line: String) {
        val color = when {
            line.contains(" E/") -> 0xFFF85149.toInt()
            line.contains(" W/") -> 0xFFE3B341.toInt()
            line.contains(" I/") -> 0xFF58A6FF.toInt()
            line.contains(" D/") -> 0xFF8B949E.toInt()
            else -> 0xFF6E7681.toInt()
        }
        val span = android.text.SpannableString(line + "\n")
        span.setSpan(android.text.style.ForegroundColorSpan(color), 0, span.length, 0)
        tvLogcat.append(span)
        if (tvLogcat.lineCount > 1000) {
            val text = tvLogcat.text.toString()
            tvLogcat.text = text.substring(text.indexOf('\n', text.length / 2) + 1)
        }
        scrollLog.post { scrollLog.fullScroll(View.FOCUS_DOWN) }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { finish(); return true }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        logJob?.cancel()
        super.onDestroy()
    }
}
