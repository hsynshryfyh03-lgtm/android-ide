package com.androidide.app

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.appcompat.widget.Toolbar
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.androidide.app.databinding.ActivitySearchBinding
import com.androidide.app.editor.EditorActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class SearchResult(
    val file: File,
    val lineNumber: Int,
    val lineContent: String,
    val matchStart: Int,
    val matchEnd: Int
)

class SearchActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySearchBinding
    private lateinit var projectDir: File
    private var searchJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val path = intent.getStringExtra("project_path") ?: run { finish(); return }
        projectDir = File(path)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "بحث في المشروع"

        setupSearchView()
        setupRecyclerView()
    }

    private fun setupSearchView() {
        binding.searchView.isIconifiedByDefault = false
        binding.searchView.queryHint = "ابحث في كل الملفات..."
        binding.searchView.requestFocus()
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean { search(query); return true }
            override fun onQueryTextChange(newText: String?): Boolean {
                if ((newText?.length ?: 0) >= 2) search(newText) else clearResults()
                return true
            }
        })
    }

    private fun setupRecyclerView() {
        binding.rvResults.layoutManager = LinearLayoutManager(this)
    }

    private fun clearResults() {
        binding.rvResults.adapter = null
        binding.tvResultCount.text = ""
        binding.progressSearch.visibility = View.GONE
    }

    private fun search(query: String?) {
        if (query.isNullOrBlank()) { clearResults(); return }
        searchJob?.cancel()
        binding.progressSearch.visibility = View.VISIBLE
        binding.tvResultCount.text = "جاري البحث..."

        searchJob = lifecycleScope.launch(Dispatchers.IO) {
            val results = mutableListOf<SearchResult>()
            val extensions = setOf("kt","kts","java","xml","gradle","json","md","properties","txt","pro")

            projectDir.walkTopDown()
                .filter { it.isFile && it.extension.lowercase() in extensions }
                .forEach { file ->
                    try {
                        file.readLines().forEachIndexed { idx, line ->
                            val lower = line.lowercase()
                            val qLower = query.lowercase()
                            var start = lower.indexOf(qLower)
                            while (start >= 0) {
                                results.add(SearchResult(file, idx + 1, line.trim(), start, start + query.length))
                                start = lower.indexOf(qLower, start + 1)
                            }
                        }
                    } catch (_: Exception) {}
                }

            withContext(Dispatchers.Main) {
                binding.progressSearch.visibility = View.GONE
                if (results.isEmpty()) {
                    binding.tvResultCount.text = "لا توجد نتائج لـ \"$query\""
                    binding.rvResults.adapter = null
                } else {
                    binding.tvResultCount.text = "${results.size} نتيجة في ${results.map { it.file.absolutePath }.distinct().size} ملف"
                    binding.rvResults.adapter = SearchResultsAdapter(results, query) { result ->
                        val intent = Intent(this@SearchActivity, EditorActivity::class.java).apply {
                            putExtra(EditorActivity.EXTRA_PROJECT_PATH, projectDir.absolutePath)
                            putExtra(EditorActivity.EXTRA_PROJECT_NAME, projectDir.name)
                            putExtra("open_file", result.file.absolutePath)
                            putExtra("goto_line", result.lineNumber)
                        }
                        startActivity(intent)
                    }
                }
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { finish(); return true }
        return super.onOptionsItemSelected(item)
    }
}

class SearchResultsAdapter(
    private val results: List<SearchResult>,
    private val query: String,
    private val onClick: (SearchResult) -> Unit
) : RecyclerView.Adapter<SearchResultsAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvFile: TextView = v.findViewById(R.id.tvResultFile)
        val tvLine: TextView = v.findViewById(R.id.tvResultLine)
        val tvContent: TextView = v.findViewById(R.id.tvResultContent)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = android.view.LayoutInflater.from(parent.context)
            .inflate(R.layout.item_search_result, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val r = results[position]
        val relPath = r.file.absolutePath.substringAfterLast("/Projects/").substringAfter("/")
        holder.tvFile.text = relPath
        holder.tvLine.text = "سطر ${r.lineNumber}"
        // Highlight the match
        val content = r.lineContent
        val span = android.text.SpannableString(content)
        val start = content.lowercase().indexOf(query.lowercase())
        if (start >= 0) {
            span.setSpan(android.text.style.BackgroundColorSpan(0x441F6FEB),
                start, minOf(start + query.length, content.length), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            span.setSpan(android.text.style.ForegroundColorSpan(0xFF58A6FF.toInt()),
                start, minOf(start + query.length, content.length), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        holder.tvContent.text = span
        holder.itemView.setOnClickListener { onClick(r) }
    }

    override fun getItemCount() = results.size
}
