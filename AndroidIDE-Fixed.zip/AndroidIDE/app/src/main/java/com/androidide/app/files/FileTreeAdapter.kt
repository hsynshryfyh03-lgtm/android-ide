package com.androidide.app.files

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.androidide.app.R
import com.androidide.app.databinding.ItemFileTreeBinding
import java.io.File

data class FileNode(
    val file: File,
    val depth: Int,
    var isExpanded: Boolean = false
)

class FileTreeAdapter(
    private val onFileClick: (File) -> Unit
) : RecyclerView.Adapter<FileTreeAdapter.VH>() {

    private val nodes = mutableListOf<FileNode>()

    fun setRoot(root: File) {
        nodes.clear()
        root.listFiles()?.sortedWith(compareBy({ it.isFile }, { it.name }))
            ?.forEach { nodes.add(FileNode(it, 0, false)) }
        notifyDataSetChanged()
    }

    inner class VH(val binding: ItemFileTreeBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(node: FileNode) {
            binding.tvName.text = node.file.name
            binding.tvName.setPadding(node.depth * 40 + 16, 0, 16, 0)
            binding.ivIcon.setImageResource(getIcon(node.file, node.isExpanded))

            if (node.file.isDirectory) {
                binding.ivChevron.visibility = View.VISIBLE
                binding.ivChevron.rotation = if (node.isExpanded) 90f else 0f
            } else {
                binding.ivChevron.visibility = View.INVISIBLE
            }

            binding.root.setOnClickListener {
                if (node.file.isDirectory) toggleDir(adapterPosition, node)
                else onFileClick(node.file)
            }
        }
    }

    private fun getIcon(file: File, expanded: Boolean): Int {
        if (file.isDirectory) return if (expanded) R.drawable.ic_folder_open else R.drawable.ic_folder
        return when (file.extension.lowercase()) {
            "kt", "kts" -> R.drawable.ic_kotlin
            "java"       -> R.drawable.ic_java
            "xml"        -> R.drawable.ic_xml
            "gradle"     -> R.drawable.ic_gradle
            "json"       -> R.drawable.ic_json
            "md"         -> R.drawable.ic_markdown
            else         -> R.drawable.ic_file
        }
    }

    private fun toggleDir(pos: Int, node: FileNode) {
        if (node.isExpanded) {
            node.isExpanded = false
            val toRemove = mutableListOf<Int>()
            var i = pos + 1
            while (i < nodes.size && nodes[i].depth > node.depth) {
                toRemove.add(i); i++
            }
            toRemove.reversed().forEach { nodes.removeAt(it); notifyItemRemoved(it) }
            notifyItemChanged(pos)
        } else {
            node.isExpanded = true
            val children = node.file.listFiles()
                ?.sortedWith(compareBy({ it.isFile }, { it.name }))
                ?.map { FileNode(it, node.depth + 1, false) } ?: emptyList()
            nodes.addAll(pos + 1, children)
            notifyItemRangeInserted(pos + 1, children.size)
            notifyItemChanged(pos)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemFileTreeBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(nodes[position])
    override fun getItemCount() = nodes.size
}
