package com.androidide.app.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.content.FileProvider
import java.io.File

object FileUtils {
    fun getLanguage(file: File): String = when (file.extension.lowercase()) {
        "kt", "kts" -> "kotlin"
        "java"       -> "java"
        "xml"        -> "xml"
        "gradle"     -> "groovy"
        "json"       -> "json"
        "md"         -> "markdown"
        "js"         -> "javascript"
        "ts"         -> "typescript"
        "py"         -> "python"
        "html"       -> "html"
        "css"        -> "css"
        "txt", "pro" -> "plaintext"
        "properties" -> "ini"
        else         -> "plaintext"
    }

    fun installApk(context: Context, apk: File) {
        val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apk)
        } else {
            Uri.fromFile(apk)
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        context.startActivity(intent)
    }
}
