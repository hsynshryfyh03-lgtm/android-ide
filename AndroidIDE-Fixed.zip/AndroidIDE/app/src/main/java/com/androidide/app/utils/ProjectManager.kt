package com.androidide.app.utils

import android.content.Context
import java.io.File

enum class ProjectTemplate(val displayName: String) {
    EMPTY_ACTIVITY("Empty Activity"),
    BASIC_VIEWS("Basic Views Activity"),
    LOGIN_SCREEN("Login Screen"),
    RECYCLERVIEW("RecyclerView App"),
    BOTTOM_NAV("Bottom Navigation")
}

class ProjectManager(private val context: Context) {

    private val projectsRoot: File = File(context.getExternalFilesDir(null), "Projects").also { it.mkdirs() }

    fun getAllProjects(): List<File> =
        projectsRoot.listFiles { f -> f.isDirectory }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun deleteProject(project: File): Boolean = project.deleteRecursively()

    fun createProject(name: String, packageName: String, template: ProjectTemplate): File? {
        return try {
            val dir = File(projectsRoot, name).also { it.mkdirs() }
            val pkgPath = packageName.replace('.', '/')
            generateProjectFiles(dir, name, packageName, pkgPath, template)
            dir
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun generateProjectFiles(dir: File, name: String, pkg: String, pkgPath: String, template: ProjectTemplate) {
        // Gradle wrapper
        writeFile(dir, "settings.gradle", """
rootProject.name = "$name"
include ':app'
""".trim())

        writeFile(dir, "build.gradle", """
buildscript {
    repositories { google(); mavenCentral() }
    dependencies {
        classpath 'com.android.tools.build:gradle:8.2.2'
        classpath 'org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.22'
    }
}
""".trim())

        writeFile(dir, "gradle.properties", """
org.gradle.jvmargs=-Xmx2048m
android.useAndroidX=true
kotlin.code.style=official
""".trim())

        writeFile(dir, "app/build.gradle", """
plugins {
    id 'com.android.application'
    id 'kotlin-android'
}

android {
    namespace '$pkg'
    compileSdk 34
    defaultConfig {
        applicationId "$pkg"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0"
    }
    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
    kotlinOptions { jvmTarget = '1.8' }
    buildFeatures { viewBinding true }
}

dependencies {
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
}
""".trim())

        writeFile(dir, "app/src/main/AndroidManifest.xml", """
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application
        android:allowBackup="true"
        android:label="$name"
        android:supportsRtl="true"
        android:theme="@style/Theme.AppCompat.Light.DarkActionBar">
        <activity android:name=".MainActivity" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
    </application>
</manifest>
""".trim())

        val mainActivity = when (template) {
            ProjectTemplate.EMPTY_ACTIVITY -> generateEmptyActivity(pkg)
            ProjectTemplate.BASIC_VIEWS -> generateBasicViewsActivity(pkg)
            ProjectTemplate.LOGIN_SCREEN -> generateLoginActivity(pkg)
            ProjectTemplate.RECYCLERVIEW -> generateRecyclerViewActivity(pkg)
            ProjectTemplate.BOTTOM_NAV -> generateBottomNavActivity(pkg)
        }
        writeFile(dir, "app/src/main/java/$pkgPath/MainActivity.kt", mainActivity)

        val layout = when (template) {
            ProjectTemplate.EMPTY_ACTIVITY -> generateEmptyLayout()
            ProjectTemplate.BASIC_VIEWS -> generateBasicLayout()
            ProjectTemplate.LOGIN_SCREEN -> generateLoginLayout()
            ProjectTemplate.RECYCLERVIEW -> generateRecyclerLayout()
            ProjectTemplate.BOTTOM_NAV -> generateBottomNavLayout()
        }
        writeFile(dir, "app/src/main/res/layout/activity_main.xml", layout)

        writeFile(dir, "app/src/main/res/values/strings.xml", """
<resources>
    <string name="app_name">$name</string>
</resources>
""".trim())

        writeFile(dir, "app/src/main/res/values/themes.xml", """
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.$name" parent="Theme.MaterialComponents.DayNight.DarkActionBar">
        <item name="colorPrimary">@color/purple_500</item>
        <item name="colorPrimaryVariant">@color/purple_700</item>
        <item name="colorOnPrimary">@color/white</item>
    </style>
</resources>
""".trim())

        writeFile(dir, "app/src/main/res/values/colors.xml", """
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="purple_200">#FFBB86FC</color>
    <color name="purple_500">#FF6200EE</color>
    <color name="purple_700">#FF3700B3</color>
    <color name="teal_200">#FF03DAC5</color>
    <color name="white">#FFFFFFFF</color>
    <color name="black">#FF000000</color>
</resources>
""".trim())

        writeFile(dir, "app/proguard-rules.pro", "# Add project specific ProGuard rules here.")
    }

    private fun writeFile(root: File, path: String, content: String) {
        val f = File(root, path)
        f.parentFile?.mkdirs()
        f.writeText(content)
    }

    private fun generateEmptyActivity(pkg: String) = """
package $pkg
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import $pkg.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}""".trim()

    private fun generateBasicViewsActivity(pkg: String) = """
package $pkg
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import $pkg.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnAction.setOnClickListener {
            val text = binding.etInput.text.toString()
            if (text.isNotEmpty()) {
                binding.tvOutput.text = "مرحباً: \$text"
                Toast.makeText(this, "تم!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}""".trim()

    private fun generateLoginActivity(pkg: String) = """
package $pkg
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import $pkg.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnLogin.setOnClickListener {
            val email = binding.etEmail.text.toString()
            val pass  = binding.etPassword.text.toString()
            if (email.isNotEmpty() && pass.length >= 6) {
                Toast.makeText(this, "مرحباً \$email!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "بيانات غير صحيحة", Toast.LENGTH_SHORT).show()
            }
        }
    }
}""".trim()

    private fun generateRecyclerViewActivity(pkg: String) = """
package $pkg
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import $pkg.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val items = (1..20).map { "عنصر رقم \$it" }
        // TODO: Create your RecyclerView Adapter
        binding.rvItems.layoutManager = LinearLayoutManager(this)
    }
}""".trim()

    private fun generateBottomNavActivity(pkg: String) = """
package $pkg
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import $pkg.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.bottomNav.setOnItemSelectedListener { item ->
            // TODO: handle navigation
            true
        }
    }
}""".trim()

    private fun generateEmptyLayout() = """
<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent">
    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_gravity="center"
        android:text="Hello World!"
        android:textSize="24sp"/>
</FrameLayout>""".trim()

    private fun generateBasicLayout() = """
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="24dp"
    android:gravity="center">
    <EditText android:id="@+id/etInput" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:hint="أدخل نصاً" android:inputType="text"/>
    <Button android:id="@+id/btnAction" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:layout_marginTop="12dp" android:text="موافق"/>
    <TextView android:id="@+id/tvOutput" android:layout_width="wrap_content"
        android:layout_height="wrap_content" android:layout_marginTop="16dp"
        android:textSize="18sp" android:text=""/>
</LinearLayout>""".trim()

    private fun generateLoginLayout() = """
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent" android:layout_height="match_parent"
    android:orientation="vertical" android:padding="32dp" android:gravity="center">
    <TextView android:layout_width="wrap_content" android:layout_height="wrap_content"
        android:text="تسجيل الدخول" android:textSize="28sp" android:textStyle="bold"
        android:layout_marginBottom="32dp"/>
    <EditText android:id="@+id/etEmail" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:hint="البريد الإلكتروني"
        android:inputType="textEmailAddress" android:layout_marginBottom="12dp"/>
    <EditText android:id="@+id/etPassword" android:layout_width="match_parent"
        android:layout_height="wrap_content" android:hint="كلمة المرور"
        android:inputType="textPassword" android:layout_marginBottom="24dp"/>
    <Button android:id="@+id/btnLogin" android:layout_width="match_parent"
        android:layout_height="56dp" android:text="دخول" android:textSize="16sp"/>
</LinearLayout>""".trim()

    private fun generateRecyclerLayout() = """
<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent" android:layout_height="match_parent">
    <androidx.recyclerview.widget.RecyclerView android:id="@+id/rvItems"
        android:layout_width="match_parent" android:layout_height="match_parent"/>
</FrameLayout>""".trim()

    private fun generateBottomNavLayout() = """
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent" android:layout_height="match_parent"
    android:orientation="vertical">
    <FrameLayout android:id="@+id/container" android:layout_width="match_parent"
        android:layout_height="0dp" android:layout_weight="1"/>
    <com.google.android.material.bottomnavigation.BottomNavigationView
        android:id="@+id/bottomNav" android:layout_width="match_parent"
        android:layout_height="wrap_content"/>
</LinearLayout>""".trim()
}
