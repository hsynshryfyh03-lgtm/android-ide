package com.androidide.app.terminal

import kotlinx.coroutines.*
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter

class TerminalSession(
    private val workDir: File,
    private val onOutput: (String) -> Unit
) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var process: Process? = null

    fun execute(command: String) {
        scope.launch {
            try {
                val pb = ProcessBuilder("sh", "-c", command)
                    .directory(workDir)
                    .redirectErrorStream(true)

                pb.environment().apply {
                    put("HOME", workDir.absolutePath)
                    put("PATH", "/system/bin:/system/xbin:${System.getenv("PATH") ?: ""}")
                    put("TERM", "xterm-256color")
                }

                process = pb.start()
                val reader = BufferedReader(InputStreamReader(process!!.inputStream))
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    onOutput(line ?: "")
                }
                val exit = process!!.waitFor()
                onOutput(if (exit == 0) "\n✓ Process exited successfully" else "\n✗ Process exited with code $exit")
            } catch (e: Exception) {
                onOutput("✗ Error: ${e.message}")
            }
        }
    }

    fun destroy() {
        process?.destroy()
        scope.cancel()
    }
}
