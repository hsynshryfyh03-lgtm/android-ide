#!/bin/sh
# Run this once to create the debug keystore for local builds
# GitHub Actions uses its own JDK environment
keytool -genkeypair \
  -alias androiddebugkey \
  -keypass android \
  -keystore debug.keystore \
  -storepass android \
  -dname "CN=Android Debug,O=Android,C=US" \
  -validity 10000 \
  -keyalg RSA \
  -keysize 2048
echo "debug.keystore created"
