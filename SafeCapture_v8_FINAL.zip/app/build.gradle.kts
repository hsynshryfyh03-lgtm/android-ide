// app/build.gradle.kts
// ─────────────────────────────────────────────────────────────────────────────
// ملف بناء وحدة التطبيق الرئيسية.
// يحتوي على: إعدادات Android، Compose، KSP لـ Room، Hilt، وكل التبعيات.
// ─────────────────────────────────────────────────────────────────────────────

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt)
}

android {
    namespace   = "com.safecapture.app"
    compileSdk  = 35

    defaultConfig {
        applicationId = "com.safecapture.app"
        minSdk        = 26          // Android 8.0 — الحد الأدنى لـ CameraX Video
        targetSdk     = 35
        versionCode   = 8
        versionName   = "8.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // ── Room: مسار تصدير الـ schema لتتبع المهاجرات ──────────────────────
        ksp {
            arg("room.schemaLocation", "$projectDir/schemas")
            arg("room.incremental",    "true")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled   = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
            // في الإنتاج: استبدل بـ signing config حقيقي
            // signingConfig = signingConfigs.getByName("release")
        }
        debug {
            isMinifyEnabled   = false
            isShrinkResources = false
            applicationIdSuffix = ".debug"
            versionNameSuffix   = "-debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
        // تحذيرات مهمة: اجعل الـ coroutines flow errors واضحة
        freeCompilerArgs += listOf(
            "-opt-in=kotlinx.coroutines.ExperimentalCoroutinesApi",
            "-opt-in=kotlinx.coroutines.FlowPreview",
        )
    }

    buildFeatures {
        compose     = true
        buildConfig = true   // للوصول إلى BuildConfig.VERSION_NAME
    }

    // ── Packaging: تجنب تعارض ملفات META-INF ─────────────────────────────────
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "META-INF/DEPENDENCIES"
        }
    }
}

dependencies {

    // ── AndroidX Core ─────────────────────────────────────────────────────────
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.splashscreen)
    implementation(libs.lifecycle.runtime.ktx)
    implementation(libs.lifecycle.viewmodel.compose)
    implementation(libs.lifecycle.runtime.compose)
    implementation(libs.activity.compose)

    // ── Compose BOM — يضمن توافق كل مكتبات Compose مع بعض ───────────────────
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.compose.ui.tooling.preview)
    implementation(libs.compose.material3)
    implementation(libs.compose.material.icons)

    // ── Navigation ────────────────────────────────────────────────────────────
    implementation(libs.navigation.compose)

    // ── Hilt ─────────────────────────────────────────────────────────────────
    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.hilt.navigation.compose)
    implementation(libs.hilt.work)
    ksp(libs.hilt.compiler.androidx)

    // ── Room ─────────────────────────────────────────────────────────────────
    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    ksp(libs.room.compiler)

    // ── DataStore ────────────────────────────────────────────────────────────
    implementation(libs.datastore.preferences)

    // ── WorkManager ──────────────────────────────────────────────────────────
    implementation(libs.work.runtime.ktx)

    // ── CameraX ──────────────────────────────────────────────────────────────
    implementation(libs.camerax.core)
    implementation(libs.camerax.camera2)
    implementation(libs.camerax.lifecycle)
    implementation(libs.camerax.video)

    // ── ML Kit ───────────────────────────────────────────────────────────────
    implementation(libs.mlkit.face.detection)

    // ── Network ──────────────────────────────────────────────────────────────
    implementation(libs.okhttp)
    implementation(libs.okhttp.logging)

    // ── Coroutines ───────────────────────────────────────────────────────────
    implementation(libs.coroutines.android)

    // ── Debug only ───────────────────────────────────────────────────────────
    debugImplementation(libs.compose.ui.tooling)
}
