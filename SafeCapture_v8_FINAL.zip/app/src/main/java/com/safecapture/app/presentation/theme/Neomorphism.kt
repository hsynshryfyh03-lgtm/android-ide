package com.safecapture.app.presentation.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

fun Modifier.neomorphicShadow(
    shadowRadius   : Dp    = 8.dp,
    offset         : Dp    = 4.dp,
    cornerRadius   : Dp    = 16.dp,
    lightColor     : Color = NeoShadowLight,
    darkColor      : Color = NeoShadowDark,
    backgroundColor: Color = NeoBackground,
): Modifier = this
    .drawBehind {
        drawIntoCanvas { canvas ->

            val paint = Paint().apply {
                asFrameworkPaint().apply {
                    isAntiAlias = true
                    color       = android.graphics.Color.TRANSPARENT

                    // ظل داكن — أسفل/يمين
                    setShadowLayer(
                        shadowRadius.toPx(),
                        offset.toPx(),
                        offset.toPx(),
                        darkColor.copy(alpha = 0.7f).toArgb(),
                    )
                }
            }

            canvas.drawRoundRect(
                left    = 0f,
                top     = 0f,
                right   = size.width,
                bottom  = size.height,
                radiusX = cornerRadius.toPx(),
                radiusY = cornerRadius.toPx(),
                paint   = paint,
            )

            // ظل فاتح — أعلى/يسار
            paint.asFrameworkPaint().setShadowLayer(
                shadowRadius.toPx(),
                -offset.toPx(),
                -offset.toPx(),
                lightColor.copy(alpha = 0.9f).toArgb(),
            )

            canvas.drawRoundRect(
                left    = 0f,
                top     = 0f,
                right   = size.width,
                bottom  = size.height,
                radiusX = cornerRadius.toPx(),
                radiusY = cornerRadius.toPx(),
                paint   = paint,
            )
        }
    }
    .background(
        color = backgroundColor,
        shape = RoundedCornerShape(cornerRadius),
    )
    .clip(RoundedCornerShape(cornerRadius))

@Composable
fun NeoCard(
    modifier    : Modifier = Modifier,
    cornerRadius: Dp       = 16.dp,
    content     : @Composable BoxScope.() -> Unit,
) {
    Box(
        modifier = modifier.neomorphicShadow(cornerRadius = cornerRadius),
        content  = content,
    )
}
