// di/RepositoryModule.kt
// ─────────────────────────────────────────────────────────────────────────────
// وحدة Hilt لربط واجهات Repository بتنفيذاتها الفعلية.
//
// لماذا @Binds وليس @Provides؟
//
//   @Provides:
//     fun provideRepo(impl: RecordingRepositoryImpl): IRecordingRepository = impl
//     → Hilt ينشئ RecordingRepositoryImpl ثم يمررها للدالة ثم يُعيدها.
//     → عمل إضافي بلا فائدة.
//
//   @Binds:
//     abstract fun bindRepo(impl: RecordingRepositoryImpl): IRecordingRepository
//     → Hilt يعرف مباشرةً: "عندما يطلب أحد IRecordingRepository، أعطه
//       RecordingRepositoryImpl" — بدون استدعاء دالة وسيطة.
//     → أكفأ في وقت الترجمة وفي وقت التشغيل.
//
// لماذا abstract class وليس object؟
//   @Binds تتطلب دالة abstract — لا يمكن تعريف abstract function داخل object.
//   abstract class هو الشكل الوحيد المقبول من Hilt لـ @Binds.
// ─────────────────────────────────────────────────────────────────────────────

package com.safecapture.app.di

import com.safecapture.app.data.repository.RecordingRepositoryImpl
import com.safecapture.app.domain.repository.IRecordingRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    /**
     * يربط [IRecordingRepository] بتنفيذه الفعلي [RecordingRepositoryImpl].
     *
     * أي كلاس يطلب حقن [IRecordingRepository] سيحصل على
     * نسخة Singleton من [RecordingRepositoryImpl] تلقائياً.
     *
     * @Singleton هنا ضروري:
     *   بدونه قد يُنشئ Hilt نسخاً متعددة من RecordingRepositoryImpl —
     *   كل نسخة لها cache مستقل → تعارض في البيانات المرئية للـ UI.
     *   مع @Singleton: نسخة واحدة مشتركة بين HomeViewModel وRecordingsViewModel
     *   وRecordingService وBootReceiver.
     *
     * @param impl التنفيذ الفعلي — يُحقن تلقائياً من DatabaseModule عبر RecordingDao.
     * @return واجهة IRecordingRepository — هذا ما يرى المستهلكون.
     */
    @Binds
    @Singleton
    abstract fun bindRecordingRepository(
        impl: RecordingRepositoryImpl,
    ): IRecordingRepository
}
