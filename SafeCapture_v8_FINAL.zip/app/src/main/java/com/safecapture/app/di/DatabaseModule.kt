// di/DatabaseModule.kt
// ─────────────────────────────────────────────────────────────────────────────
// وحدة Hilt لتوفير قاعدة بيانات Room وكل الـ DAOs.
//
// التسلسل الهرمي للحقن:
//   RecordingDatabase  →  RecordingDao  →  RecordingRepositoryImpl
//
// قاعدة: كل ما يتعلق بـ Room فقط يُعرَّف هنا.
// ─────────────────────────────────────────────────────────────────────────────

package com.safecapture.app.di

import android.content.Context
import androidx.room.Room
import com.safecapture.app.data.local.RecordingDatabase
import com.safecapture.app.data.local.dao.RecordingDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    /**
     * يوفّر نسخة Singleton من [RecordingDatabase].
     *
     * fallbackToDestructiveMigration():
     *   في حال وجود تغيير في الهيكل بدون Migration مُعرَّفة،
     *   يحذف قاعدة البيانات القديمة ويُنشئ جديدة.
     *
     *   ⚠️ مقبول فقط أثناء التطوير — قبل الإصدار الأول للمستخدمين،
     *   استبدلها بـ addMigrations(*RecordingDatabase.MIGRATIONS).
     *
     *   عند الجاهزية للإنتاج:
     *   ```kotlin
     *   .addMigrations(*RecordingDatabase.MIGRATIONS)
     *   // احذف سطر fallbackToDestructiveMigration()
     *   ```
     *
     * @param context ApplicationContext — دورة حياته مرتبطة بالتطبيق.
     * @return نسخة واحدة من قاعدة البيانات.
     */
    @Provides
    @Singleton
    fun provideDatabase(
        @ApplicationContext context: Context,
    ): RecordingDatabase = Room.databaseBuilder(
        context,
        RecordingDatabase::class.java,
        RecordingDatabase.DATABASE_NAME,
    )
        .fallbackToDestructiveMigration()
        .build()

    /**
     * يوفّر [RecordingDao] مُستخرَجاً من [RecordingDatabase].
     *
     * لماذا @Provides هنا وليس @Binds؟
     *   RecordingDao هو interface يُنشئه Room تلقائياً — لا يمكن استخدام
     *   @Binds لأنه لا توجد كلاس concrete نُقدّمها.
     *   @Provides يستدعي db.recordingDao() ويُعيد النسخة التي أنشأها Room.
     *
     * لماذا لا يحتاج @Singleton؟
     *   Room يُعيد دائماً نفس نسخة الـ DAO من نفس الـ Database instance —
     *   @Singleton على Database يكفي لضمان ذلك.
     *   لكن إضافة @Singleton هنا لا ضرر منها وتجعل القصد أوضح.
     *
     * @param db نسخة قاعدة البيانات المُحقَنة من [provideDatabase].
     * @return نسخة الـ DAO الجاهزة للحقن.
     */
    @Provides
    @Singleton
    fun provideRecordingDao(
        db: RecordingDatabase,
    ): RecordingDao = db.recordingDao()
}
