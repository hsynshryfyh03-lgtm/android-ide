// domain/model/RecordingStateHolder.kt
// ─────────────────────────────────────────────────────────────────────────────
// جسر الحالة العالمي بين RecordingService والـ ViewModels.
//
// المشكلة التي يحلّها:
//   RecordingService يعمل في خلفية العملية (background).
//   HomeViewModel يعيش في دورة حياة الـ UI.
//   لا يمكن للـ Service أن يُحقن الـ ViewModel مباشرةً (Hilt لا يدعم ذلك).
//
// الحل:
//   Singleton object يحمل StateFlow مشترك.
//   الـ Service يكتب فيه (emit).
//   الـ ViewModel يقرأ منه (collect).
//
// لماذا object وليس @Singleton Hilt؟
//   لأن RecordingService وHomeViewModel في scopes مختلفة.
//   object في Kotlin مضمون أن يكون نسخة واحدة في العملية كلها —
//   وهو بالضبط ما نحتاجه هنا.
//
// لماذا MutableStateFlow وليس LiveData أو BroadcastChannel؟
//   • StateFlow يحتفظ بآخر قيمة (مثل LiveData) — لا تُفقد الحالة.
//   • StateFlow آمن مع coroutines بشكل كامل.
//   • لا يحتاج LifecycleOwner — يعمل داخل Service مباشرةً.
// ─────────────────────────────────────────────────────────────────────────────

package com.safecapture.app.domain.model

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * حامل الحالة العالمي لنظام التسجيل.
 *
 * **الكتابة:** من [com.safecapture.app.service.RecordingService] فقط.
 * **القراءة:** من أي ViewModel أو Composable يحتاج الحالة.
 *
 * مثال الاستخدام في Service:
 * ```kotlin
 * RecordingStateHolder.update(RecordingState.Recording(id, startedAt, path))
 * ```
 *
 * مثال الاستخدام في ViewModel:
 * ```kotlin
 * val state = RecordingStateHolder.state.stateIn(viewModelScope, ...)
 * ```
 */
object RecordingStateHolder {

    // MutableStateFlow خاص — لا يمكن لأحد خارج هذا الـ object تغيير الحالة مباشرةً.
    // القيمة الافتراضية: Idle — التطبيق يبدأ دائماً بلا تسجيل نشط.
    private val _state = MutableStateFlow<RecordingState>(RecordingState.Idle)

    /**
     * Stream الحالة القابل للمراقبة — للقراءة فقط من الخارج.
     * يبثّ آخر حالة فوراً عند الاشتراك (سلوك StateFlow).
     */
    val state: StateFlow<RecordingState> = _state.asStateFlow()

    /**
     * يحدّث الحالة الحالية.
     * يجب استدعاؤه من [com.safecapture.app.service.RecordingService] فقط.
     *
     * آمن للاستدعاء من أي thread — StateFlow thread-safe.
     *
     * @param newState الحالة الجديدة بعد حدث معين (بدء/إيقاف/حفظ).
     */
    fun update(newState: RecordingState) {
        _state.value = newState
    }
}
