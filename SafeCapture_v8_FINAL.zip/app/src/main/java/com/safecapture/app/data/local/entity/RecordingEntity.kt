// data/local/entity/RecordingEntity.kt
// ─────────────────────────────────────────────────────────────────────────────
// كيان قاعدة البيانات (Room Entity) — يمثّل صفاً واحداً في جدول "recordings".
//
// مسؤوليتان فقط:
//   1. تعريف هيكل الجدول لـ Room (annotations).
//   2. التحويل من/إلى نموذج Domain (toDomain / fromDomain).
//
// قاعدة: لا منطق تجاري هنا — فقط بيانات وتحويل.
// ─────────────────────────────────────────────────────────────────────────────

package com.safecapture.app.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.safecapture.app.domain.model.Recording

/**
 * يمثّل صفاً واحداً في جدول [TABLE_NAME] في قاعدة بيانات Room.
 *
 * فهرسة [filePath]:
 *   أُضيف Index على [filePath] لأن [RecordingService] يبحث عن التسجيل
 *   بمساره مباشرةً بعد الحفظ — بدون Index يكون البحث O(n).
 *
 * فهرسة [createdAt]:
 *   كل الاستعلامات تُرتَّب بـ ORDER BY created_at DESC —
 *   الـ Index يجعل الترتيب O(log n) بدلاً من O(n log n).
 */
@Entity(
    tableName = TABLE_NAME,
    indices   = [
        Index(value = ["file_path"],   unique = true),
        Index(value = ["created_at"]),
    ],
)
data class RecordingEntity(

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0L,

    /** اسم الملف للعرض — مثال: "REC_20240315_143022.mp4" */
    @ColumnInfo(name = "file_name")
    val fileName: String,

    /**
     * المسار المطلق للملف — مثال: "/data/user/0/com.safecapture.app/files/REC_...mp4"
     * مفهرَس وفريد: لا يمكن أن يُسجَّل نفس الملف مرتين.
     */
    @ColumnInfo(name = "file_path")
    val filePath: String,

    /** مدة التسجيل بالميلي ثانية. القيمة 0 أثناء التسجيل — تُحدَّث بعد الإيقاف. */
    @ColumnInfo(name = "duration_ms")
    val durationMs: Long = 0L,

    /** حجم الملف بالبايت. القيمة 0 أثناء التسجيل — تُحدَّث بعد الإيقاف. */
    @ColumnInfo(name = "size_bytes")
    val sizeBytes: Long = 0L,

    /**
     * وقت بدء التسجيل — Unix epoch بالميلي ثانية.
     * مفهرَس: يُستخدم في كل استعلامات الترتيب والحذف التلقائي.
     */
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),

    /** true بعد رفع ناجح إلى Telegram. */
    @ColumnInfo(name = "is_uploaded", defaultValue = "0")
    val isUploaded: Boolean = false,

    /** true بينما WorkManager يُعالج طلب الرفع. */
    @ColumnInfo(name = "upload_pending", defaultValue = "0")
    val uploadPending: Boolean = false,
) {

    // ── Mapper: Entity → Domain ───────────────────────────────────────────────

    /**
     * يحوّل هذا الـ Entity إلى نموذج Domain نقي.
     * يُستدعى في [com.safecapture.app.data.repository.RecordingRepositoryImpl]
     * بعد كل استعلام من Room.
     */
    fun toDomain(): Recording = Recording(
        id            = id,
        fileName      = fileName,
        filePath      = filePath,
        durationMs    = durationMs,
        sizeBytes     = sizeBytes,
        createdAt     = createdAt,
        isUploaded    = isUploaded,
        uploadPending = uploadPending,
    )

    // ── Companion: Domain → Entity ────────────────────────────────────────────

    companion object {

        /** اسم الجدول — يُستخدم في الـ @Entity وفي استعلامات @Query. */
        const val TABLE_NAME = "recordings"

        /**
         * يحوّل نموذج Domain إلى Entity لحفظه في Room.
         * يُستدعى في [com.safecapture.app.data.repository.RecordingRepositoryImpl]
         * قبل كل عملية insert أو update.
         *
         * @param domain نموذج Domain المراد تخزينه.
         */
        fun fromDomain(domain: Recording): RecordingEntity = RecordingEntity(
            id            = domain.id,
            fileName      = domain.fileName,
            filePath      = domain.filePath,
            durationMs    = domain.durationMs,
            sizeBytes     = domain.sizeBytes,
            createdAt     = domain.createdAt,
            isUploaded    = domain.isUploaded,
            uploadPending = domain.uploadPending,
        )
    }
}

/** اسم الجدول كـ constant خارجي — لاستخدامه في @Query بدون magic strings. */
const val TABLE_NAME = "recordings"
