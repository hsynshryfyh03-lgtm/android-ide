package com.safecapture.app.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val SafeLightColorScheme = lightColorScheme(
    primary          = AccentPrimary,
    onPrimary        = Color.White,
    primaryContainer = NeoSurface,
    secondary        = AccentSecondary,
    onSecondary      = Color.White,
    tertiary         = AccentSuccess,
    onTertiary       = Color.White,
    error            = AccentRecording,
    onError          = Color.White,
    background       = NeoBackground,
    onBackground     = TextPrimary,
    surface          = NeoSurface,
    onSurface        = TextPrimary,
    surfaceVariant   = NeoSurface,
    onSurfaceVariant = TextSecondary,
    outline          = NeoShadowDark,
    outlineVariant   = NeoShadowLight,
    scrim            = OverlayDark,
)

@Composable
fun SafeCaptureTheme(content: @Composable () -> Unit) {
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as android.app.Activity).window
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars     = true
                isAppearanceLightNavigationBars = true
            }
        }
    }

    MaterialTheme(
        colorScheme = SafeLightColorScheme,
        typography  = SafeCaptureTypography,
        content     = content,
    )
}
