// worker/TelegramUploadWorker.kt
// ─────────────────────────────────────────────────────────────────────────────
// WorkManager CoroutineWorker — يرفع التسجيل إلى Telegram Bot API.
//
// الإصلاحات المطبّقة من تقرير الفحص:
//   1. OkHttpClient الآن Singleton في companion object — لا تسرب موارد.
//   2. response.use { } — يغلق الاتصال تلقائياً حتى عند الاستثناء.
//   3. منطق retry/failure واضح: 4xx = فشل نهائي، 5xx = أعِد المحاولة.
//
// استراتيجية إعادة المحاولة:
//   • WorkManager يُعيد المحاولة تلقائياً عند Result.retry().
//   • BackoffPolicy.EXPONENTIAL: 30s → 60s → 120s → ...
//   • الحد الأقصى للمحاولات: 3 (مُهيَّأ عند الجدولة في RecordingService).
//   • يتطلب شبكة متصلة — WorkManager يُعيد الجدولة تلقائياً عند انقطاع الإنترنت.
//
// حدود Telegram Bot API:
//   • الحجم الأقصى للملف عبر sendVideo: 50 MB.
//   • الملفات الأكبر تحتاج sendDocument أو Telegram Bot API المدفوع.
// ─────────────────────────────────────────────────────────────────────────────

package com.safecapture.app.worker

import android.content.Context
import android.util.Log
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.safecapture.app.data.preferences.AppPreferences
import com.safecapture.app.domain.repository.IRecordingRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.util.concurrent.TimeUnit

@HiltWorker
class TelegramUploadWorker @AssistedInject constructor(
    @Assisted appContext  : Context,
    @Assisted workerParams: WorkerParameters,
    private val repository : IRecordingRepository,
    private val preferences: AppPreferences,
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        private const val TAG = "TelegramUploadWorker"

        /** مفتاح بيانات الإدخال — معرّف التسجيل من Room. */
        const val KEY_RECORDING_ID = "recording_id"

        private const val TELEGRAM_BASE      = "https://api.telegram.org/bot"
        private const val MAX_FILE_SIZE_BYTES = 50L * 1024 * 1024   // 50 MB

        // ── FIX: OkHttpClient Singleton ───────────────────────────────────────
        //
        // المشكلة القديمة:
        //   كان OkHttpClient يُنشأ كـ instance variable داخل الكلاس،
        //   أي نسخة جديدة مع كل Worker instance — thread pool + connection pool
        //   جديدَين في كل مرة = تسرب موارد خطير.
        //
        // الحل:
        //   companion object يضمن إنشاء OkHttpClient مرة واحدة فقط
        //   طوال عمر العملية كلها — كل Workers تشارك نفس الـ client.
        // ─────────────────────────────────────────────────────────────────────
        private val httpClient: OkHttpClient by lazy {
            OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(120, TimeUnit.SECONDS)   // رفع ملفات كبيرة يحتاج وقتاً
                .readTimeout(60,  TimeUnit.SECONDS)
                .build()
        }
    }

    // ── doWork ────────────────────────────────────────────────────────────────

    override suspend fun doWork(): Result {

        // 1. التحقق من صحة بيانات الإدخال
        val recordingId = inputData.getLong(KEY_RECORDING_ID, -1L)
        if (recordingId == -1L) {
            Log.e(TAG, "Invalid recording id — aborting permanently")
            return Result.failure()
        }

        // 2. جلب السجل من قاعدة البيانات
        val recording = repository.getById(recordingId)
        if (recording == null) {
            Log.e(TAG, "Recording $recordingId not found — may have been deleted")
            return Result.failure()
        }

        // 3. تجاوز الرفعات المكتملة مسبقاً (idempotency)
        if (recording.isUploaded) {
            Log.d(TAG, "Recording $recordingId already uploaded — skipping")
            return Result.success()
        }

        // 4. التحقق من إعدادات Telegram
        val botToken = preferences.telegramBotToken.first()
        val chatId   = preferences.telegramChatId.first()

        if (botToken.isBlank() || chatId.isBlank()) {
            Log.w(TAG, "Telegram credentials missing — clearing pending flag")
            repository.setUploadPending(recordingId, false)
            return Result.failure()
        }

        // 5. التحقق من وجود الملف
        val file = File(recording.filePath)
        if (!file.exists()) {
            Log.e(TAG, "File not found: ${recording.filePath}")
            repository.setUploadPending(recordingId, false)
            return Result.failure()
        }

        // 6. التحقق من حجم الملف
        if (file.length() > MAX_FILE_SIZE_BYTES) {
            Log.w(TAG, "File exceeds 50MB Telegram limit (${file.length()} bytes) — skipping")
            repository.setUploadPending(recordingId, false)
            return Result.failure()
        }

        // 7. محاولة الرفع
        return try {
            uploadToTelegram(
                botToken    = botToken,
                chatId      = chatId,
                file        = file,
                recordingId = recordingId,
            )
        } catch (e: Exception) {
            Log.e(TAG, "Upload failed with exception: ${e.message}", e)
            // استثناء في الشبكة أو I/O — أعِد المحاولة
            Result.retry()
        }
    }

    // ── رفع الملف إلى Telegram ────────────────────────────────────────────────

    /**
     * يرفع الملف إلى Telegram باستخدام sendVideo API.
     *
     * استخدام response.use { }:
     *   يضمن إغلاق الاتصال تلقائياً بعد قراءة الـ body —
     *   حتى لو حدث استثناء أثناء القراءة.
     *   هذا يحل مشكلة تسرب الاتصالات في النسخة القديمة.
     */
    private suspend fun uploadToTelegram(
        botToken   : String,
        chatId     : String,
        file       : File,
        recordingId: Long,
    ): Result {

        val url = "$TELEGRAM_BASE$botToken/sendVideo"

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("chat_id", chatId)
            .addFormDataPart(
                "caption",
                "📹 SafeCapture — ${file.nameWithoutExtension}",
            )
            .addFormDataPart(
                "video",
                file.name,
                file.asRequestBody("video/mp4".toMediaTypeOrNull()),
            )
            .build()

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        // ── FIX: response.use { } بدلاً من response مفتوح ───────────────────
        //
        // المشكلة القديمة:
        //   val response = client.newCall(request).execute()
        //   if (response.isSuccessful) { ... }
        //   else { val body = response.body?.string() ... }
        //   → response لم يُغلق قط = تسرب connection pool.
        //
        // الحل:
        //   httpClient.newCall(request).execute().use { response -> ... }
        //   → Kotlin يستدعي response.close() تلقائياً عند نهاية الـ block
        //     حتى عند الاستثناء.
        // ─────────────────────────────────────────────────────────────────────
        return httpClient.newCall(request).execute().use { response ->

            if (response.isSuccessful) {
                Log.d(TAG, "Upload successful for recording $recordingId")
                repository.markUploaded(recordingId)
                Result.success()

            } else {
                // قراءة body للتشخيص — آمنة لأننا داخل use { }
                val errorBody = response.body?.string() ?: "(empty body)"
                Log.e(TAG, "Telegram API error ${response.code}: $errorBody")

                when (response.code) {
                    // ── 4xx: خطأ في الطلب نفسه — لا فائدة من إعادة المحاولة ──
                    // 400 Bad Request  : بيانات غير صحيحة
                    // 401 Unauthorized : رمز Bot خاطئ
                    // 403 Forbidden    : Bot لا يملك صلاحية الإرسال للـ chat
                    // 404 Not Found    : مسار API خاطئ
                    in 400..499 -> {
                        Log.e(TAG, "4xx error — permanent failure, not retrying")
                        repository.setUploadPending(recordingId, false)
                        Result.failure()
                    }

                    // ── 429 Too Many Requests: تجاوز حد المعدل ───────────────
                    // WorkManager سيُعيد المحاولة مع exponential backoff
                    429 -> {
                        Log.w(TAG, "Rate limited by Telegram — will retry")
                        Result.retry()
                    }

                    // ── 5xx: خطأ في خادم Telegram — أعِد المحاولة ────────────
                    in 500..599 -> {
                        Log.w(TAG, "5xx server error — will retry")
                        Result.retry()
                    }

                    // ── غير متوقع ─────────────────────────────────────────────
                    else -> {
                        Log.e(TAG, "Unexpected response code ${response.code}")
                        Result.retry()
                    }
                }
            }
        }
    }
}
