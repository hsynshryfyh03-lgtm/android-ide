package com.safecapture.app.presentation.ui.recordings

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.safecapture.app.domain.model.Recording
import com.safecapture.app.domain.repository.IRecordingRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@HiltViewModel
class RecordingsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: IRecordingRepository,
) : ViewModel() {

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val recordings: StateFlow<List<Recording>> = _query
        .flatMapLatest { q ->
            if (q.isBlank()) repository.observeAll()
            else             repository.search(q)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _pendingDelete = MutableStateFlow<Recording?>(null)
    val pendingDelete: StateFlow<Recording?> = _pendingDelete.asStateFlow()

    private val _showDeleteAll = MutableStateFlow(false)
    val showDeleteAll: StateFlow<Boolean> = _showDeleteAll.asStateFlow()

    fun onQueryChange(q: String) {
        _query.value = q
    }

    fun requestDelete(recording: Recording) { _pendingDelete.value = recording }
    fun cancelDelete()                       { _pendingDelete.value = null     }

    fun confirmDelete() {
        val r = _pendingDelete.value ?: return
        viewModelScope.launch {
            File(r.filePath).takeIf { it.exists() }?.delete()
            repository.deleteById(r.id)
            _pendingDelete.value = null
        }
    }

    fun requestDeleteAll() { _showDeleteAll.value = true  }
    fun cancelDeleteAll()  { _showDeleteAll.value = false }

    fun confirmDeleteAll() {
        viewModelScope.launch {
            // .first() يضمن الحصول على القائمة الحالية الفعلية
            // وليس قيمة stateIn الابتدائية emptyList()
            repository.observeAll().first().forEach { r ->
                File(r.filePath).takeIf { it.exists() }?.delete()
            }
            repository.deleteAll()
            _showDeleteAll.value = false
        }
    }

    fun shareRecording(recording: Recording) {
        val file = File(recording.filePath)
        if (!file.exists()) return

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file,
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        context.startActivity(
            Intent.createChooser(intent, recording.fileName)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
