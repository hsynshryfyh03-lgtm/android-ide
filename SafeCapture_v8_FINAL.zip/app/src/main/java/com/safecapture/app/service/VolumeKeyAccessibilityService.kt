// service/VolumeKeyAccessibilityService.kt
// ─────────────────────────────────────────────────────────────────────────────
// خدمة إمكانية الوصول — تراقب ضغطات زر خفض الصوت وتُشغّل التسجيل
// عند الضغط المزدوج السريع.
//
// لماذا AccessibilityService وليس KeyEvent في Activity؟
//   • KeyEvent في Activity يعمل فقط عندما تكون الشاشة مفتوحة وتطبيقنا في المقدمة.
//   • AccessibilityService يعمل في الخلفية حتى عندما الشاشة مقفلة.
//   • هذا هو السبب الوحيد لاستخدام هذه الخدمة — لا نحتاج أي بيانات إمكانية الوصول.
//
// آلية الضغط المزدوج:
//   الضغطة الأولى  → حفظ الوقت
//   الضغطة الثانية → إذا كان الفارق < doublePressDelayMs → تشغيل التسجيل
//
// ملاحظة أمنية:
//   هذه الخدمة تحتاج موافقة صريحة من المستخدم في إعدادات Android.
//   لا تجمع أي بيانات — فقط تراقب مفتاح الصوت.
// ─────────────────────────────────────────────────────────────────────────────

package com.safecapture.app.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.safecapture.app.data.preferences.AppPreferences
import com.safecapture.app.domain.model.RecordingState
import com.safecapture.app.domain.model.RecordingStateHolder
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class VolumeKeyAccessibilityService : AccessibilityService() {

    // ── Hilt Injections ───────────────────────────────────────────────────────

    @Inject lateinit var preferences: AppPreferences

    // ── Coroutine Scope ───────────────────────────────────────────────────────

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // ── State ─────────────────────────────────────────────────────────────────

    /** وقت آخر ضغطة على زر خفض الصوت — Unix epoch بالميلي ثانية. */
    private var lastVolumeDownTime = 0L

    // ── Companion ─────────────────────────────────────────────────────────────

    companion object {
        private const val TAG = "VolumeKeyA11yService"
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onServiceConnected() {
        super.onServiceConnected()

        // إعداد الخدمة لمراقبة أحداث المفاتيح فقط
        // لا نطلب ACCESS_WINDOW_CONTENT أو غيره — الحد الأدنى من الصلاحيات
        serviceInfo = serviceInfo.apply {
            eventTypes  = AccessibilityEvent.TYPE_VIEW_FOCUSED   // مطلوب كحد أدنى
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags        = AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
        }

        Log.d(TAG, "Accessibility service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // لا نحتاج أي أحداث إمكانية الوصول — الهدف فقط مفاتيح الصوت
    }

    override fun onInterrupt() {
        Log.d(TAG, "Accessibility service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        Log.d(TAG, "Accessibility service destroyed")
    }

    // ── مراقبة أحداث المفاتيح ────────────────────────────────────────────────

    /**
     * يُستدعى لكل ضغطة مفتاح على الجهاز.
     *
     * @return true  → استهلاك الحدث (لا يصل لتطبيق آخر — يمنع خفض الصوت).
     *         false → تمرير الحدث (يعمل كزر صوت طبيعي).
     *
     * القرار:
     *   نُمرّر الحدث دائماً (false) إلا عند الضغط المزدوج المحدد —
     *   هذا يحافظ على وظيفة الصوت الطبيعية.
     */
    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event == null) return false

        // نراقب فقط زر خفض الصوت عند الضغط (ACTION_DOWN)
        // نتجاهل ACTION_UP لتجنب الحسبان المزدوج
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        if (event.action  != KeyEvent.ACTION_DOWN)         return false

        val now = System.currentTimeMillis()

        serviceScope.launch {
            val delayMs = preferences.doublePressDelayMs.first().toLong()

            val timeSinceLast = now - lastVolumeDownTime
            lastVolumeDownTime = now

            if (timeSinceLast in 1..delayMs) {
                // ✅ ضغطة مزدوجة مكتشفة
                handleDoublePress()
            }
            // else: ضغطة أولى أو ضغطة بطيئة جداً — انتظر الثانية
        }

        // false: لا نستهلك الحدث — الصوت يتغير بشكل طبيعي
        // إذا أردت منع تغيير الصوت أثناء التسجيل: أعد true هنا
        return false
    }

    // ── معالجة الضغط المزدوج ─────────────────────────────────────────────────

    /**
     * يُشغّل أو يوقف التسجيل عند الضغط المزدوج.
     * يُرسل اهتزازاً قصيراً كتأكيد للمستخدم (إذا كان مفعّلاً).
     */
    private suspend fun handleDoublePress() {
        val vibrate = preferences.vibrationFeedback.first()

        when (RecordingStateHolder.state.value) {
            is RecordingState.Idle -> {
                Log.d(TAG, "Double press detected — starting recording")
                if (vibrate) vibrate(longArrayOf(0, 50, 50, 50))
                startRecordingService()
            }
            is RecordingState.Recording -> {
                Log.d(TAG, "Double press detected — stopping recording")
                if (vibrate) vibrate(longArrayOf(0, 100))
                stopRecordingService()
            }
            is RecordingState.Saving -> {
                // جارٍ الحفظ — تجاهل الضغط
                Log.d(TAG, "Double press ignored — currently saving")
            }
        }
    }

    // ── تشغيل/إيقاف خدمة التسجيل ─────────────────────────────────────────────

    private fun startRecordingService() {
        try {
            startForegroundService(RecordingService.startIntent(this))
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start RecordingService", e)
        }
    }

    private fun stopRecordingService() {
        try {
            startService(RecordingService.stopIntent(this))
        } catch (e: Exception) {
            Log.e(TAG, "Failed to stop RecordingService", e)
        }
    }

    // ── اهتزاز التأكيد ───────────────────────────────────────────────────────

    /**
     * يُصدر نمط اهتزاز كتأكيد بصري للمستخدم.
     *
     * @param pattern مصفوفة [تأخير، مدة، تأخير، مدة، ...] بالميلي ثانية.
     *
     * أمثلة:
     *   [0, 50, 50, 50] → نبضتان قصيرتان (تأكيد البدء)
     *   [0, 100]        → نبضة واحدة متوسطة (تأكيد الإيقاف)
     */
    @Suppress("DEPRECATION")
    private fun vibrate(pattern: LongArray) {
        try {
            val vibrator = getSystemService(Vibrator::class.java) ?: return
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                val effect = VibrationEffect.createWaveform(pattern, -1)
                vibrator.vibrate(effect)
            } else {
                vibrator.vibrate(pattern, -1)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Vibration failed: ${e.message}")
        }
    }
}
