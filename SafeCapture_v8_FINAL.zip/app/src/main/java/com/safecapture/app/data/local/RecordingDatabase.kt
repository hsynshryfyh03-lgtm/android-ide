// data/local/RecordingDatabase.kt
// ─────────────────────────────────────────────────────────────────────────────
// تعريف قاعدة بيانات Room — نقطة الدخول الوحيدة للـ DAO.
//
// مسؤوليات هذا الملف:
//   1. تعريف الكيانات (entities) المشمولة في قاعدة البيانات.
//   2. تحديد رقم الإصدار (version) للمهاجرات.
//   3. كشف الـ DAO كدالة abstract.
//
// قاعدة: لا منطق هنا — فقط تعريف البنية.
// ─────────────────────────────────────────────────────────────────────────────

package com.safecapture.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.safecapture.app.data.local.dao.RecordingDao
import com.safecapture.app.data.local.entity.RecordingEntity

/**
 * قاعدة بيانات Room الرئيسية للتطبيق.
 *
 * إصدار البيانات:
 *   version = 1 — الإصدار الأول، لا توجد مهاجرات بعد.
 *
 *   عند تغيير هيكل الجدول مستقبلاً (إضافة عمود، تغيير نوع، إلخ):
 *     1. زِد [version] بمقدار 1.
 *     2. أنشئ Migration object في [MIGRATIONS].
 *     3. استبدل [fallbackToDestructiveMigration] بـ addMigrations(*MIGRATIONS).
 *
 * exportSchema = true:
 *   Room يُصدر هيكل قاعدة البيانات إلى app/schemas/
 *   يُستخدم لمراجعة التغييرات في Git وكتابة اختبارات المهاجرات.
 *   مُهيَّأ في app/build.gradle.kts عبر:
 *     ksp { arg("room.schemaLocation", "$projectDir/schemas") }
 */
@Database(
    entities     = [RecordingEntity::class],
    version      = DATABASE_VERSION,
    exportSchema = true,
)
abstract class RecordingDatabase : RoomDatabase() {

    /** الـ DAO الوحيد للوصول إلى جدول التسجيلات. */
    abstract fun recordingDao(): RecordingDao

    companion object {

        /** اسم ملف قاعدة البيانات في تخزين التطبيق. */
        const val DATABASE_NAME = "safecapture.db"

        /**
         * قائمة المهاجرات — تُضاف هنا عند ترقية [DATABASE_VERSION].
         *
         * مثال لمهاجرة مستقبلية (من v1 إلى v2 — إضافة عمود notes):
         * ```kotlin
         * val MIGRATION_1_2 = object : Migration(1, 2) {
         *     override fun migrate(db: SupportSQLiteDatabase) {
         *         db.execSQL("ALTER TABLE recordings ADD COLUMN notes TEXT NOT NULL DEFAULT ''")
         *     }
         * }
         * ```
         */
        val MIGRATIONS: Array<Migration> = emptyArray()
    }
}

/**
 * رقم إصدار قاعدة البيانات — يُستخدم في [@Database] وفي [DatabaseModule].
 *
 * قاعدة: زِد هذا الرقم بمقدار 1 مع كل تغيير في هيكل الجداول،
 * وأضف Migration مقابلاً في [RecordingDatabase.MIGRATIONS].
 */
const val DATABASE_VERSION = 1
