// data/local/dao/RecordingDao.kt
// ─────────────────────────────────────────────────────────────────────────────
// Data Access Object — الطبقة الوحيدة التي تتحدث مع قاعدة البيانات مباشرةً.
//
// قواعد:
//   • كل دالة تفاعلية (مراقبة) تُعيد Flow<T>.
//   • كل دالة أحادية (كتابة/قراءة مرة واحدة) هي suspend.
//   • لا منطق هنا — فقط استعلامات SQL نقية.
//   • الـ mapping من Entity إلى Domain يحدث في Repository، ليس هنا.
// ─────────────────────────────────────────────────────────────────────────────

package com.safecapture.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.safecapture.app.data.local.entity.RecordingEntity
import com.safecapture.app.data.local.entity.TABLE_NAME
import kotlinx.coroutines.flow.Flow

@Dao
interface RecordingDao {

    // ── INSERT ────────────────────────────────────────────────────────────────

    /**
     * يُدرج سجل تسجيل جديد.
     *
     * [OnConflictStrategy.ABORT]: إذا تعارض مع قيد الفرادة (file_path unique)
     * يُلقي استثناءً — هذا مقصود، يكشف الأخطاء البرمجية مبكراً.
     * لا نستخدم REPLACE لأنه يحذف الصف القديم ويُنشئ جديداً (يُغيّر الـ id).
     *
     * @return الـ id المولَّد تلقائياً من Room.
     */
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(entity: RecordingEntity): Long

    // ── UPDATE ────────────────────────────────────────────────────────────────

    /**
     * يُحدّث سجلاً كاملاً — يطابق بالـ id.
     * يُستخدم في حالات التحديث الشامل النادرة.
     */
    @Update
    suspend fun update(entity: RecordingEntity)

    /**
     * يُحدّث المدة والحجم فقط بعد اكتمال التسجيل.
     * أكفأ من [update] — يلمس عمودَين فقط.
     */
    @Query("""
        UPDATE $TABLE_NAME
        SET    duration_ms = :durationMs,
               size_bytes  = :sizeBytes
        WHERE  id = :id
    """)
    suspend fun updateDurationAndSize(id: Long, durationMs: Long, sizeBytes: Long)

    /**
     * يضع علامة "تم الرفع" — عملية ذرية تُغيّر عمودَين معاً.
     * يضبط is_uploaded = 1 و upload_pending = 0 في استعلام واحد.
     */
    @Query("""
        UPDATE $TABLE_NAME
        SET    is_uploaded    = 1,
               upload_pending = 0
        WHERE  id = :id
    """)
    suspend fun markUploaded(id: Long)

    /**
     * يضبط حالة انتظار الرفع.
     *
     * @param pending 1 عند جدولة WorkManager، 0 عند الإلغاء أو الفشل النهائي.
     */
    @Query("""
        UPDATE $TABLE_NAME
        SET    upload_pending = :pending
        WHERE  id = :id
    """)
    suspend fun setUploadPending(id: Long, pending: Boolean)

    // ── SELECT — Reactive (Flow) ──────────────────────────────────────────────

    /**
     * يُصدر كل التسجيلات من الأحدث إلى الأقدم.
     * يُصدر تلقائياً كلما تغيّر الجدول (INSERT / UPDATE / DELETE).
     */
    @Query("""
        SELECT * FROM $TABLE_NAME
        ORDER BY created_at DESC
    """)
    fun observeAll(): Flow<List<RecordingEntity>>

    /**
     * يُصدر التسجيلات التي يتطابق اسمها مع [query] — بحث جزئي غير حساس للحالة.
     *
     * LOWER() على الجانبَين يضمن مطابقة غير حساسة للحروف الإنجليزية.
     * ملاحظة: LOWER() في SQLite لا يدعم الأحرف غير ASCII (عربي، إلخ)
     * لكن أسماء الملفات دائماً ASCII هنا فلا مشكلة.
     */
    @Query("""
        SELECT * FROM $TABLE_NAME
        WHERE  LOWER(file_name) LIKE '%' || LOWER(:query) || '%'
        ORDER BY created_at DESC
    """)
    fun search(query: String): Flow<List<RecordingEntity>>

    /**
     * يُصدر العدد الكلي للتسجيلات.
     * COALESCE غير ضروري هنا لأن COUNT لا يُعيد NULL أبداً،
     * لكنه يوضّح القصد ويمنع الارتباك.
     */
    @Query("SELECT COUNT(*) FROM $TABLE_NAME")
    fun observeCount(): Flow<Int>

    /**
     * يُصدر مجموع كل المدد بالميلي ثانية.
     * COALESCE(..., 0): إذا كان الجدول فارغاً يُعيد SUM قيمة NULL —
     * COALESCE يحوّلها إلى 0 بدلاً من null (يمنع NullPointerException).
     */
    @Query("SELECT COALESCE(SUM(duration_ms), 0) FROM $TABLE_NAME")
    fun observeTotalDuration(): Flow<Long>

    /**
     * يُصدر مجموع كل الأحجام بالبايت.
     * نفس منطق COALESCE كـ [observeTotalDuration].
     */
    @Query("SELECT COALESCE(SUM(size_bytes), 0) FROM $TABLE_NAME")
    fun observeTotalSize(): Flow<Long>

    // ── SELECT — One-shot (suspend) ───────────────────────────────────────────

    /**
     * يُعيد كل التسجيلات غير المرفوعة وغير المجدوَلة للرفع.
     * يُستخدم عند إعادة التشغيل لاستئناف الرفعات الفائتة.
     */
    @Query("""
        SELECT * FROM $TABLE_NAME
        WHERE  is_uploaded    = 0
        AND    upload_pending = 0
    """)
    suspend fun getPendingUploads(): List<RecordingEntity>

    /**
     * يُعيد سجلاً واحداً بمعرّفه.
     *
     * @return الـ Entity إذا وُجد، أو null إذا حُذف.
     */
    @Query("SELECT * FROM $TABLE_NAME WHERE id = :id")
    suspend fun getById(id: Long): RecordingEntity?

    // ── DELETE ────────────────────────────────────────────────────────────────

    /** يحذف سجلاً واحداً بمعرّفه. */
    @Query("DELETE FROM $TABLE_NAME WHERE id = :id")
    suspend fun deleteById(id: Long)

    /** يحذف كل السجلات من الجدول. */
    @Query("DELETE FROM $TABLE_NAME")
    suspend fun deleteAll()

    /**
     * يحذف أقدم التسجيلات ويُبقي فقط آخر [keepCount] منها.
     *
     * منطق الاستعلام:
     *   SELECT id ... ORDER BY created_at DESC LIMIT MAX OFFSET keepCount
     *   → يختار كل السجلات بعد أحدث [keepCount] منها (أي الأقدم).
     *   DELETE WHERE id IN (...)
     *   → يحذفها.
     *
     * استخدام 9999999 بدلاً من -1:
     *   LIMIT -1 يعني "بلا حد" في SQLite القياسي، لكن Room يرفضه
     *   في بعض إصدارات Android — 9999999 آمن وعملي.
     */
    @Query("""
        DELETE FROM $TABLE_NAME
        WHERE id IN (
            SELECT   id
            FROM     $TABLE_NAME
            ORDER BY created_at DESC
            LIMIT    9999999 OFFSET :keepCount
        )
    """)
    suspend fun deleteOldest(keepCount: Int)
}
