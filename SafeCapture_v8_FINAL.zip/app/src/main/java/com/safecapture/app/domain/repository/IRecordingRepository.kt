// domain/repository/IRecordingRepository.kt
// ─────────────────────────────────────────────────────────────────────────────
// عقد Repository في طبقة Domain.
//
// مبدأ Dependency Inversion (حرف D في SOLID):
//   • Domain تعرّف الواجهة (Interface) هنا.
//   • Data تنفّذ الواجهة (RecordingRepositoryImpl) هناك.
//   • ViewModels تعتمد على الواجهة — لا على التنفيذ.
//
// النتيجة:
//   • يمكن استبدال Room بأي قاعدة بيانات أخرى دون تغيير سطر واحد في الـ ViewModels.
//   • يمكن كتابة FakeRepository للاختبار بسهولة تامة.
// ─────────────────────────────────────────────────────────────────────────────

package com.safecapture.app.domain.repository

import com.safecapture.app.domain.model.Recording
import kotlinx.coroutines.flow.Flow

/**
 * عقد الوصول إلى بيانات التسجيلات.
 *
 * التقسيم:
 *  • دوال [Flow] — للمراقبة التفاعلية (تتحدث الواجهة تلقائياً عند تغير البيانات).
 *  • دوال [suspend] — للعمليات الأحادية (إدراج، تحديث، حذف).
 */
interface IRecordingRepository {

    // ── مراقبة تفاعلية (Reactive Observation) ────────────────────────────────

    /**
     * يُصدر قائمة كل التسجيلات مرتّبةً من الأحدث إلى الأقدم.
     * يُصدر تلقائياً كلما تغيرت البيانات في قاعدة البيانات.
     */
    fun observeAll(): Flow<List<Recording>>

    /**
     * يُصدر قائمة التسجيلات التي يتطابق اسم ملفها مع [query].
     * البحث غير حساس لحالة الأحرف (case-insensitive).
     *
     * @param query نص البحث — يبحث عن تطابق جزئي (LIKE '%query%').
     */
    fun search(query: String): Flow<List<Recording>>

    /**
     * يُصدر العدد الكلي للتسجيلات المحفوظة.
     * يُستخدم في بطاقة الإحصائيات في HomeScreen.
     */
    fun observeCount(): Flow<Int>

    /**
     * يُصدر مجموع مدد كل التسجيلات بالميلي ثانية.
     * يُستخدم في بطاقة الإحصائيات في HomeScreen.
     */
    fun observeTotalDuration(): Flow<Long>

    /**
     * يُصدر مجموع أحجام كل التسجيلات بالبايت.
     * يُستخدم في بطاقة الإحصائيات في HomeScreen.
     */
    fun observeTotalSize(): Flow<Long>

    // ── عمليات أحادية (One-shot Operations) ──────────────────────────────────

    /**
     * يُدرج تسجيلاً جديداً في قاعدة البيانات.
     *
     * @param recording نموذج التسجيل — [Recording.id] يجب أن يكون 0 (Room تولّد الـ id).
     * @return الـ id المولَّد تلقائياً — يُستخدم لتحديث السجل لاحقاً.
     */
    suspend fun insert(recording: Recording): Long

    /**
     * يُحدّث سجلاً موجوداً كاملاً.
     * يُستخدم في حالات التحديث الشامل.
     *
     * @param recording يجب أن يحمل [Recording.id] صحيحاً موجوداً في DB.
     */
    suspend fun update(recording: Recording)

    /**
     * يُحدّث حقلَي المدة والحجم فقط بعد اكتمال التسجيل.
     * أكفأ من [update] لأنه يغيّر عمودَين فقط.
     *
     * @param id         معرّف السجل المراد تحديثه.
     * @param durationMs المدة الكاملة للتسجيل بالميلي ثانية.
     * @param sizeBytes  الحجم الكامل للملف بالبايت.
     */
    suspend fun updateDurationAndSize(id: Long, durationMs: Long, sizeBytes: Long)

    /**
     * يضع علامة "تم الرفع" على التسجيل بعد نجاح رفعه إلى Telegram.
     * يضبط [Recording.isUploaded] = true و [Recording.uploadPending] = false معاً.
     *
     * @param id معرّف السجل.
     */
    suspend fun markUploaded(id: Long)

    /**
     * يضبط حالة انتظار الرفع.
     * يُستدعى من WorkManager عند بدء أو إلغاء مهمة الرفع.
     *
     * @param id      معرّف السجل.
     * @param pending true عند جدولة المهمة، false عند إلغائها أو فشلها نهائياً.
     */
    suspend fun setUploadPending(id: Long, pending: Boolean)

    /**
     * يُعيد قائمة التسجيلات غير المرفوعة وغير المجدوَلة.
     * يُستخدم عند إعادة تشغيل التطبيق للعثور على رفعات فائتة.
     */
    suspend fun getPendingUploads(): List<Recording>

    /**
     * يُعيد تسجيلاً واحداً بمعرّفه.
     *
     * @param id معرّف السجل.
     * @return التسجيل إذا وُجد، أو null إذا حُذف.
     */
    suspend fun getById(id: Long): Recording?

    /**
     * يحذف تسجيلاً واحداً من قاعدة البيانات بمعرّفه.
     * ملاحظة: لا يحذف الملف من التخزين — هذا دور الـ ViewModel.
     *
     * @param id معرّف السجل المراد حذفه.
     */
    suspend fun deleteById(id: Long)

    /**
     * يحذف كل التسجيلات من قاعدة البيانات.
     * ملاحظة: لا يحذف الملفات من التخزين — هذا دور الـ ViewModel.
     */
    suspend fun deleteAll()

    /**
     * يحذف أقدم التسجيلات ويُبقي فقط آخر [keepCount] منها.
     * يُستدعى من WorkManager عند تفعيل الحذف التلقائي.
     *
     * @param keepCount عدد أحدث التسجيلات المراد الإبقاء عليها.
     */
    suspend fun deleteOldest(keepCount: Int)
}
