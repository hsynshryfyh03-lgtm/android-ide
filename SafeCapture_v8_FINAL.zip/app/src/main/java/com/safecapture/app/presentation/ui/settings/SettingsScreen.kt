package com.safecapture.app.presentation.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import com.safecapture.app.R
import com.safecapture.app.presentation.theme.AccentPrimary
import com.safecapture.app.presentation.theme.AccentSuccess
import com.safecapture.app.presentation.theme.AccentWarning
import com.safecapture.app.presentation.theme.NeoBackground
import com.safecapture.app.presentation.theme.NeoSurface
import com.safecapture.app.presentation.theme.TextHint
import com.safecapture.app.presentation.theme.TextPrimary
import com.safecapture.app.presentation.theme.TextSecondary
import com.safecapture.app.presentation.theme.neomorphicShadow

@Composable
fun SettingsScreen(vm: SettingsViewModel = hiltViewModel()) {
    val delay       by vm.doublePressDelayMs .collectAsStateWithLifecycle()
    val vibration   by vm.vibrationFeedback  .collectAsStateWithLifecycle()
    val quality     by vm.videoQuality       .collectAsStateWithLifecycle()
    val facing      by vm.cameraFacing       .collectAsStateWithLifecycle()
    val maxDur      by vm.maxDurationMs      .collectAsStateWithLifecycle()
    val timestamp   by vm.timestampOverlay   .collectAsStateWithLifecycle()
    val autoDelete  by vm.autoDeleteEnabled  .collectAsStateWithLifecycle()
    val tgUpload    by vm.telegramAutoUpload .collectAsStateWithLifecycle()
    val tgToken     by vm.telegramBotToken   .collectAsStateWithLifecycle()
    val tgChat      by vm.telegramChatId     .collectAsStateWithLifecycle()
    val disguise    by vm.disguiseModeEnabled.collectAsStateWithLifecycle()
    val a11yEnabled by vm.accessibilityEnabled.collectAsStateWithLifecycle()

    // FIX: يُحدّث حالة زر إمكانية الوصول كلما عاد المستخدم لهذه الشاشة —
    // سواء من إعدادات النظام أو من أي شاشة أخرى.
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    LaunchedEffect(lifecycle) {
        lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            vm.refreshAccessibility()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NeoBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
    ) {
        Spacer(Modifier.height(20.dp))

        Text(
            text       = stringResource(R.string.settings_title),
            style      = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color      = TextPrimary,
        )

        Spacer(Modifier.height(20.dp))

        // ── Trigger ───────────────────────────────────────────────────────────

        SectionHeader(stringResource(R.string.section_trigger))

        SegmentedRow(
            label    = stringResource(R.string.trigger_sensitivity),
            subLabel = stringResource(R.string.trigger_sensitivity_sub),
            options  = listOf("400" to "سريع", "600" to "متوسط", "800" to "بطيء"),
            selected = delay.toString(),
            onSelect = { vm.setDoublePressDelay(it.toInt()) },
        )

        Spacer(Modifier.height(10.dp))

        SettingSwitch(
            label     = stringResource(R.string.vibration_feedback),
            subLabel  = stringResource(R.string.vibration_feedback_sub),
            checked   = vibration,
            onChecked = vm::setVibrationFeedback,
        )

        Spacer(Modifier.height(10.dp))

        SettingRow(
            label    = stringResource(R.string.accessibility_service),
            subLabel = stringResource(R.string.accessibility_service_sub),
        ) {
            Button(
                onClick = { vm.openAccessibilitySettings() },
                colors  = ButtonDefaults.buttonColors(
                    containerColor = if (a11yEnabled) AccentSuccess else AccentPrimary,
                ),
            ) {
                Text(
                    text  = if (a11yEnabled) stringResource(R.string.accessibility_enabled)
                            else             stringResource(R.string.enable_accessibility),
                    style = MaterialTheme.typography.labelLarge,
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        // ── Recording ─────────────────────────────────────────────────────────

        SectionHeader(stringResource(R.string.section_recording))

        SegmentedRow(
            label    = stringResource(R.string.video_quality),
            subLabel = null,
            options  = listOf("480p" to "480p", "720p" to "720p", "1080p" to "1080p"),
            selected = quality,
            onSelect = vm::setVideoQuality,
        )

        Spacer(Modifier.height(10.dp))

        SegmentedRow(
            label    = stringResource(R.string.camera_selector),
            subLabel = null,
            options  = listOf(
                "back"  to stringResource(R.string.camera_back),
                "front" to stringResource(R.string.camera_front),
            ),
            selected = facing,
            onSelect = vm::setCameraFacing,
        )

        Spacer(Modifier.height(10.dp))

        SegmentedRow(
            label    = stringResource(R.string.max_duration),
            subLabel = null,
            options  = listOf(
                (5  * 60_000L).toString() to "5 د",
                (15 * 60_000L).toString() to "15 د",
                (30 * 60_000L).toString() to "30 د",
                (60 * 60_000L).toString() to "60 د",
                "0"                        to "∞",
            ),
            selected = maxDur.toString(),
            onSelect = { vm.setMaxDuration(it.toLong()) },
        )

        Spacer(Modifier.height(10.dp))

        SettingSwitch(
            label     = stringResource(R.string.timestamp_overlay),
            subLabel  = stringResource(R.string.timestamp_overlay_sub),
            checked   = timestamp,
            onChecked = vm::setTimestampOverlay,
        )

        Spacer(Modifier.height(20.dp))

        // ── Storage ───────────────────────────────────────────────────────────

        SectionHeader(stringResource(R.string.section_storage))

        SettingSwitch(
            label     = stringResource(R.string.auto_delete),
            subLabel  = stringResource(R.string.auto_delete_sub),
            checked   = autoDelete,
            onChecked = vm::setAutoDeleteEnabled,
        )

        Spacer(Modifier.height(20.dp))

        // ── Telegram ──────────────────────────────────────────────────────────

        SectionHeader(stringResource(R.string.section_telegram))

        SettingSwitch(
            label     = stringResource(R.string.telegram_auto_upload),
            subLabel  = stringResource(R.string.telegram_auto_upload_sub),
            checked   = tgUpload,
            onChecked = vm::setTelegramAutoUpload,
        )

        if (tgUpload) {
            Spacer(Modifier.height(12.dp))
            TelegramConfigCard(
                token  = tgToken,
                chatId = tgChat,
                onSave = { t, c ->
                    vm.setTelegramBotToken(t)
                    vm.setTelegramChatId(c)
                },
            )
        }

        Spacer(Modifier.height(20.dp))

        // ── Disguise ──────────────────────────────────────────────────────────

        SectionHeader(stringResource(R.string.section_disguise))

        SettingSwitch(
            label     = stringResource(R.string.disguise_mode),
            subLabel  = stringResource(R.string.disguise_mode_sub),
            checked   = disguise,
            onChecked = vm::setDisguiseMode,
        )

        if (disguise) {
            Spacer(Modifier.height(6.dp))
            Text(
                text     = stringResource(R.string.disguise_secret_hint),
                style    = MaterialTheme.typography.labelSmall,
                color    = AccentWarning,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
        }

        Spacer(Modifier.height(20.dp))

        // ── About ─────────────────────────────────────────────────────────────

        SectionHeader(stringResource(R.string.section_about))

        SettingRow(label = stringResource(R.string.version), subLabel = null) {
            Text(
                text  = stringResource(R.string.app_version),
                color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium,
            )
        }

        Spacer(Modifier.height(32.dp))
    }
}

// ── Telegram Config ───────────────────────────────────────────────────────────

@Composable
private fun TelegramConfigCard(
    token : String,
    chatId: String,
    onSave: (String, String) -> Unit,
) {
    var localToken by remember(token)  { mutableStateOf(token)  }
    var localChat  by remember(chatId) { mutableStateOf(chatId) }
    var saved      by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .neomorphicShadow(shadowRadius = 8.dp, offset = 4.dp, cornerRadius = 16.dp)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        TgInputField(
            label    = stringResource(R.string.telegram_token_label),
            value    = localToken,
            onChange = { localToken = it; saved = false },
        )
        TgInputField(
            label    = stringResource(R.string.telegram_chatid_label),
            value    = localChat,
            onChange = { localChat = it; saved = false },
        )
        Text(
            text  = stringResource(R.string.telegram_hint),
            style = MaterialTheme.typography.labelSmall,
            color = TextHint,
        )
        Button(
            onClick  = { onSave(localToken.trim(), localChat.trim()); saved = true },
            modifier = Modifier.align(Alignment.End),
            colors   = ButtonDefaults.buttonColors(containerColor = AccentPrimary),
        ) {
            Text(
                text  = if (saved) stringResource(R.string.telegram_saved)
                        else       stringResource(R.string.telegram_save),
                style = MaterialTheme.typography.labelLarge,
            )
        }
    }
}

@Composable
private fun TgInputField(label: String, value: String, onChange: (String) -> Unit) {
    Column {
        Text(
            text  = label,
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary,
        )
        Spacer(Modifier.height(4.dp))
        BasicTextField(
            value         = value,
            onValueChange = onChange,
            singleLine    = true,
            textStyle     = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
            cursorBrush   = SolidColor(AccentPrimary),
            modifier      = Modifier
                .fillMaxWidth()
                .neomorphicShadow(shadowRadius = 4.dp, offset = 2.dp, cornerRadius = 10.dp)
                .padding(horizontal = 12.dp, vertical = 10.dp),
        )
    }
}

// ── Shared Composables ────────────────────────────────────────────────────────

@Composable
private fun SectionHeader(title: String) {
    Text(
        text       = title,
        style      = MaterialTheme.typography.labelLarge,
        color      = AccentPrimary,
        fontWeight = FontWeight.SemiBold,
        modifier   = Modifier.padding(bottom = 10.dp),
    )
}

@Composable
private fun SettingSwitch(
    label    : String,
    subLabel : String?,
    checked  : Boolean,
    onChecked: (Boolean) -> Unit,
) {
    SettingRow(label = label, subLabel = subLabel) {
        Switch(
            checked         = checked,
            onCheckedChange = onChecked,
            colors          = SwitchDefaults.colors(
                checkedThumbColor = AccentPrimary,
                checkedTrackColor = AccentPrimary.copy(alpha = 0.4f),
            ),
        )
    }
}

@Composable
private fun SettingRow(
    label   : String,
    subLabel: String?,
    trailing: @Composable () -> Unit,
) {
    Row(
        modifier              = Modifier
            .fillMaxWidth()
            .neomorphicShadow(shadowRadius = 6.dp, offset = 3.dp, cornerRadius = 14.dp)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text       = label,
                style      = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium,
                color      = TextPrimary,
            )
            if (subLabel != null) {
                Spacer(Modifier.height(2.dp))
                Text(
                    text  = subLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = TextHint,
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        trailing()
    }
}

@Composable
private fun SegmentedRow(
    label   : String,
    subLabel: String?,
    options : List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .neomorphicShadow(shadowRadius = 6.dp, offset = 3.dp, cornerRadius = 14.dp)
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Text(
            text       = label,
            style      = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Medium,
            color      = TextPrimary,
        )
        if (subLabel != null) {
            Spacer(Modifier.height(2.dp))
            Text(
                text  = subLabel,
                style = MaterialTheme.typography.labelSmall,
                color = TextHint,
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(
            modifier              = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            options.forEach { (key, display) ->
                val isSelected = key == selected
                Button(
                    onClick  = { onSelect(key) },
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp),
                    colors   = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) AccentPrimary else NeoSurface,
                        contentColor   = if (isSelected) Color.White   else TextSecondary,
                    ),
                ) {
                    Text(text = display, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}
