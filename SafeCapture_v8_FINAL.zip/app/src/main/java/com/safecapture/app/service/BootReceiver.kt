// service/BootReceiver.kt
// ─────────────────────────────────────────────────────────────────────────────
// BroadcastReceiver يستقبل حدث إعادة تشغيل الجهاز (BOOT_COMPLETED).
//
// مهمته الوحيدة:
//   إعادة جدولة رفعات Telegram التي كانت معلّقة قبل إعادة التشغيل.
//
// لماذا هذا ضروري؟
//   WorkManager يُعيد جدولة مهامه تلقائياً بعد إعادة التشغيل — لكن فقط
//   المهام التي كانت مجدولة وقت الإيقاف. إذا أُغلق التطبيق بشكل غير نظيف
//   أثناء التسجيل، قد تبقى سجلات في DB بـ upload_pending = true
//   بدون مهمة WorkManager مقابلة.
//   هذا الـ Receiver يُصلح هذه الحالة.
//
// ملاحظة: لا يُشغّل التسجيل تلقائياً — فقط يستأنف الرفعات المعلّقة.
// ─────────────────────────────────────────────────────────────────────────────

package com.safecapture.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.safecapture.app.data.preferences.AppPreferences
import com.safecapture.app.domain.repository.IRecordingRepository
import com.safecapture.app.worker.TelegramUploadWorker
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@AndroidEntryPoint
class BootReceiver : BroadcastReceiver() {

    // ── Hilt Injections ───────────────────────────────────────────────────────

    @Inject lateinit var repository : IRecordingRepository
    @Inject lateinit var preferences: AppPreferences

    // ── Companion ─────────────────────────────────────────────────────────────

    companion object {
        private const val TAG = "BootReceiver"
    }

    // ── onReceive ─────────────────────────────────────────────────────────────

    /**
     * يُستدعى عند استقبال BOOT_COMPLETED أو QUICKBOOT_POWERON.
     *
     * قاعدة BroadcastReceiver: onReceive يعمل على Main thread ولا يجب
     * أن يُنفّذ عمليات طويلة مباشرةً. لذلك نستخدم goAsync() +
     * coroutine scope منفصل لإنهاء العمل بأمان.
     *
     * goAsync():
     *   يُخبر النظام أن الـ Receiver لم ينتهِ بعد رغم عودة onReceive —
     *   يمنح وقتاً إضافياً (10 ثوانٍ) لإنهاء العمل غير المتزامن.
     */
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED &&
            intent.action != "android.intent.action.QUICKBOOT_POWERON") {
            return
        }

        Log.d(TAG, "Boot completed — checking for pending uploads")

        // goAsync() يمنحنا PendingResult لإخبار النظام متى ننتهي
        val pendingResult = goAsync()

        // scope منفصل — لا نستخدم GlobalScope لأنه غير قابل للإلغاء
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        scope.launch {
            try {
                reschedulePendingUploads(context)
            } catch (e: Exception) {
                Log.e(TAG, "Error rescheduling uploads after boot", e)
            } finally {
                // إخبار النظام بانتهاء العمل — مهم جداً لمنع ANR
                pendingResult.finish()
            }
        }
    }

    // ── إعادة جدولة الرفعات المعلّقة ─────────────────────────────────────────

    /**
     * يبحث في قاعدة البيانات عن سجلات غير مرفوعة ويجدول رفعها.
     *
     * الفلتر المستخدم في [IRecordingRepository.getPendingUploads]:
     *   is_uploaded = 0 AND upload_pending = 0
     *
     * لماذا upload_pending = 0 في الفلتر؟
     *   السجلات ذات upload_pending = 1 لديها مهمة WorkManager مجدولة بالفعل —
     *   WorkManager يُعيد جدولتها تلقائياً بعد الـ boot.
     *   السجلات ذات upload_pending = 0 هي التي فقدت مهمتها وتحتاج إعادة جدولة.
     */
    private suspend fun reschedulePendingUploads(context: Context) {
        // التحقق من تفعيل الرفع التلقائي
        val autoUpload = preferences.telegramAutoUpload.first()
        val botToken   = preferences.telegramBotToken.first()
        val chatId     = preferences.telegramChatId.first()

        if (!autoUpload || botToken.isBlank() || chatId.isBlank()) {
            Log.d(TAG, "Telegram auto-upload not configured — skipping")
            return
        }

        val pending = repository.getPendingUploads()

        if (pending.isEmpty()) {
            Log.d(TAG, "No pending uploads found after boot")
            return
        }

        Log.d(TAG, "Found ${pending.size} pending upload(s) — rescheduling")

        val workManager = WorkManager.getInstance(context)

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        pending.forEach { recording ->
            // تأشير السجل كـ pending مجدداً
            repository.setUploadPending(recording.id, true)

            val uploadRequest = OneTimeWorkRequestBuilder<TelegramUploadWorker>()
                .setConstraints(constraints)
                .setInputData(
                    workDataOf(TelegramUploadWorker.KEY_RECORDING_ID to recording.id)
                )
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    30, TimeUnit.SECONDS,
                )
                .addTag("telegram_upload_${recording.id}")
                .build()

            workManager.enqueue(uploadRequest)
            Log.d(TAG, "Rescheduled upload for recording ${recording.id}: ${recording.fileName}")
        }

        Log.d(TAG, "Rescheduled ${pending.size} upload(s) successfully")
    }
}
