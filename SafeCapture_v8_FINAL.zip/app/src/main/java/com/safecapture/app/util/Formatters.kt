package com.safecapture.app.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun Long.toHms(): String {
    val h = this / 3600
    val m = (this % 3600) / 60
    val s = this % 60
    return "%02d:%02d:%02d".format(h, m, s)
}

fun Long.toReadableSize(): String = when {
    this < 1_024L          -> "$this B"
    this < 1_048_576L      -> "${"%.1f".format(this / 1_024.0)} KB"
    this < 1_073_741_824L  -> "${"%.1f".format(this / 1_048_576.0)} MB"
    else                   -> "${"%.1f".format(this / 1_073_741_824.0)} GB"
}

fun Long.toDisplayDate(): String =
    SimpleDateFormat("yyyy-MM-dd  HH:mm", Locale.getDefault()).format(Date(this))
