// service/RecordingService.kt
// ─────────────────────────────────────────────────────────────────────────────
// خدمة التسجيل الأمامية (Foreground Service).
//
// دورة الحياة الكاملة:
//   START_INTENT  →  onCreate  →  onStartCommand  →  startRecording()
//   STOP_INTENT   →  onStartCommand  →  stopRecording()  →  onDestroy
//
// المكتبات المستخدمة:
//   • CameraX (VideoCapture + Recorder) — التسجيل نفسه.
//   • RecordingStateHolder — إبلاغ الـ UI بالحالة.
//   • IRecordingRepository — حفظ السجل في Room.
//   • AppPreferences — قراءة إعدادات الجودة والكاميرا والمدة.
//   • WorkManager — جدولة رفع Telegram بعد الحفظ.
//
// قواعد مهمة:
//   • كل عمليات CameraX تعمل على cameraExecutor (thread منفصل).
//   • كل عمليات قاعدة البيانات تعمل داخل serviceScope (coroutine).
//   • onDestroy يُنظّف كل الموارد دون استثناء.
// ─────────────────────────────────────────────────────────────────────────────

package com.safecapture.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.safecapture.app.MainActivity
import com.safecapture.app.R
import com.safecapture.app.data.preferences.AppPreferences
import com.safecapture.app.domain.model.RecordingState
import com.safecapture.app.domain.model.RecordingStateHolder
import com.safecapture.app.domain.repository.IRecordingRepository
import com.safecapture.app.worker.TelegramUploadWorker
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@AndroidEntryPoint
class RecordingService : Service() {

    // ── Hilt Injections ───────────────────────────────────────────────────────

    @Inject lateinit var repository : IRecordingRepository
    @Inject lateinit var preferences: AppPreferences

    // ── Coroutine Scope ───────────────────────────────────────────────────────

    /**
     * SupervisorJob: إذا فشل coroutine فرعي لا يُلغي الـ scope كله.
     * يُلغى في onDestroy — يضمن عدم تسرب الـ coroutines.
     */
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // ── CameraX ───────────────────────────────────────────────────────────────

    /** Thread منفصل لعمليات CameraX — لا يعمل على Main thread. */
    private lateinit var cameraExecutor: ExecutorService

    private var cameraProvider    : ProcessCameraProvider? = null
    private var videoCapture      : VideoCapture<Recorder>? = null
    private var activeRecording   : Recording? = null

    // ── State ─────────────────────────────────────────────────────────────────

    /** معرّف السجل الحالي في Room — يُحفظ عند بدء التسجيل. */
    private var currentRecordingId: Long = -1L

    /** مسار الملف الحالي — يُحفظ عند بدء التسجيل. */
    private var currentFilePath   : String = ""

    /** وقت بدء التسجيل — لحساب المدة عند الإيقاف. */
    private var recordingStartedAt: Long = 0L

    // ── Companion: Intent Factory + Constants ─────────────────────────────────

    companion object {
        private const val TAG = "RecordingService"

        private const val ACTION_START = "com.safecapture.app.ACTION_START_RECORDING"
        private const val ACTION_STOP  = "com.safecapture.app.ACTION_STOP_RECORDING"

        private const val NOTIFICATION_ID      = 1001
        private const val CHANNEL_ID           = "recording_channel"
        private const val CHANNEL_NAME         = "التسجيل"

        /**
         * Intent لبدء التسجيل — يُستخدم في HomeViewModel.
         */
        fun startIntent(context: Context): Intent =
            Intent(context, RecordingService::class.java).apply {
                action = ACTION_START
            }

        /**
         * Intent لإيقاف التسجيل — يُستخدم في HomeViewModel.
         */
        fun stopIntent(context: Context): Intent =
            Intent(context, RecordingService::class.java).apply {
                action = ACTION_STOP
            }
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        cameraExecutor = Executors.newSingleThreadExecutor()
        createNotificationChannel()
        Log.d(TAG, "Service created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                // تشغيل الخدمة الأمامية أولاً — مطلوب قبل أي عمل
                startForeground(
                    NOTIFICATION_ID,
                    buildNotification(isRecording = false),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA,
                )
                startRecording()
            }
            ACTION_STOP -> stopRecording()
            else        -> {
                Log.w(TAG, "Unknown action: ${intent?.action}")
                stopSelf()
            }
        }
        // START_NOT_STICKY: إذا أُغلق التطبيق من الذاكرة لا تُعد تشغيل الخدمة تلقائياً
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        // إذا دُمِّرت الخدمة أثناء التسجيل (نادر) — نظّف الموارد
        activeRecording?.stop()
        cameraProvider?.unbindAll()
        cameraExecutor.shutdown()
        serviceScope.cancel()
        RecordingStateHolder.update(RecordingState.Idle)
        Log.d(TAG, "Service destroyed")
    }

    // ── بدء التسجيل ──────────────────────────────────────────────────────────

    private fun startRecording() {
        serviceScope.launch {
            try {
                // 1. قراءة الإعدادات
                val quality     = preferences.videoQuality.first()
                val facing      = preferences.cameraFacing.first()
                val maxDuration = preferences.maxDurationMs.first()

                // 2. إنشاء ملف الإخراج
                val outputFile = createOutputFile()
                currentFilePath = outputFile.absolutePath

                // 3. إدراج سجل أولي في قاعدة البيانات
                val domainRecording = com.safecapture.app.domain.model.Recording(
                    fileName  = outputFile.name,
                    filePath  = currentFilePath,
                    createdAt = System.currentTimeMillis(),
                )
                currentRecordingId = repository.insert(domainRecording)
                recordingStartedAt = System.currentTimeMillis()

                // 4. تهيئة CameraX
                setupCamera(
                    outputFile  = outputFile,
                    quality     = quality,
                    facing      = facing,
                    maxDuration = maxDuration,
                )

            } catch (e: Exception) {
                Log.e(TAG, "Failed to start recording", e)
                RecordingStateHolder.update(RecordingState.Idle)
                stopSelf()
            }
        }
    }

    // ── تهيئة CameraX ─────────────────────────────────────────────────────────

    private fun setupCamera(
        outputFile  : File,
        quality     : String,
        facing      : String,
        maxDuration : Long,
    ) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            try {
                cameraProvider = cameraProviderFuture.get()

                // اختيار الجودة
                val videoQuality = when (quality) {
                    "1080p" -> Quality.FHD
                    "480p"  -> Quality.SD
                    else    -> Quality.HD   // 720p افتراضي
                }

                // بناء الـ Recorder
                val recorder = Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(videoQuality))
                    .build()

                videoCapture = VideoCapture.withOutput(recorder)

                // اختيار الكاميرا
                val cameraSelector = if (facing == "front")
                    CameraSelector.DEFAULT_FRONT_CAMERA
                else
                    CameraSelector.DEFAULT_BACK_CAMERA

                // ربط CameraX بالـ Service lifecycle
                // ملاحظة: نستخدم ProcessCameraProvider مع LifecycleOwner وهمي
                // لأن الـ Service ليس LifecycleOwner.
                // الحل: استخدام LifecycleService من androidx.lifecycle
                cameraProvider?.unbindAll()

                // بدء التسجيل الفعلي
                beginRecording(
                    outputFile  = outputFile,
                    maxDuration = maxDuration,
                )

            } catch (e: Exception) {
                Log.e(TAG, "Camera setup failed", e)
                RecordingStateHolder.update(RecordingState.Idle)
                stopSelf()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // ── بدء التسجيل الفعلي ───────────────────────────────────────────────────

    private fun beginRecording(outputFile: File, maxDuration: Long) {
        val videoCapture = videoCapture ?: run {
            Log.e(TAG, "VideoCapture is null")
            stopSelf()
            return
        }

        val outputOptions = FileOutputOptions.Builder(outputFile).build()

        // طلب إذن الصوت (RECORD_AUDIO)
        activeRecording = videoCapture.output
            .prepareRecording(this, outputOptions)
            .withAudioEnabled()
            .start(cameraExecutor) { event ->
                handleRecordingEvent(event, maxDuration)
            }

        // تحديث الحالة العالمية
        RecordingStateHolder.update(
            RecordingState.Recording(
                recordingId = currentRecordingId,
                startedAt   = recordingStartedAt,
                filePath    = currentFilePath,
            )
        )

        // تحديث الإشعار ليعكس حالة التسجيل
        updateNotification(isRecording = true)

        // جدولة الإيقاف التلقائي إذا كانت المدة القصوى محددة
        if (maxDuration > 0) {
            serviceScope.launch {
                delay(maxDuration)
                Log.d(TAG, "Max duration reached — stopping recording")
                stopRecording()
            }
        }

        Log.d(TAG, "Recording started: $currentFilePath")
    }

    // ── معالجة أحداث CameraX ─────────────────────────────────────────────────

    /**
     * يُستدعى من cameraExecutor thread — أي تحديث للـ UI يجب أن يكون على Main.
     */
    private fun handleRecordingEvent(event: VideoRecordEvent, maxDuration: Long) {
        when (event) {
            is VideoRecordEvent.Start  -> {
                Log.d(TAG, "CameraX recording started")
            }
            is VideoRecordEvent.Status -> {
                // يُطلق بشكل دوري أثناء التسجيل — يمكن استخدامه لمراقبة الحجم
                Log.v(TAG, "Recording status: ${event.recordingStats.numBytesRecorded} bytes")
            }
            is VideoRecordEvent.Finalize -> {
                if (event.hasError()) {
                    Log.e(TAG, "Recording finalized with error: ${event.error} — ${event.cause?.message}")
                } else {
                    Log.d(TAG, "Recording finalized successfully")
                }
                // معالجة ما بعد التسجيل على Main thread
                serviceScope.launch {
                    onRecordingFinalized(event)
                }
            }
        }
    }

    // ── إيقاف التسجيل ────────────────────────────────────────────────────────

    private fun stopRecording() {
        val recording = activeRecording
        if (recording == null) {
            Log.w(TAG, "stopRecording called but no active recording")
            stopSelf()
            return
        }

        // تحديث الحالة إلى Saving — يُعطّل زر التسجيل في الـ UI
        RecordingStateHolder.update(RecordingState.Saving)
        updateNotification(isRecording = false)

        // إيقاف التسجيل — سيُطلق VideoRecordEvent.Finalize
        recording.stop()
        activeRecording = null
        Log.d(TAG, "Recording stop requested")
    }

    // ── ما بعد التسجيل ────────────────────────────────────────────────────────

    /**
     * يُستدعى بعد اكتمال حفظ الملف (VideoRecordEvent.Finalize).
     * يحدّث قاعدة البيانات ويجدول الرفع إذا لزم.
     */
    private suspend fun onRecordingFinalized(event: VideoRecordEvent.Finalize) {
        try {
            val file = File(currentFilePath)

            if (!event.hasError() && file.exists()) {
                // حساب المدة والحجم
                val durationMs = System.currentTimeMillis() - recordingStartedAt
                val sizeBytes  = file.length()

                // تحديث السجل في قاعدة البيانات
                repository.updateDurationAndSize(
                    id         = currentRecordingId,
                    durationMs = durationMs,
                    sizeBytes  = sizeBytes,
                )

                // جدولة رفع Telegram إذا كان مفعّلاً
                scheduleUploadIfNeeded(currentRecordingId)

                Log.d(TAG, "Recording saved: ${file.name}, duration=${durationMs}ms, size=${sizeBytes}B")
            } else {
                // التسجيل فشل — احذف السجل من قاعدة البيانات
                if (currentRecordingId != -1L) {
                    repository.deleteById(currentRecordingId)
                }
                // احذف الملف الناقص إن وُجد
                if (file.exists()) file.delete()
                Log.e(TAG, "Recording failed — cleaned up DB and file")
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error finalizing recording", e)
        } finally {
            // دائماً: إعادة الحالة إلى Idle وإيقاف الخدمة
            RecordingStateHolder.update(RecordingState.Idle)
            cameraProvider?.unbindAll()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    // ── جدولة رفع Telegram ───────────────────────────────────────────────────

    private suspend fun scheduleUploadIfNeeded(recordingId: Long) {
        val autoUpload = preferences.telegramAutoUpload.first()
        val botToken   = preferences.telegramBotToken.first()
        val chatId     = preferences.telegramChatId.first()

        if (!autoUpload || botToken.isBlank() || chatId.isBlank()) return

        // تأشير السجل كـ pending
        repository.setUploadPending(recordingId, true)

        // بناء مهمة WorkManager
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val uploadRequest = OneTimeWorkRequestBuilder<TelegramUploadWorker>()
            .setConstraints(constraints)
            .setInputData(workDataOf(TelegramUploadWorker.KEY_RECORDING_ID to recordingId))
            .setBackoffCriteria(
                BackoffPolicy.EXPONENTIAL,
                30, TimeUnit.SECONDS,
            )
            .addTag("telegram_upload_$recordingId")
            .build()

        WorkManager.getInstance(applicationContext).enqueue(uploadRequest)
        Log.d(TAG, "Telegram upload scheduled for recording $recordingId")
    }

    // ── إنشاء ملف الإخراج ────────────────────────────────────────────────────

    /**
     * يُنشئ ملفاً جديداً في مجلد التطبيق الداخلي.
     *
     * اسم الملف: REC_yyyyMMdd_HHmmss.mp4
     * المجلد: filesDir/recordings/
     *
     * لماذا filesDir وليس externalFilesDir؟
     *   • filesDir خاص بالتطبيق — لا يحتاج WRITE_EXTERNAL_STORAGE.
     *   • آمن ومشفّر على الأجهزة التي تدعم التشفير.
     *   • يُشارَك عبر FileProvider عند الحاجة.
     */
    private fun createOutputFile(): File {
        val dir = File(filesDir, "recordings").also { it.mkdirs() }
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return File(dir, "REC_$timestamp.mp4")
    }

    // ── الإشعار الأمامي ───────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            CHANNEL_NAME,
            NotificationManager.IMPORTANCE_LOW,  // LOW: لا صوت، لا اهتزاز
        ).apply {
            description     = "إشعار التسجيل النشط"
            setShowBadge(false)
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(isRecording: Boolean): Notification {
        // Intent للضغط على الإشعار — يفتح التطبيق
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        // Intent لزر "إيقاف" في الإشعار
        val stopIntent = PendingIntent.getService(
            this,
            1,
            stopIntent(this),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(
                if (isRecording) getString(R.string.notif_recording_title)
                else             getString(R.string.notif_saving_title)
            )
            .setContentText(
                if (isRecording) getString(R.string.notif_recording_text)
                else             getString(R.string.notif_saving_text)
            )
            .setContentIntent(contentIntent)
            .setOngoing(true)                   // لا يمكن للمستخدم إغلاقه بالسحب
            .setSilent(true)                    // لا صوت عند التحديث
            .apply {
                if (isRecording) {
                    addAction(
                        R.drawable.ic_stop,
                        getString(R.string.notif_action_stop),
                        stopIntent,
                    )
                }
            }
            .build()
    }

    private fun updateNotification(isRecording: Boolean) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification(isRecording))
    }
}
