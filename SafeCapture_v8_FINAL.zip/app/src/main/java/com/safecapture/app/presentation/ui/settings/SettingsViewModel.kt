package com.safecapture.app.presentation.ui.settings

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.safecapture.app.data.preferences.AppPreferences
import com.safecapture.app.service.VolumeKeyAccessibilityService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val prefs: AppPreferences,
) : ViewModel() {

    // ── StateFlows ────────────────────────────────────────────────────────────

    val doublePressDelayMs  = prefs.doublePressDelayMs .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppPreferences.Defaults.DOUBLE_PRESS_DELAY_MS)
    val vibrationFeedback   = prefs.vibrationFeedback  .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppPreferences.Defaults.VIBRATION_FEEDBACK)
    val videoQuality        = prefs.videoQuality       .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppPreferences.Defaults.VIDEO_QUALITY)
    val cameraFacing        = prefs.cameraFacing       .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppPreferences.Defaults.CAMERA_FACING)
    val maxDurationMs       = prefs.maxDurationMs      .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppPreferences.Defaults.MAX_DURATION_MS)
    val timestampOverlay    = prefs.timestampOverlay   .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppPreferences.Defaults.TIMESTAMP_OVERLAY)
    val autoDeleteEnabled   = prefs.autoDeleteEnabled  .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppPreferences.Defaults.AUTO_DELETE_ENABLED)
    val telegramAutoUpload  = prefs.telegramAutoUpload .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppPreferences.Defaults.TELEGRAM_AUTO_UPLOAD)
    val telegramBotToken    = prefs.telegramBotToken   .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppPreferences.Defaults.TELEGRAM_BOT_TOKEN)
    val telegramChatId      = prefs.telegramChatId     .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppPreferences.Defaults.TELEGRAM_CHAT_ID)
    val disguiseModeEnabled = prefs.disguiseModeEnabled.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppPreferences.Defaults.DISGUISE_MODE_ENABLED)

    // FIX: النسخة القديمة كانت تربط accessibilityEnabled بـ vibrationFeedback —
    // أي لا يتحدث الزر إلا عند تغيير إعداد الاهتزاز.
    //
    // الحل الصحيح: MutableStateFlow يُحدَّث صراحةً عند:
    //   1. بدء تشغيل الـ ViewModel (القيمة الابتدائية).
    //   2. عند استدعاء checkAndUpdateAccessibility() من الـ Screen عند العودة.
    //
    // لماذا لا نستخدم ContentObserver هنا؟
    //   ContentObserver يحتاج LifecycleOwner — الـ ViewModel لا يملكه مباشرةً.
    //   الحل الأبسط والأكثر موثوقية: الـ Screen تستدعي refreshAccessibility()
    //   في LaunchedEffect عند كل recomposition بعد العودة من إعدادات النظام.

    private val _accessibilityEnabled = kotlinx.coroutines.flow.MutableStateFlow(
        checkAccessibilityEnabled()
    )
    val accessibilityEnabled: StateFlow<Boolean> = _accessibilityEnabled

    // ── Setters ───────────────────────────────────────────────────────────────

    fun setDoublePressDelay(ms: Int)       = viewModelScope.launch { prefs.setDoublePressDelayMs(ms) }
    fun setVibrationFeedback(v: Boolean)   = viewModelScope.launch { prefs.setVibrationFeedback(v)  }
    fun setVideoQuality(q: String)         = viewModelScope.launch { prefs.setVideoQuality(q)        }
    fun setCameraFacing(f: String)         = viewModelScope.launch { prefs.setCameraFacing(f)        }
    fun setMaxDuration(ms: Long)           = viewModelScope.launch { prefs.setMaxDurationMs(ms)      }
    fun setTimestampOverlay(v: Boolean)    = viewModelScope.launch { prefs.setTimestampOverlay(v)    }
    fun setAutoDeleteEnabled(v: Boolean)   = viewModelScope.launch { prefs.setAutoDeleteEnabled(v)   }
    fun setTelegramAutoUpload(v: Boolean)  = viewModelScope.launch { prefs.setTelegramAutoUpload(v)  }
    fun setTelegramBotToken(t: String)     = viewModelScope.launch { prefs.setTelegramBotToken(t)    }
    fun setTelegramChatId(c: String)       = viewModelScope.launch { prefs.setTelegramChatId(c)      }

    fun setDisguiseMode(v: Boolean) = viewModelScope.launch {
        prefs.setDisguiseModeEnabled(v)
        toggleDisguiseLauncher(v)
    }

    // ── إمكانية الوصول ────────────────────────────────────────────────────────

    /**
     * تُستدعى من الـ Screen في LaunchedEffect عند كل عودة من إعدادات النظام.
     * تُحدّث حالة الزر بالقيمة الحالية الفعلية من Settings.Secure.
     */
    fun refreshAccessibility() {
        _accessibilityEnabled.value = checkAccessibilityEnabled()
    }

    fun openAccessibilitySettings() {
        context.startActivity(
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    // ── Private Helpers ───────────────────────────────────────────────────────

    private fun checkAccessibilityEnabled(): Boolean {
        val serviceName = ComponentName(
            context,
            VolumeKeyAccessibilityService::class.java,
        ).flattenToString()

        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
        ) ?: return false

        return enabled.split(":").any {
            it.equals(serviceName, ignoreCase = true)
        }
    }

    private fun toggleDisguiseLauncher(enable: Boolean) {
        val component = ComponentName(
            context,
            "com.safecapture.app.presentation.ui.disguise.DisguiseActivity",
        )
        context.packageManager.setComponentEnabledSetting(
            component,
            if (enable) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            else        PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            PackageManager.DONT_KILL_APP,
        )
    }
}
