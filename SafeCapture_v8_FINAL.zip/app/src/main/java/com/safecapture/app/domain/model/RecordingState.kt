// domain/model/RecordingState.kt
// ─────────────────────────────────────────────────────────────────────────────
// آلة الحالة (State Machine) لدورة حياة التسجيل.
//
// الحالات الممكنة وانتقالاتها:
//
//         ┌─────────────────────────────────────────┐
//         │                                         │
//         ▼                                         │
//       Idle  ──── startRecording() ──►  Recording  │
//                                         │         │
//                                   stopRecording() │
//                                         │         │
//                                         ▼         │
//                                       Saving ─────┘
//                                    (onSaveComplete)
//
// قاعدة: لا يوجد انتقال مباشر من Idle إلى Saving، أو من Recording إلى Idle.
// كل انتقال يمر عبر الحالة المتوسطة الصحيحة.
// ─────────────────────────────────────────────────────────────────────────────

package com.safecapture.app.domain.model

/**
 * يمثّل حالة نظام التسجيل في أي لحظة.
 *
 * استخدام sealed class يضمن أن الـ when expression
 * شاملة (exhaustive) وقت الترجمة — لا يمكن نسيان حالة.
 */
sealed class RecordingState {

    /**
     * الحالة الافتراضية — لا يوجد تسجيل نشط.
     * الزر: أحمر (Record).
     */
    data object Idle : RecordingState()

    /**
     * تسجيل نشط حالياً.
     *
     * @param recordingId  معرّف الصف في Room — يُستخدم لتحديث السجل لاحقاً.
     * @param startedAt    وقت بدء التسجيل — Unix epoch بالميلي ثانية.
     *                     يُستخدم لحساب المدة المنقضية في الواجهة.
     * @param filePath     المسار الكامل للملف الذي يُكتب فيه الآن.
     */
    data class Recording(
        val recordingId: Long,
        val startedAt  : Long = System.currentTimeMillis(),
        val filePath   : String,
    ) : RecordingState()

    /**
     * التسجيل توقف وجارٍ الآن حفظ الملف وتحديث قاعدة البيانات.
     * الزر: معطّل (لا يقبل ضغطات).
     *
     * هذه الحالة عابرة — تنتهي بالعودة إلى [Idle] بعد اكتمال الحفظ.
     */
    data object Saving : RecordingState()
}
