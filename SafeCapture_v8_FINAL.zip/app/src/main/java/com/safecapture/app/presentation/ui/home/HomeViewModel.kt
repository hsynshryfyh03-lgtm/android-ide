package com.safecapture.app.presentation.ui.home

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.safecapture.app.domain.model.RecordingState
import com.safecapture.app.domain.model.RecordingStateHolder
import com.safecapture.app.domain.repository.IRecordingRepository
import com.safecapture.app.service.RecordingService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: IRecordingRepository,
) : ViewModel() {

    val recordingState: StateFlow<RecordingState> = RecordingStateHolder.state
        .stateIn(viewModelScope, SharingStarted.Eagerly, RecordingState.Idle)

    // FIX: بدلاً من coroutine دائم يعمل كل ثانية حتى في Idle،
    // نستخدم flatMapLatest — يُنشئ timer فقط عند التسجيل ويُلغيه فوراً عند الإيقاف.
    // في حالة Idle يُصدر 0L فوراً بدون أي delay.
    @OptIn(ExperimentalCoroutinesApi::class)
    val elapsedSeconds: StateFlow<Long> = RecordingStateHolder.state
        .flatMapLatest { state ->
            if (state is RecordingState.Recording) {
                flow {
                    while (true) {
                        emit((System.currentTimeMillis() - state.startedAt) / 1_000L)
                        delay(1_000L)
                    }
                }
            } else {
                flow { emit(0L) }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0L)

    val recordingCount: StateFlow<Int> = repository.observeCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    val totalDurationMs: StateFlow<Long> = repository.observeTotalDuration()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0L)

    val totalSizeBytes: StateFlow<Long> = repository.observeTotalSize()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0L)

    fun toggleRecording() {
        when (recordingState.value) {
            is RecordingState.Idle      -> context.startForegroundService(
                RecordingService.startIntent(context)
            )
            is RecordingState.Recording -> context.startService(
                RecordingService.stopIntent(context)
            )
            is RecordingState.Saving    -> Unit
        }
    }
}
