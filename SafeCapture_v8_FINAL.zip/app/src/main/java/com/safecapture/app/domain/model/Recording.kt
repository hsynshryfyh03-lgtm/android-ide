// domain/model/Recording.kt
// ─────────────────────────────────────────────────────────────────────────────
// نموذج Domain النقي — لا يعرف شيئاً عن Room أو Android أو أي framework.
//
// قاعدة Clean Architecture:
//   • لا @Entity، لا @ColumnInfo، لا أي annotation خارجي هنا
//   • هذا الكلاس هو "لغة المشروع" — كل الطبقات تتحدث بهذا النموذج
//   • الـ mapping من/إلى RecordingEntity يحدث في طبقة Data فقط
// ─────────────────────────────────────────────────────────────────────────────

package com.safecapture.app.domain.model

/**
 * يمثّل تسجيلاً واحداً مكتملاً محفوظاً في قاعدة البيانات.
 *
 * @param id            معرّف فريد تولّده Room تلقائياً (0 = لم يُحفظ بعد).
 * @param fileName      اسم الملف للعرض في الواجهة (مثال: "REC_20240315_143022.mp4").
 * @param filePath      المسار المطلق للملف على جهاز التخزين.
 * @param durationMs    مدة التسجيل بالميلي ثانية (0 أثناء التسجيل، تُحدَّث بعد الإيقاف).
 * @param sizeBytes     حجم الملف بالبايت (0 أثناء التسجيل، تُحدَّث بعد الإيقاف).
 * @param createdAt     وقت بدء التسجيل — Unix epoch بالميلي ثانية.
 * @param isUploaded    صحيح بعد رفع ناجح إلى Telegram.
 * @param uploadPending صحيح بينما WorkManager يعالج طلب الرفع.
 */
data class Recording(
    val id           : Long    = 0L,
    val fileName     : String,
    val filePath     : String,
    val durationMs   : Long    = 0L,
    val sizeBytes    : Long    = 0L,
    val createdAt    : Long    = System.currentTimeMillis(),
    val isUploaded   : Boolean = false,
    val uploadPending: Boolean = false,
)
