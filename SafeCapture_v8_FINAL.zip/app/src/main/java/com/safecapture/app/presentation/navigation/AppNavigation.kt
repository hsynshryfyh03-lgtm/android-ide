package com.safecapture.app.presentation.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.safecapture.app.R
import com.safecapture.app.presentation.theme.AccentPrimary
import com.safecapture.app.presentation.theme.NeoBackground
import com.safecapture.app.presentation.theme.NeoSurface
import com.safecapture.app.presentation.theme.TextHint
import com.safecapture.app.presentation.ui.home.HomeScreen
import com.safecapture.app.presentation.ui.recordings.RecordingsScreen
import com.safecapture.app.presentation.ui.settings.SettingsScreen

sealed class Screen(val route: String) {
    data object Home       : Screen("home")
    data object Recordings : Screen("recordings")
    data object Settings   : Screen("settings")
}

private data class BottomNavItem(
    val screen      : Screen,
    val labelRes    : Int,
    val selectedIcon: ImageVector,
    val defaultIcon : ImageVector,
)

private val bottomNavItems = listOf(
    BottomNavItem(Screen.Home,       R.string.nav_home,       Icons.Filled.Home,       Icons.Outlined.Home),
    BottomNavItem(Screen.Recordings, R.string.nav_recordings, Icons.Filled.PlayCircle, Icons.Outlined.PlayCircle),
    BottomNavItem(Screen.Settings,   R.string.nav_settings,   Icons.Filled.Settings,   Icons.Outlined.Settings),
)

@Composable
fun AppNavigation() {
    val navController        = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination   = navBackStackEntry?.destination

    Scaffold(
        modifier       = Modifier
            .fillMaxSize()
            .background(NeoBackground),
        containerColor = NeoBackground,
        bottomBar = {
            NavigationBar(
                containerColor = NeoSurface,
                // FIX: كانت Dp.Unspecified = Float.NaN — تُفسد حسابات layout
                tonalElevation = 0.dp,
            ) {
                bottomNavItems.forEach { item ->
                    val isSelected = currentDestination
                        ?.hierarchy
                        ?.any { it.route == item.screen.route } == true

                    NavigationBarItem(
                        icon = {
                            Icon(
                                imageVector        = if (isSelected) item.selectedIcon else item.defaultIcon,
                                contentDescription = stringResource(item.labelRes),
                            )
                        },
                        label    = { Text(stringResource(item.labelRes)) },
                        selected = isSelected,
                        colors   = NavigationBarItemDefaults.colors(
                            selectedIconColor   = AccentPrimary,
                            selectedTextColor   = AccentPrimary,
                            unselectedIconColor = TextHint,
                            unselectedTextColor = TextHint,
                            indicatorColor      = NeoBackground,
                        ),
                        onClick = {
                            navController.navigate(item.screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState    = true
                            }
                        },
                    )
                }
            }
        },
    ) { innerPadding ->
        NavHost(
            navController    = navController,
            startDestination = Screen.Home.route,
            modifier         = Modifier.padding(innerPadding),
        ) {
            composable(Screen.Home.route)       { HomeScreen() }
            composable(Screen.Recordings.route) { RecordingsScreen() }
            composable(Screen.Settings.route)   { SettingsScreen() }
        }
    }
}
