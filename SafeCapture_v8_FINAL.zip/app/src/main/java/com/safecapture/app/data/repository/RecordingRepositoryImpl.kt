// data/repository/RecordingRepositoryImpl.kt
// ─────────────────────────────────────────────────────────────────────────────
// التنفيذ الفعلي لـ IRecordingRepository.
//
// مسؤوليته الوحيدة:
//   الوساطة بين طبقة Domain (تتحدث بـ Recording)
//   وطبقة Data (تتحدث بـ RecordingEntity).
//
// كل دالة تفعل شيئاً واحداً فقط:
//   • تحوّل الـ Domain model إلى Entity (عند الكتابة).
//   • تستدعي الـ DAO.
//   • تحوّل النتيجة من Entity إلى Domain model (عند القراءة).
//
// قاعدة: لا منطق تجاري هنا — فقط تحويل وتفويض.
// ─────────────────────────────────────────────────────────────────────────────

package com.safecapture.app.data.repository

import com.safecapture.app.data.local.dao.RecordingDao
import com.safecapture.app.data.local.entity.RecordingEntity
import com.safecapture.app.domain.model.Recording
import com.safecapture.app.domain.repository.IRecordingRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * تنفيذ [IRecordingRepository] باستخدام Room كمصدر البيانات.
 *
 * مُحقَن كـ [@Singleton] — نسخة واحدة فقط في دورة حياة التطبيق كلها،
 * مما يضمن أن كل المستهلكين يرون نفس البيانات.
 *
 * يُربط بالواجهة عبر [@Binds] في [com.safecapture.app.di.RepositoryModule].
 */
@Singleton
class RecordingRepositoryImpl @Inject constructor(
    private val dao: RecordingDao,
) : IRecordingRepository {

    // ── مراقبة تفاعلية ────────────────────────────────────────────────────────

    /**
     * يحوّل Flow<List<RecordingEntity>> إلى Flow<List<Recording>>.
     * .map على الـ Flow يحوّل كل إصدار جديد تلقائياً.
     */
    override fun observeAll(): Flow<List<Recording>> =
        dao.observeAll().map { list -> list.map { it.toDomain() } }

    override fun search(query: String): Flow<List<Recording>> =
        dao.search(query).map { list -> list.map { it.toDomain() } }

    override fun observeCount(): Flow<Int> =
        dao.observeCount()

    override fun observeTotalDuration(): Flow<Long> =
        dao.observeTotalDuration()

    override fun observeTotalSize(): Flow<Long> =
        dao.observeTotalSize()

    // ── عمليات الكتابة ────────────────────────────────────────────────────────

    /**
     * يحوّل [Recording] إلى [RecordingEntity] ثم يُدرجه.
     *
     * @return الـ id المولَّد من Room — يجب حفظه في [RecordingStateHolder]
     *         لتحديث السجل لاحقاً بعد انتهاء التسجيل.
     */
    override suspend fun insert(recording: Recording): Long =
        dao.insert(RecordingEntity.fromDomain(recording))

    /**
     * يحوّل [Recording] إلى [RecordingEntity] ثم يُحدّثه كاملاً.
     * يُستخدم في حالات التحديث الشامل النادرة فقط.
     */
    override suspend fun update(recording: Recording) =
        dao.update(RecordingEntity.fromDomain(recording))

    /**
     * يُحدّث حقلَي المدة والحجم مباشرةً بدون تحويل.
     * الأكفأ لأنه يلمس عمودَين فقط في قاعدة البيانات.
     */
    override suspend fun updateDurationAndSize(id: Long, durationMs: Long, sizeBytes: Long) =
        dao.updateDurationAndSize(id, durationMs, sizeBytes)

    // ── عمليات حالة الرفع ────────────────────────────────────────────────────

    override suspend fun markUploaded(id: Long) =
        dao.markUploaded(id)

    override suspend fun setUploadPending(id: Long, pending: Boolean) =
        dao.setUploadPending(id, pending)

    // ── استعلامات أحادية ─────────────────────────────────────────────────────

    /**
     * يُعيد كل التسجيلات غير المرفوعة وغير المجدوَلة.
     * يحوّل كل Entity إلى Domain model.
     */
    override suspend fun getPendingUploads(): List<Recording> =
        dao.getPendingUploads().map { it.toDomain() }

    /**
     * يُعيد تسجيلاً واحداً بمعرّفه.
     * عامل الـ safe call (?.) يتعامل مع حالة null بأمان:
     *   إذا حُذف السجل يُعيد null بدلاً من رمي استثناء.
     */
    override suspend fun getById(id: Long): Recording? =
        dao.getById(id)?.toDomain()

    // ── عمليات الحذف ─────────────────────────────────────────────────────────

    /**
     * يحذف سجلاً واحداً من قاعدة البيانات.
     * تذكير: حذف الملف من التخزين مسؤولية المستدعي (ViewModel).
     */
    override suspend fun deleteById(id: Long) =
        dao.deleteById(id)

    /**
     * يحذف كل السجلات.
     * تذكير: حذف الملفات من التخزين مسؤولية المستدعي (ViewModel).
     */
    override suspend fun deleteAll() =
        dao.deleteAll()

    /**
     * يحذف أقدم التسجيلات ويُبقي [keepCount] فقط.
     * يُستدعى من WorkManager عند تفعيل الحذف التلقائي.
     */
    override suspend fun deleteOldest(keepCount: Int) =
        dao.deleteOldest(keepCount)
}
