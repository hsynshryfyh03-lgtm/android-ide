package com.safecapture.app.presentation.ui.recordings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.safecapture.app.R
import com.safecapture.app.domain.model.Recording
import com.safecapture.app.presentation.theme.AccentPrimary
import com.safecapture.app.presentation.theme.AccentRecording
import com.safecapture.app.presentation.theme.AccentSuccess
import com.safecapture.app.presentation.theme.NeoBackground
import com.safecapture.app.presentation.theme.NeoSurface
import com.safecapture.app.presentation.theme.TextHint
import com.safecapture.app.presentation.theme.TextPrimary
import com.safecapture.app.presentation.theme.TextSecondary
import com.safecapture.app.presentation.theme.neomorphicShadow
import com.safecapture.app.util.toDisplayDate
import com.safecapture.app.util.toHms
import com.safecapture.app.util.toReadableSize

@Composable
fun RecordingsScreen(vm: RecordingsViewModel = hiltViewModel()) {
    val recordings by vm.recordings   .collectAsStateWithLifecycle()
    val query      by vm.query        .collectAsStateWithLifecycle()
    val pendingDel by vm.pendingDelete.collectAsStateWithLifecycle()
    val showDelAll by vm.showDeleteAll.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NeoBackground)
            .padding(horizontal = 16.dp),
    ) {
        Spacer(Modifier.height(20.dp))

        Row(
            modifier              = Modifier.fillMaxWidth(),
            verticalAlignment     = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text       = stringResource(R.string.nav_recordings),
                style      = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color      = TextPrimary,
            )
            if (recordings.isNotEmpty()) {
                IconButton(onClick = { vm.requestDeleteAll() }) {
                    Icon(
                        imageVector        = Icons.Filled.Delete,
                        contentDescription = stringResource(R.string.delete_all),
                        tint               = AccentRecording,
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        SearchBar(query = query, onQueryChange = vm::onQueryChange)

        Spacer(Modifier.height(16.dp))

        if (recordings.isEmpty()) {
            EmptyState()
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(recordings, key = { it.id }) { recording ->
                    RecordingCard(
                        recording = recording,
                        onShare   = { vm.shareRecording(recording) },
                        onDelete  = { vm.requestDelete(recording)  },
                    )
                }
                item { Spacer(Modifier.height(8.dp)) }
            }
        }
    }

    pendingDel?.let {
        AlertDialog(
            onDismissRequest = vm::cancelDelete,
            title            = { Text(stringResource(R.string.delete_recording)) },
            text             = { Text(stringResource(R.string.delete_confirm))   },
            confirmButton    = {
                TextButton(onClick = vm::confirmDelete) {
                    Text(stringResource(R.string.confirm), color = AccentRecording)
                }
            },
            dismissButton    = {
                TextButton(onClick = vm::cancelDelete) {
                    Text(stringResource(R.string.cancel))
                }
            },
            containerColor = NeoSurface,
        )
    }

    if (showDelAll) {
        AlertDialog(
            onDismissRequest = vm::cancelDeleteAll,
            title            = { Text(stringResource(R.string.delete_all))     },
            text             = { Text(stringResource(R.string.delete_confirm)) },
            confirmButton    = {
                TextButton(onClick = vm::confirmDeleteAll) {
                    Text(stringResource(R.string.confirm), color = AccentRecording)
                }
            },
            dismissButton    = {
                TextButton(onClick = vm::cancelDeleteAll) {
                    Text(stringResource(R.string.cancel))
                }
            },
            containerColor = NeoSurface,
        )
    }
}

@Composable
private fun SearchBar(query: String, onQueryChange: (String) -> Unit) {
    Row(
        modifier          = Modifier
            .fillMaxWidth()
            .neomorphicShadow(shadowRadius = 6.dp, offset = 3.dp, cornerRadius = 14.dp)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector        = Icons.Filled.Search,
            contentDescription = null,
            tint               = TextHint,
            modifier           = Modifier.size(20.dp),
        )
        Spacer(Modifier.width(8.dp))
        BasicTextField(
            value         = query,
            onValueChange = onQueryChange,
            singleLine    = true,
            textStyle     = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
            cursorBrush   = SolidColor(AccentPrimary),
            modifier      = Modifier.weight(1f),
            decorationBox = { inner ->
                if (query.isEmpty()) {
                    Text(
                        text  = stringResource(R.string.search_hint),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextHint,
                    )
                }
                inner()
            },
        )
    }
}

@Composable
private fun RecordingCard(
    recording: Recording,
    onShare  : () -> Unit,
    onDelete : () -> Unit,
) {
    Row(
        modifier          = Modifier
            .fillMaxWidth()
            .neomorphicShadow(shadowRadius = 8.dp, offset = 4.dp, cornerRadius = 16.dp)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier         = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(AccentPrimary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector        = Icons.Filled.VideoFile,
                contentDescription = null,
                tint               = AccentPrimary,
                modifier           = Modifier.size(26.dp),
            )
        }

        Spacer(Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text       = recording.fileName,
                style      = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color      = TextPrimary,
                maxLines   = 1,
            )
            Spacer(Modifier.height(2.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    text  = (recording.durationMs / 1000L).toHms(),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                )
                Text("·", style = MaterialTheme.typography.labelSmall, color = TextHint)
                Text(
                    text  = recording.sizeBytes.toReadableSize(),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                )
                if (recording.isUploaded) {
                    Text("·", style = MaterialTheme.typography.labelSmall, color = TextHint)
                    Text(
                        text  = "✓ TG",
                        style = MaterialTheme.typography.labelSmall,
                        color = AccentSuccess,
                    )
                } else if (recording.uploadPending) {
                    Text("·", style = MaterialTheme.typography.labelSmall, color = TextHint)
                    Text(
                        text  = "↑",
                        style = MaterialTheme.typography.labelSmall,
                        color = AccentPrimary,
                    )
                }
            }
            Spacer(Modifier.height(2.dp))
            Text(
                text  = recording.createdAt.toDisplayDate(),
                style = MaterialTheme.typography.labelSmall,
                color = TextHint,
            )
        }

        IconButton(onClick = onShare) {
            Icon(
                imageVector        = Icons.Filled.Share,
                contentDescription = stringResource(R.string.share_recording),
                tint               = AccentPrimary,
                modifier           = Modifier.size(20.dp),
            )
        }
        IconButton(onClick = onDelete) {
            Icon(
                imageVector        = Icons.Filled.Delete,
                contentDescription = stringResource(R.string.delete_recording),
                tint               = AccentRecording,
                modifier           = Modifier.size(20.dp),
            )
        }
    }
}

@Composable
private fun EmptyState() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector        = Icons.Filled.VideoFile,
                contentDescription = null,
                tint               = TextHint,
                modifier           = Modifier.size(64.dp),
            )
            Spacer(Modifier.height(16.dp))
            Text(
                text  = stringResource(R.string.no_recordings),
                style = MaterialTheme.typography.titleMedium,
                color = TextSecondary,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text  = stringResource(R.string.no_recordings_sub),
                style = MaterialTheme.typography.bodyMedium,
                color = TextHint,
            )
        }
    }
}
