// di/AppModule.kt
// ─────────────────────────────────────────────────────────────────────────────
// وحدة Hilt للتبعيات على مستوى التطبيق كاملاً (SingletonComponent).
//
// مسؤوليته:
//   توفير DataStore<Preferences> كـ Singleton للحقن في AppPreferences.
//
// لماذا DataStore هنا وليس في DatabaseModule؟
//   • DatabaseModule مخصص لـ Room فقط — فصل المسؤوليات.
//   • AppModule يحتوي التبعيات العامة غير المصنّفة.
//
// تعريف preferencesDataStore:
//   extension property على Context — يضمن إنشاء DataStore مرة واحدة فقط
//   بفضل آلية delegation في Kotlin (by preferencesDataStore).
//   إذا استُدعيت context.dataStore مرتين، تُعاد نفس النسخة.
// ─────────────────────────────────────────────────────────────────────────────

package com.safecapture.app.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

// ── DataStore Extension Property ──────────────────────────────────────────────
//
// تعريف خارج الكلاس مقصود:
//   • preferencesDataStore delegate يعمل على مستوى الملف — ليس داخل كلاس.
//   • "safecapture_prefs" هو اسم ملف التفضيلات على القرص.
//   • private: لا يُستخدم مباشرةً خارج هذا الملف — فقط عبر provideDataStore.
// ─────────────────────────────────────────────────────────────────────────────
private val Context.dataStore: DataStore<Preferences>
    by preferencesDataStore(name = "safecapture_prefs")

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    /**
     * يوفّر DataStore<Preferences> كـ Singleton على مستوى التطبيق.
     *
     * @param context ApplicationContext — دورة حياته مرتبطة بالتطبيق كله،
     *                لا بـ Activity أو Fragment — آمن للاستخدام مع Singleton.
     *
     * @return نسخة واحدة من DataStore<Preferences> تُحقن في AppPreferences.
     */
    @Provides
    @Singleton
    fun provideDataStore(
        @ApplicationContext context: Context,
    ): DataStore<Preferences> = context.dataStore
}
