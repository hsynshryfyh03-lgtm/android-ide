# proguard-rules.pro
# ─────────────────────────────────────────────────────────────────────────────
# قواعد R8/ProGuard لحماية كود الإنتاج من الحذف الخاطئ أو إعادة التسمية.
#
# R8 (المُستخدم في Android) يفعل ثلاثة أشياء:
#   1. Shrinking   — حذف الكود غير المستخدم.
#   2. Obfuscation — إعادة تسمية الكلاسات والدوال بأسماء قصيرة (a, b, c...).
#   3. Optimization — دمج وتبسيط الكود.
#
# المشكلة: بعض المكتبات تعتمد على Reflection لاستدعاء كلاسات بأسمائها —
#   R8 لا يعرف أنها مستخدمة فيحذفها أو يُعيد تسميتها → crash وقت التشغيل.
# الحل: -keep rules تُخبر R8 بما يجب الإبقاء عليه.
# ─────────────────────────────────────────────────────────────────────────────


# ── Hilt ─────────────────────────────────────────────────────────────────────
# Hilt يولّد كلاسات في وقت الترجمة — R8 يجب أن يُبقيها.
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }
-keep @dagger.hilt.android.lifecycle.HiltViewModel class * { *; }
-keep @dagger.hilt.android.AndroidEntryPoint class * { *; }
-keep @dagger.hilt.InstallIn class * { *; }


# ── Room ─────────────────────────────────────────────────────────────────────
# Room يولّد implementation كلاسات من الـ DAOs — يجب الإبقاء عليها.
-keep class * extends androidx.room.RoomDatabase { *; }
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao interface * { *; }
-keepclassmembers class * extends androidx.room.RoomDatabase {
    abstract ** *Dao();
}


# ── Kotlin Coroutines ─────────────────────────────────────────────────────────
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory { *; }
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler { *; }
-keepclassmembernames class kotlinx.** {
    volatile <fields>;
}


# ── Kotlin Serialization (احتياطي — إذا أُضيفت مستقبلاً) ────────────────────
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt


# ── WorkManager ───────────────────────────────────────────────────────────────
# WorkManager يُنشئ Workers عبر Reflection باستخدام اسم الكلاس.
-keep class * extends androidx.work.Worker { *; }
-keep class * extends androidx.work.CoroutineWorker { *; }
-keep class * extends androidx.work.ListenableWorker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}
# HiltWorker يحتاج AssistedInject — يجب الإبقاء على الـ constructors.
-keep @androidx.hilt.work.HiltWorker class * { *; }


# ── OkHttp ────────────────────────────────────────────────────────────────────
-dontwarn okhttp3.**
-dontwarn okio.**
-keep class okhttp3.** { *; }
-keep interface okhttp3.** { *; }
# OkHttp يستخدم Reflection لقراءة TLS platform
-keepnames class okhttp3.internal.platform.** { *; }


# ── CameraX ───────────────────────────────────────────────────────────────────
-keep class androidx.camera.** { *; }
-dontwarn androidx.camera.**


# ── ML Kit ───────────────────────────────────────────────────────────────────
-keep class com.google.mlkit.** { *; }
-dontwarn com.google.mlkit.**
-keep class com.google.android.gms.** { *; }
-dontwarn com.google.android.gms.**


# ── DataStore ─────────────────────────────────────────────────────────────────
-keep class androidx.datastore.** { *; }


# ── Compose ───────────────────────────────────────────────────────────────────
# Compose Compiler يولّد كود يُستخدم via Reflection في Preview.
-keep class androidx.compose.** { *; }
-dontwarn androidx.compose.**


# ── App — Domain Models ───────────────────────────────────────────────────────
# نماذج Domain تُستخدم في Room queries و Kotlin serialization —
# إعادة تسميتها تكسر الـ mapping.
-keep class com.safecapture.app.domain.model.** { *; }
-keep class com.safecapture.app.data.local.entity.** { *; }


# ── App — Services & Receivers ────────────────────────────────────────────────
# Android يُنشئ هذه الكلاسات بأسمائها من AndroidManifest.xml —
# إعادة تسميتها تمنع النظام من إيجادها.
-keep class com.safecapture.app.service.** { *; }
-keep class com.safecapture.app.worker.** { *; }


# ── Debugging: احتفظ بأسماء الكلاسات في stack traces ────────────────────────
# يُسهّل تشخيص الأخطاء في Crashlytics أو Firebase.
-keepattributes SourceFile, LineNumberTable
-renamesourcefileattribute SourceFile


# ── تجاهل تحذيرات المكتبات الخارجية ─────────────────────────────────────────
-dontwarn org.bouncycastle.**
-dontwarn org.conscrypt.**
-dontwarn org.openjsse.**
