// build.gradle.kts  (root)
// ─────────────────────────────────────────────────────────────────────────────
// ملف البناء الجذري — مهمته الوحيدة هي:
//   1. الإعلان عن الـ plugins المستخدمة في الوحدات الفرعية (apply = false)
//   2. لا يحتوي على أي تبعيات مباشرة — هذا دور app/build.gradle.kts
//
// قاعدة: لا تضع هنا أي dependencies {} أو android {} blocks.
// ─────────────────────────────────────────────────────────────────────────────

plugins {
    // Android Application Plugin
    alias(libs.plugins.android.application)  apply false

    // Android Library Plugin (للمستقبل إذا أُضيفت وحدات library)
    alias(libs.plugins.android.library)      apply false

    // Kotlin Android
    alias(libs.plugins.kotlin.android)       apply false

    // Kotlin Compose Compiler Plugin (مطلوب منفصلاً منذ Kotlin 2.0)
    alias(libs.plugins.kotlin.compose)       apply false

    // KSP — Kotlin Symbol Processing (بديل kapt لـ Room + Hilt)
    alias(libs.plugins.ksp)                  apply false

    // Hilt Dependency Injection
    alias(libs.plugins.hilt)                 apply false
}
