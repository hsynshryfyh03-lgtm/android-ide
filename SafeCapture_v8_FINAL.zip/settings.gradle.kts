// settings.gradle.kts
// ─────────────────────────────────────────────────────────────────────────────
// نقطة الدخول لنظام Gradle — يُحدد:
//   1. اسم المشروع
//   2. مستودعات التحميل (repositories)
//   3. الوحدات (modules) المشمولة في البناء
// ─────────────────────────────────────────────────────────────────────────────

pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    // FAIL_ON_PROJECT_REPOS: يمنع أي وحدة من إضافة مستودعاتها الخاصة.
    // يضمن أن كل التبعيات تأتي من هنا فقط.
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)

    repositories {
        google()
        mavenCentral()
    }
}

// ── اسم المشروع الظاهر في Android Studio ─────────────────────────────────────
rootProject.name = "SafeCapture"

// ── الوحدات المشمولة ──────────────────────────────────────────────────────────
include(":app")
