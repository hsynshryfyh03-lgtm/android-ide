package com.husseindev.sentinelprotocol.service

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.husseindev.sentinelprotocol.camera.CameraEngine
import com.husseindev.sentinelprotocol.core.constants.AppConstants
import com.husseindev.sentinelprotocol.domain.model.*
import com.husseindev.sentinelprotocol.domain.repository.SettingsRepository
import com.husseindev.sentinelprotocol.domain.usecase.SaveRecordingUseCase
import com.husseindev.sentinelprotocol.worker.UploadToTelegramWorker
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import java.io.File
import javax.inject.Inject

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Foreground Service
//  Night Mode + Telegram Upload + Quick Toggle
//  برمجة حسين حميد
// ══════════════════════════════════════════

@AndroidEntryPoint
class SentinelForegroundService : LifecycleService() {

    private val TAG = "SentinelFGService"

    @Inject lateinit var cameraEngine   : CameraEngine
    @Inject lateinit var notifManager   : SentinelNotificationManager
    @Inject lateinit var saveRecording  : SaveRecordingUseCase
    @Inject lateinit var settingsRepo   : SettingsRepository

    private var wakeLock : PowerManager.WakeLock? = null
    private val scope    = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    companion object {
        const val ACTION_START  = "ACTION_SENTINEL_START"
        const val ACTION_STOP   = "ACTION_SENTINEL_STOP"
        const val ACTION_TOGGLE = "ACTION_SENTINEL_TOGGLE"
        const val EXTRA_CAMERA      = "extra_camera_facing"
        const val EXTRA_SENSITIVITY = "extra_sensitivity"
        var isRunning = false
    }

    override fun onCreate() {
        super.onCreate()
        notifManager.createNotificationChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        when (intent?.action) {
            ACTION_STOP   -> { stopSelf(); return START_NOT_STICKY }
            ACTION_TOGGLE -> {
                if (isRunning) stopSelf() else startForegroundCompat()
                return START_NOT_STICKY
            }
            else -> startForegroundCompat()
        }

        val facingStr = intent?.getStringExtra(EXTRA_CAMERA) ?: CameraFacing.BACK.name
        val sensitStr = intent?.getStringExtra(EXTRA_SENSITIVITY) ?: SensitivityLevel.MEDIUM.name
        val facing    = CameraFacing.valueOf(facingStr)
        val sensitivity = SensitivityLevel.valueOf(sensitStr)

        isRunning = true

        // Load full config for night mode + virtual fence
        scope.launch {
            val config = settingsRepo.getConfig().first()
            cameraEngine.setMonitoringActive(true)
            cameraEngine.bindCamera(
                lifecycleOwner      = this@SentinelForegroundService,
                facing              = facing,
                sensitivity         = sensitivity,
                nightModeEnabled    = config.nightModeEnabled,
                nightStartHour      = config.nightStartHour,
                nightEndHour        = config.nightEndHour,
                virtualFence        = config.virtualFence,
                preview             = null,
                onRecordingComplete = { file -> onRecordingFinished(file, config) }
            )
        }

        return START_STICKY
    }

    private fun onRecordingFinished(file: File, config: SentinelConfig) {
        scope.launch {
            val event = RecordingEvent(
                filePath      = file.absolutePath,
                triggerType   = TriggerType.MOTION_FACE,
                fileSizeBytes = file.length()
            )
            saveRecording(event)

            // ── Telegram upload ─────────────────────────────────────────────
            if (config.telegram.enabled && config.telegram.sendVideos && config.telegram.botToken.isNotBlank()) {
                UploadToTelegramWorker.enqueue(
                    context  = applicationContext,
                    filePath = file.absolutePath,
                    fileType = UploadToTelegramWorker.TYPE_VIDEO,
                    caption  = "اكتشاف حركة — تسجيل تلقائي"
                )
            }
        }
    }

    private fun startForegroundCompat() {
        val notif    = notifManager.buildForegroundNotification()
        val hasAudio = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val fgsType = if (hasAudio) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            }
            startForeground(AppConstants.NOTIFICATION_ID_FOREGROUND, notif, fgsType)
        } else {
            startForeground(AppConstants.NOTIFICATION_ID_FOREGROUND, notif)
        }
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "SentinelProtocol::WakeLock"
        ).also { it.acquire(12 * 60 * 60 * 1000L) }
    }

    override fun onDestroy() {
        isRunning = false
        cameraEngine.setMonitoringActive(false)
        cameraEngine.unbind()
        wakeLock?.release()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? { super.onBind(intent); return null }
}
