package com.hussein.alarmpro.ui.screens

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.hussein.alarmpro.data.model.Alarm
import com.hussein.alarmpro.ui.components.*
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.*
import com.hussein.alarmpro.viewmodel.AlarmViewModel
import android.app.admin.DevicePolicyManager
import androidx.compose.runtime.produceState
import androidx.compose.foundation.layout.PaddingValues
import android.content.ComponentName
import android.provider.Settings
import com.hussein.alarmpro.admin.AlarmDeviceAdmin
import java.text.SimpleDateFormat
import java.util.*
// ─────────────────────────────────────────────────────────────────────────────
// EditAlarmScreen  — iOS 26 design language
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditAlarmScreen(
    alarm: Alarm?,
    viewModel: AlarmViewModel,
    onBack: () -> Unit
) {
    val isAr   = TimeUtils.isArabic()
    val ctx    = LocalContext.current
    val template = viewModel.template.collectAsState().value
    val base   = alarm ?: viewModel.newAlarmFromTemplate(7, 0)
    // ── State ──────────────────────────────────────────────────────────────
    var hour       by remember { mutableStateOf(base.hour % 12) }
    var minute     by remember { mutableStateOf(base.minute) }
    var isAm       by remember { mutableStateOf(base.hour < 12) }
    var label      by remember { mutableStateOf(base.label) }
    var days       by remember { mutableStateOf(base.days) }
    var enabled    by remember { mutableStateOf(base.isEnabled) }
    var soundUri   by remember { mutableStateOf(base.soundUri) }
    var soundName  by remember { mutableStateOf(base.soundName) }
    var volume     by remember { mutableStateOf(base.volumePercent.toFloat()) }
    var vibrate    by remember { mutableStateOf(base.isVibrate) }
    var vibPat     by remember { mutableStateOf(base.vibrationPattern) }
    var snoozeEn   by remember { mutableStateOf(base.isSnoozeEnabled) }
    var snoozeMin  by remember { mutableStateOf(base.snoozeMinutes) }
    var snoozeReduce by remember { mutableStateOf(base.snoozeReduceMinutes) }
    var snoozeMax  by remember { mutableStateOf(base.snoozeMaxCount) }
    var autoSnooze by remember { mutableStateOf(base.autoSnoozeMinutes) }
    var dismissType by remember { mutableStateOf(base.dismissType) }
    var dismissTask by remember { mutableStateOf(base.dismissTask) }
    var taskDiff   by remember { mutableStateOf(base.dismissTaskDifficulty) }
    var autoDissmiss by remember { mutableStateOf(base.autoDissmissMinutes) }
    var wakeCheck  by remember { mutableStateOf(base.wakeCheckEnabled) }
    var wakeDelay  by remember { mutableStateOf(base.wakeCheckDelayMinutes) }
    var wakeCount  by remember { mutableStateOf(base.wakeCheckCountdownMinutes) }
    var ringBg     by remember { mutableStateOf(base.ringBgUri) }
    var preAlarm   by remember { mutableStateOf(base.preAlarmNotifyMinutes) }
    var bypassDnd  by remember { mutableStateOf(base.bypassDnd) }
    var gradual    by remember { mutableStateOf(base.gradualVolume) }
    var gradualDur by remember { mutableStateOf(base.gradualVolumeDurationSec) }
    // Feature 3: specific date scheduling
    var scheduledDate by remember { mutableStateOf(base.scheduledDate) }
    var showDatePicker by remember { mutableStateOf(false) }
    // Feature 6: bedtime
    var bedtimeEnabled by remember { mutableStateOf(base.bedtimeEnabled) }
    var sleepHours     by remember { mutableStateOf(base.sleepHours) }
    // Feature 8: group
    var groupId by remember { mutableStateOf(base.groupId) }
    // Feature 18: vacation exempt
    var vacationExempt by remember { mutableStateOf(base.vacationExempt) }
    // Strict Mode
    var strictMode by remember { mutableStateOf(base.strictMode) }
    // Test alarm state
    var testPlayer: MediaPlayer? by remember { mutableStateOf(null) }
    var isTestPlaying by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        onDispose {
            testPlayer?.release()
        }
    }
    // Media picker
    val soundPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri = result.data?.data
            if (uri != null) {
                soundUri  = uri.toString()
                soundName = getAudioName(ctx, uri) ?: uri.lastPathSegment ?: ""
                runCatching {
                    ctx.contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            }
    val bgPicker = rememberLauncherForActivityResult(
                ringBg = uri.toString()
    // Compute 24h hour
    val hour24 = if (isAm) {
        if (hour == 12) 0 else hour
    } else {
        if (hour == 12) 12 else hour + 12
    fun save() {
        testPlayer?.release()
        val updated = base.copy(
            hour = hour24, minute = minute, label = label, isEnabled = enabled,
            days = days, soundUri = soundUri, soundName = soundName,
            volumePercent = volume.toInt(), isVibrate = vibrate, vibrationPattern = vibPat,
            isSnoozeEnabled = snoozeEn, snoozeMinutes = snoozeMin,
            snoozeReduceMinutes = snoozeReduce, snoozeMaxCount = snoozeMax,
            autoSnoozeMinutes = autoSnooze, dismissType = dismissType,
            dismissTask = dismissTask, dismissTaskDifficulty = taskDiff,
            autoDissmissMinutes = autoDissmiss, wakeCheckEnabled = wakeCheck,
            wakeCheckDelayMinutes = wakeDelay, wakeCheckCountdownMinutes = wakeCount,
            ringBgUri = ringBg, preAlarmNotifyMinutes = preAlarm, skipToday = false,
            bypassDnd = bypassDnd, gradualVolume = gradual, gradualVolumeDurationSec = gradualDur,
            scheduledDate = scheduledDate, bedtimeEnabled = bedtimeEnabled, sleepHours = sleepHours,
            groupId = groupId, vacationExempt = vacationExempt, strictMode = strictMode
        )
        if (alarm == null) viewModel.addAlarm(updated)
        else viewModel.updateAlarm(updated)
        onBack()
    // ── UI ─────────────────────────────────────────────────────────────────
    LiquidGlassBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            if (alarm == null)
                                (if (isAr) "منبه جديد" else "New Alarm")
                            else (if (isAr) "تعديل" else "Edit Alarm"),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.SemiBold)
                        )
                    },
                    navigationIcon = {
                        // iOS-style back arrow
                        IconButton(onClick = { testPlayer?.release(); onBack() }) {
                            Icon(Icons.Filled.ChevronLeft, null,
                                tint = OrbBlue, modifier = Modifier.size(28.dp))
                        }
                    actions = {
                        // Test button
                        Box(
                            modifier = Modifier
                                .padding(end = 4.dp)
                                .height(32.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    if (isTestPlaying) OrbPink.copy(0.25f)
                                    else OrbBlue.copy(0.18f)
                                )
                                .border(
                                    1.dp,
                                    if (isTestPlaying) OrbPink.copy(0.6f) else OrbBlue.copy(0.5f),
                                    RoundedCornerShape(16.dp)
                                .clickable {
                                    if (isTestPlaying) {
                                        testPlayer?.stop(); testPlayer?.release()
                                        testPlayer = null; isTestPlaying = false
                                    } else {
                                        testPlayer = testRing(ctx, soundUri)
                                        isTestPlaying = true
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                Modifier.padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    if (isTestPlaying) Icons.Filled.Stop else Icons.Filled.PlayArrow,
                                    null,
                                    tint = if (isTestPlaying) OrbPink else OrbBlue,
                                    modifier = Modifier.size(14.dp)
                                Spacer(Modifier.width(3.dp))
                                Text(
                                    if (isTestPlaying)
                                        (if (isAr) "إيقاف" else "Stop")
                                    else
                                        (if (isAr) "اختبار" else "Test"),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = if (isTestPlaying) OrbPink else OrbBlue,
                                        fontWeight = FontWeight.SemiBold
                                    )
                            }
                        // Save
                        TextButton(onClick = { save() }) {
                            Text(
                                if (isAr) "حفظ" else "Save",
                                color = OrbBlue,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 16.sp
                            )
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                )
        ) { pd ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pd)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // ── iOS-style Time Picker ──────────────────────────────
                IosTimePicker(
                    hour   = hour,
                    minute = minute,
                    isAm   = isAm,
                    onHourChange   = { hour   = it },
                    onMinuteChange = { minute = it },
                    onAmPmChange   = { isAm   = it },
                    isAr = isAr
                // ── Label ──────────────────────────────────────────────
                GlassCard(Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = label,
                        onValueChange = { label = it },
                        placeholder = { Text(
                            if (isAr) "التسمية (اختياري)" else "Label (optional)",
                            color = TextTertiary
                        )},
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(4.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary, unfocusedTextColor = TextSecondary,
                            focusedBorderColor = OrbBlue, unfocusedBorderColor = Color.Transparent,
                            cursorColor = OrbBlue
                    )
                // ── Repeat ─────────────────────────────────────────────
                DaysSelectorCard(days = days, onDaysChange = { days = it }, isAr = isAr)
                // ── Sound ──────────────────────────────────────────────
                SoundCard(
                    soundUri = soundUri, soundName = soundName, volume = volume,
                    onVolumeChange = { volume = it },
                    onSelectBuiltin = { s -> soundUri = s.uri; soundName = s.displayName },
                    onPickSound = {
                        soundPicker.launch(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            type = "audio/*"
                            addCategory(Intent.CATEGORY_OPENABLE)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                     Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                        })
                    onClearSound = { soundUri = ""; soundName = "" },
                // ── DND Bypass + Gradual Volume ─────────────────────────
                SoundOptionsCard(
                    bypassDnd = bypassDnd, gradual = gradual, gradualDur = gradualDur,
                    onBypassChange = { bypassDnd = it },
                    onGradualChange = { gradual = it },
                    onDurChange = { gradualDur = it },
                // ── Vibration ──────────────────────────────────────────
                VibrationCard(
                    vibrate = vibrate, vibPat = vibPat,
                    onVibrateChange = { vibrate = it }, onPatChange = { vibPat = it },
                // ── Snooze ─────────────────────────────────────────────
                SnoozeCard(
                    snoozeEn = snoozeEn, snoozeMin = snoozeMin,
                    snoozeReduce = snoozeReduce, snoozeMax = snoozeMax, autoSnooze = autoSnooze,
                    onSnoozeEnChange = { snoozeEn = it }, onSnoozeMinChange = { snoozeMin = it },
                    onReduceChange = { snoozeReduce = it }, onMaxChange = { snoozeMax = it },
                    onAutoChange = { autoSnooze = it }, isAr = isAr
                // ── Dismiss Task ───────────────────────────────────────
                DismissCard(
                    dismissType = dismissType, dismissTask = dismissTask, taskDiff = taskDiff,
                    autoDissmiss = autoDissmiss,
                    onTypeChange = { dismissType = it }, onTaskChange = { dismissTask = it },
                    onDiffChange = { taskDiff = it }, onAutoChange = { autoDissmiss = it },
                // ── Wake Check ─────────────────────────────────────────
                WakeCheckCard(
                    wakeCheck = wakeCheck, wakeDelay = wakeDelay, wakeCount = wakeCount,
                    onEnableChange = { wakeCheck = it }, onDelayChange = { wakeDelay = it },
                    onCountdownChange = { wakeCount = it }, isAr = isAr
                // ── Pre-alarm ──────────────────────────────────────────
                PreAlarmCard(preAlarm = preAlarm, onChange = { preAlarm = it }, isAr = isAr)
                // ── Ring Background ────────────────────────────────────
                RingBgCard(
                    ringBg = ringBg,
                    onPick = {
                        bgPicker.launch(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            type = "image/*"
                    onClear = { ringBg = "" }, isAr = isAr
                // ── Feature 3: Specific Date ───────────────────────────────
                if (showDatePicker) {
                    DatePickerModal(
                        initialMillis = if (scheduledDate > 0L) scheduledDate
                                        else System.currentTimeMillis(),
                        onDateSelected = { ms ->
                            scheduledDate = ms
                            days = -1
                            showDatePicker = false
                        },
                        onDismiss = { showDatePicker = false }
                SpecificDateCard(
                    days = days, scheduledDate = scheduledDate,
                    onEnableDate = { showDatePicker = true },
                    onClearDate = { scheduledDate = 0L; days = 0 },
                // ── Feature 6: Bedtime ─────────────────────────────────────
                BedtimeCard(
                    bedtimeEnabled = bedtimeEnabled, sleepHours = sleepHours,
                    hour24 = hour24,
                    onEnableChange = { bedtimeEnabled = it },
                    onHoursChange = { sleepHours = it }, isAr = isAr
                // ── Feature 8: Group ───────────────────────────────────────
                val groups by viewModel.groups.collectAsState()
                GroupPickerCard(
                    groups = groups, selectedGroupId = groupId,
                    onGroupSelected = { groupId = it }, isAr = isAr
                // ── Feature 18: Vacation Exempt ────────────────────────────
                VacationExemptCard(
                    exempt = vacationExempt,
                    onExemptChange = { vacationExempt = it },
                // ── Strict Mode ────────────────────────────────────────────────
                StrictModeCard(
                    strictMode = strictMode,
                    onStrictModeChange = { enabled ->
                        strictMode = enabled
                        // Auto-enable task if none selected (strict needs at least one task)
                        if (enabled && dismissTask == 0) dismissTask = 1
                Spacer(Modifier.height(20.dp))
}
// iOS Time Picker  — compact, proportioned, AM/PM integrated
private fun IosTimePicker(
    hour: Int, minute: Int, isAm: Boolean,
    onHourChange: (Int) -> Unit,
    onMinuteChange: (Int) -> Unit,
    onAmPmChange: (Boolean) -> Unit,
    isAr: Boolean
    val hour24Display = when {
        isAm && hour == 0 -> 12
        isAm -> hour
        !isAm && hour == 0 -> 12
        else -> hour
    val displayTime = String.format("%02d:%02d", hour24Display, minute)
    val amPmLabel   = if (isAm) (if (isAr) "ص" else "AM") else (if (isAr) "م" else "PM")
    GlassCard(Modifier.fillMaxWidth()) {
        Column(
            Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Display time large
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
                Text(
                    text = displayTime,
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = 60.sp,
                        fontWeight = FontWeight.Thin,
                        letterSpacing = (-2).sp,
                        color = TextPrimary
                Spacer(Modifier.width(10.dp))
                // AM/PM toggle button
                Column(
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    AmPmButton(
                        label = if (isAr) "ص" else "AM",
                        selected = isAm,
                        onClick = { onAmPmChange(true) }
                        label = if (isAr) "م" else "PM",
                        selected = !isAm,
                        onClick = { onAmPmChange(false) }
            Spacer(Modifier.height(10.dp))
            HorizontalDivider(color = GlassBorder, thickness = 0.5.dp)
            // Compact wheel pickers side by side
                    .fillMaxWidth()
                    .height(160.dp),
                verticalAlignment = Alignment.CenterVertically
                // Hour wheel 1-12
                IosWheelPicker(
                    items   = (1..12).map { String.format("%02d", it) },
                    selectedIndex = if (hour == 0) 11 else hour - 1,
                    onItemSelected = { onHourChange(it + 1) },
                    modifier = Modifier.width(80.dp),
                    visibleItems = 5,
                    itemHeight = 36.dp
                    ":",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        color = TextSecondary, fontSize = 28.sp
                    ),
                    modifier = Modifier.padding(horizontal = 4.dp)
                // Minute wheel 0-59
                    items   = (0..59).map { String.format("%02d", it) },
                    selectedIndex = minute,
                    onItemSelected = onMinuteChange,
private fun AmPmButton(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .width(40.dp)
            .height(28.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(if (selected) OrbBlue else GlassBg)
            .border(
                1.dp,
                if (selected) OrbBlue.copy(0.8f) else GlassBorder,
                RoundedCornerShape(7.dp)
            )
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = if (selected) Color.White else TextTertiary,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                fontSize = 12.sp
// ── Days Selector ─────────────────────────────────────────────────────────────
private fun DaysSelectorCard(days: Int, onDaysChange: (Int) -> Unit, isAr: Boolean) {
    val dayLabels = if (isAr)
        listOf("أحد","إثنين","ثلاثاء","أربعاء","خميس","جمعة","سبت")
    else listOf("Sun","Mon","Tue","Wed","Thu","Fri","Sat")
        Column(Modifier.padding(16.dp)) {
            SectionLabel(if (isAr) "التكرار" else "Repeat")
            // Quick preset chips
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(
                    Pair(if (isAr) "مرة" else "Once",    0),
                    Pair(if (isAr) "يومياً" else "Daily", 0b1111111),
                    Pair(if (isAr) "عمل" else "Work",    0b0111110),
                    Pair(if (isAr) "عطلة" else "WE",      0b1000001)
                ).forEach { (lbl, mask) ->
                    FilterChip(
                        selected = days == mask,
                        onClick  = { onDaysChange(mask) },
                        label    = { Text(lbl, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = OrbBlue.copy(0.25f),
                            selectedLabelColor = OrbBlue
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                dayLabels.forEachIndexed { idx, lbl ->
                    val sel = (days shr idx) and 1 == 1
                        selected = sel,
                        onClick  = {
                            onDaysChange(
                                if (sel) days and (1 shl idx).inv()
                                else     days or  (1 shl idx)
                        label    = { Text(lbl, fontSize = 9.sp) },
                        modifier = Modifier.weight(1f),
// ── Sound Card ────────────────────────────────────────────────────────────────
private fun SoundCard(
    soundUri: String, soundName: String, volume: Float,
    onVolumeChange: (Float) -> Unit,
    onSelectBuiltin: (BuiltinSound) -> Unit,
    onPickSound: () -> Unit,
    onClearSound: () -> Unit,
    val context = LocalContext.current
    val sounds = remember { loadBuiltinSounds(context) }
            SectionLabel(if (isAr) "الصوت" else "Sound")
            if (sounds.size > 1) {
                Text(if (isAr) "نغمات مدمجة" else "Built-in",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary))
                Spacer(Modifier.height(6.dp))
                sounds.forEach { s ->
                    val selected = soundUri == s.uri
                    Row(
                        Modifier.fillMaxWidth().clickable { onSelectBuiltin(s) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = selected, onClick = { onSelectBuiltin(s) },
                            colors = RadioButtonDefaults.colors(selectedColor = OrbBlue))
                        Icon(Icons.Filled.MusicNote, null,
                            tint = if (selected) OrbBlue else TextTertiary,
                            modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(s.displayName,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = if (selected) OrbBlue else TextPrimary))
                    }
                Spacer(Modifier.height(8.dp))
                HorizontalDivider(color = GlassBorder, thickness = 0.5.dp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.MusicNote, null, tint = OrbBlue, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(soundName.ifBlank { if (isAr) "النغمة الافتراضية" else "Default Ringtone" },
                    style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                if (soundName.isNotBlank()) {
                    IconButton(onClick = onClearSound, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Filled.Close, null, tint = TextTertiary, modifier = Modifier.size(16.dp))
                TextButton(onClick = onPickSound) { Text(if (isAr) "اختيار" else "Pick", color = OrbBlue) }
                Icon(Icons.Filled.VolumeDown, null, tint = TextTertiary, modifier = Modifier.size(16.dp))
                Slider(
                    value = volume, onValueChange = onVolumeChange, valueRange = 0f..100f,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                    colors = SliderDefaults.colors(thumbColor = OrbBlue,
                        activeTrackColor = OrbBlue, inactiveTrackColor = GlassBorder)
                Icon(Icons.Filled.VolumeUp, null, tint = TextTertiary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("${volume.toInt()}%", style = MaterialTheme.typography.labelSmall)
// ── Sound Options (DND bypass + Gradual volume) ───────────────────────────────
private fun SoundOptionsCard(
    bypassDnd: Boolean, gradual: Boolean, gradualDur: Int,
    onBypassChange: (Boolean) -> Unit,
    onGradualChange: (Boolean) -> Unit,
    onDurChange: (Int) -> Unit,
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // DND Bypass
                Icon(Icons.Filled.DoNotDisturb, null, tint = OrbBlue, modifier = Modifier.size(18.dp))
                Column(Modifier.weight(1f)) {
                    Text(if (isAr) "تجاوز وضع الصمت" else "Override Silent/DND",
                        style = MaterialTheme.typography.titleSmall)
                    Text(if (isAr) "يرن حتى لو الهاتف صامت" else "Ring even when phone is silent",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary, fontSize = 11.sp))
                IosSwitch(checked = bypassDnd, onCheckedChange = onBypassChange)
            // Gradual volume
                Icon(Icons.Filled.GraphicEq, null, tint = OrbBlue, modifier = Modifier.size(18.dp))
                    Text(if (isAr) "رفع الصوت تدريجياً" else "Gradual Volume",
                    Text(if (isAr) "يبدأ خافتاً ثم يرتفع" else "Starts quiet, gradually louder",
                IosSwitch(checked = gradual, onCheckedChange = onGradualChange)
            if (gradual) {
                StepSetting(
                    label = if (isAr) "مدة الرفع التدريجي" else "Ramp-up duration",
                    value = gradualDur, unit = if (isAr) "ثانية" else "sec",
                    range = 5..120, onValueChange = onDurChange
// ── Vibration Card ────────────────────────────────────────────────────────────
private fun VibrationCard(
    vibrate: Boolean, vibPat: Int,
    onVibrateChange: (Boolean) -> Unit, onPatChange: (Int) -> Unit, isAr: Boolean
                Icon(Icons.Filled.Vibration, null, tint = OrbBlue, modifier = Modifier.size(18.dp))
                Text(if (isAr) "الاهتزاز" else "Vibration",
                    style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                IosSwitch(checked = vibrate, onCheckedChange = onVibrateChange)
            if (vibrate) {
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        Pair(if (isAr) "افتراضي" else "Default", 1),
                        Pair(if (isAr) "نبضي"    else "Pulse",   2),
                        Pair(if (isAr) "تصاعدي"  else "Escalate",3)
                    ).forEach { (lbl, pat) ->
                        FilterChip(
                            selected = vibPat == pat, onClick = { onPatChange(pat) },
                            label = { Text(lbl, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = OrbPurple.copy(0.3f),
                                selectedLabelColor = OrbPurple)
// ── Snooze Card ───────────────────────────────────────────────────────────────
private fun SnoozeCard(
    snoozeEn: Boolean, snoozeMin: Int, snoozeReduce: Int, snoozeMax: Int, autoSnooze: Int,
    onSnoozeEnChange: (Boolean) -> Unit, onSnoozeMinChange: (Int) -> Unit,
    onReduceChange: (Int) -> Unit, onMaxChange: (Int) -> Unit, onAutoChange: (Int) -> Unit,
                Icon(Icons.Filled.Snooze, null, tint = OrbBlue, modifier = Modifier.size(18.dp))
                Text(if (isAr) "الغفوة" else "Snooze",
                IosSwitch(checked = snoozeEn, onCheckedChange = onSnoozeEnChange)
            if (snoozeEn) {
                StepSetting(if (isAr) "مدة الغفوة" else "Duration", snoozeMin, if (isAr) "د" else "m", 1..60, onSnoozeMinChange)
                StepSetting(if (isAr) "تقليل كل غفوة" else "Reduce/snooze", snoozeReduce, if (isAr) "د" else "m", 0..10, onReduceChange)
                StepSetting(if (isAr) "الحد الأقصى (-1=∞)" else "Max (-1=∞)", snoozeMax, "", -1..20, onMaxChange)
// ── Dismiss Card ──────────────────────────────────────────────────────────────
private fun DismissCard(
    dismissType: Int, dismissTask: Int, taskDiff: Int, autoDissmiss: Int,
    onTypeChange: (Int) -> Unit, onTaskChange: (Int) -> Unit,
    onDiffChange: (Int) -> Unit, onAutoChange: (Int) -> Unit, isAr: Boolean
            SectionLabel(if (isAr) "طريقة الإيقاف" else "Dismiss Method")
            val types = if (isAr) listOf("شاشة","قلب","طاقة","صوت")
                        else listOf("Screen","Flip","Power","Volume")
                types.forEachIndexed { i, t ->
                        selected = dismissType == i, onClick = { onTypeChange(i) },
                        label = { Text(t, fontSize = 11.sp) },
                            selectedContainerColor = OrbBlue.copy(0.25f), selectedLabelColor = OrbBlue)
            Spacer(Modifier.height(12.dp))
            SectionLabel(if (isAr) "مهمة الإيقاف" else "Dismiss Task")
            val tasks = if (isAr)
                listOf("بدون","رياضيات","إعادة كتابة","نقرات","خطوات 🚶")
            else listOf("None","Math","Rewrite","Tap","Walk 🚶")
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                tasks.forEachIndexed { i, t ->
                        Modifier.fillMaxWidth().clickable { onTaskChange(i) }.padding(vertical = 2.dp),
                        RadioButton(
                            selected = dismissTask == i, onClick = { onTaskChange(i) },
                            colors = RadioButtonDefaults.colors(selectedColor = OrbBlue)
                        Text(t, style = MaterialTheme.typography.bodyMedium)
            if (dismissTask > 0 && dismissTask < 4) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(if (isAr) "سهل" else "Easy", if (isAr) "متوسط" else "Med",
                           if (isAr) "صعب" else "Hard").forEachIndexed { i, d ->
                            selected = taskDiff == i, onClick = { onDiffChange(i) },
                            label = { Text(d, fontSize = 11.sp) },
                                selectedContainerColor = OrbPink.copy(0.25f), selectedLabelColor = OrbPink)
// ── Wake Check Card ───────────────────────────────────────────────────────────
private fun WakeCheckCard(
    wakeCheck: Boolean, wakeDelay: Int, wakeCount: Int,
    onEnableChange: (Boolean) -> Unit, onDelayChange: (Int) -> Unit,
    onCountdownChange: (Int) -> Unit, isAr: Boolean
                Icon(Icons.Filled.Visibility, null, tint = OrbBlue, modifier = Modifier.size(18.dp))
                    Text(if (isAr) "التحقق من الاستيقاظ" else "Wake Verification",
                        style = MaterialTheme.typography.titleMedium)
                    Text(if (isAr) "يتحقق أنك مستيقظ فعلاً" else "Confirms you're actually awake",
                IosSwitch(checked = wakeCheck, onCheckedChange = onEnableChange)
            if (wakeCheck) {
                StepSetting(if (isAr) "تأخير التحقق" else "Check delay",
                    wakeDelay, if (isAr) "د" else "min", 1..30, onDelayChange)
                StepSetting(if (isAr) "العد التنازلي" else "Countdown",
                    wakeCount, if (isAr) "د" else "min", 1..10, onCountdownChange)
// ── Pre-Alarm Card ────────────────────────────────────────────────────────────
private fun PreAlarmCard(preAlarm: Int, onChange: (Int) -> Unit, isAr: Boolean) {
            SectionLabel(if (isAr) "إشعار مسبق" else "Pre-alarm Reminder")
            StepSetting(
                label = if (isAr) "قبل الموعد بـ (-1=أبداً)" else "Minutes before (-1=off)",
                value = preAlarm, unit = if (isAr) "د" else "min",
                range = -1..60, onValueChange = onChange
// ── Ring Background Card ──────────────────────────────────────────────────────
private fun RingBgCard(ringBg: String, onPick: () -> Unit, onClear: () -> Unit, isAr: Boolean) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Wallpaper, null, tint = OrbBlue, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(
                ringBg.ifBlank { if (isAr) "خلفية شاشة الرنين (افتراضية)" else "Ring Screen BG (default)" },
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f)
            if (ringBg.isNotBlank()) {
                IconButton(onClick = onClear, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Filled.Close, null, tint = TextTertiary, modifier = Modifier.size(16.dp))
            TextButton(onClick = onPick) { Text(if (isAr) "اختيار" else "Pick", color = OrbBlue) }
// ── Shared helpers ────────────────────────────────────────────────────────────
fun StepSetting(label: String, value: Int, unit: String, range: IntRange, onValueChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        IconButton(onClick = { if (value > range.first) onValueChange(value - 1) },
            modifier = Modifier.size(30.dp)) {
            Icon(Icons.Filled.Remove, null, tint = TextSecondary, modifier = Modifier.size(14.dp))
            if (value == -1) "∞" else "$value${if (unit.isNotBlank()) " $unit" else ""}",
            style = MaterialTheme.typography.titleMedium.copy(color = OrbBlue),
            modifier = Modifier.widthIn(min = 48.dp),
            textAlign = TextAlign.Center
        IconButton(onClick = { if (value < range.last) onValueChange(value + 1) },
            Icon(Icons.Filled.Add, null, tint = TextSecondary, modifier = Modifier.size(14.dp))
fun SectionLabel(text: String) {
    Text(text, style = MaterialTheme.typography.labelLarge.copy(
        color = OrbBlue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold))
private fun getAudioName(ctx: Context, uri: Uri): String? = runCatching {
    ctx.contentResolver.query(
        uri, arrayOf(MediaStore.Audio.Media.DISPLAY_NAME), null, null, null
    )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
}.getOrNull()
private fun testRing(ctx: Context, soundUri: String): MediaPlayer? = runCatching {
    val uri = if (soundUri.isNotBlank()) Uri.parse(soundUri)
              else android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI
    MediaPlayer().apply {
        setAudioAttributes(
            android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
        setDataSource(ctx, uri)
        isLooping = false
        prepare(); start()
// ── Feature 3: Specific Date Card ────────────────────────────────────────────
private fun SpecificDateCard(
    days: Int, scheduledDate: Long,
    onEnableDate: () -> Unit,
    onClearDate: () -> Unit,
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }
            Icon(Icons.Filled.CalendarMonth, null, tint = OrbCyan, modifier = Modifier.size(18.dp))
            Column(Modifier.weight(1f)) {
                    if (isAr) "تاريخ محدد" else "Specific Date",
                    style = MaterialTheme.typography.titleSmall
                    if (days == -1 && scheduledDate > 0L)
                        fmt.format(java.util.Date(scheduledDate))
                    else
                        if (isAr) "غير مفعّل" else "Not set",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = if (days == -1) OrbCyan else TextTertiary
            if (days == -1 && scheduledDate > 0L) {
                IconButton(onClick = onClearDate, modifier = Modifier.size(32.dp)) {
            TextButton(onClick = onEnableDate) {
                        (if (isAr) "تغيير" else "Change")
                        (if (isAr) "اختيار" else "Pick"),
                    color = OrbCyan
// ── Feature 3: Date Picker Modal ──────────────────────────────────────────────
private fun DatePickerModal(
    initialMillis: Long,
    onDateSelected: (Long) -> Unit,
    onDismiss: () -> Unit
    val state = rememberDatePickerState(
        initialSelectedDateMillis = initialMillis,
        selectableDates = object : SelectableDates {
            override fun isSelectableDate(utcTimeMillis: Long) =
                utcTimeMillis >= System.currentTimeMillis() - 86400_000L
    )
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                state.selectedDateMillis?.let { onDateSelected(it) } ?: onDismiss()
            }) { Text("OK", color = OrbBlue) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(if (TimeUtils.isArabic()) "إلغاء" else "Cancel") }
        colors = DatePickerDefaults.colors(containerColor = DarkNavy)
        DatePicker(state = state)
// ── Feature 6: Bedtime Card ───────────────────────────────────────────────────
private fun BedtimeCard(
    bedtimeEnabled: Boolean, sleepHours: Int, hour24: Int,
    onEnableChange: (Boolean) -> Unit,
    onHoursChange: (Int) -> Unit,
    // Calculate suggested bedtime
    val bedHour = ((hour24 - sleepHours) + 24) % 24
    val bedTimeStr = String.format("%02d:00", bedHour)
                Icon(Icons.Filled.Bedtime, null, tint = OrbPurple, modifier = Modifier.size(18.dp))
                    Text(
                        if (isAr) "تذكير النوم" else "Bedtime Reminder",
                        style = MaterialTheme.typography.titleSmall
                        if (isAr) "يذكّرك بوقت النوم لتستيقظ نشيطاً"
                        else "Reminds you when to sleep",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextTertiary, fontSize = 11.sp
                IosSwitch(checked = bedtimeEnabled, onCheckedChange = onEnableChange)
            if (bedtimeEnabled) {
                    label = if (isAr) "ساعات النوم المطلوبة" else "Sleep hours needed",
                    value = sleepHours,
                    unit = if (isAr) "س" else "h",
                    range = 4..12,
                    onValueChange = onHoursChange
                // Show calculated bedtime
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
                        .background(OrbPurple.copy(0.12f))
                        .border(
                            0.5.dp, OrbPurple.copy(0.4f),
                            androidx.compose.foundation.shape.RoundedCornerShape(10.dp)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                    Icon(Icons.Filled.NightsStay, null, tint = OrbPurple, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(6.dp))
                        if (isAr) "وقت النوم المقترح: $bedTimeStr"
                        else "Suggested bedtime: $bedTimeStr",
                            color = OrbPurple, fontWeight = FontWeight.Medium
// ── Feature 8: Group Picker Card ──────────────────────────────────────────────
private fun GroupPickerCard(
    groups: List<com.hussein.alarmpro.data.model.AlarmGroup>,
    selectedGroupId: Int,
    onGroupSelected: (Int) -> Unit,
    if (groups.isEmpty()) return
                Icon(Icons.Filled.Layers, null, tint = OrbBlue, modifier = Modifier.size(18.dp))
                    if (isAr) "المجموعة" else "Group",
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.weight(1f)
                if (selectedGroupId != 0) {
                    TextButton(onClick = { onGroupSelected(0) }) {
                        Text(if (isAr) "إزالة" else "Clear", color = OrbPink, fontSize = 12.sp)
            // None option
                Modifier.fillMaxWidth()
                    .clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
                    .background(if (selectedGroupId == 0) OrbBlue.copy(0.18f) else Color.Transparent)
                    .clickable { onGroupSelected(0) }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                RadioButton(
                    selected = selectedGroupId == 0,
                    onClick = { onGroupSelected(0) },
                    colors = RadioButtonDefaults.colors(selectedColor = OrbBlue)
                    if (isAr) "بدون مجموعة" else "No group",
                    style = MaterialTheme.typography.bodyMedium
            groups.forEach { group ->
                val sel = selectedGroupId == group.id
                    Modifier.fillMaxWidth()
                        .background(if (sel) OrbBlue.copy(0.18f) else Color.Transparent)
                        .clickable { onGroupSelected(group.id) }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    RadioButton(
                        onClick = { onGroupSelected(group.id) },
                        colors = RadioButtonDefaults.colors(selectedColor = OrbBlue)
                    // Color dot from group's colorHex
                    val dotColor = runCatching {
                        Color(android.graphics.Color.parseColor(group.colorHex))
                    }.getOrElse { OrbBlue }
                    Box(
                        Modifier.size(10.dp)
                            .clip(CircleShape)
                            .background(dotColor)
                    Spacer(Modifier.width(8.dp))
                    Text(group.name, style = MaterialTheme.typography.bodyMedium)
// ── Feature 18: Vacation Exempt Card ─────────────────────────────────────────
private fun VacationExemptCard(
    exempt: Boolean,
    onExemptChange: (Boolean) -> Unit,
            Icon(Icons.Filled.WbSunny, null, tint = OrbOrange, modifier = Modifier.size(18.dp))
                    if (isAr) "إعفاء من وضع الإجازة" else "Vacation Mode Exempt",
                    if (isAr) "يرن حتى أثناء وضع الإجازة"
                    else "Rings even during vacation mode",
                        color = TextTertiary, fontSize = 11.sp
            IosSwitch(checked = exempt, onCheckedChange = onExemptChange)
// ── Strict Mode Card ──────────────────────────────────────────────────────────
private fun StrictModeCard(
    strictMode: Boolean,
    onStrictModeChange: (Boolean) -> Unit,
    val ctx = LocalContext.current
    val adminLauncher = rememberLauncherForActivityResult(
    ) { /* re-check on resume */ }
    // Check prerequisites live (recompose on each state change)
    val dpm = remember(ctx) { ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager }
    val adminComp = remember(ctx) { ComponentName(ctx, AlarmDeviceAdmin::class.java) }
    val isAdminActive by produceState(false) {
        while (true) { value = dpm.isAdminActive(adminComp); kotlinx.coroutines.delay(1000) }
    val isA11yEnabled by produceState(false) {
        while (true) {
            val target = "${ctx.packageName}/com.hussein.alarmpro.service.StrictAccessibilityService"
            val enabled = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            value = enabled.split(':').any { it.trim().equals(target, true) }
            kotlinx.coroutines.delay(1000)
    val isArmed = isAdminActive && isA11yEnabled
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            // Header toggle
                Box(
                    Modifier.size(36.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
                        .background(if (strictMode) OrbPink.copy(0.2f) else GlassBg)
                        .border(1.dp, if (strictMode) OrbPink.copy(0.6f) else GlassBorder,
                            androidx.compose.foundation.shape.RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                    Icon(Icons.Filled.Lock, null,
                        tint = if (strictMode) OrbPink else TextTertiary,
                        modifier = Modifier.size(18.dp))
                        if (isAr) "الوضع الصارم 🔒" else "Strict Mode 🔒",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = if (strictMode) OrbPink else TextPrimary
                        if (isAr) "من المستحيل إيقاف المنبه بدون إكمال المهمة"
                        else "Makes dismissal impossible without completing the task",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary, fontSize = 11.sp)
                IosSwitch(checked = strictMode, onCheckedChange = onStrictModeChange)
            if (strictMode) {
                // What strict mode does
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        if (isAr) "🚫 لا غفوة — الإيقاف عبر المهمة فقط" else "🚫 No snooze — task is the only exit",
                        if (isAr) "🔊 يرفع الصوت إذا خفّضته" else "🔊 Raises volume if you lower it",
                        if (isAr) "📱 يعيد الشاشة لو أطفأتها" else "📱 Turns screen back on if you turn it off",
                        if (isAr) "⚙️ يحظر فتح الإعدادات" else "⚙️ Blocks opening Settings"
                    ).forEach { feat ->
                        Text(feat, style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontSize = 11.sp))
                // Prerequisites
                    if (isAr) "المتطلبات:" else "Requirements:",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                PrerequisiteRow(
                    icon = Icons.Filled.Shield,
                    label = if (isAr) "مشرف الجهاز" else "Device Admin",
                    desc  = if (isAr) "يمنع حذف التطبيق" else "Prevents app uninstall",
                    enabled = isAdminActive,
                    isAr = isAr,
                    onEnable = {
                        adminLauncher.launch(
                            Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComp)
                                putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                    if (isAr) "مطلوب للوضع الصارم لمنع حذف التطبيق والتهرب من المنبه"
                                    else "Required for Strict Mode to prevent uninstall and alarm bypass"
                    icon = Icons.Filled.Accessible,
                    label = if (isAr) "خدمة إمكانية الوصول" else "Accessibility Service",
                    desc  = if (isAr) "يحظر الإعدادات ويتحكم بمفاتيح الصوت" else "Blocks settings & intercepts volume keys",
                    enabled = isA11yEnabled,
                        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                // Status summary
                if (isArmed) {
                        modifier = Modifier.fillMaxWidth()
                            .clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
                            .background(ToggleOn.copy(0.12f))
                            .border(1.dp, ToggleOn.copy(0.4f), androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
                            .padding(10.dp),
                        Icon(Icons.Filled.VerifiedUser, null, tint = ToggleOn, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                            if (isAr) "✅ الحصن مُفعّل — الوضع الصارم يعمل بكامل طاقته"
                            else "✅ Fully armed — Strict Mode at maximum power",
                            style = MaterialTheme.typography.bodySmall.copy(color = ToggleOn, fontWeight = FontWeight.Medium)
                } else {
                            .background(OrbOrange.copy(0.12f))
                            .border(1.dp, OrbOrange.copy(0.4f), androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
                        Icon(Icons.Filled.Warning, null, tint = OrbOrange, modifier = Modifier.size(16.dp))
                            if (isAr) "⚠️ فعّل المتطلبات أعلاه لأقصى حماية (المهمة إلزامية دائماً)"
                            else "⚠️ Enable requirements above for full protection (task is always mandatory)",
                            style = MaterialTheme.typography.bodySmall.copy(color = OrbOrange, fontSize = 10.sp)
private fun PrerequisiteRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    desc: String,
    enabled: Boolean,
    isAr: Boolean,
    onEnable: () -> Unit
    Row(
        modifier = Modifier.fillMaxWidth()
            .clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
            .background(if (enabled) ToggleOn.copy(0.08f) else GlassBg)
            .border(0.5.dp, if (enabled) ToggleOn.copy(0.3f) else GlassBorder,
                androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
        Icon(
            if (enabled) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
            null,
            tint = if (enabled) ToggleOn else OrbPink,
            modifier = Modifier.size(18.dp)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.titleSmall.copy(
                color = if (enabled) ToggleOn else TextPrimary
            ))
            Text(desc, style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary, fontSize = 10.sp))
        if (!enabled) {
            TextButton(onClick = onEnable, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
                Text(if (isAr) "تفعيل" else "Enable",
                    style = MaterialTheme.typography.labelSmall.copy(color = OrbPink, fontWeight = FontWeight.Bold))
        } else {
            Icon(Icons.Filled.Lock, null, tint = ToggleOn.copy(0.7f), modifier = Modifier.size(14.dp))
