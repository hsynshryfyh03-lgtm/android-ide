package com.husseindev.sentinelprotocol.domain.model

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Domain Models
//  برمجة حسين حميد
// ══════════════════════════════════════════

import android.graphics.RectF

// ── Recording Event ───────────────────────
data class RecordingEvent(
    val id            : Long   = 0,
    val filePath      : String,
    val thumbnailPath : String? = null,
    val timestamp     : Long   = System.currentTimeMillis(),
    val durationMs    : Long   = 0L,
    val triggerType   : TriggerType,
    val detectionCount: Int    = 0,
    val fileSizeBytes : Long   = 0L,
    val isEmergency   : Boolean = false
)

enum class TriggerType { MOTION_FACE, MOTION_PERSON, EMERGENCY_VOLUME, MANUAL }

// ── Detection Result ─────────────────────
data class DetectionResult(
    val faces       : List<DetectedFace>   = emptyList(),
    val persons     : List<DetectedPerson> = emptyList(),
    val timestamp   : Long = System.currentTimeMillis(),
    val imageWidth  : Int  = 0,
    val imageHeight : Int  = 0
) {
    val hasDetection  get() = faces.isNotEmpty() || persons.isNotEmpty()
    val totalDetected get() = faces.size + persons.size
}

// ── Detected Face — enriched with ML Kit ACCURATE data ────────────────────
data class DetectedFace(
    val boundingBox       : RectF,
    val confidence        : Float,
    val trackingId        : Int?   = null,
    val smileProbability  : Float  = 0f,
    val leftEyeOpenProb   : Float  = 0f,
    val rightEyeOpenProb  : Float  = 0f,
    val headEulerAngleY   : Float  = 0f  // Left/right head rotation
)

// ── Detected Person — enriched with Pose Detection data ──────────────────
data class DetectedPerson(
    val boundingBox   : RectF,
    val confidence    : Float,
    val label         : String = "شخص",
    val landmarkCount : Int    = 0
)

// ── Sentinel Config ───────────────────────
data class SentinelConfig(
    val pin                     : String  = "1234",
    val panicCode               : String  = "0000",
    val cameraFacing            : CameraFacing = CameraFacing.BACK,
    val sensitivityLevel        : SensitivityLevel = SensitivityLevel.MEDIUM,
    val autoStartOnBoot         : Boolean = false,
    val emergencyTriggerEnabled : Boolean = true,
    val batteryStopThreshold    : Int     = 15
)

enum class CameraFacing { FRONT, BACK }
enum class SensitivityLevel(val minConfidence: Float) {
    LOW(0.7f), MEDIUM(0.5f), HIGH(0.3f)
}

// ── Monitoring State ─────────────────────
sealed class MonitoringState {
    object Idle          : MonitoringState()
    object Starting      : MonitoringState()
    data class Active(val detectionResult: DetectionResult? = null) : MonitoringState()
    data class Recording(val secondsElapsed: Int = 0, val trigger: TriggerType) : MonitoringState()
    data class Error(val message: String) : MonitoringState()
}

// ── Intruder Photo ────────────────────────
data class IntruderPhoto(
    val id            : Long   = 0,
    val filePath      : String,
    val timestamp     : Long   = System.currentTimeMillis(),
    val attemptNumber : Int    = 0
)

// ── Hourly Activity (for heatmap) ─────────
data class HourlyActivity(
    val hour  : Int,   // 0-23
    val count : Int
)
