package com.husseindev.sentinelprotocol.presentation.screen.monitoring

import androidx.camera.core.Preview
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.husseindev.sentinelprotocol.camera.CameraEngine
import com.husseindev.sentinelprotocol.domain.model.*
import com.husseindev.sentinelprotocol.domain.usecase.SaveRecordingUseCase
import com.husseindev.sentinelprotocol.presentation.components.CctvWatermarkOverlay
import com.husseindev.sentinelprotocol.presentation.components.RecordingIndicator
import com.husseindev.sentinelprotocol.presentation.theme.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject
import androidx.compose.ui.graphics.Canvas
import androidx.compose.foundation.Canvas

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Monitoring Screen
//  Live CameraX + ML Kit Face & Pose Overlay
//  برمجة حسين حميد
// ══════════════════════════════════════════

@HiltViewModel
class MonitoringViewModel @Inject constructor(
    private val cameraEngine  : CameraEngine,
    private val saveRecording : SaveRecordingUseCase
) : ViewModel() {

    val detectionState = cameraEngine.detectionState
    val isRecording    = cameraEngine.isRecording

    fun startManualRecord() {
        cameraEngine.startRecording(onComplete = { file -> onRecordingDone(file) })
    }

    fun stopManualRecord() = cameraEngine.stopRecording()

    private fun onRecordingDone(file: File) {
        viewModelScope.launch {
            saveRecording(RecordingEvent(
                filePath      = file.absolutePath,
                triggerType   = TriggerType.MANUAL,
                fileSizeBytes = file.length()
            ))
        }
    }
}

@Composable
fun MonitoringScreen(
    cameraEngine : CameraEngine,
    onBack       : () -> Unit,
    viewModel    : MonitoringViewModel = hiltViewModel()
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val detection      by viewModel.detectionState.collectAsStateWithLifecycle()
    val isRecording    by viewModel.isRecording.collectAsStateWithLifecycle()

    val preview = remember { Preview.Builder().build() }

    LaunchedEffect(Unit) {
        cameraEngine.bindCamera(
            lifecycleOwner      = lifecycleOwner,
            preview             = preview,
            onRecordingComplete = {}
        )
    }

    Box(Modifier.fillMaxSize().background(DeepBlack)) {

        // ── Camera Preview ──────────────────────
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory  = { ctx ->
                PreviewView(ctx).apply {
                    implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                    preview.setSurfaceProvider(surfaceProvider)
                }
            }
        )

        // ── Detection Overlay (Canvas-based — FIXED) ─────────────────────────
        detection?.let { result ->
            if (result.hasDetection && result.imageWidth > 0 && result.imageHeight > 0) {
                DetectionOverlay(
                    modifier    = Modifier.fillMaxSize(),
                    result      = result
                )
            }
        }

        // ── CCTV Watermark ──────────────────────
        CctvWatermarkOverlay(Modifier.align(Alignment.TopStart))

        // ── REC Indicator ───────────────────────
        Row(Modifier.align(Alignment.TopEnd).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            RecordingIndicator(isRecording)
        }

        // ── Detection badge ─────────────────────
        val total = (detection?.faces?.size ?: 0) + (detection?.persons?.size ?: 0)
        if (total > 0) {
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 12.dp)
                    .background(TealDark.copy(0.75f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    detection?.faces?.size?.takeIf { it > 0 }?.let { f ->
                        Text("وجوه: $f", color = TealLight, fontSize = 12.sp,
                            fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
                    }
                    detection?.persons?.size?.takeIf { it > 0 }?.let { p ->
                        Text("أجسام: $p", color = ActiveGreen, fontSize = 12.sp,
                            fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
                    }
                }
            }
        }

        // ── Bottom Controls ─────────────────────
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(DeepBlack.copy(alpha = 0.75f))
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment     = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = null, tint = TextPrimary)
            }

            // Record toggle
            IconButton(
                onClick  = { if (isRecording) viewModel.stopManualRecord() else viewModel.startManualRecord() },
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(if (isRecording) RecordingRed else TealPrimary)
                    .border(2.dp, Color.White.copy(0.3f), CircleShape)
            ) {
                Icon(
                    imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                    contentDescription = null,
                    tint     = Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }

            // Detection count badge
            Box(
                Modifier.size(48.dp).clip(CircleShape)
                    .background(if (total > 0) TealGlow else Color.Transparent)
                    .border(1.dp, if (total > 0) TealPrimary else TextDim, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text       = "$total",
                    color      = if (total > 0) TealLight else TextDim,
                    fontSize   = 16.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = TajawalFamily
                )
            }
        }
    }
}

// ── Detection Overlay — FIXED: uses Canvas with proper coordinate scaling ─────
@Composable
private fun DetectionOverlay(modifier: Modifier, result: DetectionResult) {
    Canvas(modifier = modifier) {
        val scaleX = size.width  / result.imageWidth.toFloat()
        val scaleY = size.height / result.imageHeight.toFloat()

        // Draw face boxes (teal)
        result.faces.forEach { face ->
            val l = face.boundingBox.left  * scaleX
            val t = face.boundingBox.top   * scaleY
            val r = face.boundingBox.right * scaleX
            val b = face.boundingBox.bottom * scaleY

            drawRect(
                color    = TealPrimary,
                topLeft  = Offset(l, t),
                size     = androidx.compose.ui.geometry.Size(r - l, b - t),
                style    = Stroke(width = 3f)
            )
            // Label background + text via drawContext
            drawRect(
                color   = TealDark.copy(alpha = 0.75f),
                topLeft = Offset(l, t - 22f),
                size    = androidx.compose.ui.geometry.Size(72f, 20f)
            )
        }

        // Draw person/pose boxes (green)
        result.persons.forEach { person ->
            val l = person.boundingBox.left  * scaleX
            val t = person.boundingBox.top   * scaleY
            val r = person.boundingBox.right * scaleX
            val b = person.boundingBox.bottom * scaleY
            val conf = (person.confidence * 100).toInt()

            drawRect(
                color    = ActiveGreen,
                topLeft  = Offset(l, t),
                size     = androidx.compose.ui.geometry.Size(r - l, b - t),
                style    = Stroke(width = 3f)
            )
            // Corner accents for professional look
            val cornerLen = minOf((r - l), (b - t)) * 0.12f
            val stroke    = Stroke(width = 5f)
            // Top-left
            drawLine(ActiveGreen, Offset(l, t), Offset(l + cornerLen, t), strokeWidth = 5f)
            drawLine(ActiveGreen, Offset(l, t), Offset(l, t + cornerLen), strokeWidth = 5f)
            // Top-right
            drawLine(ActiveGreen, Offset(r, t), Offset(r - cornerLen, t), strokeWidth = 5f)
            drawLine(ActiveGreen, Offset(r, t), Offset(r, t + cornerLen), strokeWidth = 5f)
            // Bottom-left
            drawLine(ActiveGreen, Offset(l, b), Offset(l + cornerLen, b), strokeWidth = 5f)
            drawLine(ActiveGreen, Offset(l, b), Offset(l, b - cornerLen), strokeWidth = 5f)
            // Bottom-right
            drawLine(ActiveGreen, Offset(r, b), Offset(r - cornerLen, b), strokeWidth = 5f)
            drawLine(ActiveGreen, Offset(r, b), Offset(r, b - cornerLen), strokeWidth = 5f)

            // Confidence label bg
            drawRect(
                color   = Color(0xFF0A3D2E).copy(alpha = 0.85f),
                topLeft = Offset(l, b),
                size    = androidx.compose.ui.geometry.Size(90f, 20f)
            )
        }
    }
}
