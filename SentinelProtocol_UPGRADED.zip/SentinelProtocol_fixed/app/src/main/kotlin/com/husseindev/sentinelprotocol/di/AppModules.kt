package com.husseindev.sentinelprotocol.di

import android.content.Context
import com.husseindev.sentinelprotocol.data.local.datastore.SettingsDataStore
import com.husseindev.sentinelprotocol.data.local.db.SentinelDatabase
import com.husseindev.sentinelprotocol.data.local.db.dao.IntruderDao
import com.husseindev.sentinelprotocol.data.local.db.dao.RecordingDao
import com.husseindev.sentinelprotocol.data.repository.RecordingRepositoryImpl
import com.husseindev.sentinelprotocol.data.repository.SettingsRepositoryImpl
import com.husseindev.sentinelprotocol.domain.repository.RecordingRepository
import com.husseindev.sentinelprotocol.domain.repository.SettingsRepository
import com.husseindev.sentinelprotocol.domain.usecase.*
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Hilt DI Modules
//  برمجة حسين حميد
// ══════════════════════════════════════════

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): SentinelDatabase =
        SentinelDatabase.build(ctx)

    @Provides @Singleton
    fun provideRecordingDao(db: SentinelDatabase): RecordingDao = db.recordingDao()

    @Provides @Singleton
    fun provideIntruderDao(db: SentinelDatabase): IntruderDao = db.intruderDao()

    @Provides @Singleton
    fun provideSettingsDataStore(@ApplicationContext ctx: Context) = SettingsDataStore(ctx)
}

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds @Singleton
    abstract fun bindRecordingRepository(impl: RecordingRepositoryImpl): RecordingRepository

    @Binds @Singleton
    abstract fun bindSettingsRepository(impl: SettingsRepositoryImpl): SettingsRepository
}

@Module
@InstallIn(SingletonComponent::class)
object UseCaseModule {

    @Provides fun provideValidatePin(r: SettingsRepository)         = ValidatePinUseCase(r)
    @Provides fun provideValidatePanic(r: SettingsRepository)       = ValidatePanicCodeUseCase(r)
    @Provides fun provideDeleteAll(r: RecordingRepository, s: SettingsRepository) = DeleteAllDataUseCase(r, s)
    @Provides fun provideStartMonitoring(r: SettingsRepository)     = StartMonitoringUseCase(r)
    @Provides fun provideStopMonitoring(r: SettingsRepository)      = StopMonitoringUseCase(r)
    @Provides fun provideSaveRecording(r: RecordingRepository)      = SaveRecordingUseCase(r)
    @Provides fun provideGetRecordings(r: RecordingRepository)      = GetAllRecordingsUseCase(r)
    @Provides fun provideSaveIntruder(r: RecordingRepository)       = SaveIntruderPhotoUseCase(r)
    @Provides fun provideGetIntruder(r: RecordingRepository)        = GetIntruderPhotosUseCase(r)
    @Provides fun provideDeleteRecording(r: RecordingRepository)    = DeleteRecordingUseCase(r)
    @Provides fun provideDeleteIntruder(r: RecordingRepository)     = DeleteIntruderPhotoUseCase(r)
    @Provides fun provideCleanup(r: RecordingRepository)            = CleanupOldRecordingsUseCase(r)
    @Provides fun provideHourlyActivity(r: RecordingRepository)     = GetHourlyActivityUseCase(r)
    @Provides fun provideStorageStats(r: RecordingRepository)       = GetStorageStatsUseCase(r)
}
