package com.husseindev.sentinelprotocol.camera

import android.content.Context
import android.os.Environment
import android.util.Log
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.video.VideoCapture
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.husseindev.sentinelprotocol.camera.analysis.FaceDetectionAnalyzer
import com.husseindev.sentinelprotocol.camera.analysis.PersonDetectionAnalyzer
import com.husseindev.sentinelprotocol.core.constants.AppConstants
import com.husseindev.sentinelprotocol.domain.model.*
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Camera Engine
//  CameraX + ML Kit Face & Pose Detection
//  30-Second Smart Pre-Event Buffer
//  برمجة حسين حميد
// ══════════════════════════════════════════

@Singleton
class CameraEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val bufferManager: VideoBufferManager
) {
    private val TAG = "CameraEngine"

    // ── State ─────────────────────────────
    private val _detectionState   = MutableStateFlow<DetectionResult?>(null)
    val detectionState: StateFlow<DetectionResult?> = _detectionState

    private val _isRecording      = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording

    private val _monitoringActive = MutableStateFlow(false)
    val monitoringActive: StateFlow<Boolean> = _monitoringActive

    // ── Camera internals ──────────────────
    private var cameraProvider    : ProcessCameraProvider? = null
    private var videoCapture      : VideoCapture<Recorder>? = null
    private var activeRecording   : Recording? = null
    private var imageCapture      : ImageCapture? = null

    // Two executors: one for faces, one for persons (parallel analysis)
    private val faceExecutor      : ExecutorService = Executors.newSingleThreadExecutor()
    private val personExecutor    : ExecutorService = Executors.newSingleThreadExecutor()
    private val scope             = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // ── Pre-event buffer state ────────────
    private var preBufferFile     : File? = null
    private var preBufferJob      : Job? = null
    private var postDetectionJob  : Job? = null
    private var eventDetectedOnce = false
    private var onRecordingCompleteCb: (File) -> Unit = {}

    // ── Post-detection countdown ──────────
    private val postDetectionTicks = (AppConstants.POST_DETECTION_SECONDS * 30).toInt()
    private var noDetectionCount  = 0

    // Output directories
    private val outputDir: File get() {
        val dir = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "SentinelProtocol")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }
    private val preBufferDir: File get() {
        val dir = File(context.cacheDir, AppConstants.PREBUFFER_DIR)
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    // ── Bind Camera ───────────────────────
    fun bindCamera(
        lifecycleOwner      : LifecycleOwner,
        facing              : CameraFacing        = CameraFacing.BACK,
        sensitivity         : SensitivityLevel    = SensitivityLevel.MEDIUM,
        preview             : Preview?            = null,
        onRecordingComplete : (File) -> Unit      = {}
    ) {
        onRecordingCompleteCb = onRecordingComplete
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)

        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
            val selector = if (facing == CameraFacing.BACK)
                CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA

            // ── Video capture setup ───────
            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.fromOrderedList(
                        listOf(Quality.FHD, Quality.HD, Quality.SD),
                        FallbackStrategy.higherQualityOrLowerThan(Quality.SD)
                    )
                ).build()
            videoCapture = VideoCapture.withOutput(recorder)

            // ── Image capture (intruder selfie) ──
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            // ── Face analysis use case ────────────
            val faceAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                .build().also { ia ->
                    ia.setAnalyzer(faceExecutor, FaceDetectionAnalyzer(
                        sensitivity   = sensitivity,
                        onDetection   = { result -> handleDetection(result) },
                        onNoDetection = { handleNoDetection() }
                    ))
                }

            // ── Pose/person analysis use case ─────
            val personAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                .build().also { ia ->
                    ia.setAnalyzer(personExecutor, PersonDetectionAnalyzer(
                        sensitivity  = sensitivity,
                        onDetection  = { result -> handleDetection(result) },
                        onNoDetection = { /* faces take priority for no-detection */ }
                    ))
                }

            try {
                cameraProvider?.unbindAll()
                val useCases = mutableListOf<UseCase>(
                    faceAnalysis, personAnalysis, videoCapture!!, imageCapture!!
                )
                preview?.let { useCases.add(0, it) }
                cameraProvider?.bindToLifecycle(lifecycleOwner, selector, *useCases.toTypedArray())
                Log.d(TAG, "Camera bound — facing: $facing, sensitivity: $sensitivity")
            } catch (e: Exception) {
                Log.e(TAG, "Camera bind failed: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(context))
    }

    // ── Detection Handler ─────────────────
    private fun handleDetection(incoming: DetectionResult) {
        // Merge new detection with existing state
        val current = _detectionState.value
        val merged = DetectionResult(
            faces       = if (incoming.faces.isNotEmpty()) incoming.faces else current?.faces ?: emptyList(),
            persons     = if (incoming.persons.isNotEmpty()) incoming.persons else current?.persons ?: emptyList(),
            timestamp   = incoming.timestamp,
            imageWidth  = incoming.imageWidth,
            imageHeight = incoming.imageHeight
        )
        _detectionState.value = merged
        noDetectionCount = 0

        if (_monitoringActive.value && !_isRecording.value) {
            // Detection happened during pre-buffer: keep the current pre-buffer file
            // and continue recording (it already has pre-event footage)
            eventDetectedOnce = true
            preBufferJob?.cancel()  // Don't rotate/discard this file
            Log.d(TAG, "Detection triggered — continuing with pre-buffer recording")
        }
    }

    // ── No-Detection Handler ──────────────
    private fun handleNoDetection() {
        if (_isRecording.value) {
            noDetectionCount++
            if (noDetectionCount >= postDetectionTicks) {
                Log.d(TAG, "No detection timeout — finalizing recording")
                val fileToSave = preBufferFile
                stopRecordingAndSave(fileToSave)
                noDetectionCount = 0
                eventDetectedOnce = false
                // Restart pre-buffer after short delay
                scope.launch {
                    delay(1000)
                    if (_monitoringActive.value) startPreBuffer()
                }
            }
        }
    }

    // ── Activate / Deactivate Monitoring ──
    fun setMonitoringActive(active: Boolean) {
        _monitoringActive.value = active
        if (active) {
            startPreBuffer()
        } else {
            preBufferJob?.cancel()
            postDetectionJob?.cancel()
            val tempFile = preBufferFile
            stopRecording()
            // Discard if no event was detected
            if (!eventDetectedOnce) tempFile?.delete()
            eventDetectedOnce = false
            preBufferFile = null
        }
    }

    // ── Pre-Event Buffer (30 seconds) ─────
    private fun startPreBuffer() {
        if (_isRecording.value) return
        preBufferFile = createOutputFile(preBufferDir, "prebuf")
        startRecordingToFile(preBufferFile!!)
        Log.d(TAG, "Pre-buffer started: ${preBufferFile?.name}")

        // Auto-rotate after 30 seconds if no event detected
        preBufferJob?.cancel()
        preBufferJob = scope.launch {
            delay(AppConstants.PRE_BUFFER_ROTATE_MS)
            if (_isRecording.value && !eventDetectedOnce) {
                Log.d(TAG, "Pre-buffer rotating — no event detected")
                val old = preBufferFile
                stopRecording()
                old?.delete()
                delay(500)
                if (_monitoringActive.value) startPreBuffer()
            }
        }
    }

    // ── Recording Internals ───────────────
    private fun createOutputFile(dir: File, prefix: String): File {
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "${prefix}_${System.currentTimeMillis()}.mp4")
    }

    private fun startRecordingToFile(file: File) {
        val vc = videoCapture ?: return
        if (_isRecording.value) return
        val outputOptions = FileOutputOptions.Builder(file).build()
        activeRecording = vc.output
            .prepareRecording(context, outputOptions)
            .withAudioEnabled()
            .start(faceExecutor) { event ->
                when (event) {
                    is VideoRecordEvent.Start    -> _isRecording.value = true
                    is VideoRecordEvent.Finalize -> {
                        _isRecording.value = false
                        if (event.hasError()) {
                            Log.e(TAG, "Recording error: ${event.error}")
                            file.delete()
                        }
                    }
                    else -> {}
                }
            }
    }

    // Public: manual recording start (from MonitoringScreen)
    fun startRecording(isEmergency: Boolean = false, onComplete: (File) -> Unit = {}) {
        val outFile = createOutputFile(outputDir, "sentinel")
        preBufferFile = outFile
        onRecordingCompleteCb = onComplete
        startRecordingToFile(outFile)
    }

    private fun stopRecordingAndSave(file: File?) {
        stopRecording()
        if (file != null && file.exists() && file.length() > 0) {
            // Move from pre-buffer dir to output dir
            val dest = createOutputFile(outputDir, "sentinel")
            if (file.renameTo(dest)) {
                onRecordingCompleteCb(dest)
                Log.d(TAG, "Recording saved: ${dest.name}")
            } else {
                onRecordingCompleteCb(file)
            }
        }
    }

    fun stopRecording() {
        activeRecording?.stop()
        activeRecording = null
    }

    // ── Intruder Selfie ───────────────────
    fun captureIntruderSelfie(attemptNumber: Int, onCaptured: (File) -> Unit) {
        val ic = imageCapture ?: return
        val dir = File(context.filesDir, AppConstants.INTRUDER_DIR).also { it.mkdirs() }
        val file = File(dir, "intruder_${System.currentTimeMillis()}.jpg")
        val opts = ImageCapture.OutputFileOptions.Builder(file).build()
        ic.takePicture(opts, faceExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) { onCaptured(file) }
            override fun onError(exc: ImageCaptureException) {
                Log.e(TAG, "Intruder selfie error: ${exc.message}")
            }
        })
    }

    fun unbind() {
        stopRecording()
        cameraProvider?.unbindAll()
    }

    fun shutdown() {
        unbind()
        preBufferJob?.cancel()
        postDetectionJob?.cancel()
        faceExecutor.shutdown()
        personExecutor.shutdown()
        scope.cancel()
    }
}
