# 📦 PDF Studio Pro — دليل البناء

## ⚡ متطلبات
- Android Studio Hedgehog 2023.1.1 أو أحدث
- JDK 11+
- Android SDK 34

## 🚀 خطوات البناء

### 1. افتح المشروع
```
File → Open → اختر مجلد PDFStudio
```

### 2. انتظر Gradle Sync
سيقوم Android Studio بتحميل جميع المكتبات تلقائياً (~2-3 دقائق).

### 3. بناء APK Debug
```
Build → Build APK(s) → Build APK(s)
```
مكان الملف: `app/build/outputs/apk/debug/app-debug.apk`

### 4. بناء APK Release (بدون توقيع)
```
Build → Build APK(s) → Build APK(s)  [بعد تغيير buildType لـ release]
```

---

## 🏗️ هيكل المشروع

```
PDFStudio/
├── app/src/main/
│   ├── java/com/hussein/pdfstudio/
│   │   ├── MainActivity.kt              ← نقطة الدخول
│   │   ├── data/
│   │   │   ├── model/Models.kt          ← نماذج البيانات
│   │   │   ├── db/AppDatabase.kt        ← Room Database
│   │   │   ├── db/NotebookDao.kt        ← DAOs
│   │   │   └── repository/             ← Repository layer
│   │   ├── utils/
│   │   │   ├── PdfCreator.kt           ★ صور→PDF (بدون ضغط)
│   │   │   ├── PdfRendererUtil.kt      ★ PDF→صور (جودة عالية)
│   │   │   └── FileHelper.kt           ← مساعد الملفات
│   │   ├── viewmodel/                  ← ViewModels
│   │   └── ui/
│   │       ├── theme/                  ← Material 3 Dark Theme
│   │       ├── navigation/NavGraph.kt  ← التنقل
│   │       ├── components/             ← مكونات قابلة للإعادة
│   │       └── screens/               ← الشاشات الأربع
│   ├── res/                            ← الموارد
│   └── AndroidManifest.xml
└── build.gradle.kts
```

---

## ★ لماذا لا يوجد ضغط أو بكسلة؟

### في PdfCreator.kt (صور→PDF):
```kotlin
BitmapFactory.Options().apply {
    inSampleSize = 1                     // ← كامل الدقة
    inPreferredConfig = ARGB_8888        // ← كامل الألوان (4 بايت/بكسل)
    inScaled = false                     // ← بدون تكييف الكثافة
}
// رسم مباشر 1:1 على صفحة PDF بنفس حجم الصورة
canvas.drawBitmap(bitmap, left, top, Paint(ANTI_ALIAS_FLAG or FILTER_BITMAP_FLAG))
```

### في PdfRendererUtil.kt (PDF→صور):
```kotlin
val scale = 3.0f  // ← 288 DPI (3× دقة الشاشة)
// الحفظ كـ PNG (lossless — بدون أي فقدان)
bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
```

---

## 📱 الشاشات الأربع

| الشاشة | الوظيفة |
|--------|---------|
| 🏠 الرئيسية | لوحة تحكم مع أيقونات الأدوات |
| 🖼️ صور→PDF | رفع صور + ترتيب + إعدادات + تحويل |
| 📄 PDF→صور | رفع PDF + جودة + حذف صفحات + تحويل |
| 📓 الدفاتر | إنشاء/حذف/تسمية دفاتر + تصدير PDF |
