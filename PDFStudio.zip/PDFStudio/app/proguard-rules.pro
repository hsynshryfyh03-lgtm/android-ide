# PDFStudio ProGuard rules

# Keep data model classes
-keep class com.hussein.pdfstudio.data.model.** { *; }

# Room
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.**

# Kotlin coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembernames class kotlinx.** { volatile <fields>; }

# Coil
-dontwarn coil.**

# Keep Compose
-keep class androidx.compose.** { *; }
