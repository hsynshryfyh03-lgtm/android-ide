package com.hussein.pdfstudio.ui.theme

import androidx.compose.ui.graphics.Color

// ─── Dark palette ─────────────────────────────────────────────────────────────
val Bg0       = Color(0xFF0D0D14)
val Bg1       = Color(0xFF12121D)
val Bg2       = Color(0xFF1A1A28)
val BgCard    = Color(0xFF16162A)
val BgSurface = Color(0xFF1E1E30)

// ─── Brand ────────────────────────────────────────────────────────────────────
val Primary      = Color(0xFFA78BFA)   // violet-400
val PrimaryDark  = Color(0xFF7C3AED)   // violet-600
val PrimaryLight = Color(0xFFC4B5FD)  // violet-300
val Accent       = Color(0xFF60A5FA)   // blue-400
val AccentGreen  = Color(0xFF34D399)   // emerald-400
val AccentPink   = Color(0xFFF472B6)   // pink-400
val AccentAmber  = Color(0xFFFBBF24)   // amber-400

// ─── Status ───────────────────────────────────────────────────────────────────
val Success = Color(0xFF10B981)
val Error   = Color(0xFFEF4444)
val Warning = Color(0xFFF59E0B)
val Info    = Color(0xFF3B82F6)

// ─── Text ─────────────────────────────────────────────────────────────────────
val TextPrimary   = Color(0xFFE2E8F0)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary  = Color(0xFF475569)

// ─── Borders ──────────────────────────────────────────────────────────────────
val Border        = Color(0x14FFFFFF)
val BorderLight   = Color(0x20FFFFFF)
