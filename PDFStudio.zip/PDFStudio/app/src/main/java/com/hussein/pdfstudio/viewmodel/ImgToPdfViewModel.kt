package com.hussein.pdfstudio.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hussein.pdfstudio.data.model.*
import com.hussein.pdfstudio.utils.FileHelper
import com.hussein.pdfstudio.utils.PdfCreator
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File

class ImgToPdfViewModel(app: Application) : AndroidViewModel(app) {

    // ── Selected images list ──────────────────────────────────────────────────
    private val _images = MutableStateFlow<List<SelectedImage>>(emptyList())
    val images: StateFlow<List<SelectedImage>> = _images.asStateFlow()

    // ── Settings ──────────────────────────────────────────────────────────────
    private val _settings = MutableStateFlow(PdfSettings())
    val settings: StateFlow<PdfSettings> = _settings.asStateFlow()

    // ── Conversion state ──────────────────────────────────────────────────────
    private val _result = MutableStateFlow<ConversionResult>(ConversionResult.Idle)
    val result: StateFlow<ConversionResult> = _result.asStateFlow()

    // ── Actions ───────────────────────────────────────────────────────────────

    fun addImages(uris: List<Uri>) {
        val context = getApplication<Application>()
        val newItems = uris.map { uri ->
            SelectedImage(uri = uri, displayName = FileHelper.getFileName(context, uri))
        }
        _images.value = _images.value + newItems
    }

    fun removeImage(id: String) {
        _images.value = _images.value.filter { it.id != id }
    }

    fun reorderImages(from: Int, to: Int) {
        val list = _images.value.toMutableList()
        if (from < 0 || to < 0 || from >= list.size || to >= list.size) return
        val item = list.removeAt(from)
        list.add(to, item)
        _images.value = list
    }

    fun clearAll() {
        _images.value = emptyList()
        _result.value = ConversionResult.Idle
    }

    fun updateSettings(newSettings: PdfSettings) {
        _settings.value = newSettings
    }

    fun convert() {
        val uris = _images.value.map { it.uri }
        if (uris.isEmpty()) return
        viewModelScope.launch {
            _result.value = ConversionResult.Progress(0, uris.size, "بدء التحويل...")
            try {
                val context = getApplication<Application>()
                val outDir  = context.cacheDir
                val outName = "PDF_${FileHelper.timestamp()}.pdf"
                val path = PdfCreator.imagesToPdf(
                    context   = context,
                    images    = uris,
                    settings  = _settings.value,
                    outputDir = outDir,
                    fileName  = outName,
                    onProgress = { cur, tot, msg ->
                        _result.value = ConversionResult.Progress(cur, tot, msg)
                    }
                )
                _result.value = ConversionResult.Success(path, uris.size)
            } catch (e: Exception) {
                _result.value = ConversionResult.Failure(e.message ?: "خطأ غير معروف")
            }
        }
    }

    fun resetResult() { _result.value = ConversionResult.Idle }
}
