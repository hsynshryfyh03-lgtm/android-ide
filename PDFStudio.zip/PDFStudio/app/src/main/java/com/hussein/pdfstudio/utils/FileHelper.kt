package com.hussein.pdfstudio.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

object FileHelper {

    fun getNotebooksDir(context: Context): File =
        File(context.filesDir, "notebooks").also { it.mkdirs() }

    fun getNotebookDir(context: Context, notebookId: Long): File =
        File(getNotebooksDir(context), "nb_$notebookId").also { it.mkdirs() }

    fun sharePdf(context: Context, pdfPath: String, chooserTitle: String = "مشاركة PDF") {
        val file = File(pdfPath)
        val uri  = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, chooserTitle))
    }

    fun shareImages(context: Context, imagePaths: List<String>) {
        val uris = imagePaths.map { path ->
            FileProvider.getUriForFile(
                context, "${context.packageName}.fileprovider", File(path)
            )
        }
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "image/png"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "مشاركة الصور"))
    }

    fun formatFileSize(bytes: Long): String = when {
        bytes < 1024L        -> "$bytes B"
        bytes < 1024L * 1024 -> String.format("%.1f KB", bytes / 1024f)
        else                 -> String.format("%.2f MB", bytes / (1024f * 1024f))
    }

    fun getFileName(context: Context, uri: Uri): String {
        var name = "ملف"
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && idx >= 0) name = cursor.getString(idx)
        }
        return name
    }

    fun getFileSize(context: Context, uri: Uri): Long {
        var size = 0L
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst() && idx >= 0) size = cursor.getLong(idx)
        }
        return size
    }

    fun timestamp(): String =
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())

    fun cleanOldCacheFiles(context: Context) {
        try {
            context.cacheDir.listFiles()?.forEach { file ->
                if (file.name.startsWith("PDF_") || file.name.startsWith("temp_")) {
                    file.delete()
                }
                if (file.isDirectory && file.name.startsWith("pdf_export_")) {
                    file.deleteRecursively()
                }
            }
        } catch (_: Exception) {}
    }
}
