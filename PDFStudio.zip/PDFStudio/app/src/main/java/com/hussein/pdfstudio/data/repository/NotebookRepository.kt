package com.hussein.pdfstudio.data.repository

import android.content.Context
import com.hussein.pdfstudio.data.db.AppDatabase
import com.hussein.pdfstudio.data.model.Notebook
import com.hussein.pdfstudio.data.model.NotebookImage
import kotlinx.coroutines.flow.Flow

class NotebookRepository(context: Context) {

    private val db      = AppDatabase.getInstance(context)
    private val nbDao   = db.notebookDao()
    private val imgDao  = db.notebookImageDao()

    // ── Notebooks ──────────────────────────────────────────────────────────
    fun getAllNotebooks(): Flow<List<Notebook>> = nbDao.getAllNotebooks()

    suspend fun getNotebookById(id: Long): Notebook? = nbDao.getNotebookById(id)

    suspend fun createNotebook(name: String, colorHex: String): Long =
        nbDao.insertNotebook(Notebook(name = name, colorHex = colorHex))

    suspend fun renameNotebook(id: Long, newName: String) =
        nbDao.renameNotebook(id, newName)

    suspend fun deleteNotebook(id: Long) = nbDao.deleteNotebook(id)

    // ── Images ─────────────────────────────────────────────────────────────
    fun getImagesForNotebook(notebookId: Long): Flow<List<NotebookImage>> =
        imgDao.getImagesForNotebook(notebookId)

    suspend fun getImagesSync(notebookId: Long): List<NotebookImage> =
        imgDao.getImagesForNotebookSync(notebookId)

    suspend fun addImageToNotebook(notebookId: Long, filePath: String) {
        val count = imgDao.getCountForNotebook(notebookId)
        imgDao.insertImage(
            NotebookImage(notebookId = notebookId, filePath = filePath, orderIndex = count)
        )
        nbDao.updateImageCount(notebookId, count + 1)
    }

    suspend fun addImagesToNotebook(notebookId: Long, filePaths: List<String>) {
        val existingCount = imgDao.getCountForNotebook(notebookId)
        val images = filePaths.mapIndexed { i, path ->
            NotebookImage(notebookId = notebookId, filePath = path, orderIndex = existingCount + i)
        }
        imgDao.insertImages(images)
        nbDao.updateImageCount(notebookId, existingCount + filePaths.size)
    }

    suspend fun deleteImageFromNotebook(image: NotebookImage, notebookId: Long) {
        imgDao.deleteImage(image.id)
        val newCount = imgDao.getCountForNotebook(notebookId)
        nbDao.updateImageCount(notebookId, newCount)
        // Delete physical file
        try { java.io.File(image.filePath).delete() } catch (_: Exception) {}
    }

    suspend fun reorderImages(images: List<NotebookImage>) {
        images.forEachIndexed { index, img ->
            imgDao.updateOrder(img.id, index)
        }
    }
}
