package com.hussein.pdfstudio.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import com.hussein.pdfstudio.data.model.*
import com.hussein.pdfstudio.ui.components.*
import com.hussein.pdfstudio.ui.theme.*
import com.hussein.pdfstudio.utils.FileHelper
import com.hussein.pdfstudio.viewmodel.ImgToPdfViewModel

@Composable
fun ImgToPdfScreen(
    viewModel: ImgToPdfViewModel,
    onBack: () -> Unit
) {
    val context  = LocalContext.current
    val images   by viewModel.images.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val result   by viewModel.result.collectAsState()

    // Show success dialog
    var showSuccess by remember { mutableStateOf(false) }
    var successPath by remember { mutableStateOf("") }

    // Pickers
    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> -> if (uris.isNotEmpty()) viewModel.addImages(uris) }

    LaunchedEffect(result) {
        if (result is ConversionResult.Success) {
            successPath  = (result as ConversionResult.Success).filePath
            showSuccess  = true
        }
    }

    GradientBackground {
        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                // Top bar
                AppTopBar(title = "صور → PDF", onBack = onBack) {
                    if (images.isNotEmpty()) {
                        GlassIconButton(Icons.Default.DeleteSweep, onClick = { viewModel.clearAll() }, tint = Error)
                    }
                }

                Column(
                    Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {

                    if (images.isEmpty()) {
                        // ── Empty state ─────────────────────────────────────
                        UploadDropZone(
                            title      = "اختر صوراً للتحويل",
                            subtitle   = "JPEG • PNG • WEBP • أي تنسيق صورة",
                            buttonText = "اختر الصور",
                            icon       = Icons.Default.AddPhotoAlternate,
                            onClick    = { imagePicker.launch("image/*") }
                        )
                    } else {
                        // ── Gallery stats ────────────────────────────────────
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                Modifier
                                    .clip(RoundedCornerShape(50.dp))
                                    .background(BgCard)
                                    .border(1.dp, Border, RoundedCornerShape(50.dp))
                                    .padding(horizontal = 14.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Image, null, tint = PrimaryLight, modifier = Modifier.size(16.dp))
                                Text("${images.size} صورة", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SmallButton("إضافة المزيد", Icons.Default.Add) { imagePicker.launch("image/*") }
                            }
                        }

                        // ── Images grid ──────────────────────────────────────
                        LazyVerticalGrid(
                            columns    = GridCells.Fixed(3),
                            modifier   = Modifier.heightIn(max = 400.dp),
                            userScrollEnabled = true,
                            contentPadding = PaddingValues(0.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement   = Arrangement.spacedBy(8.dp),
                        ) {
                            itemsIndexed(images, key = { _, img -> img.id }) { index, img ->
                                ImageGridItem(
                                    uri     = img.uri,
                                    number  = index + 1,
                                    onDelete = { viewModel.removeImage(img.id) }
                                )
                            }
                        }

                        // ── Settings card ─────────────────────────────────────
                        SettingsCard(settings = settings, onChange = viewModel::updateSettings)

                        // ── Convert button ────────────────────────────────────
                        GradientButton(
                            text      = "تحويل إلى PDF  ⚡",
                            onClick   = { viewModel.convert() },
                            modifier  = Modifier.fillMaxWidth(),
                            enabled   = images.isNotEmpty(),
                            isLoading = result is ConversionResult.Progress,
                            icon      = Icons.Default.PictureAsPdf
                        )
                    }
                    Spacer(Modifier.navigationBarsPadding())
                }
            }

            // ── Progress overlay ──────────────────────────────────────────────
            if (result is ConversionResult.Progress) {
                val p = result as ConversionResult.Progress
                ProgressOverlay(p.current, p.total, p.message)
            }
        }
    }

    // ── Success dialog ────────────────────────────────────────────────────────
    if (showSuccess) {
        AlertDialog(
            onDismissRequest = { showSuccess = false; viewModel.resetResult() },
            containerColor   = Bg1,
            shape            = RoundedCornerShape(20.dp),
            title = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF064E3B)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.CheckCircle, null, tint = AccentGreen, modifier = Modifier.size(32.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("تم التحويل بنجاح!", color = TextPrimary, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Text("تم إنشاء ملف PDF بجودة أصلية كاملة بدون أي ضغط أو بكسلة.",
                    color = TextSecondary, fontSize = 14.sp)
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = {
                        FileHelper.sharePdf(context, successPath)
                    }) { Text("مشاركة", color = Primary) }
                    Button(
                        onClick = { showSuccess = false; viewModel.resetResult(); viewModel.clearAll() },
                        colors  = ButtonDefaults.buttonColors(containerColor = Primary)
                    ) { Text("تحويل جديد") }
                }
            }
        )
    }

    // Error snackbar
    if (result is ConversionResult.Failure) {
        LaunchedEffect(result) {
            kotlinx.coroutines.delay(3000)
            viewModel.resetResult()
        }
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            Box(Modifier.padding(bottom = 24.dp).navigationBarsPadding()) {
                ToastMessage((result as ConversionResult.Failure).error, isError = true)
            }
        }
    }
}

@Composable
private fun ImageGridItem(uri: Uri, number: Int, onDelete: () -> Unit) {
    Box(
        Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(10.dp))
            .background(Bg2)
            .border(1.dp, Border, RoundedCornerShape(10.dp))
    ) {
        AsyncImage(
            model            = uri,
            contentDescription = null,
            contentScale     = ContentScale.Crop,
            modifier         = Modifier.fillMaxSize()
        )
        // Number badge (top end)
        Box(
            Modifier
                .align(Alignment.TopEnd)
                .padding(5.dp)
                .size(22.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Primary, PrimaryDark))),
            contentAlignment = Alignment.Center
        ) {
            Text(number.toString(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        // Delete button (top start)
        Box(
            Modifier
                .align(Alignment.TopStart)
                .padding(5.dp)
                .size(24.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Error)
                .clickable(onClick = onDelete),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Close, null, tint = Color.White, modifier = Modifier.size(14.dp))
        }
    }
}

@Composable
private fun SettingsCard(settings: PdfSettings, onChange: (PdfSettings) -> Unit) {
    StudioCard {
        SectionTitle("إعدادات الـ PDF", Icons.Default.Settings)
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {

            // Page size
            LabeledOption("حجم الصفحة") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PageSize.values().take(3).forEach { size ->
                        val sel = settings.pageSize == size
                        Box(
                            Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (sel) Primary else Bg2)
                                .border(1.dp, if (sel) Primary else Border, RoundedCornerShape(8.dp))
                                .clickable { onChange(settings.copy(pageSize = size)) }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(size.label, color = if (sel) Color.White else TextSecondary, fontSize = 12.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                }
            }

            // Page numbers
            ToggleRow(
                label   = "ترقيم الصفحات",
                icon    = Icons.Default.Tag,
                checked = settings.addPageNumbers,
                onToggle = { onChange(settings.copy(addPageNumbers = it)) }
            )

            // Grayscale
            ToggleRow(
                label   = "تحويل للرمادي",
                icon    = Icons.Default.InvertColors,
                checked = settings.grayscale,
                onToggle = { onChange(settings.copy(grayscale = it)) }
            )

            // Quality info badge (always lossless)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF064E3B).copy(.6f))
                    .border(1.dp, AccentGreen.copy(.3f), RoundedCornerShape(10.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.HighQuality, null, tint = AccentGreen, modifier = Modifier.size(20.dp))
                Column {
                    Text("جودة أصلية — بدون ضغط", color = AccentGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text("inSampleSize=1 • ARGB_8888 • بدون تقليص", color = AccentGreen.copy(.7f), fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun LabeledOption(label: String, content: @Composable () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(label, color = TextSecondary, fontSize = 12.sp)
        content()
    }
}

@Composable
private fun ToggleRow(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, checked: Boolean, onToggle: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(Bg2)
            .border(1.dp, if (checked) Primary.copy(.4f) else Border, RoundedCornerShape(10.dp))
            .clickable { onToggle(!checked) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = if (checked) PrimaryLight else TextSecondary, modifier = Modifier.size(18.dp))
            Text(label, color = if (checked) TextPrimary else TextSecondary, fontSize = 14.sp)
        }
        Switch(
            checked = checked, onCheckedChange = onToggle,
            colors  = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Primary, uncheckedTrackColor = Bg1)
        )
    }
}

@Composable
private fun SmallButton(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Bg2)
            .border(1.dp, Border, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = TextSecondary, modifier = Modifier.size(14.dp))
        Text(text, color = TextSecondary, fontSize = 12.sp)
    }
}
