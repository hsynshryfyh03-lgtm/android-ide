package com.hussein.pdfstudio.utils

import android.content.Context
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.provider.OpenableColumns
import com.hussein.pdfstudio.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

object PdfCreator {

    /**
     * Converts a list of image URIs to a single PDF file.
     *
     * ★ KEY: Images are drawn at NATIVE resolution with NO compression,
     *        NO downscaling, NO JPEG artifacts — pure lossless pixel rendering.
     *
     * @param onProgress callback with (current, total, message)
     * @return absolute path of the created PDF
     */
    suspend fun imagesToPdf(
        context: Context,
        images: List<Uri>,
        settings: PdfSettings,
        outputDir: File = context.cacheDir,
        fileName: String = "PDF_${System.currentTimeMillis()}.pdf",
        onProgress: (Int, Int, String) -> Unit = { _, _, _ -> }
    ): String = withContext(Dispatchers.IO) {

        val pdfDocument = PdfDocument()
        val total = images.size

        images.forEachIndexed { index, uri ->
            onProgress(index, total, "جارٍ معالجة الصورة ${index + 1} من $total...")

            // ── 1. Load bitmap at FULL quality (no downsampling) ─────────────
            val bitmap = loadFullQualityBitmap(context, uri, settings.grayscale)
                ?: return@forEachIndexed

            // ── 2. Calculate page dimensions ──────────────────────────────────
            val (pageW, pageH) = when (settings.pageSize) {
                PageSize.MATCH_IMAGE -> Pair(bitmap.width, bitmap.height)
                else -> Pair(settings.pageSize.widthPx, settings.pageSize.heightPx)
            }

            val marginPx = dpToPx(context, settings.marginDp)
            val drawW = pageW - marginPx * 2
            val drawH = pageH - marginPx * 2

            // ── 3. Scale bitmap to fit inside page keeping aspect ratio ───────
            val scaledBitmap = if (settings.pageSize == PageSize.MATCH_IMAGE) {
                bitmap  // 1:1 — no scaling at all
            } else {
                val scaleX = drawW.toFloat() / bitmap.width
                val scaleY = drawH.toFloat() / bitmap.height
                val scale  = minOf(scaleX, scaleY)
                if (scale >= 1f) bitmap   // image smaller than page — no scale up
                else Bitmap.createScaledBitmap(
                    bitmap,
                    (bitmap.width  * scale).toInt(),
                    (bitmap.height * scale).toInt(),
                    true  // bilinear filter — smooth downscale, NO pixelation
                )
            }

            // ── 4. Create PDF page ────────────────────────────────────────────
            val pageInfo = PdfDocument.PageInfo.Builder(pageW, pageH, index + 1).create()
            val page     = pdfDocument.startPage(pageInfo)
            val canvas   = page.canvas

            // White background
            canvas.drawColor(Color.WHITE)

            // Center image on page
            val left = marginPx + (drawW - scaledBitmap.width)  / 2f
            val top  = marginPx + (drawH - scaledBitmap.height) / 2f

            // ★ Paint with ANTI_ALIAS + FILTER_BITMAP = smoothest possible rendering
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            canvas.drawBitmap(scaledBitmap, left, top, paint)

            // ── 5. Page number ─────────────────────────────────────────────────
            if (settings.addPageNumbers) {
                drawPageNumber(canvas, index + 1, total, pageW, pageH, settings.numberPosition)
            }

            pdfDocument.finishPage(page)

            // Recycle scaled copy if different
            if (scaledBitmap !== bitmap) scaledBitmap.recycle()
            bitmap.recycle()
        }

        // ── 6. Save PDF ───────────────────────────────────────────────────────
        onProgress(total, total, "جارٍ حفظ الملف...")
        val outFile = File(outputDir, fileName)
        FileOutputStream(outFile).use { pdfDocument.writeTo(it) }
        pdfDocument.close()

        outFile.absolutePath
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Also accepts file paths (for Notebooks)
    // ─────────────────────────────────────────────────────────────────────────
    suspend fun pathsToPdf(
        context: Context,
        paths: List<String>,
        settings: PdfSettings,
        outputDir: File = context.cacheDir,
        fileName: String = "PDF_${System.currentTimeMillis()}.pdf",
        onProgress: (Int, Int, String) -> Unit = { _, _, _ -> }
    ): String {
        val uris = paths.map { android.net.Uri.fromFile(File(it)) }
        return imagesToPdf(context, uris, settings, outputDir, fileName, onProgress)
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Private helpers
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Loads bitmap at 100% native resolution.
     * NO inSampleSize, NO downscaling, ARGB_8888 = 4 bytes per pixel = full color depth.
     */
    private fun loadFullQualityBitmap(context: Context, uri: Uri, toGrayscale: Boolean): Bitmap? {
        return try {
            val options = BitmapFactory.Options().apply {
                inSampleSize        = 1                          // ← full resolution
                inPreferredConfig   = Bitmap.Config.ARGB_8888   // ← full color
                inScaled            = false                      // ← no density scaling
            }
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val bmp = BitmapFactory.decodeStream(stream, null, options)
                if (toGrayscale && bmp != null) toGrayscaleBitmap(bmp) else bmp
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun loadFullQualityBitmapFromPath(path: String, toGrayscale: Boolean): Bitmap? {
        return try {
            val options = BitmapFactory.Options().apply {
                inSampleSize      = 1
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inScaled          = false
            }
            val bmp = BitmapFactory.decodeFile(path, options)
            if (toGrayscale && bmp != null) toGrayscaleBitmap(bmp) else bmp
        } catch (e: Exception) { null }
    }

    private fun toGrayscaleBitmap(src: Bitmap): Bitmap {
        val gray = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(gray)
        val paint  = Paint()
        val matrix = ColorMatrix().apply { setSaturation(0f) }
        paint.colorFilter = ColorMatrixColorFilter(matrix)
        canvas.drawBitmap(src, 0f, 0f, paint)
        src.recycle()
        return gray
    }

    private fun drawPageNumber(
        canvas: Canvas, current: Int, total: Int,
        pageW: Int, pageH: Int, position: NumberPosition
    ) {
        val text = "$current / $total"
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color     = Color.argb(180, 80, 80, 80)
            textSize  = (pageH * 0.018f).coerceIn(24f, 48f)
            typeface  = Typeface.DEFAULT_BOLD
            textAlign = when (position) {
                NumberPosition.TOP_LEFT,    NumberPosition.BOTTOM_LEFT  -> Paint.Align.LEFT
                NumberPosition.TOP_RIGHT,   NumberPosition.BOTTOM_RIGHT -> Paint.Align.RIGHT
                NumberPosition.BOTTOM_CENTER -> Paint.Align.CENTER
            }
        }
        val margin = (pageH * 0.02f)
        val x = when (position) {
            NumberPosition.TOP_LEFT,    NumberPosition.BOTTOM_LEFT   -> margin
            NumberPosition.TOP_RIGHT,   NumberPosition.BOTTOM_RIGHT  -> pageW - margin
            NumberPosition.BOTTOM_CENTER -> pageW / 2f
        }
        val y = when (position) {
            NumberPosition.TOP_LEFT, NumberPosition.TOP_RIGHT -> margin + paint.textSize
            else -> pageH - margin
        }
        canvas.drawText(text, x, y, paint)
    }

    private fun dpToPx(context: Context, dp: Int): Int =
        (dp * context.resources.displayMetrics.density).toInt()

    fun getFileName(context: Context, uri: Uri): String {
        var name = "image"
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && idx >= 0) name = cursor.getString(idx)
        }
        return name
    }
}
