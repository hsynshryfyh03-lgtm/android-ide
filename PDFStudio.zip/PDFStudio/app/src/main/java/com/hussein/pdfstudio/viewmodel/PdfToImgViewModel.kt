package com.hussein.pdfstudio.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hussein.pdfstudio.data.model.ConversionResult
import com.hussein.pdfstudio.utils.FileHelper
import com.hussein.pdfstudio.utils.PdfRendererUtil
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class PdfFileInfo(
    val uri: Uri,
    val name: String,
    val size: Long,
    val pageCount: Int = 0,
)

data class PdfToImgSettings(
    val quality: RenderQuality = RenderQuality.ULTRA,
    val deleteEnabled: Boolean = false,
    val deleteFrom: Int = 1,
    val deleteTo: Int = 1,
)

enum class RenderQuality(val label: String, val description: String, val scale: Float) {
    STANDARD("عادية",  "~96 DPI",   1.0f),
    HIGH    ("عالية",   "~192 DPI",  2.0f),
    ULTRA   ("فائقة",   "~288 DPI — موصى به", 3.0f),
    MAX     ("أقصى",    "~384 DPI",  4.0f),
}

class PdfToImgViewModel(app: Application) : AndroidViewModel(app) {

    private val _fileInfo    = MutableStateFlow<PdfFileInfo?>(null)
    val fileInfo: StateFlow<PdfFileInfo?> = _fileInfo.asStateFlow()

    private val _settings    = MutableStateFlow(PdfToImgSettings())
    val settings: StateFlow<PdfToImgSettings> = _settings.asStateFlow()

    private val _result      = MutableStateFlow<ConversionResult>(ConversionResult.Idle)
    val result: StateFlow<ConversionResult> = _result.asStateFlow()

    private val _outputPaths = MutableStateFlow<List<String>>(emptyList())
    val outputPaths: StateFlow<List<String>> = _outputPaths.asStateFlow()

    // ── File selection ────────────────────────────────────────────────────────

    fun selectFile(uri: Uri) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            val name    = FileHelper.getFileName(context, uri)
            val size    = FileHelper.getFileSize(context, uri)
            _result.value = ConversionResult.Progress(0, 1, "جارٍ تحميل الملف...")
            val pages = PdfRendererUtil.getPageCount(context, uri)
            _fileInfo.value = PdfFileInfo(uri, name, size, pages)
            _result.value = ConversionResult.Idle
            _outputPaths.value = emptyList()
        }
    }

    fun clearFile() {
        _fileInfo.value  = null
        _result.value    = ConversionResult.Idle
        _outputPaths.value = emptyList()
    }

    fun updateSettings(new: PdfToImgSettings) { _settings.value = new }

    // ── Convert ───────────────────────────────────────────────────────────────

    fun convert() {
        val info = _fileInfo.value ?: return
        val s    = _settings.value
        viewModelScope.launch {
            val context = getApplication<Application>()
            _result.value = ConversionResult.Progress(0, info.pageCount, "بدء التحويل...")
            try {
                val deleteSet = if (s.deleteEnabled && s.deleteTo >= s.deleteFrom) {
                    (s.deleteFrom..s.deleteTo).toSet()
                } else emptySet()

                val paths = PdfRendererUtil.pdfToImages(
                    context     = context,
                    pdfUri      = info.uri,
                    scale       = s.quality.scale,
                    deletePages = deleteSet,
                    onProgress  = { cur, tot, msg ->
                        _result.value = ConversionResult.Progress(cur, tot, msg)
                    }
                )
                _outputPaths.value = paths
                _result.value = ConversionResult.Success(paths.firstOrNull() ?: "", paths.size)
            } catch (e: Exception) {
                _result.value = ConversionResult.Failure(e.message ?: "خطأ غير معروف")
            }
        }
    }

    fun resetResult() { _result.value = ConversionResult.Idle }
}
