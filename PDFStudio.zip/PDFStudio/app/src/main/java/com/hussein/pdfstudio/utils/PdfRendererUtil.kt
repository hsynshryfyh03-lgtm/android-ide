package com.hussein.pdfstudio.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

object PdfRendererUtil {

    data class PdfInfo(val pageCount: Int, val filePath: String)

    /**
     * Converts a PDF file to a list of PNG images.
     * Scale controls DPI: 1.0 = screen DPI (~96 DPI), 3.0 = 288 DPI (near-print quality)
     */
    suspend fun pdfToImages(
        context: Context,
        pdfUri: Uri,
        scale: Float = 3.0f,          // 3x = very high quality, no pixelation
        deletePages: Set<Int> = emptySet(),
        outputDir: File = File(context.cacheDir, "pdf_export_${System.currentTimeMillis()}"),
        onProgress: (Int, Int, String) -> Unit = { _, _, _ -> }
    ): List<String> = withContext(Dispatchers.IO) {

        outputDir.mkdirs()
        val resultPaths = mutableListOf<String>()

        // Copy URI to temp file (PdfRenderer needs a seekable file)
        val tempFile = File(context.cacheDir, "temp_input_${System.currentTimeMillis()}.pdf")
        context.contentResolver.openInputStream(pdfUri)?.use { input ->
            tempFile.outputStream().use { output -> input.copyTo(output) }
        }

        val pfd      = ParcelFileDescriptor.open(tempFile, ParcelFileDescriptor.MODE_READ_ONLY)
        val renderer = PdfRenderer(pfd)
        val total    = renderer.pageCount
        var savedIndex = 0

        for (pageIndex in 0 until total) {
            val pageNum = pageIndex + 1  // 1-based
            if (pageNum in deletePages) {
                onProgress(pageIndex + 1, total, "تخطي صفحة $pageNum (محذوفة)")
                continue
            }

            onProgress(pageIndex + 1, total, "جارٍ تحويل صفحة $pageNum من $total...")
            val page = renderer.openPage(pageIndex)

            // Calculate output size at desired scale
            val width  = (page.width  * scale).toInt()
            val height = (page.height * scale).toInt()

            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            // White background (PDF pages are transparent by default)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.WHITE)

            // Render at full quality
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()

            // Save as PNG (lossless — no compression artifacts)
            val outFile = File(outputDir, "page_${String.format("%04d", ++savedIndex)}.png")
            FileOutputStream(outFile).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            bitmap.recycle()
            resultPaths.add(outFile.absolutePath)
        }

        renderer.close()
        pfd.close()
        tempFile.delete()

        resultPaths
    }

    /** Returns page count of a PDF without rendering */
    suspend fun getPageCount(context: Context, uri: Uri): Int = withContext(Dispatchers.IO) {
        try {
            val tempFile = File(context.cacheDir, "count_temp_${System.currentTimeMillis()}.pdf")
            context.contentResolver.openInputStream(uri)?.use { input ->
                tempFile.outputStream().use { it2 -> input.copyTo(it2) }
            }
            val pfd      = ParcelFileDescriptor.open(tempFile, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(pfd)
            val count    = renderer.pageCount
            renderer.close()
            pfd.close()
            tempFile.delete()
            count
        } catch (e: Exception) { 0 }
    }

    /** Copies an image URI to internal storage and returns path */
    suspend fun copyUriToInternalStorage(context: Context, uri: Uri, dir: File): String? =
        withContext(Dispatchers.IO) {
            try {
                dir.mkdirs()
                val name = "img_${System.currentTimeMillis()}_${(0..9999).random()}.jpg"
                val dest = File(dir, name)
                context.contentResolver.openInputStream(uri)?.use { input ->
                    dest.outputStream().use { output -> input.copyTo(output) }
                }
                dest.absolutePath
            } catch (e: Exception) { null }
        }
}
