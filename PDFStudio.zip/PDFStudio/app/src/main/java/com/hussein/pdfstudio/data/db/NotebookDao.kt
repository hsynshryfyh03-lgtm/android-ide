package com.hussein.pdfstudio.data.db

import androidx.room.*
import com.hussein.pdfstudio.data.model.Notebook
import com.hussein.pdfstudio.data.model.NotebookImage
import kotlinx.coroutines.flow.Flow

@Dao
interface NotebookDao {

    // ─── Notebooks ────────────────────────────────────────────────────────────
    @Query("SELECT * FROM notebooks ORDER BY updatedAt DESC")
    fun getAllNotebooks(): Flow<List<Notebook>>

    @Query("SELECT * FROM notebooks WHERE id = :id")
    suspend fun getNotebookById(id: Long): Notebook?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotebook(notebook: Notebook): Long

    @Update
    suspend fun updateNotebook(notebook: Notebook)

    @Query("DELETE FROM notebooks WHERE id = :id")
    suspend fun deleteNotebook(id: Long)

    @Query("UPDATE notebooks SET name = :name, updatedAt = :updatedAt WHERE id = :id")
    suspend fun renameNotebook(id: Long, name: String, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE notebooks SET imageCount = :count, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateImageCount(id: Long, count: Int, updatedAt: Long = System.currentTimeMillis())
}

@Dao
interface NotebookImageDao {

    @Query("SELECT * FROM notebook_images WHERE notebookId = :notebookId ORDER BY orderIndex ASC")
    fun getImagesForNotebook(notebookId: Long): Flow<List<NotebookImage>>

    @Query("SELECT * FROM notebook_images WHERE notebookId = :notebookId ORDER BY orderIndex ASC")
    suspend fun getImagesForNotebookSync(notebookId: Long): List<NotebookImage>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertImage(image: NotebookImage): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertImages(images: List<NotebookImage>)

    @Query("DELETE FROM notebook_images WHERE id = :id")
    suspend fun deleteImage(id: Long)

    @Query("DELETE FROM notebook_images WHERE notebookId = :notebookId")
    suspend fun deleteAllImagesForNotebook(notebookId: Long)

    @Query("SELECT COUNT(*) FROM notebook_images WHERE notebookId = :notebookId")
    suspend fun getCountForNotebook(notebookId: Long): Int

    @Query("UPDATE notebook_images SET orderIndex = :orderIndex WHERE id = :id")
    suspend fun updateOrder(id: Long, orderIndex: Int)
}
