package com.hussein.pdfstudio.ui.navigation

sealed class Screen(val route: String) {
    object Home           : Screen("home")
    object ImgToPdf       : Screen("img_to_pdf")
    object PdfToImg       : Screen("pdf_to_img")
    object Notebooks      : Screen("notebooks")
    object NotebookDetail : Screen("notebook/{notebookId}") {
        fun createRoute(id: Long) = "notebook/$id"
    }
}
