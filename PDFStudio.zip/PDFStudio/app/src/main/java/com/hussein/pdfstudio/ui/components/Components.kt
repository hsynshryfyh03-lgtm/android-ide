package com.hussein.pdfstudio.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.hussein.pdfstudio.ui.theme.*

// ─── Gradient Background ──────────────────────────────────────────────────────
@Composable
fun GradientBackground(content: @Composable () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors  = listOf(Color(0xFF1E1B4B), Bg0),
                    radius  = 1800f
                )
            )
    ) { content() }
}

// ─── App Top Bar ──────────────────────────────────────────────────────────────
@Composable
fun AppTopBar(
    title: String,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Surface(
        color = Bg1,
        tonalElevation = 0.dp,
        shadowElevation = 0.dp
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .height(64.dp)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (onBack != null) {
                GlassIconButton(icon = Icons.Default.ArrowBack, onClick = onBack, tint = TextSecondary)
            } else {
                // Logo box
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Brush.linearGradient(listOf(Primary, AccentGreen))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PictureAsPdf, null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }
            Text(
                title,
                style     = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color     = TextPrimary,
                modifier  = Modifier.weight(1f)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { actions() }
        }
    }
}

// ─── Glass Icon Button ────────────────────────────────────────────────────────
@Composable
fun GlassIconButton(
    icon: ImageVector,
    onClick: () -> Unit,
    tint: Color = TextSecondary,
    size: Dp = 38.dp
) {
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(10.dp))
            .background(BgCard)
            .border(1.dp, Border, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp))
    }
}

// ─── Primary Gradient Button ──────────────────────────────────────────────────
@Composable
fun GradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    isLoading: Boolean = false
) {
    val alpha = if (enabled) 1f else 0.5f
    Box(
        modifier
            .height(52.dp)
            .clip(RoundedCornerShape(14.dp))
            .alpha(alpha)
            .background(
                if (enabled)
                    Brush.linearGradient(listOf(Primary, PrimaryDark))
                else
                    Brush.linearGradient(listOf(Bg2, Bg2))
            )
            .clickable(enabled = enabled && !isLoading, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                color = Color.White,
                strokeWidth = 2.dp,
                modifier = Modifier.size(24.dp)
            )
        } else {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (icon != null) Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
                Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            }
        }
    }
}

// ─── Card ─────────────────────────────────────────────────────────────────────
@Composable
fun StudioCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(BgCard)
            .border(1.dp, Border, RoundedCornerShape(14.dp))
            .padding(20.dp)
    ) { content() }
}

// ─── Section Title ────────────────────────────────────────────────────────────
@Composable
fun SectionTitle(text: String, icon: ImageVector? = null) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (icon != null) {
            Box(
                Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(Primary)
            )
        }
        Text(text, color = TextSecondary, style = MaterialTheme.typography.labelLarge)
    }
}

// ─── Progress Overlay ─────────────────────────────────────────────────────────
@Composable
fun ProgressOverlay(current: Int, total: Int, message: String) {
    val progress = if (total > 0) current.toFloat() / total else 0f
    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xCC000000)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Bg1)
                .border(1.dp, Border, RoundedCornerShape(20.dp))
                .padding(32.dp)
                .width(280.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Animated logo
            val infiniteTransition = rememberInfiniteTransition(label = "spin")
            val rotation by infiniteTransition.animateFloat(
                0f, 360f, InfiniteRepeatableSpec(tween(2000, easing = LinearEasing)),
                label = "rot"
            )
            Box(
                Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.linearGradient(listOf(Primary, AccentGreen)))
                    .rotate(rotation * 0.1f),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Autorenew, null, tint = Color.White, modifier = Modifier.size(32.dp).rotate(rotation))
            }

            Text("جارٍ المعالجة...", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(message, color = TextSecondary, fontSize = 13.sp, textAlign = TextAlign.Center)

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                    color    = Primary,
                    trackColor = Bg2,
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("$current / $total", color = TextTertiary, fontSize = 11.sp)
                    Text("${(progress * 100).toInt()}%", color = Primary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ─── Upload / Drop Zone ───────────────────────────────────────────────────────
@Composable
fun UploadDropZone(
    title: String,
    subtitle: String,
    buttonText: String,
    icon: ImageVector = Icons.Default.Upload,
    onClick: () -> Unit
) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x08FFFFFF))
            .border(2.dp, Brush.linearGradient(listOf(Primary.copy(alpha = .3f), AccentGreen.copy(alpha = .3f))), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(40.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(Bg2)
                    .border(1.dp, Border, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = PrimaryLight, modifier = Modifier.size(32.dp))
            }
            Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 17.sp, textAlign = TextAlign.Center)
            Text(subtitle, color = TextSecondary, fontSize = 13.sp, textAlign = TextAlign.Center)
            Box(
                Modifier
                    .clip(RoundedCornerShape(50.dp))
                    .background(Brush.linearGradient(listOf(Primary, PrimaryDark)))
                    .padding(horizontal = 28.dp, vertical = 12.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Text(buttonText, color = Color.White, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

// ─── Toast Snackbar ───────────────────────────────────────────────────────────
@Composable
fun ToastMessage(
    message: String,
    isError: Boolean = false,
    isSuccess: Boolean = false
) {
    val bg = when {
        isSuccess -> Color(0xFF064E3B)
        isError   -> Color(0xFF7F1D1D)
        else      -> Bg2
    }
    val border = when {
        isSuccess -> AccentGreen.copy(alpha = .5f)
        isError   -> Error.copy(alpha = .5f)
        else      -> Border
    }
    val icon = when {
        isSuccess -> Icons.Default.CheckCircle
        isError   -> Icons.Default.Error
        else      -> Icons.Default.Info
    }
    val iconColor = when {
        isSuccess -> AccentGreen
        isError   -> Error
        else      -> Accent
    }
    Row(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(12.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = iconColor, modifier = Modifier.size(20.dp))
        Text(message, color = TextPrimary, fontSize = 14.sp)
    }
}

// ─── Color picker row ─────────────────────────────────────────────────────────
val NB_COLORS = listOf(
    "#A78BFA", "#60A5FA", "#34D399", "#F472B6",
    "#FBBF24", "#F87171", "#818CF8", "#2DD4BF",
    "#FB923C", "#A3E635", "#E879F9", "#67E8F9"
)

@Composable
fun ColorPickerRow(selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        NB_COLORS.forEach { hex ->
            val color = Color(android.graphics.Color.parseColor(hex))
            Box(
                Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(color)
                    .border(
                        width  = if (selected == hex) 3.dp else 0.dp,
                        color  = Color.White,
                        shape  = CircleShape
                    )
                    .clickable { onSelect(hex) }
            ) {
                if (selected == hex) {
                    Icon(
                        Icons.Default.Check, null,
                        tint = Color.White,
                        modifier = Modifier.align(Alignment.Center).size(18.dp)
                    )
                }
            }
        }
    }
}
