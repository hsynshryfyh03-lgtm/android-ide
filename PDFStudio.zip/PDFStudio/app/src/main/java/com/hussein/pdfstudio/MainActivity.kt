package com.hussein.pdfstudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.material3.Surface
import com.hussein.pdfstudio.ui.navigation.AppNavGraph
import com.hussein.pdfstudio.ui.theme.PDFStudioTheme
import com.hussein.pdfstudio.ui.theme.Bg0

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PDFStudioTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color    = Bg0
                ) {
                    AppNavGraph()
                }
            }
        }
    }
}
