package com.hussein.pdfstudio.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import android.net.Uri

// ─── Notebook ─────────────────────────────────────────────────────────────────
@Entity(tableName = "notebooks")
data class Notebook(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val colorHex: String = "#A78BFA",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val imageCount: Int = 0,
)

// ─── Notebook Image ───────────────────────────────────────────────────────────
@Entity(
    tableName = "notebook_images",
    foreignKeys = [ForeignKey(
        entity = Notebook::class,
        parentColumns = ["id"],
        childColumns = ["notebookId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("notebookId")]
)
data class NotebookImage(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val notebookId: Long,
    val filePath: String,     // absolute path in internal storage
    val orderIndex: Int = 0,
    val addedAt: Long = System.currentTimeMillis(),
)

// ─── PDF Settings ─────────────────────────────────────────────────────────────
data class PdfSettings(
    val pageSize: PageSize   = PageSize.MATCH_IMAGE,
    val marginDp: Int        = 0,
    val addPageNumbers: Boolean = false,
    val numberPosition: NumberPosition = NumberPosition.BOTTOM_CENTER,
    val grayscale: Boolean   = false,
    val quality: ImageQuality = ImageQuality.LOSSLESS,
)

enum class PageSize(val label: String, val widthPx: Int, val heightPx: Int) {
    MATCH_IMAGE("مطابق للصورة", 0, 0),
    A4("A4 (210×297mm)", 2480, 3508),          // 300 DPI
    A4_LANDSCAPE("A4 أفقي", 3508, 2480),
    LETTER("Letter (215×279mm)", 2550, 3300),
    SQUARE_2K("مربع 2K", 2048, 2048),
}

enum class NumberPosition(val label: String) {
    TOP_LEFT("أعلى يسار"),
    TOP_RIGHT("أعلى يمين"),
    BOTTOM_LEFT("أسفل يسار"),
    BOTTOM_RIGHT("أسفل يمين"),
    BOTTOM_CENTER("أسفل وسط"),
}

enum class ImageQuality(val label: String, val description: String) {
    LOSSLESS("بدون ضغط", "جودة أصلية 100% – موصى به"),
    HIGH("عالية",        "حجم أصغر قليلاً"),
    MEDIUM("متوسطة",     "توازن جيد"),
    LOW("منخفضة",        "حجم ملف أصغر"),
}

// ─── Conversion Result ────────────────────────────────────────────────────────
sealed class ConversionResult {
    object Idle : ConversionResult()
    data class Progress(val current: Int, val total: Int, val message: String) : ConversionResult()
    data class Success(val filePath: String, val pageCount: Int) : ConversionResult()
    data class Failure(val error: String) : ConversionResult()
}

// ─── Selected Image (for Images→PDF) ─────────────────────────────────────────
data class SelectedImage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val uri: android.net.Uri,
    val displayName: String = "",
)
