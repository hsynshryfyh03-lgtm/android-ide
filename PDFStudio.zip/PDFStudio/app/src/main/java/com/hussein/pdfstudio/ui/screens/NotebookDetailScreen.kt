package com.hussein.pdfstudio.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import coil.compose.AsyncImage
import com.hussein.pdfstudio.data.model.ConversionResult
import com.hussein.pdfstudio.data.model.NotebookImage
import com.hussein.pdfstudio.ui.components.*
import com.hussein.pdfstudio.ui.theme.*
import com.hussein.pdfstudio.utils.FileHelper
import com.hussein.pdfstudio.viewmodel.NotebooksViewModel
import java.io.File

@Composable
fun NotebookDetailScreen(
    notebookId: Long,
    viewModel: NotebooksViewModel,
    onBack: () -> Unit
) {
    val context  = LocalContext.current
    val notebook by viewModel.currentNotebook.collectAsState()
    val images   by viewModel.notebookImages.collectAsState()
    val export   by viewModel.exportResult.collectAsState()

    var showExportSuccess by remember { mutableStateOf(false) }
    var exportPath        by remember { mutableStateOf("") }

    LaunchedEffect(notebookId) { viewModel.openNotebook(notebookId) }

    LaunchedEffect(export) {
        if (export is ConversionResult.Success) {
            exportPath       = (export as ConversionResult.Success).filePath
            showExportSuccess = true
        }
    }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris -> if (uris.isNotEmpty()) viewModel.addImagesToCurrentNotebook(uris) }

    val nb         = notebook
    val nbColor    = try { Color(android.graphics.Color.parseColor(nb?.colorHex ?: "#A78BFA")) } catch (_: Exception) { Primary }

    GradientBackground {
        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                // Top bar
                AppTopBar(title = nb?.name ?: "الدفتر", onBack = onBack) {
                    GlassIconButton(Icons.Default.AddPhotoAlternate, onClick = { imagePicker.launch("image/*") }, tint = PrimaryLight)
                    GlassIconButton(Icons.Default.Share, onClick = {
                        val paths = images.map { it.filePath }
                        if (paths.isNotEmpty()) FileHelper.shareImages(context, paths)
                    }, tint = Accent)
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Brush.linearGradient(listOf(Primary, PrimaryDark)))
                            .clickable { viewModel.exportToPdf() }
                            .padding(horizontal = 14.dp, vertical = 9.dp)
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PictureAsPdf, null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Text("تصدير PDF", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Color accent line
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .background(Brush.linearGradient(listOf(nbColor, nbColor.copy(.4f))))
                )

                if (images.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Box(
                                Modifier
                                    .size(80.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Bg2)
                                    .border(1.dp, Border, RoundedCornerShape(20.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.AddPhotoAlternate, null, tint = TextTertiary, modifier = Modifier.size(36.dp))
                            }
                            Text("الدفتر فارغ", color = TextSecondary, fontSize = 16.sp)
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(50.dp))
                                    .background(Brush.linearGradient(listOf(Primary, PrimaryDark)))
                                    .clickable { imagePicker.launch("image/*") }
                                    .padding(horizontal = 24.dp, vertical = 12.dp)
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Add, null, tint = Color.White)
                                    Text("إضافة صور", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                } else {
                    // Notebook header info
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        StatChip("${images.size} صورة", Icons.Default.Image, nbColor)
                        StatChip("جاهز للتصدير", Icons.Default.CheckCircle, AccentGreen)
                    }

                    LazyVerticalGrid(
                        columns   = GridCells.Fixed(3),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement   = Arrangement.spacedBy(8.dp),
                    ) {
                        itemsIndexed(images, key = { _, img -> img.id }) { index, img ->
                            NbImageCard(image = img, index = index, onDelete = { viewModel.deleteImageFromNotebook(img) })
                        }
                        item { Spacer(Modifier.navigationBarsPadding()) }
                    }
                }
            }

            // Progress
            if (export is ConversionResult.Progress) {
                val p = export as ConversionResult.Progress
                ProgressOverlay(p.current, p.total, p.message)
            }
        }
    }

    // Export success dialog
    if (showExportSuccess) {
        AlertDialog(
            onDismissRequest = { showExportSuccess = false; viewModel.resetExportResult() },
            containerColor   = Bg1,
            shape            = RoundedCornerShape(20.dp),
            title = {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, null, tint = AccentGreen, modifier = Modifier.size(28.dp))
                    Text("تم تصدير PDF بنجاح!", color = TextPrimary, fontWeight = FontWeight.Bold)
                }
            },
            text = { Text("ملف PDF جاهز بجودة أصلية.", color = TextSecondary) },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { FileHelper.sharePdf(context, exportPath) }) { Text("مشاركة", color = Primary) }
                    Button(
                        onClick = { showExportSuccess = false; viewModel.resetExportResult() },
                        colors  = ButtonDefaults.buttonColors(containerColor = Primary)
                    ) { Text("موافق") }
                }
            }
        )
    }
}

@Composable
private fun NbImageCard(image: NotebookImage, index: Int, onDelete: () -> Unit) {
    var confirmDelete by remember { mutableStateOf(false) }
    Box(
        Modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(10.dp))
            .background(Bg2)
            .border(1.dp, Border, RoundedCornerShape(10.dp))
    ) {
        AsyncImage(
            model  = File(image.filePath),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        // Index badge
        Box(
            Modifier
                .align(Alignment.TopEnd)
                .padding(5.dp)
                .size(22.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(.6f)),
            contentAlignment = Alignment.Center
        ) {
            Text((index + 1).toString(), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        // Delete
        Box(
            Modifier
                .align(Alignment.TopStart)
                .padding(5.dp)
                .size(24.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Error)
                .clickable { confirmDelete = true },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Close, null, tint = Color.White, modifier = Modifier.size(14.dp))
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor   = Bg1,
            shape            = RoundedCornerShape(16.dp),
            title = { Text("حذف الصورة؟", color = TextPrimary) },
            text  = { Text("سيتم حذف هذه الصورة من الدفتر نهائياً.", color = TextSecondary, fontSize = 14.sp) },
            confirmButton = {
                Button(onClick = { onDelete(); confirmDelete = false }, colors = ButtonDefaults.buttonColors(containerColor = Error)) {
                    Text("حذف")
                }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("إلغاء", color = TextSecondary) } }
        )
    }
}

@Composable
private fun StatChip(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color) {
    Row(
        Modifier
            .clip(RoundedCornerShape(50.dp))
            .background(color.copy(.12f))
            .border(1.dp, color.copy(.25f), RoundedCornerShape(50.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(14.dp))
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}
