package com.hussein.pdfstudio.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.hussein.pdfstudio.ui.components.GradientBackground
import com.hussein.pdfstudio.ui.components.StudioCard
import com.hussein.pdfstudio.ui.theme.*

@Composable
fun HomeScreen(
    onImgToPdf: () -> Unit,
    onPdfToImg: () -> Unit,
    onNotebooks: () -> Unit,
) {
    GradientBackground {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // ── Hero ─────────────────────────────────────────────────────────
            Column(
                Modifier.fillMaxWidth().padding(vertical = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val pulse = rememberInfiniteTransition(label = "pulse")
                val glow by pulse.animateFloat(
                    0.3f, 0.7f,
                    InfiniteRepeatableSpec(tween(2000), RepeatMode.Reverse),
                    label = "glow"
                )
                Box(
                    Modifier
                        .size(100.dp)
                        .clip(RoundedCornerShape(26.dp))
                        .background(Brush.linearGradient(listOf(Primary, AccentGreen)))
                        .shadow(24.dp, RoundedCornerShape(26.dp), spotColor = Primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PictureAsPdf, null, tint = Color.White, modifier = Modifier.size(50.dp))
                }
                Text(
                    "PDF Studio Pro",
                    color = TextPrimary, fontSize = 26.sp, fontWeight = FontWeight.Black
                )
                Text(
                    "أدوات PDF الاحترافية — كل شيء في مكان واحد",
                    color = TextSecondary, fontSize = 14.sp
                )
                // Badge
                Box(
                    Modifier
                        .clip(RoundedCornerShape(50.dp))
                        .background(Color(0xFF064E3B).copy(alpha = .8f))
                        .border(1.dp, AccentGreen.copy(.4f), RoundedCornerShape(50.dp))
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(AccentGreen).alpha(glow))
                        Text("جودة أصلية — بدون ضغط أو بكسلة", color = AccentGreen, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            // ── Feature Cards ─────────────────────────────────────────────────
            Text("الأدوات", color = TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)

            FeatureCard(
                icon         = Icons.Default.Image,
                title        = "صور → PDF",
                description  = "حوّل أي عدد من الصور إلى ملف PDF واحد بجودة أصلية كاملة",
                gradient     = listOf(Color(0xFF4F46E5), Color(0xFF7C3AED)),
                badge        = "بدون ضغط",
                badgeColor   = AccentGreen,
                onClick      = onImgToPdf
            )
            FeatureCard(
                icon         = Icons.Default.PictureAsPdf,
                title        = "PDF → صور",
                description  = "حوّل صفحات PDF إلى صور PNG عالية الدقة مع خيار حذف الصفحات",
                gradient     = listOf(Color(0xFF0369A1), Color(0xFF0E7490)),
                badge        = "دقة عالية",
                badgeColor   = Accent,
                onClick      = onPdfToImg
            )
            FeatureCard(
                icon         = Icons.Default.MenuBook,
                title        = "الدفاتر",
                description  = "نظّم صورك في دفاتر ملوّنة وصدّرها كـ PDF في أي وقت",
                gradient     = listOf(Color(0xFF065F46), Color(0xFF0F766E)),
                badge        = "تنظيم",
                badgeColor   = AccentGreen,
                onClick      = onNotebooks
            )

            // ── Info strip ────────────────────────────────────────────────────
            StudioCard {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    InfoItem("🚫 ضغط", "بدون أي ضغط")
                    InfoItem("📐 بكسلة", "صفر بكسلة")
                    InfoItem("🎨 لون", "ARGB_8888")
                    InfoItem("⚡ سرعة", "محسّن")
                }
            }

            Spacer(Modifier.navigationBarsPadding())
        }
    }
}

@Composable
private fun FeatureCard(
    icon: ImageVector,
    title: String,
    description: String,
    gradient: List<Color>,
    badge: String,
    badgeColor: Color,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(BgCard)
            .border(1.dp, Border, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(18.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Brush.linearGradient(gradient)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(28.dp))
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Box(
                    Modifier
                        .clip(RoundedCornerShape(50.dp))
                        .background(badgeColor.copy(.15f))
                        .border(1.dp, badgeColor.copy(.3f), RoundedCornerShape(50.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(badge, color = badgeColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            Text(description, color = TextSecondary, fontSize = 13.sp, lineHeight = 18.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = TextTertiary, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun InfoItem(emoji: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(emoji, fontSize = 20.sp)
        Text(label, color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}
