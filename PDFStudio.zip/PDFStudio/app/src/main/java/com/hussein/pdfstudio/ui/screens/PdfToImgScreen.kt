package com.hussein.pdfstudio.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import coil.compose.AsyncImage
import com.hussein.pdfstudio.data.model.ConversionResult
import com.hussein.pdfstudio.ui.components.*
import com.hussein.pdfstudio.ui.theme.*
import com.hussein.pdfstudio.utils.FileHelper
import com.hussein.pdfstudio.viewmodel.*
import android.content.Context
import java.io.File

@Composable
fun PdfToImgScreen(
    viewModel: PdfToImgViewModel,
    onBack: () -> Unit
) {
    val context  = LocalContext.current
    val fileInfo by viewModel.fileInfo.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val result   by viewModel.result.collectAsState()
    val outputs  by viewModel.outputPaths.collectAsState()

    val pdfPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> uri?.let { viewModel.selectFile(it) } }

    GradientBackground {
        Box(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                AppTopBar(title = "PDF → صور", onBack = onBack) {
                    if (fileInfo != null) {
                        GlassIconButton(Icons.Default.Close, onClick = { viewModel.clearFile() }, tint = Error)
                    }
                }

                // ── Results screen ────────────────────────────────────────────
                if (outputs.isNotEmpty() && result is ConversionResult.Success) {
                    ResultsScreen(
                        paths   = outputs,
                        context = context,
                        onNew   = { viewModel.clearFile() }
                    )
                    return@Column
                }

                Column(
                    Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {

                    if (fileInfo == null) {
                        // ── Drop zone ─────────────────────────────────────────
                        UploadDropZone(
                            title      = "اختر ملف PDF",
                            subtitle   = "يدعم جميع ملفات PDF",
                            buttonText = "اختر ملف PDF",
                            icon       = Icons.Default.PictureAsPdf,
                            onClick    = { pdfPicker.launch("application/pdf") }
                        )
                    } else {
                        // ── File info card ─────────────────────────────────────
                        FileInfoCard(info = fileInfo!!)

                        // ── Quality selector ──────────────────────────────────
                        StudioCard {
                            SectionTitle("جودة التحويل", Icons.Default.HighQuality)
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                RenderQuality.values().forEach { q ->
                                    val sel = settings.quality == q
                                    Row(
                                        Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (sel) Primary.copy(.15f) else Bg2)
                                            .border(1.dp, if (sel) Primary.copy(.5f) else Border, RoundedCornerShape(10.dp))
                                            .clickable { viewModel.updateSettings(settings.copy(quality = q)) }
                                            .padding(horizontal = 16.dp, vertical = 12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(q.label, color = if (sel) PrimaryLight else TextPrimary, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, fontSize = 14.sp)
                                            Text(q.description, color = TextSecondary, fontSize = 12.sp)
                                        }
                                        if (sel) Icon(Icons.Default.CheckCircle, null, tint = Primary, modifier = Modifier.size(20.dp))
                                        if (q == RenderQuality.ULTRA) {
                                            Box(
                                                Modifier
                                                    .clip(RoundedCornerShape(50.dp))
                                                    .background(AccentGreen.copy(.2f))
                                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                                            ) {
                                                Text("موصى به", color = AccentGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // ── Delete pages toggle ───────────────────────────────
                        StudioCard {
                            SectionTitle("حذف صفحات (اختياري)", Icons.Default.DeleteSweep)
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Bg2)
                                        .border(1.dp, if (settings.deleteEnabled) Error.copy(.4f) else Border, RoundedCornerShape(10.dp))
                                        .clickable { viewModel.updateSettings(settings.copy(deleteEnabled = !settings.deleteEnabled)) }
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.DeleteForever, null, tint = if (settings.deleteEnabled) Error else TextSecondary, modifier = Modifier.size(18.dp))
                                        Text("حذف نطاق صفحات", color = TextPrimary, fontSize = 14.sp)
                                    }
                                    Switch(
                                        checked  = settings.deleteEnabled,
                                        onCheckedChange = { viewModel.updateSettings(settings.copy(deleteEnabled = it)) },
                                        colors   = SwitchDefaults.colors(checkedTrackColor = Error, uncheckedTrackColor = Bg1, checkedThumbColor = Color.White)
                                    )
                                }
                                if (settings.deleteEnabled) {
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                                    ) {
                                        PageInput("من صفحة", settings.deleteFrom.toString(),
                                            onValue = { v -> viewModel.updateSettings(settings.copy(deleteFrom = v.toIntOrNull() ?: 1)) },
                                            modifier = Modifier.weight(1f)
                                        )
                                        PageInput("إلى صفحة", settings.deleteTo.toString(),
                                            onValue = { v -> viewModel.updateSettings(settings.copy(deleteTo = v.toIntOrNull() ?: 1)) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                    if (settings.deleteTo >= settings.deleteFrom) {
                                        val count = settings.deleteTo - settings.deleteFrom + 1
                                        Text(
                                            "سيتم حذف $count صفحة من الصفحة ${settings.deleteFrom} إلى ${settings.deleteTo}",
                                            color = Error, fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }

                        // ── Convert button ────────────────────────────────────
                        GradientButton(
                            text      = "ابدأ التحويل  →  صور PNG",
                            onClick   = { viewModel.convert() },
                            modifier  = Modifier.fillMaxWidth(),
                            isLoading = result is ConversionResult.Progress,
                            icon      = Icons.Default.Transform
                        )
                    }
                    Spacer(Modifier.navigationBarsPadding())
                }
            }

            // Progress overlay
            if (result is ConversionResult.Progress) {
                val p = result as ConversionResult.Progress
                ProgressOverlay(p.current, p.total, p.message)
            }
        }
    }
}

@Composable
private fun FileInfoCard(info: PdfFileInfo) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(BgCard)
            .border(1.dp, Border, RoundedCornerShape(14.dp))
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFFFF6B6B).copy(.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.PictureAsPdf, null, tint = Color(0xFFFF6B6B), modifier = Modifier.size(26.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(info.name, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
            Text(
                "${FileHelper.formatFileSize(info.size)}  •  ${info.pageCount} صفحة",
                color = TextSecondary, fontSize = 12.sp
            )
        }
        Box(
            Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(AccentGreen.copy(.15f))
                .border(1.dp, AccentGreen.copy(.3f), RoundedCornerShape(8.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Text("${info.pageCount} ص", color = AccentGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ResultsScreen(paths: List<String>, context: Context, onNew: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Success header
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFF064E3B).copy(.8f))
                .border(1.dp, AccentGreen.copy(.3f), RoundedCornerShape(14.dp))
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, null, tint = AccentGreen, modifier = Modifier.size(24.dp))
                Column {
                    Text("تم التحويل بنجاح!", color = AccentGreen, fontWeight = FontWeight.Bold)
                    Text("${paths.size} صورة PNG جاهزة", color = AccentGreen.copy(.7f), fontSize = 12.sp)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallAction("مشاركة الكل") { FileHelper.shareImages(context, paths) }
                SmallAction("جديد") { onNew() }
            }
        }

        // Images grid
        LazyVerticalGrid(
            columns   = GridCells.Fixed(2),
            modifier  = Modifier.heightIn(max = 700.dp),
            contentPadding = PaddingValues(0.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement   = Arrangement.spacedBy(10.dp),
        ) {
            itemsIndexed(paths) { index, path ->
                Box(
                    Modifier
                        .aspectRatio(0.7f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Bg2)
                        .border(1.dp, Border, RoundedCornerShape(10.dp))
                ) {
                    AsyncImage(
                        model  = File(path),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        Modifier
                            .align(Alignment.BottomStart)
                            .padding(6.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color.Black.copy(.6f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("صفحة ${index + 1}", color = Color.White, fontSize = 11.sp)
                    }
                }
            }
        }
        Spacer(Modifier.navigationBarsPadding())
    }
}

@Composable
private fun PageInput(label: String, value: String, onValue: (String) -> Unit, modifier: Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, color = TextSecondary, fontSize = 12.sp)
        OutlinedTextField(
            value    = value,
            onValueChange = onValue,
            singleLine = true,
            colors   = OutlinedTextFieldDefaults.colors(
                focusedBorderColor   = Primary,
                unfocusedBorderColor = Border,
                focusedTextColor     = TextPrimary,
                unfocusedTextColor   = TextPrimary,
                cursorColor          = Primary,
            ),
            modifier = Modifier.fillMaxWidth(),
            shape    = RoundedCornerShape(10.dp)
        )
    }
}

@Composable
private fun SmallAction(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(AccentGreen.copy(.2f))
            .border(1.dp, AccentGreen.copy(.3f), RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text(text, color = AccentGreen, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}
