package com.hussein.pdfstudio.ui.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.hussein.pdfstudio.ui.screens.*
import com.hussein.pdfstudio.viewmodel.*

@Composable
fun AppNavGraph(navController: NavHostController = rememberNavController()) {

    val imgToPdfVm:   ImgToPdfViewModel   = viewModel()
    val pdfToImgVm:   PdfToImgViewModel   = viewModel()
    val notebooksVm:  NotebooksViewModel  = viewModel()

    NavHost(
        navController    = navController,
        startDestination = Screen.Home.route
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                onImgToPdf  = { navController.navigate(Screen.ImgToPdf.route) },
                onPdfToImg  = { navController.navigate(Screen.PdfToImg.route) },
                onNotebooks = { navController.navigate(Screen.Notebooks.route) },
            )
        }

        composable(Screen.ImgToPdf.route) {
            ImgToPdfScreen(
                viewModel = imgToPdfVm,
                onBack    = { navController.popBackStack() }
            )
        }

        composable(Screen.PdfToImg.route) {
            PdfToImgScreen(
                viewModel = pdfToImgVm,
                onBack    = { navController.popBackStack() }
            )
        }

        composable(Screen.Notebooks.route) {
            NotebooksScreen(
                viewModel       = notebooksVm,
                onOpenNotebook  = { id -> navController.navigate(Screen.NotebookDetail.createRoute(id)) },
                onBack          = { navController.popBackStack() }
            )
        }

        composable(
            route     = Screen.NotebookDetail.route,
            arguments = listOf(navArgument("notebookId") { type = NavType.LongType })
        ) { backStack ->
            val notebookId = backStack.arguments?.getLong("notebookId") ?: return@composable
            NotebookDetailScreen(
                notebookId = notebookId,
                viewModel  = notebooksVm,
                onBack     = { navController.popBackStack() }
            )
        }
    }
}
