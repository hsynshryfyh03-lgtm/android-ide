package com.hussein.pdfstudio.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.hussein.pdfstudio.data.model.*
import com.hussein.pdfstudio.data.repository.NotebookRepository
import com.hussein.pdfstudio.utils.FileHelper
import com.hussein.pdfstudio.utils.PdfCreator
import com.hussein.pdfstudio.utils.PdfRendererUtil
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class NotebooksViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = NotebookRepository(app)

    val notebooks: StateFlow<List<Notebook>> = repo.getAllNotebooks()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentNotebook  = MutableStateFlow<Notebook?>(null)
    val currentNotebook: StateFlow<Notebook?> = _currentNotebook.asStateFlow()

    private val _notebookImages   = MutableStateFlow<List<NotebookImage>>(emptyList())
    val notebookImages: StateFlow<List<NotebookImage>> = _notebookImages.asStateFlow()

    private val _exportResult     = MutableStateFlow<ConversionResult>(ConversionResult.Idle)
    val exportResult: StateFlow<ConversionResult> = _exportResult.asStateFlow()

    private val _searchQuery      = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val filteredNotebooks = combine(notebooks, _searchQuery) { list, query ->
        if (query.isBlank()) list
        else list.filter { it.name.contains(query, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ── Notebooks CRUD ────────────────────────────────────────────────────────

    fun createNotebook(name: String, colorHex: String) {
        viewModelScope.launch { repo.createNotebook(name, colorHex) }
    }

    fun renameNotebook(id: Long, newName: String) {
        viewModelScope.launch { repo.renameNotebook(id, newName) }
    }

    fun deleteNotebook(id: Long) {
        viewModelScope.launch { repo.deleteNotebook(id) }
    }

    fun setSearchQuery(q: String) { _searchQuery.value = q }

    // ── Open a notebook ───────────────────────────────────────────────────────

    private var imagesJob: Job? = null

    fun openNotebook(notebookId: Long) {
        viewModelScope.launch {
            _currentNotebook.value = repo.getNotebookById(notebookId)
        }
        // Cancel previous collector and start fresh
        imagesJob?.cancel()
        imagesJob = viewModelScope.launch {
            repo.getImagesForNotebook(notebookId).collect { imgs ->
                _notebookImages.value = imgs
            }
        }
    }

    // ── Images inside a notebook ──────────────────────────────────────────────

    fun addImagesToCurrentNotebook(uris: List<Uri>) {
        val nbId = _currentNotebook.value?.id ?: return
        viewModelScope.launch {
            val context = getApplication<Application>()
            val dir     = FileHelper.getNotebookDir(context, nbId)
            val paths   = uris.mapNotNull { uri ->
                PdfRendererUtil.copyUriToInternalStorage(context, uri, dir)
            }
            if (paths.isNotEmpty()) repo.addImagesToNotebook(nbId, paths)
        }
    }

    fun deleteImageFromNotebook(image: NotebookImage) {
        val nbId = _currentNotebook.value?.id ?: return
        viewModelScope.launch { repo.deleteImageFromNotebook(image, nbId) }
    }

    fun reorderImages(from: Int, to: Int) {
        val list = _notebookImages.value.toMutableList()
        if (from < 0 || to < 0 || from >= list.size || to >= list.size) return
        val item = list.removeAt(from)
        list.add(to, item)
        _notebookImages.value = list
        viewModelScope.launch { repo.reorderImages(list) }
    }

    // ── Export notebook to PDF ────────────────────────────────────────────────

    fun exportToPdf() {
        val nb    = _currentNotebook.value ?: return
        val paths = _notebookImages.value.map { it.filePath }
        if (paths.isEmpty()) return
        viewModelScope.launch {
            _exportResult.value = ConversionResult.Progress(0, paths.size, "بدء التصدير...")
            val context = getApplication<Application>()
            try {
                val outPath = PdfCreator.pathsToPdf(
                    context   = context,
                    paths     = paths,
                    settings  = PdfSettings(),
                    fileName  = "${nb.name}_${FileHelper.timestamp()}.pdf",
                    onProgress = { cur, tot, msg ->
                        _exportResult.value = ConversionResult.Progress(cur, tot, msg)
                    }
                )
                _exportResult.value = ConversionResult.Success(outPath, paths.size)
            } catch (e: Exception) {
                _exportResult.value = ConversionResult.Failure(e.message ?: "خطأ")
            }
        }
    }

    fun resetExportResult() { _exportResult.value = ConversionResult.Idle }
}
