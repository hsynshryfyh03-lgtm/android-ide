package com.hussein.pdfstudio.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.hussein.pdfstudio.data.model.Notebook
import com.hussein.pdfstudio.ui.components.*
import com.hussein.pdfstudio.ui.theme.*
import com.hussein.pdfstudio.viewmodel.NotebooksViewModel

@Composable
fun NotebooksScreen(
    viewModel: NotebooksViewModel,
    onOpenNotebook: (Long) -> Unit,
    onBack: () -> Unit
) {
    val notebooks  by viewModel.filteredNotebooks.collectAsState()
    val query      by viewModel.searchQuery.collectAsState()

    var showCreate    by remember { mutableStateOf(false) }
    var showDeleteId  by remember { mutableStateOf<Long?>(null) }
    var showRenameNb  by remember { mutableStateOf<Notebook?>(null) }
    var searchActive  by remember { mutableStateOf(false) }

    GradientBackground {
        Column(Modifier.fillMaxSize()) {
            AppTopBar(title = "الدفاتر", onBack = onBack) {
                GlassIconButton(Icons.Default.Search, onClick = { searchActive = !searchActive })
            }

            AnimatedVisibility(searchActive, enter = expandVertically(), exit = shrinkVertically()) {
                OutlinedTextField(
                    value         = query,
                    onValueChange = viewModel::setSearchQuery,
                    placeholder   = { Text("بحث في الدفاتر...", color = TextTertiary) },
                    singleLine    = true,
                    leadingIcon   = { Icon(Icons.Default.Search, null, tint = TextSecondary) },
                    modifier      = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    colors        = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor   = Primary,
                        unfocusedBorderColor = Border,
                        focusedTextColor     = TextPrimary,
                        unfocusedTextColor   = TextPrimary,
                        cursorColor          = Primary,
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Box(Modifier.weight(1f)) {
                if (notebooks.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                Modifier
                                    .size(80.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(Bg2)
                                    .border(1.dp, Border, RoundedCornerShape(20.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.MenuBook, null, tint = TextTertiary, modifier = Modifier.size(36.dp))
                            }
                            Text("لا توجد دفاتر بعد", color = TextSecondary, fontSize = 16.sp)
                            Text("أنشئ دفترك الأول الآن", color = TextTertiary, fontSize = 13.sp)
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        columns        = GridCells.Fixed(2),
                        contentPadding = PaddingValues(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement   = Arrangement.spacedBy(12.dp),
                    ) {
                        items(notebooks, key = { it.id }) { nb ->
                            NotebookCard(
                                notebook   = nb,
                                onClick    = { onOpenNotebook(nb.id) },
                                onRename   = { showRenameNb = nb },
                                onDelete   = { showDeleteId = nb.id }
                            )
                        }
                        item { Spacer(Modifier.navigationBarsPadding()) }
                    }
                }

                // FAB
                FloatingActionButton(
                    onClick      = { showCreate = true },
                    modifier     = Modifier.align(Alignment.BottomEnd).padding(20.dp).navigationBarsPadding(),
                    containerColor = Primary,
                    contentColor   = Color.White,
                    shape          = RoundedCornerShape(16.dp),
                ) {
                    Row(
                        Modifier.padding(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Add, null)
                        Text("دفتر جديد", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // ── Create dialog ─────────────────────────────────────────────────────────
    if (showCreate) {
        CreateNotebookDialog(
            onConfirm = { name, color ->
                viewModel.createNotebook(name, color)
                showCreate = false
            },
            onDismiss = { showCreate = false }
        )
    }

    // ── Rename dialog ─────────────────────────────────────────────────────────
    showRenameNb?.let { nb ->
        var newName by remember { mutableStateOf(nb.name) }
        AlertDialog(
            onDismissRequest = { showRenameNb = null },
            containerColor   = Bg1,
            shape            = RoundedCornerShape(20.dp),
            title = { Text("إعادة تسمية", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text  = {
                OutlinedTextField(
                    value         = newName,
                    onValueChange = { newName = it },
                    singleLine    = true,
                    label         = { Text("اسم الدفتر", color = TextSecondary) },
                    colors        = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Primary, unfocusedBorderColor = Border,
                        focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary, cursorColor = Primary
                    ),
                    shape  = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = { if (newName.isNotBlank()) { viewModel.renameNotebook(nb.id, newName); showRenameNb = null } },
                    colors  = ButtonDefaults.buttonColors(containerColor = Primary)
                ) { Text("حفظ") }
            },
            dismissButton = { TextButton(onClick = { showRenameNb = null }) { Text("إلغاء", color = TextSecondary) } }
        )
    }

    // ── Delete dialog ─────────────────────────────────────────────────────────
    showDeleteId?.let { id ->
        AlertDialog(
            onDismissRequest = { showDeleteId = null },
            containerColor   = Bg1,
            shape            = RoundedCornerShape(20.dp),
            title = { Text("حذف الدفتر؟", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text  = { Text("سيتم حذف الدفتر وجميع صوره نهائياً.", color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = { viewModel.deleteNotebook(id); showDeleteId = null },
                    colors  = ButtonDefaults.buttonColors(containerColor = Error)
                ) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { showDeleteId = null }) { Text("إلغاء", color = TextSecondary) } }
        )
    }
}

@Composable
private fun NotebookCard(
    notebook: Notebook,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    val color = try { Color(android.graphics.Color.parseColor(notebook.colorHex)) } catch (_: Exception) { Primary }
    var expanded by remember { mutableStateOf(false) }

    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(0.85f)
            .clip(RoundedCornerShape(16.dp))
            .background(BgCard)
            .border(1.dp, color.copy(.3f), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
    ) {
        // Color accent top bar
        Box(
            Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                .background(Brush.linearGradient(listOf(color, color.copy(.6f))))
        )
        Column(
            Modifier.fillMaxSize().padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(color.copy(.15f))
                        .border(1.dp, color.copy(.3f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.MenuBook, null, tint = color, modifier = Modifier.size(22.dp))
                }
                Box {
                    GlassIconButton(Icons.Default.MoreVert, onClick = { expanded = true }, tint = TextTertiary, size = 30.dp)
                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        containerColor   = BgCard
                    ) {
                        DropdownMenuItem(
                            text         = { Text("إعادة تسمية", color = TextPrimary, fontSize = 13.sp) },
                            leadingIcon  = { Icon(Icons.Default.Edit, null, tint = TextSecondary) },
                            onClick      = { onRename(); expanded = false }
                        )
                        DropdownMenuItem(
                            text         = { Text("حذف", color = Error, fontSize = 13.sp) },
                            leadingIcon  = { Icon(Icons.Default.Delete, null, tint = Error) },
                            onClick      = { onDelete(); expanded = false }
                        )
                    }
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(notebook.name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 2)
                Text("${notebook.imageCount} صورة", color = TextSecondary, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun CreateNotebookDialog(onConfirm: (String, String) -> Unit, onDismiss: () -> Unit) {
    var name     by remember { mutableStateOf("") }
    var selColor by remember { mutableStateOf(NB_COLORS.first()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor   = Bg1,
        shape            = RoundedCornerShape(20.dp),
        title = { Text("دفتر جديد", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text  = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                OutlinedTextField(
                    value         = name,
                    onValueChange = { name = it },
                    singleLine    = true,
                    label         = { Text("اسم الدفتر", color = TextSecondary) },
                    colors        = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Primary, unfocusedBorderColor = Border,
                        focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary, cursorColor = Primary
                    ),
                    shape  = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Text("اختر لوناً", color = TextSecondary, fontSize = 13.sp)
                ColorPickerRow(selected = selColor, onSelect = { selColor = it })
            }
        },
        confirmButton = {
            Button(
                onClick = { if (name.isNotBlank()) onConfirm(name, selColor) },
                colors  = ButtonDefaults.buttonColors(containerColor = Primary)
            ) { Text("إنشاء") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = TextSecondary) } }
    )
}
