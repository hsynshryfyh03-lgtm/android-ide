# AlarmPro v2.0 — Cosmic Edition 🌌

## What's New in v2.0

### 🎨 Design System — Complete Overhaul

#### Typography
- **Google Fonts: Nunito** — Rounded, modern, beautiful at all sizes
  - 8 weight variants: Thin → Black
  - All screens now use Nunito automatically via `AlarmTypography`

#### Color System
- **20+ new colors** including:
  - Aurora palette: `AuroraGreen`, `AuroraBlue`, `AuroraPurple`, `AuroraPink`
  - Premium accents: `OrbLavender`, `OrbAqua`, `OrbNebula`, `OrbGold`, `OrbSunrise`
  - Shimmer tokens: `ShimmerBase`, `ShimmerHighlight`, `ShimmerDark`
  - Special effects: `PulseBlue`, `PulsePurple`, `StarColor`

---

### 🌟 New UI Components

#### `LiquidGlassBackground` — 5-Orb Cosmic Nebula
- Was: 3 orbs
- Now: **5 orbs** with Lissajous figure paths
- Added: nebula core gradient, bottom vignette, pulsing intensity animation

#### `StarFieldBackground` — 180-star parallax field
- 3 depth layers: far (100 tiny), mid (50 medium), near (30 bright)
- Bright stars have **4-point cross diffraction spikes** with halos
- All stars twinkle with independent sinusoidal alpha modulation
- **Zero GC pressure** — drawn on Canvas, not Compose nodes

#### `SparkleOverlay` — 24 drifting light particles
- Used on RingingActivity for premium wake-up experience
- Each particle: fade in/out lifecycle + twinkle modulation
- Colors from full orb palette

#### `NeonCard` — Electric pulsing card
- Outer neon glow halo (drawn before clip)
- Animated border intensity (breathing pulse)
- Used in Settings and RingingActivity

#### `AuroraCard` — Shifting aurora gradient
- Continuously shifting horizontal gradient
- Aurora sweep border
- Used in Settings "About" section

#### `DeepGlassSheet` — Heavier glass for modals
- Higher alpha fill than `GlassCard`
- Stronger specular top line

---

### ⏰ Clock Faces — 6 Styles (was 4)

| Style | Description |
|-------|-------------|
| **Classic** | iOS-inspired glass + rotating aurora ring |
| **Modern** | Thin minimal markers, accent second hand |
| **Minimal** | 4 cardinal dots only |
| **Digital** | Large Nunito digits + seconds arc |
| **Neon** ✨ NEW | Electric glowing hands, plasma-colored ticks |
| **Retro** ✨ NEW | Warm amber vintage with wide tick markers |

---

### 🎴 Alarm Card — Color-Coded by Time-of-Day

| Hour Range | Color |
|-----------|-------|
| 5–8 AM (Dawn) | `OrbSunrise` orange |
| 9–11 AM (Morning) | `OrbOrange` amber |
| 12–4 PM (Afternoon) | `OrbBlue` |
| 5–7 PM (Sunset) | `OrbPurple` |
| 8–10 PM (Evening) | `OrbNebula` |
| Night | `OrbIndigo` |

- **Aurora gradient border** on enabled alarms (changes with time-of-day color)
- Animated **status indicator dot** with ambient glow
- **Shimmer entry** using `compose-shimmer` library
- **Staggered slide-in animation** on list load (60ms per card)

---

### 📱 Screen Updates

#### HomeScreen
- **180-star parallax starfield** behind everything
- Section count shown in a glass pill badge
- **Staggered animation** — cards slide in with spring+fade
- FAB morphs with `expandHorizontally` + `shrinkHorizontally`
- Clock face picker now shows **3-column grid** (6 faces)

#### RingingActivity
- Stars + sparkles overlay for immersive experience
- Bell container now has **secondary aurora ring**
- Dismiss & Snooze buttons have **neon glow halos**
- Time display: 92sp Nunito Thin

#### SettingsScreen
- **Navigation uses icon cards** (2-col grid layout)
- Section labels with colored left-border accent
- All action buttons are custom `Box` (not Material buttons)
- "About" uses `AuroraCard` for premium feel

#### AlarmGroupsScreen
- Color dot → **full icon circle** with glow halo
- Staggered `slideInHorizontally` entry animation
- Delete via glass circle button

#### VacationModeScreen
- Animated sun icon in TopBar (rotates)
- Sun badge pulses when vacation is active
- `NeonCard` for the main card (cyan tint)

---

### 📦 New Dependencies

```kotlin
// Google Fonts — Nunito typography
implementation("androidx.compose.ui:ui-text-google-fonts")

// Lottie — JSON animations
implementation("com.airbnb.android:lottie-compose:6.5.2")

// Shimmer — skeleton loading & glow effects
implementation("com.valentinilk.shimmer:compose-shimmer:1.3.3")

// Coil 3 — GPU-accelerated image loading
implementation("io.coil-kt.coil3:coil-compose:3.0.4")
implementation("io.coil-kt.coil3:coil-network-okhttp:3.0.4")
```

---

### 📁 New/Modified Files

```
app/build.gradle.kts                       ← Added 4 new libraries
ui/theme/Color.kt                          ← +15 colors, aurora/shimmer/star tokens
ui/theme/Type.kt                           ← Google Fonts (Nunito) all 8 weights
ui/theme/Theme.kt                          ← Added container colors
ui/components/GlassComponents.kt           ← NeonCard, AuroraCard, DeepGlassSheet
ui/components/ParticleEffect.kt            ← StarFieldBackground, SparkleOverlay
ui/components/ClockFaces.kt                ← +2 faces: Neon, Retro
ui/components/AlarmCard.kt                 ← Time-of-day color, aurora border, shimmer
ui/screens/HomeScreen.kt                   ← Stars, staggered anims, 6-face grid
ui/screens/RingingActivity.kt             ← Stars, sparkles, neon buttons
ui/screens/SettingsScreen.kt               ← Icon cards, NeonCard, AuroraCard
ui/screens/AlarmGroupsScreen.kt            ← Glow dots, slide-in animations
ui/screens/VacationModeScreen.kt           ← Rotating sun, NeonCard
res/values/themes.xml                      ← SplashScreen branding
res/values/strings.xml                     ← Font cert references
res/values/font_certs.xml                  ← Google Fonts certificates
```

---

**Designed & Enhanced by Claude Sonnet 4.6**
