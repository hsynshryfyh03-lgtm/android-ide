# AlarmPro ProGuard Rules

# Keep data models
-keep class com.hussein.alarmpro.data.model.** { *; }
-keep class com.hussein.alarmpro.data.db.** { *; }
-keep class com.hussein.alarmpro.data.datastore.** { *; }

# Hilt
-keepnames @dagger.hilt.android.lifecycle.HiltViewModel class * extends androidx.lifecycle.ViewModel

# Room
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**

# Admin receiver
-keep class com.hussein.alarmpro.admin.** { *; }

# Receivers and services
-keep class com.hussein.alarmpro.receiver.** { *; }
-keep class com.hussein.alarmpro.service.** { *; }
-keep class com.hussein.alarmpro.widget.** { *; }

# Kotlin
-keep class kotlin.** { *; }
-keep class kotlin.Metadata { *; }
-dontwarn kotlin.**
-dontwarn kotlinx.**

# Compose
-dontwarn androidx.compose.**
