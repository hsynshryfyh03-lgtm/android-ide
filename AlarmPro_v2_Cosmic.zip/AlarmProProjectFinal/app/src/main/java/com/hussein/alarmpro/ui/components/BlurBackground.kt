package com.hussein.alarmpro.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RenderEffect
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Real-blur background for RingingActivity.
 *
 * API 31+ (Android 12+): Uses RenderEffect hardware blur — zero cost GPU blur.
 * API 26-30:              Software stack-blur via Bitmap manipulation.
 *
 * When no URI provided → renders animated LiquidGlass only.
 */
@Composable
fun BlurredRingBackground(
    imageUri: String,
    blurRadius: Float = 20f,
    modifier: Modifier = Modifier
) {
    if (imageUri.isBlank()) {
        // Default: pure glass background (already drawn by LiquidGlassBackground)
        return
    }

    val context = LocalContext.current
    var bitmap by remember { mutableStateOf<ImageBitmap?>(null) }

    LaunchedEffect(imageUri) {
        bitmap = withContext(Dispatchers.IO) {
            loadBitmapFromUri(context, imageUri)?.asImageBitmap()
        }
    }

    bitmap?.let { bmp ->
        Box(modifier = modifier.fillMaxSize()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                // API 31+: hardware RenderEffect blur
                HardwareBlurImage(
                    bitmap = bmp,
                    blurRadius = blurRadius,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                // API 26-30: software stack-blur
                val blurred = remember(bmp) {
                    stackBlur(bmp.asAndroidBitmap(), blurRadius.toInt().coerceIn(1, 25))
                        ?.asImageBitmap()
                }
                blurred?.let { b ->
                    Image(
                        bitmap = b,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                        alpha = 0.55f
                    )
                }
            }
            // Dark + glass overlay on top
            Box(
                Modifier
                    .fillMaxSize()
                    .drawWithContent {
                        drawContent()
                        drawRect(
                            brush = Brush.verticalGradient(
                                listOf(
                                    Color.Black.copy(alpha = 0.55f),
                                    Color.Black.copy(alpha = 0.35f),
                                    Color.Black.copy(alpha = 0.65f)
                                )
                            )
                        )
                    }
            )
        }
    }
}

@RequiresApi(Build.VERSION_CODES.S)
@Composable
@Suppress("NewApi")
private fun HardwareBlurImage(
    bitmap: ImageBitmap,
    blurRadius: Float,
    modifier: Modifier = Modifier
) {
    // RenderEffect hardware blur — zero GPU overhead
    Image(
        bitmap = bitmap,
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = modifier.graphicsLayer {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                renderEffect = RenderEffect
                    .createBlurEffect(blurRadius, blurRadius, Shader.TileMode.CLAMP)
                    .asComposeRenderEffect()
            }
        },
        alpha = 0.65f
    )
}

private fun loadBitmapFromUri(context: Context, uriString: String): Bitmap? = runCatching {
    val uri = Uri.parse(uriString)
    context.contentResolver.openInputStream(uri)?.use { stream ->
        val options = BitmapFactory.Options().apply {
            // Downsample to save memory — we're going to blur it anyway
            inSampleSize = 4
        }
        BitmapFactory.decodeStream(stream, null, options)
    }
}.getOrNull()

/**
 * Fast stack-blur algorithm for API < 31.
 * Radius 1-25 produces good results at low CPU cost.
 */
private fun stackBlur(bitmap: Bitmap, radius: Int): Bitmap? {
    if (radius < 1) return bitmap
    return runCatching {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        val wm = w - 1; val hm = h - 1
        val wh = w * h; val div = radius + radius + 1
        val r = IntArray(wh); val g = IntArray(wh); val b = IntArray(wh)
        var rsum: Int; var gsum: Int; var bsum: Int
        var x: Int; var y: Int; var i: Int; var p: Int
        var yp: Int; var yi: Int; var yw: Int
        val vmin = IntArray(maxOf(w, h))
        var divsum = (div + 1) shr 1; divsum *= divsum
        val dv = IntArray(256 * divsum)
        for (idx in dv.indices) dv[idx] = idx / divsum
        var stackpointer: Int
        var stackstart: Int
        val stack = IntArray(div * 3)
        var sir: Int
        val pix: Int
        val r1 = radius + 1
        var routsum: Int; var goutsum: Int; var boutsum: Int
        var rinsum: Int; var ginsum: Int; var binsum: Int

        yw = 0; yi = 0
        for (yIdx in 0 until h) {
            rinsum = 0; ginsum = 0; binsum = 0
            routsum = 0; goutsum = 0; boutsum = 0
            rsum = 0; gsum = 0; bsum = 0
            for (i2 in -radius..radius) {
                p = pixels[yi + minOf(wm, maxOf(i2, 0))]
                sir = i2 + radius; val s3 = sir * 3
                stack[s3]     = (p and 0xff0000) shr 16
                stack[s3 + 1] = (p and 0x00ff00) shr 8
                stack[s3 + 2] =  p and 0x0000ff
                val rbs = r1 - kotlin.math.abs(i2)
                rsum += stack[s3]     * rbs; gsum += stack[s3 + 1] * rbs; bsum += stack[s3 + 2] * rbs
                if (i2 > 0) { rinsum += stack[s3]; ginsum += stack[s3 + 1]; binsum += stack[s3 + 2] }
                else        { routsum += stack[s3]; goutsum += stack[s3 + 1]; boutsum += stack[s3 + 2] }
            }
            stackpointer = radius
            for (xIdx in 0 until w) {
                r[yi] = dv[rsum]; g[yi] = dv[gsum]; b[yi] = dv[bsum]
                rsum -= routsum; gsum -= goutsum; bsum -= boutsum
                stackstart = (stackpointer - radius + div) % div
                sir = stackstart * 3
                routsum -= stack[sir]; goutsum -= stack[sir + 1]; boutsum -= stack[sir + 2]
                if (yIdx == 0) vmin[xIdx] = minOf(xIdx + radius + 1, wm)
                p = pixels[yw + vmin[xIdx]]
                stack[sir]     = (p and 0xff0000) shr 16
                stack[sir + 1] = (p and 0x00ff00) shr 8
                stack[sir + 2] =  p and 0x0000ff
                rinsum += stack[sir]; ginsum += stack[sir + 1]; binsum += stack[sir + 2]
                rsum += rinsum; gsum += ginsum; bsum += binsum
                stackpointer = (stackpointer + 1) % div; sir = stackpointer * 3
                routsum += stack[sir]; goutsum += stack[sir + 1]; boutsum += stack[sir + 2]
                rinsum -= stack[sir]; ginsum -= stack[sir + 1]; binsum -= stack[sir + 2]
                yi++
            }
            yw += w
        }
        // Vertical pass
        for (xIdx in 0 until w) {
            rinsum = 0; ginsum = 0; binsum = 0
            routsum = 0; goutsum = 0; boutsum = 0; rsum = 0; gsum = 0; bsum = 0
            yp = -radius * w
            for (i2 in -radius..radius) {
                yi = maxOf(0, yp) + xIdx
                sir = (i2 + radius) * 3
                stack[sir]     = r[yi]; stack[sir + 1] = g[yi]; stack[sir + 2] = b[yi]
                val rbs = r1 - kotlin.math.abs(i2)
                rsum += r[yi] * rbs; gsum += g[yi] * rbs; bsum += b[yi] * rbs
                if (i2 > 0) { rinsum += stack[sir]; ginsum += stack[sir + 1]; binsum += stack[sir + 2] }
                else        { routsum += stack[sir]; goutsum += stack[sir + 1]; boutsum += stack[sir + 2] }
                if (i2 < hm) yp += w
            }
            yi = xIdx; stackpointer = radius
            for (yIdx in 0 until h) {
                pixels[yi] = (0xff000000.toInt()) or (dv[rsum] shl 16) or (dv[gsum] shl 8) or dv[bsum]
                rsum -= routsum; gsum -= goutsum; bsum -= boutsum
                stackstart = (stackpointer - radius + div) % div; sir = stackstart * 3
                routsum -= stack[sir]; goutsum -= stack[sir + 1]; boutsum -= stack[sir + 2]
                if (xIdx == 0) vmin[yIdx] = minOf(yIdx + r1, hm) * w
                p = xIdx + vmin[yIdx]
                stack[sir]     = r[p]; stack[sir + 1] = g[p]; stack[sir + 2] = b[p]
                rinsum += stack[sir]; ginsum += stack[sir + 1]; binsum += stack[sir + 2]
                rsum += rinsum; gsum += ginsum; bsum += binsum
                stackpointer = (stackpointer + 1) % div; sir = stackpointer * 3
                routsum += stack[sir]; goutsum += stack[sir + 1]; boutsum += stack[sir + 2]
                rinsum -= stack[sir]; ginsum -= stack[sir + 1]; binsum -= stack[sir + 2]
                yi += w
            }
        }
        val result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        result.setPixels(pixels, 0, w, 0, 0, w, h)
        result
    }.getOrNull()
}
