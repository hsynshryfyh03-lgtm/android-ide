package com.hussein.alarmpro.util

import android.app.NotificationManager
import android.content.Context
import android.media.AudioManager
import android.os.Build
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Feature 2: Forces alarm audio even when the phone is in silent or DND mode.
 * Strategy:
 *   1. Temporarily set ringer mode to NORMAL before playing
 *   2. Use NotificationManager interruption filter bypass (requires DND permission)
 *   3. STREAM_ALARM is separate from STREAM_RING — always audible if volume > 0
 */
@Singleton
class DndHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val notifManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private var savedRingerMode: Int = AudioManager.RINGER_MODE_NORMAL
    private var savedAlarmVolume: Int = -1

    /** Call before playing alarm sound */
    fun prepareForAlarm() {
        savedRingerMode = audioManager.ringerMode
        savedAlarmVolume = audioManager.getStreamVolume(AudioManager.STREAM_ALARM)

        // STREAM_ALARM bypasses silent mode by design on Android, but ensure volume > 0
        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
        if (audioManager.getStreamVolume(AudioManager.STREAM_ALARM) == 0) {
            audioManager.setStreamVolume(AudioManager.STREAM_ALARM, maxVol, 0)
        }

        // Request DND bypass if we have the permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (notifManager.isNotificationPolicyAccessGranted) {
                runCatching {
                    notifManager.setInterruptionFilter(
                        NotificationManager.INTERRUPTION_FILTER_ALARMS
                    )
                }
            }
        }
    }

    /** Call after alarm is dismissed */
    fun restore() {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (notifManager.isNotificationPolicyAccessGranted) {
                    notifManager.setInterruptionFilter(
                        NotificationManager.INTERRUPTION_FILTER_ALL
                    )
                }
            }
            if (savedAlarmVolume >= 0) {
                audioManager.setStreamVolume(AudioManager.STREAM_ALARM, savedAlarmVolume, 0)
            }
        }
        savedAlarmVolume = -1
    }

    val isDndPermissionGranted: Boolean
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            notifManager.isNotificationPolicyAccessGranted else true
}
