package com.hussein.alarmpro.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.hussein.alarmpro.data.model.Alarm
import com.hussein.alarmpro.receiver.AlarmReceiver
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class PreAlarmScheduler @Inject constructor(
    @ApplicationContext private val context: Context,
    private val alarmScheduler: AlarmScheduler
) {
    private val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    /** Schedule a pre-alarm notification N minutes before the alarm fires */
    fun schedule(alarm: Alarm) {
        if (alarm.preAlarmNotifyMinutes <= 0) return
        val mainTrigger = alarmScheduler.nextTriggerMillis(alarm) ?: return
        val preTrigger  = mainTrigger - (alarm.preAlarmNotifyMinutes * 60_000L)
        if (preTrigger <= System.currentTimeMillis()) return

        val pi = buildPendingIntent(alarm.id)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && am.canScheduleExactAlarms()) {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, preTrigger, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, preTrigger, pi)
        }
    }

    fun cancel(alarmId: Int) {
        am.cancel(buildPendingIntent(alarmId))
    }

    private fun buildPendingIntent(alarmId: Int): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.hussein.alarmpro.ACTION_PRE_ALARM_FIRE"
            putExtra("alarm_id", alarmId)
        }
        return PendingIntent.getBroadcast(
            context, alarmId + 20000, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
