package com.hussein.alarmpro.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.hussein.alarmpro.data.model.Alarm
import com.hussein.alarmpro.ui.components.*
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.AlarmScheduler
import com.hussein.alarmpro.util.TimeUtils
import com.hussein.alarmpro.viewmodel.AlarmViewModel
import kotlinx.coroutines.delay
import java.util.Calendar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: AlarmViewModel,
    scheduler: AlarmScheduler,
    onAddAlarm: () -> Unit,
    onEditAlarm: (Alarm) -> Unit,
    onSettings: () -> Unit
) {
    val alarms by viewModel.alarms.collectAsState()
    val isAr = TimeUtils.isArabic()
    var clockFace by remember { mutableStateOf(ClockFaceStyle.CLASSIC) }
    var showFaceMenu by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val sorted = remember(alarms) {
        alarms.sortedWith(
            compareByDescending<Alarm> { it.isEnabled }.thenBy { it.hour * 60 + it.minute }
        )
    }
    val isScrolled by remember {
        derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 40 }
    }

    LiquidGlassBackground {
        // Starfield layer for depth
        StarFieldBackground(Modifier.fillMaxSize())

        Box(Modifier.fillMaxSize()) {
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 140.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                item { Spacer(Modifier.height(72.dp)) }

                // ── Clock Header ─────────────────────────────────────────────
                item {
                    ClockHeaderSection(
                        clockFace = clockFace,
                        alarms = sorted,
                        scheduler = scheduler,
                        isAr = isAr,
                        onLongPress = { showFaceMenu = true }
                    )
                }

                // Clock face picker
                item {
                    AnimatedVisibility(
                        visible = showFaceMenu,
                        enter = expandVertically(spring(stiffness = Spring.StiffnessLow)) + fadeIn(tween(200)),
                        exit  = shrinkVertically(tween(180)) + fadeOut(tween(180))
                    ) {
                        ClockFacePicker(
                            current = clockFace, isAr = isAr,
                            onSelect = { clockFace = it; showFaceMenu = false },
                            onDismiss = { showFaceMenu = false }
                        )
                    }
                }

                // Section header
                if (sorted.isNotEmpty()) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (isAr) "المنبهات" else "ALARMS",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextTertiary, fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp
                                )
                            )
                            Spacer(Modifier.width(8.dp))
                            Box(Modifier.weight(1f).height(0.5.dp).background(
                                Brush.horizontalGradient(listOf(Separator, Color.Transparent))))
                            Spacer(Modifier.width(8.dp))
                            // Count badge
                            Box(
                                Modifier
                                    .clip(RoundedCornerShape(50))
                                    .background(GlassBg)
                                    .border(0.5.dp, GlassBorder, RoundedCornerShape(50))
                                    .padding(horizontal = 7.dp, vertical = 2.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("${sorted.size}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = TextTertiary, fontSize = 10.sp))
                            }
                        }
                    }
                }

                // Alarm cards with staggered entry
                if (sorted.isEmpty()) {
                    item { EmptyAlarmsPlaceholder(isAr = isAr) }
                } else {
                    itemsIndexed(sorted, key = { _, a -> a.id }) { index, alarm ->
                        val nextMillis = remember(alarm) { scheduler.nextTriggerMillis(alarm) }
                        // Staggered slide-in animation
                        val visible = remember { mutableStateOf(false) }
                        LaunchedEffect(Unit) {
                            delay(index * 60L)
                            visible.value = true
                        }
                        AnimatedVisibility(
                            visible = visible.value,
                            enter = slideInVertically(
                                animationSpec = spring(stiffness = Spring.StiffnessMediumLow,
                                    dampingRatio = Spring.DampingRatioMediumBouncy),
                                initialOffsetY = { it / 3 }
                            ) + fadeIn(tween(300))
                        ) {
                            AlarmCard(
                                alarm = alarm,
                                nextTriggerMillis = nextMillis,
                                onToggle = { en -> viewModel.toggleAlarm(alarm, en) },
                                onEdit   = { onEditAlarm(alarm) },
                                onDelete = { viewModel.deleteAlarm(alarm) }
                            )
                        }
                    }
                }
            }

            // ── Floating Top Bar ─────────────────────────────────────────────
            IosTopBar(isAr = isAr, onSettings = onSettings,
                modifier = Modifier.align(Alignment.TopCenter))

            // ── Floating Add Button ──────────────────────────────────────────
            IosFloatingAddButton(
                isAr = isAr, isScrolled = isScrolled, onClick = onAddAlarm,
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 32.dp)
            )
        }
    }
}

// ── Premium Floating Top Bar ─────────────────────────────────────────────────
@Composable
private fun IosTopBar(isAr: Boolean, onSettings: () -> Unit, modifier: Modifier = Modifier) {
    var now by remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) { while (true) { now = Calendar.getInstance(); delay(60_000) } }

    val dateStr = remember(now) {
        val days  = arrayOf("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
        val months= arrayOf("January","February","March","April","May","June","July","August","September","October","November","December")
        val arDays= arrayOf("الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت")
        val arMon = arrayOf("يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر")
        val dow   = now.get(Calendar.DAY_OF_WEEK) - 1
        val month = now.get(Calendar.MONTH)
        val day   = now.get(Calendar.DAY_OF_MONTH)
        if (isAr) "${arDays[dow]}، $day ${arMon[month]}" else "${days[dow]}, ${months[month]} $day"
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = if (isAr) "منبهاتي" else "My Alarms",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.ExtraBold, color = TextPrimary, fontSize = 32.sp
                )
            )
            Text(text = dateStr,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextTertiary, fontSize = 12.sp, fontWeight = FontWeight.Medium))
        }

        // Settings glass button
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(Brush.verticalGradient(
                    listOf(Color.White.copy(0.26f), Color.White.copy(0.10f))))
                .border(1.dp, Brush.linearGradient(
                    listOf(Color.White.copy(0.60f), OrbBlue.copy(0.20f))), CircleShape)
                .clickable { onSettings() }
                .drawBehind {
                    drawCircle(Brush.radialGradient(
                        listOf(Color.White.copy(0.12f), Color.Transparent),
                        radius = size.minDimension * 0.5f), radius = size.minDimension * 0.5f)
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Settings, null, tint = TextPrimary, modifier = Modifier.size(18.dp))
        }
    }
}

// ── Clock Header ──────────────────────────────────────────────────────────────
@Composable
private fun ClockHeaderSection(
    clockFace: ClockFaceStyle,
    alarms: List<Alarm>,
    scheduler: AlarmScheduler,
    isAr: Boolean,
    onLongPress: () -> Unit
) {
    val nextAlarm = remember(alarms) { alarms.firstOrNull { it.isEnabled } }
    val nextMillis = remember(nextAlarm) { nextAlarm?.let { scheduler.nextTriggerMillis(it) } }

    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .pointerInput(Unit) { detectTapGestures(onLongPress = { onLongPress() }) }
                .padding(vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            // Multi-layer glow behind clock
            Box(
                Modifier.size(230.dp).drawBehind {
                    // Outer nebula glow
                    drawCircle(brush = Brush.radialGradient(
                        listOf(OrbPurple.copy(0.12f), OrbBlue.copy(0.08f), Color.Transparent),
                        radius = size.minDimension * 0.8f), radius = size.minDimension * 0.8f)
                    // Inner glow ring
                    drawCircle(brush = Brush.radialGradient(
                        listOf(OrbBlue.copy(0.18f), Color.Transparent),
                        radius = size.minDimension * 0.55f), radius = size.minDimension * 0.55f)
                }
            )
            AnalogClockWithFace(face = clockFace, size = 192.dp)
        }

        Spacer(Modifier.height(12.dp))

        // Next alarm info
        if (nextAlarm != null && nextMillis != null) {
            val remaining = TimeUtils.timeUntilLabel(nextMillis, isAr)
            if (remaining.isNotBlank()) {
                GlassPill(color = OrbBlue) {
                    Row(verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Icon(Icons.Filled.Alarm, null, tint = OrbBlue, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = if (isAr) "المنبه القادم · $remaining" else "Next · $remaining",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = OrbBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        } else {
            Text(
                text = if (isAr) "اضغط مطولاً لتغيير وجه الساعة" else "Long press to change clock style",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = TextQuaternary, fontSize = 10.sp, letterSpacing = 0.3.sp)
            )
        }
        Spacer(Modifier.height(4.dp))
    }
}

// ── Clock Face Picker ─────────────────────────────────────────────────────────
@Composable
private fun ClockFacePicker(
    current: ClockFaceStyle, isAr: Boolean,
    onSelect: (ClockFaceStyle) -> Unit, onDismiss: () -> Unit
) {
    val faces = listOf(
        ClockFaceStyle.CLASSIC to (if (isAr) "كلاسيكي" else "Classic"),
        ClockFaceStyle.MODERN  to (if (isAr) "حديث"    else "Modern"),
        ClockFaceStyle.DIGITAL to (if (isAr) "رقمي"    else "Digital"),
        ClockFaceStyle.MINIMAL to (if (isAr) "مينيمال" else "Minimal"),
        ClockFaceStyle.NEON    to (if (isAr) "نيون"    else "Neon"),
        ClockFaceStyle.RETRO   to (if (isAr) "ريترو"   else "Retro"),
    )
    GlassCard(Modifier.fillMaxWidth(), cornerRadius = 22.dp) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Watch, null, tint = OrbBlue, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text(if (isAr) "شكل الساعة" else "Clock Style",
                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.weight(1f))
                Box(Modifier.size(26.dp).clip(CircleShape).background(GlassBg)
                    .clickable { onDismiss() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Close, null, tint = TextTertiary, modifier = Modifier.size(13.dp))
                }
            }
            Spacer(Modifier.height(12.dp))
            // 3-column grid
            for (row in faces.chunked(3)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    row.forEach { (face, label) ->
                        val sel = face == current
                        Box(
                            modifier = Modifier.weight(1f)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (sel) OrbBlue.copy(0.25f) else Color.White.copy(0.07f))
                                .border(1.dp,
                                    if (sel) OrbBlue.copy(0.75f) else Color.White.copy(0.15f),
                                    RoundedCornerShape(14.dp))
                                .clickable { onSelect(face) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(label, style = MaterialTheme.typography.labelSmall.copy(
                                color = if (sel) OrbBlue else TextTertiary, fontSize = 10.sp,
                                fontWeight = if (sel) FontWeight.ExtraBold else FontWeight.Normal))
                        }
                    }
                    // Pad remaining
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

// ── Floating Add Button ───────────────────────────────────────────────────────
@Composable
private fun IosFloatingAddButton(
    isAr: Boolean, isScrolled: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier
) {
    val inf = rememberInfiniteTransition(label = "fab")
    val glowAlpha by inf.animateFloat(0.28f, 0.65f,
        infiniteRepeatable(tween(2000, easing = EaseInOutSine), RepeatMode.Reverse), "glow")

    val targetWidth by animateDpAsState(
        targetValue = if (isScrolled) 58.dp else 160.dp,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow), label = "w")

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        // Outer ambient glow
        Box(Modifier.size(targetWidth + 24.dp, 80.dp).drawBehind {
            drawCircle(brush = Brush.radialGradient(
                listOf(OrbBlue.copy(glowAlpha * 0.40f), Color.Transparent),
                radius = size.minDimension * 1.1f), radius = size.minDimension * 1.1f)
        })

        // Glass pill button
        Box(
            modifier = Modifier
                .width(targetWidth).height(56.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(Brush.verticalGradient(
                    listOf(Color.White.copy(0.30f), OrbBlue.copy(0.55f))))
                .border(1.dp, Brush.linearGradient(
                    listOf(Color.White.copy(0.65f), Color.White.copy(0.20f),
                        OrbBlue.copy(0.20f))), RoundedCornerShape(28.dp))
                .drawBehind {
                    // Top specular
                    drawRect(Brush.verticalGradient(
                        listOf(Color.White.copy(0.20f), Color.Transparent),
                        endY = size.height * 0.42f))
                    // Bottom shadow
                    drawRect(Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Black.copy(0.20f)),
                        startY = size.height * 0.65f))
                }
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 20.dp)) {
                Icon(Icons.Filled.Add, null, tint = Color.White, modifier = Modifier.size(24.dp))
                AnimatedVisibility(
                    visible = !isScrolled,
                    enter = expandHorizontally(spring(stiffness = Spring.StiffnessLow)) + fadeIn(),
                    exit  = shrinkHorizontally(tween(160)) + fadeOut(tween(120))
                ) {
                    Row {
                        Spacer(Modifier.width(7.dp))
                        Text(
                            text = if (isAr) "منبه جديد" else "New Alarm",
                            style = MaterialTheme.typography.titleSmall.copy(
                                color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                        )
                    }
                }
            }
        }
    }
}

// ── Empty State ───────────────────────────────────────────────────────────────
@Composable
private fun EmptyAlarmsPlaceholder(isAr: Boolean) {
    val inf = rememberInfiniteTransition(label = "empty")
    val pulse by inf.animateFloat(0.88f, 1.06f,
        infiniteRepeatable(tween(1800, easing = EaseInOutSine), RepeatMode.Reverse), "p")
    val glowA by inf.animateFloat(0.06f, 0.22f,
        infiniteRepeatable(tween(2200, easing = EaseInOutSine), RepeatMode.Reverse), "g")
    val rotate by inf.animateFloat(0f, 360f,
        infiniteRepeatable(tween(20_000, easing = LinearEasing)), "r")

    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 52.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier.size(110.dp)
                .graphicsLayer(scaleX = pulse, scaleY = pulse)
                .drawBehind {
                    // Outer glow halo
                    drawCircle(brush = Brush.radialGradient(
                        listOf(OrbBlue.copy(glowA), OrbPurple.copy(glowA * 0.4f), Color.Transparent),
                        radius = size.minDimension), radius = size.minDimension)
                },
            contentAlignment = Alignment.Center
        ) {
            // Rotating outer ring
            Canvas(modifier = Modifier.size(94.dp)) {
                val cx = size.width/2f; val cy = size.height/2f; val r = size.minDimension/2f - 2f
                rotate(rotate, pivot = Offset(cx, cy)) {
                    drawCircle(brush = Brush.sweepGradient(
                        listOf(OrbBlue.copy(0f), OrbBlue.copy(0.65f), OrbPurple.copy(0.35f), OrbBlue.copy(0f)),
                        center = Offset(cx, cy)),
                        radius = r, center = Offset(cx, cy), style = Stroke(2f))
                }
            }
            // Glass circle
            Box(
                Modifier.size(76.dp).clip(CircleShape)
                    .background(Brush.verticalGradient(
                        listOf(Color.White.copy(0.16f), Color.White.copy(0.07f))))
                    .border(1.dp, Brush.linearGradient(
                        listOf(Color.White.copy(0.45f), OrbBlue.copy(0.20f))), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Alarm, null, tint = TextTertiary.copy(0.60f),
                    modifier = Modifier.size(36.dp))
            }
        }

        Spacer(Modifier.height(22.dp))
        Text(if (isAr) "لا توجد منبهات بعد" else "No Alarms Yet",
            style = MaterialTheme.typography.titleLarge.copy(
                color = TextSecondary, fontWeight = FontWeight.Bold))
        Spacer(Modifier.height(7.dp))
        Text(
            if (isAr) "اضغط «منبه جديد» للبدء" else "Tap «New Alarm» to get started",
            style = MaterialTheme.typography.bodyMedium.copy(
                color = TextTertiary, fontWeight = FontWeight.Medium),
            textAlign = TextAlign.Center
        )
    }
}
