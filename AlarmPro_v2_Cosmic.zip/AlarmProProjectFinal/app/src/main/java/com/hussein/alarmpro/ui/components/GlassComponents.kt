package com.hussein.alarmpro.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.hussein.alarmpro.ui.theme.*
import kotlin.math.sin
import kotlin.math.cos

// ═══════════════════════════════════════════════════════════════════════════════
// COSMIC NEBULA BACKGROUND — 5-orb deep space animated system
// Each orb follows an independent Lissajous figure path
// ═══════════════════════════════════════════════════════════════════════════════
@Composable
fun LiquidGlassBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val transition = rememberInfiniteTransition(label = "cosmos")

    val t1 by transition.animateFloat(0f, (2f * Math.PI).toFloat(),
        infiniteRepeatable(tween(18_000, easing = LinearEasing)), "t1")
    val t2 by transition.animateFloat((Math.PI).toFloat(), (3f * Math.PI).toFloat(),
        infiniteRepeatable(tween(24_000, easing = LinearEasing)), "t2")
    val t3 by transition.animateFloat((Math.PI / 2f).toFloat(), (5f * Math.PI / 2f).toFloat(),
        infiniteRepeatable(tween(15_000, easing = LinearEasing)), "t3")
    val t4 by transition.animateFloat(0f, (2f * Math.PI).toFloat(),
        infiniteRepeatable(tween(31_000, easing = LinearEasing)), "t4")
    val t5 by transition.animateFloat((Math.PI * 0.7f).toFloat(), (Math.PI * 2.7f).toFloat(),
        infiniteRepeatable(tween(22_000, easing = LinearEasing)), "t5")

    // Nebula shimmer intensity pulse
    val pulse by transition.animateFloat(0.85f, 1.0f,
        infiniteRepeatable(tween(4000, easing = EaseInOutSine), RepeatMode.Reverse), "pulse")

    Box(
        modifier = modifier
            .fillMaxSize()
            .drawBehind {
                val w = size.width
                val h = size.height

                // ── Layer 0: Pure OLED black base
                drawRect(DeepBlack)

                // ── Layer 1: Deep space nebula core (static radial)
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(
                            NebulaMid.copy(alpha = 0.7f),
                            NebulaStart.copy(alpha = 0.4f),
                            Color.Transparent
                        ),
                        center = Offset(w * 0.5f, h * 0.45f),
                        radius = w * 0.75f
                    ),
                    radius = w * 0.75f,
                    center = Offset(w * 0.5f, h * 0.45f)
                )

                // ── Orb 1: Signature iOS blue (top-left Lissajous)
                val o1x = (0.15f + 0.32f * sin(t1)) * w
                val o1y = (0.18f + 0.20f * cos(t1 * 0.65f)) * h
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(
                            OrbBlue.copy(alpha = 0.55f * pulse),
                            OrbBlue.copy(alpha = 0.18f * pulse),
                            Color.Transparent
                        ),
                        center = Offset(o1x, o1y), radius = w * 0.58f
                    ),
                    radius = w * 0.58f, center = Offset(o1x, o1y)
                )

                // ── Orb 2: Electric violet (bottom-right)
                val o2x = (0.68f + 0.26f * sin(t2)) * w
                val o2y = (0.62f + 0.22f * cos(t2 * 0.78f)) * h
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(
                            OrbPurple.copy(alpha = 0.50f * pulse),
                            OrbNebula.copy(alpha = 0.12f),
                            Color.Transparent
                        ),
                        center = Offset(o2x, o2y), radius = w * 0.52f
                    ),
                    radius = w * 0.52f, center = Offset(o2x, o2y)
                )

                // ── Orb 3: Aurora cyan (bottom-center)
                val o3x = (0.42f + 0.20f * sin(t3)) * w
                val o3y = (0.80f + 0.12f * cos(t3 * 1.18f)) * h
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(OrbCyan.copy(alpha = 0.25f * pulse), Color.Transparent),
                        center = Offset(o3x, o3y), radius = w * 0.40f
                    ),
                    radius = w * 0.40f, center = Offset(o3x, o3y)
                )

                // ── Orb 4: Deep indigo accent (top-right)
                val o4x = (0.82f + 0.14f * sin(t4 * 1.3f)) * w
                val o4y = (0.22f + 0.16f * cos(t4)) * h
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(OrbIndigo.copy(alpha = 0.30f * pulse), Color.Transparent),
                        center = Offset(o4x, o4y), radius = w * 0.35f
                    ),
                    radius = w * 0.35f, center = Offset(o4x, o4y)
                )

                // ── Orb 5: Rose nebula (mid-left micro)
                val o5x = (0.08f + 0.12f * cos(t5 * 0.9f)) * w
                val o5y = (0.55f + 0.18f * sin(t5)) * h
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(OrbPink.copy(alpha = 0.16f * pulse), Color.Transparent),
                        center = Offset(o5x, o5y), radius = w * 0.28f
                    ),
                    radius = w * 0.28f, center = Offset(o5x, o5y)
                )

                // ── Horizon glow: signature top-edge blue shimmer
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(
                            OrbBlue.copy(alpha = 0.06f),
                            OrbPurple.copy(alpha = 0.03f),
                            Color.Transparent
                        ),
                        endY = h * 0.22f
                    )
                )

                // ── Bottom vignette: ground the composition
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f)),
                        startY = h * 0.75f
                    )
                )
            },
        content = content
    )
}

// ═══════════════════════════════════════════════════════════════════════════════
// PREMIUM GLASS CARD — Multi-layer frosted glass with specular highlights
// Features: gradient fill + luminous border + inner highlight + depth shadow
// ═══════════════════════════════════════════════════════════════════════════════
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 22.dp,
    alpha: Float = 1f,
    tint: Color = Color.White,
    elevation: Boolean = true,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .clip(shape)
            // Layer 1: Base translucent fill — mimics frosted glass
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        tint.copy(alpha = 0.20f * alpha),
                        tint.copy(alpha = 0.08f * alpha)
                    )
                )
            )
            // Layer 2: Luminous multi-stop border (bright top, blue bottom)
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.55f * alpha),
                        Color.White.copy(alpha = 0.25f * alpha),
                        Color.White.copy(alpha = 0.08f * alpha),
                        OrbBlue.copy(alpha = 0.20f * alpha)
                    ),
                    start = Offset(0f, 0f),
                    end   = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
                ),
                shape = shape
            )
            // Layer 3: Inner specular surface highlight
            .drawBehind {
                // Top edge specular (the bright rim at the top of glass)
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.13f * alpha),
                            Color.Transparent
                        ),
                        endY = size.height * 0.30f
                    )
                )
                // Bottom inner shadow for depth
                if (elevation) {
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.18f * alpha)
                            ),
                            startY = size.height * 0.68f
                        )
                    )
                }
            },
        content = content
    )
}

// ═══════════════════════════════════════════════════════════════════════════════
// PREMIUM GLASS PILL — Capsule shape for tags/labels/next-alarm badges
// ═══════════════════════════════════════════════════════════════════════════════
@Composable
fun GlassPill(
    modifier: Modifier = Modifier,
    color: Color = OrbBlue,
    alpha: Float = 1f,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(
                brush = Brush.verticalGradient(
                    listOf(
                        color.copy(alpha = 0.25f * alpha),
                        color.copy(alpha = 0.10f * alpha)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    listOf(
                        color.copy(alpha = 0.70f * alpha),
                        color.copy(alpha = 0.25f * alpha),
                        color.copy(alpha = 0.10f * alpha)
                    )
                ),
                shape = RoundedCornerShape(50)
            )
            .drawBehind {
                // Inner top highlight
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.08f * alpha), Color.Transparent),
                        endY = size.height * 0.45f
                    )
                )
            },
        content = content
    )
}

// ═══════════════════════════════════════════════════════════════════════════════
// NEON GLOW CARD — Electric neon border with pulsing glow effect
// Perfect for active/highlighted states
// ═══════════════════════════════════════════════════════════════════════════════
@Composable
fun NeonCard(
    modifier: Modifier = Modifier,
    color: Color = OrbBlue,
    cornerRadius: Dp = 22.dp,
    pulsing: Boolean = true,
    content: @Composable BoxScope.() -> Unit
) {
    val inf = rememberInfiniteTransition(label = "neon")
    val glowIntensity by if (pulsing) {
        inf.animateFloat(0.50f, 1.0f,
            infiniteRepeatable(tween(1500, easing = EaseInOutSine), RepeatMode.Reverse), "neon")
    } else {
        remember { derivedStateOf { mutableStateOf(0.75f) } }.let {
            remember { mutableStateOf(0.75f) }
        }.let {
            inf.animateFloat(0.75f, 0.75f,
                infiniteRepeatable(tween(1000), RepeatMode.Restart), "neon_static")
        }
    }

    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .clip(shape)
            // Ambient outer glow drawn before clipping
            .drawBehind {
                // Outer neon glow
                drawRoundRect(
                    brush = Brush.radialGradient(
                        listOf(
                            color.copy(alpha = 0.35f * glowIntensity),
                            color.copy(alpha = 0.10f * glowIntensity),
                            Color.Transparent
                        ),
                        radius = size.minDimension * 0.9f
                    ),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(
                        cornerRadius.toPx() + 6f
                    ),
                    topLeft = Offset(-6f, -6f),
                    size = size.copy(
                        width = size.width + 12f,
                        height = size.height + 12f
                    )
                )
            }
            .background(
                brush = Brush.verticalGradient(
                    listOf(
                        color.copy(alpha = 0.18f),
                        Color.Black.copy(alpha = 0.55f)
                    )
                )
            )
            .border(
                width = 1.5.dp,
                brush = Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = 0.55f * glowIntensity),
                        color.copy(alpha = 0.85f * glowIntensity),
                        color.copy(alpha = 0.40f * glowIntensity)
                    )
                ),
                shape = shape
            ),
        content = content
    )
}

// ═══════════════════════════════════════════════════════════════════════════════
// AURORA CARD — Shifting color gradient card (mesmerizing aurora borealis)
// ═══════════════════════════════════════════════════════════════════════════════
@Composable
fun AuroraCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 22.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val inf = rememberInfiniteTransition(label = "aurora")
    val shift by inf.animateFloat(0f, 1f,
        infiniteRepeatable(tween(5000, easing = LinearEasing)), "shift")

    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .clip(shape)
            .drawBehind {
                val hueShift = shift * 360f
                // Shifting aurora gradient
                drawRect(
                    brush = Brush.linearGradient(
                        listOf(
                            OrbBlue.copy(alpha = 0.22f),
                            OrbPurple.copy(alpha = 0.18f),
                            OrbCyan.copy(alpha = 0.15f),
                            OrbBlue.copy(alpha = 0.22f)
                        ),
                        start = Offset(shift * size.width, 0f),
                        end   = Offset((shift + 1f) * size.width, size.height)
                    )
                )
                // Top specular
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color.White.copy(0.12f), Color.Transparent),
                        endY = size.height * 0.35f
                    )
                )
            }
            .border(
                width = 1.dp,
                brush = Brush.sweepGradient(
                    listOf(
                        Color.White.copy(0.45f),
                        OrbBlue.copy(0.35f),
                        OrbPurple.copy(0.25f),
                        OrbCyan.copy(0.20f),
                        Color.White.copy(0.45f)
                    )
                ),
                shape = shape
            ),
        content = content
    )
}

// ═══════════════════════════════════════════════════════════════════════════════
// GLASS NAV BAR — Floating pill-shaped bottom navigation
// ═══════════════════════════════════════════════════════════════════════════════
@Composable
fun GlassNavBar(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(30.dp))
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.28f),
                        Color.White.copy(alpha = 0.14f)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.60f),
                        Color.White.copy(alpha = 0.08f)
                    )
                ),
                shape = RoundedCornerShape(30.dp)
            )
            .drawBehind {
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color.White.copy(alpha = 0.20f), Color.Transparent),
                        endY = size.height * 0.28f
                    )
                )
            },
        content = content
    )
}

// ═══════════════════════════════════════════════════════════════════════════════
// DEEP GLASS SHEET — Heavier glass for modals/bottom sheets
// ═══════════════════════════════════════════════════════════════════════════════
@Composable
fun DeepGlassSheet(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 28.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(topStart = cornerRadius, topEnd = cornerRadius)
    androidx.compose.foundation.layout.Column(
        modifier = modifier
            .clip(shape)
            .background(
                brush = Brush.verticalGradient(
                    listOf(
                        Color.White.copy(alpha = 0.24f),
                        Color.White.copy(alpha = 0.10f),
                        DarkNavy.copy(alpha = 0.85f)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.60f), Color.White.copy(alpha = 0.05f))
                ),
                shape = shape
            )
            .drawBehind {
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(Color.White.copy(0.16f), Color.Transparent),
                        endY = size.height * 0.15f
                    )
                )
            },
        content = content
    )
}
