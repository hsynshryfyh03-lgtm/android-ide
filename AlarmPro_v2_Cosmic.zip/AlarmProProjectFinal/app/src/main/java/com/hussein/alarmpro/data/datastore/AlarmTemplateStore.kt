package com.hussein.alarmpro.data.datastore

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "alarm_template")

/**
 * Stores the default template that is used when creating new alarms.
 * User can customize these defaults from Settings screen.
 */
@Singleton
class AlarmTemplateStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val VOLUME         = intPreferencesKey("tpl_volume")
        val VIBRATE        = booleanPreferencesKey("tpl_vibrate")
        val VIB_PATTERN    = intPreferencesKey("tpl_vib_pattern")
        val SNOOZE_EN      = booleanPreferencesKey("tpl_snooze_enabled")
        val SNOOZE_MIN     = intPreferencesKey("tpl_snooze_min")
        val SNOOZE_REDUCE  = intPreferencesKey("tpl_snooze_reduce")
        val SNOOZE_MAX     = intPreferencesKey("tpl_snooze_max")
        val AUTO_SNOOZE    = intPreferencesKey("tpl_auto_snooze")
        val DISMISS_TYPE   = intPreferencesKey("tpl_dismiss_type")
        val DISMISS_TASK   = intPreferencesKey("tpl_dismiss_task")
        val TASK_DIFF      = intPreferencesKey("tpl_task_difficulty")
        val AUTO_DISMISS   = intPreferencesKey("tpl_auto_dismiss")
        val WAKE_CHECK_EN  = booleanPreferencesKey("tpl_wake_check_enabled")
        val WAKE_DELAY     = intPreferencesKey("tpl_wake_delay")
        val WAKE_COUNTDOWN = intPreferencesKey("tpl_wake_countdown")
        val PRE_ALARM_MIN  = intPreferencesKey("tpl_pre_alarm_min")
        val SOUND_URI      = stringPreferencesKey("tpl_sound_uri")
        val SOUND_NAME     = stringPreferencesKey("tpl_sound_name")
    }

    data class AlarmTemplate(
        val volumePercent: Int = 80,
        val isVibrate: Boolean = true,
        val vibrationPattern: Int = 1,
        val isSnoozeEnabled: Boolean = true,
        val snoozeMinutes: Int = 9,
        val snoozeReduceMinutes: Int = 0,
        val snoozeMaxCount: Int = -1,
        val autoSnoozeMinutes: Int = -1,
        val dismissType: Int = 0,
        val dismissTask: Int = 0,
        val dismissTaskDifficulty: Int = 1,
        val autoDissmissMinutes: Int = -1,
        val wakeCheckEnabled: Boolean = false,
        val wakeCheckDelayMinutes: Int = 5,
        val wakeCheckCountdownMinutes: Int = 2,
        val preAlarmNotifyMinutes: Int = 5,
        val soundUri: String = "",
        val soundName: String = ""
    )

    val template: Flow<AlarmTemplate> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            AlarmTemplate(
                volumePercent          = p[Keys.VOLUME] ?: 80,
                isVibrate              = p[Keys.VIBRATE] ?: true,
                vibrationPattern       = p[Keys.VIB_PATTERN] ?: 1,
                isSnoozeEnabled        = p[Keys.SNOOZE_EN] ?: true,
                snoozeMinutes          = p[Keys.SNOOZE_MIN] ?: 9,
                snoozeReduceMinutes    = p[Keys.SNOOZE_REDUCE] ?: 0,
                snoozeMaxCount         = p[Keys.SNOOZE_MAX] ?: -1,
                autoSnoozeMinutes      = p[Keys.AUTO_SNOOZE] ?: -1,
                dismissType            = p[Keys.DISMISS_TYPE] ?: 0,
                dismissTask            = p[Keys.DISMISS_TASK] ?: 0,
                dismissTaskDifficulty  = p[Keys.TASK_DIFF] ?: 1,
                autoDissmissMinutes    = p[Keys.AUTO_DISMISS] ?: -1,
                wakeCheckEnabled       = p[Keys.WAKE_CHECK_EN] ?: false,
                wakeCheckDelayMinutes  = p[Keys.WAKE_DELAY] ?: 5,
                wakeCheckCountdownMinutes = p[Keys.WAKE_COUNTDOWN] ?: 2,
                preAlarmNotifyMinutes  = p[Keys.PRE_ALARM_MIN] ?: 5,
                soundUri               = p[Keys.SOUND_URI] ?: "",
                soundName              = p[Keys.SOUND_NAME] ?: ""
            )
        }

    suspend fun saveTemplate(t: AlarmTemplate) {
        context.dataStore.edit { p ->
            p[Keys.VOLUME]         = t.volumePercent
            p[Keys.VIBRATE]        = t.isVibrate
            p[Keys.VIB_PATTERN]    = t.vibrationPattern
            p[Keys.SNOOZE_EN]      = t.isSnoozeEnabled
            p[Keys.SNOOZE_MIN]     = t.snoozeMinutes
            p[Keys.SNOOZE_REDUCE]  = t.snoozeReduceMinutes
            p[Keys.SNOOZE_MAX]     = t.snoozeMaxCount
            p[Keys.AUTO_SNOOZE]    = t.autoSnoozeMinutes
            p[Keys.DISMISS_TYPE]   = t.dismissType
            p[Keys.DISMISS_TASK]   = t.dismissTask
            p[Keys.TASK_DIFF]      = t.dismissTaskDifficulty
            p[Keys.AUTO_DISMISS]   = t.autoDissmissMinutes
            p[Keys.WAKE_CHECK_EN]  = t.wakeCheckEnabled
            p[Keys.WAKE_DELAY]     = t.wakeCheckDelayMinutes
            p[Keys.WAKE_COUNTDOWN] = t.wakeCheckCountdownMinutes
            p[Keys.PRE_ALARM_MIN]  = t.preAlarmNotifyMinutes
            p[Keys.SOUND_URI]      = t.soundUri
            p[Keys.SOUND_NAME]     = t.soundName
        }
    }
}
