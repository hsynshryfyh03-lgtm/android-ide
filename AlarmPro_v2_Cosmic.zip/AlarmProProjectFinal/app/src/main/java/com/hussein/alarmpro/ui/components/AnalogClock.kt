package com.hussein.alarmpro.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.hussein.alarmpro.ui.theme.*
import kotlinx.coroutines.delay
import java.util.Calendar
import kotlin.math.*

@Composable
fun AnalogClock(modifier: Modifier = Modifier, size: Dp = 220.dp) {
    var cal by remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) {
        while (true) {
            cal = Calendar.getInstance()
            delay(1000L)
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "ring")
    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(20_000, easing = LinearEasing)),
        label = "ring"
    )

    Canvas(modifier = modifier.size(size)) {
        val cx = this.size.width / 2f
        val cy = this.size.height / 2f
        val radius = (this.size.minDimension / 2f) * 0.92f

        drawClockFace(cx, cy, radius)
        drawRotatingRing(cx, cy, radius, ringRotation)
        drawTicks(cx, cy, radius)
        drawHands(cx, cy, radius, cal)
        drawCenter(cx, cy)
    }
}

private fun DrawScope.drawClockFace(cx: Float, cy: Float, radius: Float) {
    // Outer glow
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(OrbBlue.copy(alpha = 0.12f), Color.Transparent),
            center = Offset(cx, cy), radius = radius * 1.3f
        ),
        radius = radius * 1.3f, center = Offset(cx, cy)
    )
    // Glass face background
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color.White.copy(alpha = 0.07f), ClockFaceColor),
            center = Offset(cx, cy - radius * 0.3f), radius = radius
        ),
        radius = radius, center = Offset(cx, cy)
    )
    // Face ring
    drawCircle(
        color = ClockRing, radius = radius,
        center = Offset(cx, cy), style = Stroke(width = 1.5f)
    )
    // Inner highlight arc at top
    drawArc(
        brush = Brush.sweepGradient(
            listOf(Color.White.copy(alpha = 0.3f), Color.Transparent, Color.Transparent),
            center = Offset(cx, cy)
        ),
        startAngle = 200f, sweepAngle = 140f,
        useCenter = false,
        topLeft = Offset(cx - radius * 0.88f, cy - radius * 0.88f),
        size = androidx.compose.ui.geometry.Size(radius * 1.76f, radius * 1.76f),
        style = Stroke(width = 1f)
    )
}

private fun DrawScope.drawRotatingRing(cx: Float, cy: Float, radius: Float, rotation: Float) {
    rotate(rotation, pivot = Offset(cx, cy)) {
        drawCircle(
            brush = Brush.sweepGradient(
                listOf(
                    OrbBlue.copy(alpha = 0f),
                    OrbBlue.copy(alpha = 0.5f),
                    OrbPurple.copy(alpha = 0.3f),
                    OrbBlue.copy(alpha = 0f)
                ),
                center = Offset(cx, cy)
            ),
            radius = radius + 6f, center = Offset(cx, cy),
            style = Stroke(width = 2.5f)
        )
    }
}

private fun DrawScope.drawTicks(cx: Float, cy: Float, radius: Float) {
    for (i in 0 until 60) {
        val angle = Math.toRadians(i * 6.0 - 90.0)
        val isHour = i % 5 == 0
        val startR = if (isHour) radius * 0.82f else radius * 0.88f
        val endR = radius * 0.95f
        val tickAlpha = if (isHour) 0.85f else 0.35f
        val tickWidth = if (isHour) 2f else 1f

        drawLine(
            color = Color.White.copy(alpha = tickAlpha),
            start = Offset(cx + startR * cos(angle).toFloat(), cy + startR * sin(angle).toFloat()),
            end   = Offset(cx + endR   * cos(angle).toFloat(), cy + endR   * sin(angle).toFloat()),
            strokeWidth = tickWidth,
            cap = StrokeCap.Round
        )
        // Hour numbers (12, 3, 6, 9)
        if (isHour && i % 15 == 0) {
            val numR = radius * 0.68f
            // Just marks, not text (Canvas text requires Paint)
            drawCircle(
                color = OrbBlue.copy(alpha = 0.6f),
                radius = 3f,
                center = Offset(cx + numR * cos(angle).toFloat(), cy + numR * sin(angle).toFloat())
            )
        }
    }
}

private fun DrawScope.drawHands(cx: Float, cy: Float, radius: Float, cal: Calendar) {
    val hour   = cal.get(Calendar.HOUR).toFloat()
    val minute = cal.get(Calendar.MINUTE).toFloat()
    val second = cal.get(Calendar.SECOND).toFloat()

    val hourAngle   = (hour + minute / 60f) * 30f - 90f
    val minuteAngle = (minute + second / 60f) * 6f  - 90f
    val secondAngle = second * 6f - 90f

    // Hour hand
    drawHand(cx, cy, radius * 0.50f, radius * 0.10f, hourAngle, ClockHourHand, 5f)
    // Minute hand
    drawHand(cx, cy, radius * 0.72f, radius * 0.12f, minuteAngle, ClockMinHand, 3.5f)
    // Second hand
    drawHand(cx, cy, radius * 0.80f, radius * 0.18f, secondAngle, ClockSecHand, 1.5f)
}

private fun DrawScope.drawHand(
    cx: Float, cy: Float,
    length: Float, backLength: Float,
    angleDeg: Float, color: Color, width: Float
) {
    val angle = Math.toRadians(angleDeg.toDouble())
    val tipX = cx + length * cos(angle).toFloat()
    val tipY = cy + length * sin(angle).toFloat()
    val backX = cx - backLength * cos(angle).toFloat()
    val backY = cy - backLength * sin(angle).toFloat()

    // Shadow
    drawLine(
        color = Color.Black.copy(alpha = 0.3f),
        start = Offset(backX + 1f, backY + 1f),
        end   = Offset(tipX  + 1f, tipY  + 1f),
        strokeWidth = width + 1f,
        cap = StrokeCap.Round
    )
    drawLine(
        color = color,
        start = Offset(backX, backY),
        end   = Offset(tipX,  tipY),
        strokeWidth = width,
        cap = StrokeCap.Round
    )
}

private fun DrawScope.drawCenter(cx: Float, cy: Float) {
    // Outer ring
    drawCircle(color = ClockCenter, radius = 8f, center = Offset(cx, cy))
    drawCircle(color = Color.White.copy(alpha = 0.9f), radius = 4f, center = Offset(cx, cy))
    drawCircle(color = ClockCenter.copy(alpha = 0.5f), radius = 12f,
        center = Offset(cx, cy), style = Stroke(width = 1.5f))
}
