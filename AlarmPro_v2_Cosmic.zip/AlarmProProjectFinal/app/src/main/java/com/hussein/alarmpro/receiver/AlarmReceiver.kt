package com.hussein.alarmpro.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.hussein.alarmpro.data.repository.AlarmRepository
import com.hussein.alarmpro.service.AlarmService
import com.hussein.alarmpro.util.AlarmScheduler
import com.hussein.alarmpro.util.NotificationHelper
import com.hussein.alarmpro.util.PreAlarmScheduler
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class AlarmReceiver : BroadcastReceiver() {

    @Inject lateinit var repository: AlarmRepository
    @Inject lateinit var scheduler: AlarmScheduler
    @Inject lateinit var preAlarmScheduler: PreAlarmScheduler
    @Inject lateinit var notifHelper: NotificationHelper
    @Inject lateinit var vacationStore: com.hussein.alarmpro.data.datastore.VacationStore

    override fun onReceive(context: Context, intent: Intent) {
        val alarmId = intent.getIntExtra("alarm_id", -1).takeIf { it != -1 } ?: return

        when (intent.action) {
            "com.hussein.alarmpro.ACTION_ALARM_FIRE" -> {
                // Check vacation mode before firing
                CoroutineScope(Dispatchers.IO).launch {
                    val alarm = repository.getById(alarmId) ?: return@launch
                    val vm = vacationStore.vacationMode.first()
                    val onVacation = vacationStore.isActiveNow(vm) && !alarm.vacationExempt
                    if (!onVacation) {
                        context.startForegroundService(
                            Intent(context, AlarmService::class.java).apply {
                                action = AlarmService.ACTION_START
                                putExtra("alarm_id", alarmId)
                            }
                        )
                    } else {
                        // Vacation active: reschedule for next occurrence without firing
                        scheduler.schedule(alarm)
                    }
                }
            }
            "com.hussein.alarmpro.ACTION_ALARM_SNOOZE" -> {
                context.startService(
                    Intent(context, AlarmService::class.java).apply {
                        action = AlarmService.ACTION_SNOOZE
                        putExtra("alarm_id", alarmId)
                    }
                )
            }
            "com.hussein.alarmpro.ACTION_ALARM_DISMISS" -> {
                context.startService(
                    Intent(context, AlarmService::class.java).apply {
                        action = AlarmService.ACTION_DISMISS
                        putExtra("alarm_id", alarmId)
                    }
                )
            }
            // Feature 4: pre-alarm notification fires here
            "com.hussein.alarmpro.ACTION_PRE_ALARM_FIRE" -> {
                CoroutineScope(Dispatchers.IO).launch {
                    val alarm = repository.getById(alarmId) ?: return@launch
                    if (alarm.isEnabled && !alarm.skipToday) {
                        notifHelper.showPreAlarm(alarm, alarm.preAlarmNotifyMinutes)
                    }
                }
            }
            "com.hussein.alarmpro.ACTION_SKIP_TODAY" -> {
                CoroutineScope(Dispatchers.IO).launch {
                    repository.getById(alarmId)?.let { alarm ->
                        repository.update(alarm.copy(skipToday = true))
                        scheduler.cancel(alarmId)
                        preAlarmScheduler.cancel(alarmId)
                    }
                }
            }
            // Wake check: re-ring alarm to verify user is awake
            "com.hussein.alarmpro.ACTION_WAKE_CHECK_FIRE" -> {
                CoroutineScope(Dispatchers.IO).launch {
                    val alarm = repository.getById(alarmId) ?: return@launch
                    if (alarm.isEnabled) {
                        context.startForegroundService(
                            Intent(context, AlarmService::class.java).apply {
                                action = AlarmService.ACTION_START
                                putExtra("alarm_id", alarmId)
                                putExtra("is_wake_check", true)
                            }
                        )
                    }
                }
            }
        }
    }
}
