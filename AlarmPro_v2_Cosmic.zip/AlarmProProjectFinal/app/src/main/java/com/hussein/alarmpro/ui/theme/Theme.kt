package com.hussein.alarmpro.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AlarmDarkColors = darkColorScheme(
    primary          = OrbBlue,
    onPrimary        = Color.White,
    secondary        = OrbPurple,
    onSecondary      = Color.White,
    tertiary         = OrbCyan,
    onTertiary       = Color.White,
    background       = DeepBlack,
    onBackground     = TextPrimary,
    surface          = DarkNavy,
    onSurface        = TextPrimary,
    surfaceVariant   = GlassBg,
    onSurfaceVariant = TextSecondary,
    outline          = GlassBorder,
    error            = OrbPink,
    onError          = Color.White,
    primaryContainer = GlassBlue,
    secondaryContainer = GlassPurple,
    tertiaryContainer  = GlassCyan
)

@Composable
fun AlarmProTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AlarmDarkColors,
        typography  = AlarmTypography,
        content     = content
    )
}
