package com.hussein.alarmpro.util

import android.content.Context
import android.content.res.AssetFileDescriptor
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.provider.Settings
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

const val ASSET_SOUND_PREFIX = "asset://"
private const val SOUNDS_DIR = "sounds"
private val SUPPORTED_EXTENSIONS = setOf("mp3", "ogg", "wav", "m4a", "aac", "flac")

data class BuiltinSound(
    val fileName: String,   // actual file name in assets/sounds/  e.g. "morning.mp3"
    val displayName: String // friendly name shown in UI (derived from file name)
) {
    val uri: String get() = "$ASSET_SOUND_PREFIX$fileName"
}

/**
 * Scans assets/sounds/ at runtime — no manual registration needed.
 * Just drop any audio file in the folder and it appears automatically.
 */
fun loadBuiltinSounds(context: Context): List<BuiltinSound> {
    // Always include the system default as first entry
    val result = mutableListOf(
        BuiltinSound("default", if (TimeUtils.isArabic()) "النغمة الافتراضية" else "Default Ringtone")
    )
    runCatching {
        val files = context.assets.list(SOUNDS_DIR) ?: return@runCatching
        files
            .filter { file ->
                val ext = file.substringAfterLast('.', "").lowercase()
                ext in SUPPORTED_EXTENSIONS
            }
            .sorted()
            .forEach { file ->
                val name = file
                    .substringBeforeLast('.')          // remove extension
                    .replace('_', ' ')                 // underscores → spaces
                    .replace('-', ' ')                 // dashes → spaces
                    .split(' ')
                    .joinToString(" ") { word ->       // capitalize each word
                        word.replaceFirstChar { it.uppercaseChar() }
                    }
                result.add(BuiltinSound(fileName = file, displayName = name))
            }
    }
    return result
}

@Singleton
class SoundManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var mediaPlayer: MediaPlayer? = null
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null

    /** Lazily loaded list of all sounds found in assets/sounds/ */
    val builtinSounds: List<BuiltinSound> by lazy { loadBuiltinSounds(context) }

    init {
        audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    fun play(soundUri: String, volumePercent: Int) {
        stop()
        setAlarmVolume(volumePercent)
        requestAudioFocus()
        mediaPlayer = when {
            soundUri.startsWith(ASSET_SOUND_PREFIX) -> {
                val fileName = soundUri.removePrefix(ASSET_SOUND_PREFIX)
                if (fileName == "default") buildDefaultPlayer()
                else buildAssetPlayer("$SOUNDS_DIR/$fileName")
            }
            soundUri.isNotBlank() -> buildUriPlayer(Uri.parse(soundUri))
            else -> buildDefaultPlayer()
        }
    }

    private fun buildAssetPlayer(assetPath: String): MediaPlayer? = runCatching {
        val afd: AssetFileDescriptor = context.assets.openFd(assetPath)
        MediaPlayer().apply {
            setAudioAttributes(alarmAudioAttrs())
            setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            isLooping = true
            prepare()
            start()
        }
    }.getOrElse { buildDefaultPlayer() }

    private fun buildUriPlayer(uri: Uri): MediaPlayer? = runCatching {
        MediaPlayer().apply {
            setAudioAttributes(alarmAudioAttrs())
            setDataSource(context, uri)
            isLooping = true
            prepare()
            start()
        }
    }.getOrElse { buildDefaultPlayer() }

    private fun buildDefaultPlayer(): MediaPlayer? = runCatching {
        MediaPlayer().apply {
            setAudioAttributes(alarmAudioAttrs())
            setDataSource(context, Settings.System.DEFAULT_ALARM_ALERT_URI)
            isLooping = true
            prepare()
            start()
        }
    }.getOrNull()

    private fun alarmAudioAttrs() = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    private fun setAlarmVolume(percent: Int) {
        val am = audioManager ?: return
        val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
        am.setStreamVolume(AudioManager.STREAM_ALARM, (max * percent / 100).coerceIn(0, max), 0)
    }

    private fun requestAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            focusRequest = AudioFocusRequest
                .Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                .setAudioAttributes(alarmAudioAttrs())
                .setWillPauseWhenDucked(false)
                .build()
            am.requestAudioFocus(focusRequest!!)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(null, AudioManager.STREAM_ALARM,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
        }
    }

    /** Dynamically update playback volume (for gradual volume feature) */
    fun setVolume(percent: Int) {
        setAlarmVolume(percent)
    }

    fun stop() {
        runCatching { mediaPlayer?.apply { if (isPlaying) stop(); release() } }
        mediaPlayer = null
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && focusRequest != null) {
            am.abandonAudioFocusRequest(focusRequest!!)
            focusRequest = null
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(null)
        }
    }

    val isPlaying: Boolean get() = mediaPlayer?.isPlaying == true
}
