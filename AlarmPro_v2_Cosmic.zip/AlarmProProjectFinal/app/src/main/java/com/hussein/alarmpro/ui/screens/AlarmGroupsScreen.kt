package com.hussein.alarmpro.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.hussein.alarmpro.data.model.AlarmGroup
import com.hussein.alarmpro.ui.components.*
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.TimeUtils
import com.hussein.alarmpro.viewmodel.AlarmViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlarmGroupsScreen(viewModel: AlarmViewModel, onBack: () -> Unit) {
    val isAr = TimeUtils.isArabic()
    val groups by viewModel.groups.collectAsState()
    val alarms by viewModel.alarms.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var newGroupName by remember { mutableStateOf("") }
    var newGroupColor by remember { mutableStateOf("#0A84FF") }

    val colorOptions = listOf(
        "#0A84FF", "#5E5CE6", "#32D2FF", "#FF375F",
        "#00C7BE", "#FF9F0A", "#30D158", "#BF9BFF"
    )

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false; newGroupName = "" },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.CreateNewFolder, null, tint = OrbBlue, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (isAr) "مجموعة جديدة" else "New Group",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold))
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    OutlinedTextField(
                        value = newGroupName, onValueChange = { newGroupName = it },
                        label = { Text(if (isAr) "اسم المجموعة" else "Group name") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary, unfocusedTextColor = TextSecondary,
                            focusedBorderColor = OrbBlue, unfocusedBorderColor = GlassBorder, cursorColor = OrbBlue))
                    Text(if (isAr) "اللون" else "Color",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary, fontWeight = FontWeight.SemiBold))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        colorOptions.forEach { hex ->
                            val col = runCatching {
                                Color(android.graphics.Color.parseColor(hex))
                            }.getOrElse { OrbBlue }
                            val sel = newGroupColor == hex
                            Box(
                                Modifier.size(32.dp).clip(CircleShape).background(col)
                                    .then(if (sel) Modifier
                                        .border(2.5.dp, Color.White, CircleShape)
                                        .drawBehind {
                                            drawCircle(Brush.radialGradient(
                                                listOf(col.copy(0.50f), Color.Transparent),
                                                radius = size.minDimension * 1.1f), radius = size.minDimension * 1.1f)
                                        }
                                    else Modifier.border(1.dp, Color.White.copy(0.15f), CircleShape))
                                    .clickable { newGroupColor = hex }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Box(Modifier.clip(RoundedCornerShape(12.dp))
                    .background(OrbBlue.copy(0.85f)).border(1.dp, Color.White.copy(0.25f), RoundedCornerShape(12.dp))
                    .clickable {
                        if (newGroupName.isNotBlank()) {
                            viewModel.addGroup(AlarmGroup(name = newGroupName, colorHex = newGroupColor))
                            newGroupName = ""; newGroupColor = "#0A84FF"; showAddDialog = false
                        }
                    }.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text(if (isAr) "إضافة" else "Add",
                        style = MaterialTheme.typography.labelMedium.copy(color = Color.White, fontWeight = FontWeight.ExtraBold))
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false; newGroupName = "" }) {
                    Text(if (isAr) "إلغاء" else "Cancel", color = TextTertiary)
                }
            },
            containerColor = DarkNavy
        )
    }

    LiquidGlassBackground {
        StarFieldBackground(Modifier.fillMaxSize())
        Scaffold(containerColor = Color.Transparent, topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp))
                            .background(OrbPurple.copy(0.25f)).border(1.dp, OrbPurple.copy(0.45f), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Layers, null, tint = OrbPurple, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(if (isAr) "مجموعات المنبه" else "Alarm Groups",
                            style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.ExtraBold))
                    }
                },
                navigationIcon = {
                    Box(Modifier.padding(start = 8.dp).size(38.dp).clip(CircleShape)
                        .background(GlassBg).border(0.5.dp, GlassBorder, CircleShape)
                        .clickable { onBack() }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.ChevronLeft, null, tint = OrbBlue, modifier = Modifier.size(22.dp))
                    }
                },
                actions = {
                    Box(Modifier.padding(end = 12.dp).size(38.dp).clip(CircleShape)
                        .background(OrbPurple.copy(0.20f)).border(1.dp, OrbPurple.copy(0.40f), CircleShape)
                        .clickable { showAddDialog = true }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Add, null, tint = OrbPurple, modifier = Modifier.size(20.dp))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }) { pd ->
            if (groups.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(pd), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(80.dp).clip(CircleShape)
                            .background(Brush.verticalGradient(listOf(Color.White.copy(0.12f), Color.White.copy(0.05f))))
                            .border(1.dp, Color.White.copy(0.20f), CircleShape),
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.FolderOpen, null, tint = TextTertiary, modifier = Modifier.size(38.dp))
                        }
                        Spacer(Modifier.height(14.dp))
                        Text(if (isAr) "لا توجد مجموعات بعد" else "No groups yet",
                            style = MaterialTheme.typography.titleMedium.copy(color = TextSecondary, fontWeight = FontWeight.Bold))
                        Spacer(Modifier.height(6.dp))
                        Text(if (isAr) "اضغط + لإضافة مجموعة" else "Tap + to add a group",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary))
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(pd).padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp, top = 8.dp)
                ) {
                    itemsIndexed(groups, key = { _, g -> g.id }) { index, group ->
                        val groupAlarms = alarms.filter { it.groupId == group.id }
                        val dotColor = runCatching {
                            Color(android.graphics.Color.parseColor(group.colorHex))
                        }.getOrElse { OrbBlue }

                        // Staggered entry
                        val visible = remember { mutableStateOf(false) }
                        LaunchedEffect(Unit) { kotlinx.coroutines.delay(index * 70L); visible.value = true }
                        AnimatedVisibility(visible = visible.value,
                            enter = slideInHorizontally(spring(stiffness = Spring.StiffnessMediumLow),
                                initialOffsetX = { it / 3 }) + fadeIn(tween(250))) {

                            GlassCard(Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp).fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically) {
                                    // Color dot with glow
                                    Box(
                                        Modifier.size(42.dp).clip(CircleShape)
                                            .background(dotColor.copy(0.18f))
                                            .border(1.5.dp, dotColor.copy(0.55f), CircleShape)
                                            .drawBehind {
                                                drawCircle(Brush.radialGradient(
                                                    listOf(dotColor.copy(0.25f), Color.Transparent),
                                                    radius = size.minDimension * 1.2f), radius = size.minDimension * 1.2f)
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Filled.Layers, null, tint = dotColor, modifier = Modifier.size(20.dp))
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(group.name, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.ExtraBold))
                                        Text(
                                            if (isAr) "${groupAlarms.size} منبه" else "${groupAlarms.size} alarms",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = dotColor.copy(0.80f), fontWeight = FontWeight.Medium))
                                    }
                                    IosSwitch(
                                        checked = groupAlarms.any { it.isEnabled },
                                        onCheckedChange = { en -> viewModel.toggleGroup(group.id, en) })
                                    Spacer(Modifier.width(4.dp))
                                    Box(Modifier.size(34.dp).clip(CircleShape)
                                        .background(OrbPink.copy(0.12f)).border(0.5.dp, OrbPink.copy(0.30f), CircleShape)
                                        .clickable { viewModel.deleteGroup(group) }, contentAlignment = Alignment.Center) {
                                        Icon(Icons.Filled.DeleteOutline, null, tint = OrbPink, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
