package com.hussein.alarmpro.ui.nav

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.hussein.alarmpro.MainActivity
import com.hussein.alarmpro.ui.screens.*
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.AlarmScheduler
import com.hussein.alarmpro.util.TimeUtils
import com.hussein.alarmpro.viewmodel.AlarmViewModel

sealed class Screen(val route: String) {
    object Home        : Screen("home")
    object AddAlarm    : Screen("add_alarm")
    object EditAlarm   : Screen("edit_alarm/{alarmId}") {
        fun createRoute(id: Int) = "edit_alarm/$id"
    }
    object Settings    : Screen("settings")
    object AlarmGroups : Screen("alarm_groups")
    object VacationMode: Screen("vacation_mode")
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun NavGraph(scheduler: AlarmScheduler) {
    val navController = rememberNavController()
    val viewModel: AlarmViewModel = hiltViewModel()
    val isAr = TimeUtils.isArabic()

    // Observe pending import from MainActivity (shared file)
    val pendingImport by MainActivity.pendingImportJson.collectAsState()
    var showImportDialog by remember { mutableStateOf(false) }
    var importJson by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(pendingImport) {
        if (pendingImport != null) {
            importJson = pendingImport
            showImportDialog = true
        }
    }

    if (showImportDialog && importJson != null) {
        val count = remember(importJson) {
            runCatching {
                com.hussein.alarmpro.util.ExportImport.importFromJson(importJson!!).size
            }.getOrDefault(0)
        }
        AlertDialog(
            onDismissRequest = { showImportDialog = false; MainActivity.clearPendingImport() },
            title = { Text(if (isAr) "استيراد المنبهات؟" else "Import Alarms?") },
            text = {
                Text(
                    if (isAr) "سيتم إضافة $count منبه إلى القائمة"
                    else "Will add $count alarms to your list"
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.importFromJson(importJson!!)
                    showImportDialog = false
                    MainActivity.clearPendingImport()
                }) { Text(if (isAr) "استيراد" else "Import", color = OrbBlue) }
            },
            dismissButton = {
                TextButton(onClick = {
                    showImportDialog = false
                    MainActivity.clearPendingImport()
                }) { Text(if (isAr) "إلغاء" else "Cancel") }
            },
            containerColor = DarkNavy
        )
    }

    NavHost(
        navController = navController,
        startDestination = Screen.Home.route,
        enterTransition = {
            slideInHorizontally(initialOffsetX = { it }, animationSpec = tween(280)) +
            fadeIn(animationSpec = tween(280))
        },
        exitTransition = {
            slideOutHorizontally(targetOffsetX = { -it / 3 }, animationSpec = tween(280)) +
            fadeOut(animationSpec = tween(200))
        },
        popEnterTransition = {
            slideInHorizontally(initialOffsetX = { -it / 3 }, animationSpec = tween(280)) +
            fadeIn(animationSpec = tween(280))
        },
        popExitTransition = {
            slideOutHorizontally(targetOffsetX = { it }, animationSpec = tween(280)) +
            fadeOut(animationSpec = tween(200))
        }
    ) {
        composable(Screen.Home.route) {
            HomeScreen(
                viewModel   = viewModel,
                scheduler   = scheduler,
                onAddAlarm  = { navController.navigate(Screen.AddAlarm.route) },
                onEditAlarm = { alarm -> navController.navigate(Screen.EditAlarm.createRoute(alarm.id)) },
                onSettings  = { navController.navigate(Screen.Settings.route) }
            )
        }

        composable(Screen.AddAlarm.route) {
            EditAlarmScreen(
                alarm     = null,
                viewModel = viewModel,
                onBack    = { navController.popBackStack() }
            )
        }

        composable(
            Screen.EditAlarm.route,
            arguments = listOf(navArgument("alarmId") { type = NavType.IntType })
        ) { back ->
            val id = back.arguments?.getInt("alarmId") ?: return@composable
            val alarms by viewModel.alarms.collectAsState()
            val alarm = alarms.find { it.id == id }
            EditAlarmScreen(
                alarm     = alarm,
                viewModel = viewModel,
                onBack    = { navController.popBackStack() }
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen(
                viewModel = viewModel,
                onBack    = { navController.popBackStack() },
                onAlarmGroups  = { navController.navigate(Screen.AlarmGroups.route) },
                onVacationMode = { navController.navigate(Screen.VacationMode.route) }
            )
        }

        composable(Screen.AlarmGroups.route) {
            AlarmGroupsScreen(
                viewModel = viewModel,
                onBack    = { navController.popBackStack() }
            )
        }

        composable(Screen.VacationMode.route) {
            VacationModeScreen(
                viewModel = viewModel,
                onBack    = { navController.popBackStack() }
            )
        }
    }
}
