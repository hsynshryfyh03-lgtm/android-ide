package com.hussein.alarmpro.data.datastore

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

private val Context.vacationStore by preferencesDataStore(name = "vacation_mode")

data class VacationMode(
    val isActive: Boolean = false,
    val startMillis: Long = 0L,
    val endMillis: Long = 0L
)

@Singleton
class VacationStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val ACTIVE = booleanPreferencesKey("vacation_active")
        val START   = longPreferencesKey("vacation_start")
        val END     = longPreferencesKey("vacation_end")
    }

    val vacationMode: Flow<VacationMode> = context.vacationStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            VacationMode(
                isActive    = p[Keys.ACTIVE] ?: false,
                startMillis = p[Keys.START]  ?: 0L,
                endMillis   = p[Keys.END]    ?: 0L
            )
        }

    suspend fun setVacation(vm: VacationMode) {
        context.vacationStore.edit { p ->
            p[Keys.ACTIVE] = vm.isActive
            p[Keys.START]  = vm.startMillis
            p[Keys.END]    = vm.endMillis
        }
    }

    suspend fun deactivate() {
        context.vacationStore.edit { p -> p[Keys.ACTIVE] = false }
    }

    /** Returns true if vacation mode is currently active and now is within the range */
    suspend fun isActiveNow(vm: VacationMode): Boolean {
        if (!vm.isActive) return false
        val now = System.currentTimeMillis()
        return now in vm.startMillis..vm.endMillis
    }

    /** Non-suspend version for use where VacationMode value is already known */
    fun isActiveNow(isActive: Boolean, startMillis: Long, endMillis: Long): Boolean {
        if (!isActive) return false
        val now = System.currentTimeMillis()
        return now in startMillis..endMillis
    }
}
