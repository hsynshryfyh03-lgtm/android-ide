package com.hussein.alarmpro.ui.screens

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.hussein.alarmpro.data.model.Alarm
import com.hussein.alarmpro.service.AlarmService
import com.hussein.alarmpro.ui.components.*
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.*
import com.hussein.alarmpro.viewmodel.AlarmViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random
import javax.inject.Inject

@AndroidEntryPoint
class RingingActivity : ComponentActivity() {
    private val viewModel: AlarmViewModel by viewModels()
    @Inject lateinit var wakeLockManager: WakeLockManager
    private var alarmId: Int = -1
    private var dismissType: Int = 0

    private val closeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) { finish() }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        return when {
            dismissType == 2 && keyCode == KeyEvent.KEYCODE_POWER -> { triggerDismiss(); true }
            dismissType == 3 && (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) -> { triggerDismiss(); true }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    private fun triggerDismiss() {
        startService(Intent(this, AlarmService::class.java).apply {
            action = AlarmService.ACTION_DISMISS; putExtra("alarm_id", alarmId) })
        cleanup()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        alarmId     = intent.getIntExtra("alarm_id", -1)
        dismissType = intent.getIntExtra("dismiss_type", 0)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true); setTurnScreenOn(true)
        }
        wakeLockManager.acquire()
        lockSystemUI()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(closeReceiver,
                IntentFilter("com.hussein.alarmpro.ACTION_CLOSE_RING"), RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(closeReceiver, IntentFilter("com.hussein.alarmpro.ACTION_CLOSE_RING"))
        }
        setContent {
            AlarmProTheme {
                val alarms by viewModel.alarms.collectAsState()
                val alarm = remember(alarms, alarmId) { alarms.find { it.id == alarmId } }
                if (alarm != null) {
                    RingingScreen(alarm = alarm,
                        onSnooze = {
                            startService(Intent(this, AlarmService::class.java).apply {
                                action = AlarmService.ACTION_SNOOZE; putExtra("alarm_id", alarmId) })
                            cleanup()
                        },
                        onDismiss = {
                            startService(Intent(this, AlarmService::class.java).apply {
                                action = AlarmService.ACTION_DISMISS; putExtra("alarm_id", alarmId) })
                            cleanup()
                        }
                    )
                }
            }
        }
    }

    private fun cleanup() { unlockSystemUI(); wakeLockManager.release(); finish() }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { unregisterReceiver(closeReceiver) }
        wakeLockManager.release()
    }

    @Deprecated("Deprecated") override fun onBackPressed() { /* blocked */ }
}

// ═══════════════════════════════════════════════════════════════════════════════
// RINGING SCREEN v2.0 — Immersive cosmic alarm experience
// ═══════════════════════════════════════════════════════════════════════════════
@Composable
private fun RingingScreen(alarm: Alarm, onSnooze: () -> Unit, onDismiss: () -> Unit) {
    val isAr = TimeUtils.isArabic()
    var showTask by remember { mutableStateOf(false) }

    val inf = rememberInfiniteTransition(label = "ringing")

    // Staggered pulse rings
    val ring1 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1500, easing = EaseOut), RepeatMode.Restart), "r1")
    val ring2 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1500, 400, easing = EaseOut), RepeatMode.Restart), "r2")
    val ring3 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1500, 800, easing = EaseOut), RepeatMode.Restart), "r3")

    val bellPulse  by inf.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(480, easing = EaseInOutSine), RepeatMode.Reverse), "bp")
    val bellRotate by inf.animateFloat(-8f, 8f, infiniteRepeatable(tween(170, easing = EaseInOutSine), RepeatMode.Reverse), "br")
    val glowA      by inf.animateFloat(0.30f, 0.80f, infiniteRepeatable(tween(800, easing = EaseInOutSine), RepeatMode.Reverse), "ga")

    Box(Modifier.fillMaxSize()) {
        // ── Cosmic background ────────────────────────────────────────────────
        LiquidGlassBackground(Modifier.fillMaxSize()) {}
        StarFieldBackground(Modifier.fillMaxSize())
        SparkleOverlay(Modifier.fillMaxSize())

        // Blurred photo background
        if (alarm.ringBgUri.isNotBlank()) {
            BlurredRingBackground(imageUri = alarm.ringBgUri, blurRadius = 28f,
                modifier = Modifier.fillMaxSize())
        }

        // Darkening overlay
        Box(Modifier.fillMaxSize().background(Color.Black.copy(0.42f)))

        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // ── Top: Time + Label ────────────────────────────────────────────
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 68.dp)
            ) {
                // Status pill (animated live dot)
                GlassPill(color = OrbPink) {
                    Row(verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)) {
                        Box(
                            Modifier.size(8.dp).clip(CircleShape).background(OrbPink)
                                .drawBehind {
                                    drawCircle(Brush.radialGradient(
                                        listOf(OrbPink.copy(glowA * 0.65f), Color.Transparent),
                                        radius = size.minDimension * 1.8f),
                                        radius = size.minDimension * 1.8f)
                                }
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(if (isAr) "المنبه يرن" else "Alarm Ringing",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = OrbPink, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp))
                    }
                }

                Spacer(Modifier.height(24.dp))

                // Big time text — Nunito Thin
                Text(
                    text = TimeUtils.formatTime(alarm.hour, alarm.minute),
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = 92.sp, fontWeight = FontWeight.Thin,
                        color = TextPrimary, letterSpacing = (-3).sp)
                )

                if (alarm.label.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(alarm.label,
                        style = MaterialTheme.typography.headlineSmall.copy(
                            color = TextSecondary, fontWeight = FontWeight.Light))
                }
            }

            // ── Center: Animated Bell ────────────────────────────────────────
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(250.dp)) {
                // 3 staggered pulse rings
                listOf(ring1 to 0.90f, ring2 to 0.72f, ring3 to 0.52f).forEach { (r, maxA) ->
                    Box(
                        Modifier.size(210.dp)
                            .graphicsLayer(scaleX = 0.35f + r*1.30f, scaleY = 0.35f + r*1.30f, alpha = (1f - r) * maxA)
                            .clip(CircleShape)
                            .background(Brush.radialGradient(
                                listOf(OrbBlue.copy(0.40f), OrbPurple.copy(0.12f), Color.Transparent)))
                    )
                }

                // Secondary aurora ring
                Box(
                    Modifier.size(160.dp).clip(CircleShape)
                        .drawBehind {
                            drawCircle(brush = Brush.sweepGradient(
                                listOf(OrbBlue.copy(0f), OrbBlue.copy(glowA * 0.5f),
                                    OrbPurple.copy(glowA * 0.3f), OrbBlue.copy(0f)),
                                center = Offset(size.width/2f, size.height/2f)),
                                radius = size.minDimension/2f,
                                center = Offset(size.width/2f, size.height/2f),
                                style = Stroke(2f))
                        }
                )

                // Glass bell container
                Box(
                    Modifier.size(124.dp)
                        .graphicsLayer(scaleX = bellPulse, scaleY = bellPulse)
                        .clip(CircleShape)
                        .background(Brush.verticalGradient(
                            listOf(Color.White.copy(0.25f), OrbBlue.copy(0.38f))))
                        .border(1.5.dp, Brush.verticalGradient(
                            listOf(Color.White.copy(0.60f), Color.White.copy(0.10f))), CircleShape)
                        .drawBehind {
                            drawCircle(Brush.radialGradient(
                                listOf(Color.White.copy(0.16f), Color.Transparent),
                                radius = size.minDimension * 0.55f), radius = size.minDimension * 0.55f)
                            // Ambient outer glow
                            drawCircle(Brush.radialGradient(
                                listOf(OrbBlue.copy(glowA * 0.45f), Color.Transparent),
                                radius = size.minDimension * 0.95f), radius = size.minDimension * 0.95f)
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Alarm, null, tint = Color.White,
                        modifier = Modifier.size(58.dp).graphicsLayer(rotationZ = bellRotate))
                }
            }

            // ── Bottom: Action Buttons ───────────────────────────────────────
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(bottom = 56.dp)
            ) {
                if (!showTask) {
                    // ── DISMISS Button ─────────────────────────────────────
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.88f).height(60.dp)
                            .clip(RoundedCornerShape(30.dp))
                            .background(Brush.verticalGradient(
                                listOf(OrbPink.copy(0.82f), SystemRed.copy(0.72f))))
                            .border(1.dp, Brush.verticalGradient(
                                listOf(Color.White.copy(0.50f), Color.White.copy(0.08f))),
                                RoundedCornerShape(30.dp))
                            .drawBehind {
                                drawRect(Brush.verticalGradient(
                                    listOf(Color.White.copy(0.18f), Color.Transparent),
                                    endY = size.height * 0.42f))
                                // Outer neon glow
                                drawRoundRect(
                                    brush = Brush.radialGradient(
                                        listOf(OrbPink.copy(0.25f), Color.Transparent),
                                        radius = size.minDimension * 1.5f),
                                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(30.dp.toPx() + 6f),
                                    topLeft = Offset(-6f, -6f),
                                    size = size.copy(size.width + 12f, size.height + 12f))
                            }
                            .clickable {
                                if (alarm.dismissTask > 0) showTask = true else onDismiss()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.AlarmOff, null, tint = Color.White,
                                modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(9.dp))
                            Text(
                                if (alarm.dismissTask > 0)
                                    (if (isAr) "إيقاف (مهمة)" else "Dismiss (task)")
                                else if (isAr) "إيقاف المنبه" else "Stop Alarm",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                            )
                        }
                    }

                    // ── SNOOZE Button ──────────────────────────────────────
                    if (alarm.isSnoozeEnabled) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.68f).height(52.dp)
                                .clip(RoundedCornerShape(26.dp))
                                .background(Color.White.copy(0.12f))
                                .border(1.dp, Color.White.copy(0.28f), RoundedCornerShape(26.dp))
                                .drawBehind {
                                    drawRect(Brush.verticalGradient(
                                        listOf(Color.White.copy(0.10f), Color.Transparent),
                                        endY = size.height * 0.45f))
                                }
                                .clickable { onSnooze() },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Snooze, null, tint = TextSecondary,
                                    modifier = Modifier.size(17.dp))
                                Spacer(Modifier.width(7.dp))
                                Text(
                                    if (isAr) "غفوة ${alarm.snoozeMinutes} دقيقة"
                                    else "Snooze ${alarm.snoozeMinutes}m",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        color = TextSecondary, fontWeight = FontWeight.SemiBold)
                                )
                            }
                        }
                    }
                } else {
                    when (alarm.dismissTask) {
                        1 -> MathTask(alarm.dismissTaskDifficulty, isAr) { onDismiss() }
                        2 -> RewriteTask(alarm.dismissTaskDifficulty, isAr) { onDismiss() }
                        3 -> QRTask(isAr) { onDismiss() }
                        4 -> WalkTask(isAr) { onDismiss() }
                    }
                }
            }
        }
    }
}

// ─── DISMISS TASKS ────────────────────────────────────────────────────────────
@Composable
private fun MathTask(difficulty: Int, isAr: Boolean, onSuccess: () -> Unit) {
    val scope = rememberCoroutineScope()
    val (question, answer) = remember(difficulty) {
        when (difficulty) {
            0 -> { val a = Random.nextInt(1,20); val b = Random.nextInt(1,20); Pair("$a + $b = ?", a + b) }
            2 -> { val a = Random.nextInt(2,12); val b = Random.nextInt(2,12); val c = Random.nextInt(1,20)
                   Pair("($a × $b) + $c = ?", a * b + c) }
            else -> { val a = Random.nextInt(5,30); val b = Random.nextInt(2, a); Pair("$a − $b = ?", a - b) }
        }
    }
    var input by remember { mutableStateOf("") }
    var error  by remember { mutableStateOf(false) }

    GlassCard(Modifier.fillMaxWidth(), cornerRadius = 26.dp) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (isAr) "حلّ المسألة للإيقاف" else "Solve to Dismiss",
                style = MaterialTheme.typography.titleMedium.copy(color = OrbBlue, fontWeight = FontWeight.ExtraBold))
            Spacer(Modifier.height(16.dp))
            NeonCard(Modifier.fillMaxWidth(), color = OrbBlue, cornerRadius = 18.dp, pulsing = false) {
                Text(question, style = MaterialTheme.typography.displaySmall.copy(
                    fontSize = 42.sp, fontWeight = FontWeight.Light),
                    modifier = Modifier.padding(horizontal = 32.dp, vertical = 18.dp)
                        .align(Alignment.CenterHorizontally))
            }
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = input, onValueChange = { input = it.filter { c -> c.isDigit() || c == '-' } },
                label = { Text(if (isAr) "الجواب" else "Answer", color = TextTertiary) },
                isError = error, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary, unfocusedTextColor = TextSecondary,
                    focusedBorderColor = OrbBlue, unfocusedBorderColor = GlassBorder,
                    errorBorderColor = OrbPink, cursorColor = OrbBlue),
                modifier = Modifier.fillMaxWidth())
            if (error) Text(if (isAr) "إجابة خاطئة!" else "Wrong answer!",
                color = OrbPink, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(16.dp))
            Box(modifier = Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(26.dp))
                .background(Brush.verticalGradient(listOf(OrbBlue.copy(0.82f), OrbPurple.copy(0.65f))))
                .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(0.50f), Color.White.copy(0.08f))), RoundedCornerShape(26.dp))
                .clickable {
                    if (input.toIntOrNull() == answer) onSuccess()
                    else { error = true; scope.launch { delay(700); error = false } }
                }, contentAlignment = Alignment.Center) {
                Text(if (isAr) "تحقق" else "Check", style = MaterialTheme.typography.titleSmall.copy(
                    color = Color.White, fontWeight = FontWeight.ExtraBold))
            }
        }
    }
}

@Composable
private fun RewriteTask(difficulty: Int, isAr: Boolean, onSuccess: () -> Unit) {
    val phrases = if (isAr)
        listOf("أنا مستيقظ الآن", "الصباح نور وخير", "سأبدأ يومي بنشاط وحيوية")
    else listOf("I am fully awake", "Good morning, rise and shine", "Today will be productive")
    val phrase = remember(difficulty) { phrases[difficulty.coerceIn(0, phrases.lastIndex)] }
    var input by remember { mutableStateOf("") }
    var error  by remember { mutableStateOf(false) }

    GlassCard(Modifier.fillMaxWidth(), cornerRadius = 26.dp) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (isAr) "اكتب العبارة للإيقاف" else "Type to Dismiss",
                style = MaterialTheme.typography.titleMedium.copy(color = OrbPurple, fontWeight = FontWeight.ExtraBold))
            Spacer(Modifier.height(14.dp))
            GlassPill(color = OrbPurple) {
                Text(phrase, style = MaterialTheme.typography.bodyLarge.copy(
                    color = TextPrimary, fontWeight = FontWeight.SemiBold),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 14.dp))
            }
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                label = { Text(if (isAr) "اكتب هنا" else "Type here", color = TextTertiary) },
                isError = error, modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary, unfocusedTextColor = TextSecondary,
                    focusedBorderColor = OrbPurple, unfocusedBorderColor = GlassBorder,
                    cursorColor = OrbPurple, errorBorderColor = OrbPink))
            if (error) Text(if (isAr) "النص غير مطابق" else "Text doesn't match",
                color = OrbPink, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(14.dp))
            Box(Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(26.dp))
                .background(Brush.verticalGradient(listOf(OrbPurple.copy(0.82f), OrbBlue.copy(0.65f))))
                .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(0.50f), Color.White.copy(0.08f))), RoundedCornerShape(26.dp))
                .clickable { if (input.trim() == phrase.trim()) onSuccess() else error = true },
                contentAlignment = Alignment.Center) {
                Text(if (isAr) "تحقق" else "Verify", style = MaterialTheme.typography.titleSmall.copy(
                    color = Color.White, fontWeight = FontWeight.ExtraBold))
            }
        }
    }
}

@Composable
private fun QRTask(isAr: Boolean, onSuccess: () -> Unit) {
    val scope = rememberCoroutineScope()
    var taps by remember { mutableStateOf(0) }
    val required = 20
    val progress = taps.toFloat() / required
    val inf = rememberInfiniteTransition(label = "qr")
    val ringScale by inf.animateFloat(0.92f, 1.08f,
        infiniteRepeatable(tween(600, easing = EaseInOutSine), RepeatMode.Reverse), "rs")

    GlassCard(Modifier.fillMaxWidth(), cornerRadius = 26.dp) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (isAr) "اضغط $required مرة" else "Tap $required Times",
                style = MaterialTheme.typography.titleMedium.copy(color = OrbBlue, fontWeight = FontWeight.ExtraBold))
            Spacer(Modifier.height(16.dp))
            Box(contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.size(90.dp).graphicsLayer(scaleX = ringScale, scaleY = ringScale),
                    color = OrbBlue, trackColor = GlassBorder, strokeWidth = 6.dp)
                Text("$taps", style = MaterialTheme.typography.headlineMedium.copy(
                    color = if (progress >= 1f) ToggleOn else OrbBlue, fontWeight = FontWeight.ExtraBold))
            }
            Spacer(Modifier.height(4.dp))
            Text("/ $required", style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary))
            Spacer(Modifier.height(16.dp))
            Box(modifier = Modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(29.dp))
                .background(Brush.verticalGradient(listOf(
                    if (progress >= 1f) ToggleOn.copy(0.82f) else OrbBlue.copy(0.82f),
                    if (progress >= 1f) OrbMint.copy(0.65f) else OrbPurple.copy(0.65f))))
                .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(0.50f), Color.White.copy(0.08f))), RoundedCornerShape(29.dp))
                .clickable {
                    taps = (taps + 1).coerceAtMost(required)
                    if (taps >= required) scope.launch { delay(300); onSuccess() }
                }, contentAlignment = Alignment.Center) {
                Text(if (progress >= 1f) (if (isAr) "✓ تم!" else "✓ Done!")
                     else if (isAr) "اضغط هنا!" else "Tap here!",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = Color.White, fontWeight = FontWeight.ExtraBold))
            }
        }
    }
}

@Composable
private fun WalkTask(isAr: Boolean, onSuccess: () -> Unit) {
    val ctx = LocalContext.current
    val required = 20
    var steps by remember { mutableStateOf(0) }
    var available by remember { mutableStateOf(true) }
    val progress = steps.toFloat() / required
    val helper = remember { AccelerometerHelper(ctx) }

    DisposableEffect(Unit) {
        available = helper.isAvailable
        if (available) helper.start { count -> steps = count.coerceAtMost(required) }
        onDispose { helper.stop() }
    }
    LaunchedEffect(steps) { if (steps >= required) { delay(300); onSuccess() } }

    val inf = rememberInfiniteTransition(label = "walk")
    val bounce by inf.animateFloat(0f, 1f,
        infiniteRepeatable(tween(600, easing = EaseInOutSine), RepeatMode.Reverse), "b")

    GlassCard(Modifier.fillMaxWidth(), cornerRadius = 26.dp) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (isAr) "امشِ $required خطوة" else "Walk $required Steps",
                style = MaterialTheme.typography.titleMedium.copy(color = OrbMint, fontWeight = FontWeight.ExtraBold))
            Spacer(Modifier.height(18.dp))
            if (!available) {
                Icon(Icons.Filled.SensorsOff, null, tint = OrbPink, modifier = Modifier.size(48.dp))
                Spacer(Modifier.height(8.dp))
                Text(if (isAr) "المستشعر غير متاح\nاضغط للتخطي" else "Sensor unavailable\nTap to skip",
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextTertiary), textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Box(Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(25.dp))
                    .background(OrbPink.copy(0.25f)).border(1.dp, OrbPink.copy(0.6f), RoundedCornerShape(25.dp))
                    .clickable { onSuccess() }, contentAlignment = Alignment.Center) {
                    Text(if (isAr) "تخطي" else "Skip",
                        style = MaterialTheme.typography.titleSmall.copy(color = OrbPink, fontWeight = FontWeight.ExtraBold))
                }
            } else {
                Box(Modifier.size(96.dp).graphicsLayer(translationY = bounce * (-6f)),
                    contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(progress = { progress }, modifier = Modifier.size(96.dp),
                        color = OrbMint, trackColor = GlassBorder, strokeWidth = 6.dp)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.DirectionsWalk, null,
                            tint = if (progress >= 1f) ToggleOn else OrbMint, modifier = Modifier.size(32.dp))
                        Text("$steps", style = MaterialTheme.typography.titleMedium.copy(
                            color = if (progress >= 1f) ToggleOn else TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp))
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(if (isAr) "$steps / $required خطوة" else "$steps / $required steps",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = if (progress >= 1f) ToggleOn else TextSecondary))
                Spacer(Modifier.height(6.dp))
                Text(if (isAr) "ضع الهاتف في يدك وامشِ" else "Hold phone and walk",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary), textAlign = TextAlign.Center)
            }
        }
    }
}
