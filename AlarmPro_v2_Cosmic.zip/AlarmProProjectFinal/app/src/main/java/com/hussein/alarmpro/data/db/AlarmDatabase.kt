package com.hussein.alarmpro.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.hussein.alarmpro.data.model.Alarm
import com.hussein.alarmpro.data.model.AlarmGroup

@Database(
    entities = [Alarm::class, AlarmGroup::class],
    version = 2,
    exportSchema = false
)
abstract class AlarmDatabase : RoomDatabase() {
    abstract fun alarmDao(): AlarmDao
    abstract fun groupDao(): AlarmGroupDao

    companion object {
        @Volatile private var INSTANCE: AlarmDatabase? = null

        // Migration 1→2: add new columns to alarms + create alarm_groups table
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // New columns added to alarms
                database.execSQL("ALTER TABLE alarms ADD COLUMN scheduledDate INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE alarms ADD COLUMN bypassDnd INTEGER NOT NULL DEFAULT 1")
                database.execSQL("ALTER TABLE alarms ADD COLUMN gradualVolume INTEGER NOT NULL DEFAULT 1")
                database.execSQL("ALTER TABLE alarms ADD COLUMN gradualVolumeDurationSec INTEGER NOT NULL DEFAULT 30")
                database.execSQL("ALTER TABLE alarms ADD COLUMN bedtimeEnabled INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE alarms ADD COLUMN sleepHours INTEGER NOT NULL DEFAULT 8")
                database.execSQL("ALTER TABLE alarms ADD COLUMN groupId INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE alarms ADD COLUMN vacationExempt INTEGER NOT NULL DEFAULT 0")
                // Create alarm_groups table
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS alarm_groups (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        name TEXT NOT NULL DEFAULT '',
                        colorHex TEXT NOT NULL DEFAULT '#0A84FF',
                        isEnabled INTEGER NOT NULL DEFAULT 1,
                        createdAt INTEGER NOT NULL DEFAULT 0
                    )
                """.trimIndent())
            }
        }

        fun getInstance(context: Context): AlarmDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext, AlarmDatabase::class.java, "alarm_db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
