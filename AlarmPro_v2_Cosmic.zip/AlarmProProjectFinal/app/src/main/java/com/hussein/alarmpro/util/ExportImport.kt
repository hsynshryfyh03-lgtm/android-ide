package com.hussein.alarmpro.util

import android.content.Context
import android.net.Uri
import com.hussein.alarmpro.data.model.Alarm
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

object ExportImport {

    fun exportToJson(alarms: List<Alarm>): String {
        val arr = JSONArray()
        for (a in alarms) arr.put(JSONObject().also { o ->
            o.put("hour", a.hour); o.put("minute", a.minute)
            o.put("label", a.label); o.put("isEnabled", a.isEnabled); o.put("days", a.days)
            o.put("soundUri", a.soundUri); o.put("soundName", a.soundName)
            o.put("volumePercent", a.volumePercent)
            o.put("isVibrate", a.isVibrate); o.put("vibrationPattern", a.vibrationPattern)
            o.put("isSnoozeEnabled", a.isSnoozeEnabled)
            o.put("snoozeMinutes", a.snoozeMinutes)
            o.put("snoozeReduceMinutes", a.snoozeReduceMinutes)
            o.put("snoozeMaxCount", a.snoozeMaxCount)
            o.put("autoSnoozeMinutes", a.autoSnoozeMinutes)
            o.put("dismissType", a.dismissType); o.put("dismissTask", a.dismissTask)
            o.put("dismissTaskDifficulty", a.dismissTaskDifficulty)
            o.put("autoDissmissMinutes", a.autoDissmissMinutes)
            o.put("wakeCheckEnabled", a.wakeCheckEnabled)
            o.put("wakeCheckDelayMinutes", a.wakeCheckDelayMinutes)
            o.put("wakeCheckCountdownMinutes", a.wakeCheckCountdownMinutes)
            o.put("ringBgUri", a.ringBgUri)
            o.put("preAlarmNotifyMinutes", a.preAlarmNotifyMinutes)
        })
        return JSONObject().apply {
            put("version", 1)
            put("app", "AlarmPro - برمجة حسين حميد الشريفي")
            put("exportedAt", System.currentTimeMillis())
            put("alarms", arr)
        }.toString(2)
    }

    fun importFromJson(json: String): List<Alarm> {
        val root = JSONObject(json)
        val arr = root.getJSONArray("alarms")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Alarm(
                id = 0,
                hour = o.optInt("hour", 7),
                minute = o.optInt("minute", 0),
                label = o.optString("label", ""),
                isEnabled = o.optBoolean("isEnabled", true),
                days = o.optInt("days", 0),
                soundUri = o.optString("soundUri", ""),
                soundName = o.optString("soundName", ""),
                volumePercent = o.optInt("volumePercent", 80),
                isVibrate = o.optBoolean("isVibrate", true),
                vibrationPattern = o.optInt("vibrationPattern", 1),
                isSnoozeEnabled = o.optBoolean("isSnoozeEnabled", true),
                snoozeMinutes = o.optInt("snoozeMinutes", 9),
                snoozeReduceMinutes = o.optInt("snoozeReduceMinutes", 0),
                snoozeMaxCount = o.optInt("snoozeMaxCount", -1),
                autoSnoozeMinutes = o.optInt("autoSnoozeMinutes", -1),
                dismissType = o.optInt("dismissType", 0),
                dismissTask = o.optInt("dismissTask", 0),
                dismissTaskDifficulty = o.optInt("dismissTaskDifficulty", 1),
                autoDissmissMinutes = o.optInt("autoDissmissMinutes", -1),
                wakeCheckEnabled = o.optBoolean("wakeCheckEnabled", false),
                wakeCheckDelayMinutes = o.optInt("wakeCheckDelayMinutes", 5),
                wakeCheckCountdownMinutes = o.optInt("wakeCheckCountdownMinutes", 2),
                ringBgUri = o.optString("ringBgUri", ""),
                preAlarmNotifyMinutes = o.optInt("preAlarmNotifyMinutes", 5)
            )
        }
    }

    fun readFromUri(context: Context, uri: Uri): String? = runCatching {
        context.contentResolver.openInputStream(uri)?.use { stream ->
            BufferedReader(InputStreamReader(stream)).readText()
        }
    }.getOrNull()

    fun writeToUri(context: Context, uri: Uri, content: String): Boolean = runCatching {
        context.contentResolver.openOutputStream(uri)?.use { out ->
            out.write(content.toByteArray(Charsets.UTF_8))
        }
        true
    }.getOrDefault(false)
}
