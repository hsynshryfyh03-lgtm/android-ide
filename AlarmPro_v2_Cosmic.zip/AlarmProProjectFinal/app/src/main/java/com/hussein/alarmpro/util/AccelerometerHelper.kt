package com.hussein.alarmpro.util

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.sqrt

/**
 * Feature 17: Detects steps via accelerometer for the walk-to-dismiss task.
 * Uses peak-detection on the magnitude of the acceleration vector.
 */
class AccelerometerHelper(context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private var stepCount = 0
    private var onStep: ((Int) -> Unit)? = null

    // Peak detection state
    private var lastMagnitude = 0.0
    private var peakUp = false
    private val STEP_THRESHOLD = 12.0   // m/s² delta to count as a step
    private val GRAVITY = 9.81

    val isAvailable: Boolean get() = accelerometer != null

    fun start(onStep: (steps: Int) -> Unit) {
        this.onStep = onStep
        stepCount = 0
        lastMagnitude = 0.0
        peakUp = false
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
        onStep = null
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0].toDouble()
        val y = event.values[1].toDouble()
        val z = event.values[2].toDouble()
        val magnitude = sqrt(x * x + y * y + z * z)
        val delta = magnitude - GRAVITY

        if (delta > STEP_THRESHOLD && !peakUp) {
            peakUp = true
        } else if (delta < -STEP_THRESHOLD / 2 && peakUp) {
            peakUp = false
            stepCount++
            onStep?.invoke(stepCount)
        }
        lastMagnitude = magnitude
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}
