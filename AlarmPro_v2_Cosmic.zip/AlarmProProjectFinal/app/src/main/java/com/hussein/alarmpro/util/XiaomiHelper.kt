package com.hussein.alarmpro.util

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

object XiaomiHelper {

    /** Returns true if running on Xiaomi / HyperOS / MIUI device */
    fun isXiaomi(): Boolean = runCatching {
        val brand = android.os.Build.MANUFACTURER.lowercase()
        val model = android.os.Build.MODEL.lowercase()
        brand.contains("xiaomi") || brand.contains("redmi") ||
        model.contains("xiaomi") || model.contains("redmi") ||
        isHyperOS() || isMIUI()
    }.getOrDefault(false)

    fun isMIUI(): Boolean = runCatching {
        Class.forName("miui.os.Build")
        true
    }.getOrDefault(false)

    fun isHyperOS(): Boolean = runCatching {
        val prop = System.getProperty("ro.miui.ui.version.name") ?: ""
        prop.isNotBlank()
    }.getOrDefault(false)

    /**
     * Open Xiaomi Autostart settings so the user can allow the app to start on boot.
     * Without this, alarms won't work after reboot on Xiaomi/HyperOS devices.
     */
    fun openAutoStartSettings(context: Context): Boolean {
        val intents = listOf(
            // HyperOS 3 / MIUI 14+
            Intent().apply {
                setClassName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity"
                )
            },
            // Older MIUI
            Intent().apply {
                setClassName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.autostart.AutoStartManagementActivity"
                )
                putExtra("package_name", context.packageName)
            },
            // Security app
            Intent().apply {
                action = "miui.intent.action.APP_PERM_EDITOR"
                setClassName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.AppPermissionsEditorActivity"
                )
                putExtra("extra_pkgname", context.packageName)
            }
        )
        for (intent in intents) {
            if (canResolve(context, intent)) {
                runCatching {
                    context.startActivity(intent.apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    })
                    return true
                }
            }
        }
        return false
    }

    /** Open Xiaomi battery saver / background process settings */
    fun openBatteryOptimizationSettings(context: Context): Boolean {
        val intent = Intent().apply {
            setClassName(
                "com.miui.powerkeeper",
                "com.miui.powerkeeper.ui.HiddenAppsConfigActivity"
            )
            putExtra("package_name", context.packageName)
            putExtra("package_label", "AlarmPro")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (canResolve(context, intent)) {
            runCatching { context.startActivity(intent); return true }
        }
        // Fallback: standard battery optimization
        runCatching {
            context.startActivity(Intent(
                android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                android.net.Uri.parse("package:${context.packageName}")
            ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
            return true
        }
        return false
    }

    private fun canResolve(context: Context, intent: Intent): Boolean = runCatching {
        context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY) != null
    }.getOrDefault(false)
}
