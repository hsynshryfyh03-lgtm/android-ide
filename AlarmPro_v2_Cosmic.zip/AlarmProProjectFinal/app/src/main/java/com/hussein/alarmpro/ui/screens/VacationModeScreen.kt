package com.hussein.alarmpro.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.hussein.alarmpro.data.datastore.VacationMode
import com.hussein.alarmpro.ui.components.*
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.TimeUtils
import com.hussein.alarmpro.viewmodel.AlarmViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VacationModeScreen(viewModel: AlarmViewModel, onBack: () -> Unit) {
    val isAr = TimeUtils.isArabic()
    val vm by viewModel.vacationMode.collectAsState()
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }

    var isActive    by remember(vm) { mutableStateOf(vm.isActive) }
    var startMillis by remember(vm) { mutableStateOf(if (vm.startMillis > 0) vm.startMillis else System.currentTimeMillis()) }
    var endMillis   by remember(vm) { mutableStateOf(if (vm.endMillis > 0) vm.endMillis else System.currentTimeMillis() + 7 * 86400_000L) }
    var showStartPicker by remember { mutableStateOf(false) }
    var showEndPicker   by remember { mutableStateOf(false) }

    if (showStartPicker) DatePickerDialogSimple(startMillis,
        { startMillis = it; showStartPicker = false }, { showStartPicker = false })
    if (showEndPicker) DatePickerDialogSimple(endMillis,
        { endMillis = it; showEndPicker = false }, { showEndPicker = false })

    val inf = rememberInfiniteTransition(label = "vac")
    val sunRotate by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(12_000, easing = LinearEasing)), "sr")
    val sunPulse  by inf.animateFloat(0.90f, 1.10f, infiniteRepeatable(tween(2000, easing = EaseInOutSine), RepeatMode.Reverse), "sp")

    LiquidGlassBackground {
        StarFieldBackground(Modifier.fillMaxSize())
        Scaffold(containerColor = Color.Transparent, topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(34.dp).clip(RoundedCornerShape(10.dp))
                                .background(OrbCyan.copy(0.22f)).border(1.dp, OrbCyan.copy(0.45f), RoundedCornerShape(10.dp))
                                .graphicsLayer(rotationZ = sunRotate),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.WbSunny, null, tint = OrbCyan, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(if (isAr) "وضع الإجازة" else "Vacation Mode",
                            style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.ExtraBold))
                    }
                },
                navigationIcon = {
                    Box(Modifier.padding(start = 8.dp).size(38.dp).clip(CircleShape)
                        .background(GlassBg).border(0.5.dp, GlassBorder, CircleShape)
                        .clickable { onBack() }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.ChevronLeft, null, tint = OrbBlue, modifier = Modifier.size(22.dp))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }) { pd ->
            Column(
                Modifier.fillMaxSize().padding(pd).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Spacer(Modifier.height(4.dp))

                // ── Hero Card ──────────────────────────────────────────────
                val heroColor = if (isActive) OrbCyan else TextTertiary
                NeonCard(Modifier.fillMaxWidth(), color = heroColor, cornerRadius = 24.dp, pulsing = isActive) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Animated sun
                            Box(Modifier.size(52.dp)
                                .graphicsLayer(scaleX = if (isActive) sunPulse else 1f, scaleY = if (isActive) sunPulse else 1f)
                                .clip(CircleShape)
                                .background(Brush.radialGradient(
                                    if (isActive) listOf(OrbCyan.copy(0.25f), OrbOrange.copy(0.12f))
                                    else listOf(Color.White.copy(0.08f), Color.Transparent)))
                                .border(1.5.dp, if (isActive) OrbCyan.copy(0.60f) else Color.White.copy(0.20f), CircleShape)
                                .drawBehind {
                                    if (isActive) drawCircle(Brush.radialGradient(
                                        listOf(OrbCyan.copy(0.30f), Color.Transparent),
                                        radius = size.minDimension * 1.2f), radius = size.minDimension * 1.2f)
                                },
                                contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.WbSunny, null, tint = if (isActive) OrbCyan else TextTertiary,
                                    modifier = Modifier.size(28.dp))
                            }
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(if (isAr) "وضع الإجازة" else "Vacation Mode",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold))
                                Text(
                                    if (isActive) (if (isAr) "المنبهات متوقفة مؤقتاً ✅" else "Alarms paused ✅")
                                    else (if (isAr) "المنبهات تعمل بشكل طبيعي" else "Alarms running normally"),
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = if (isActive) OrbCyan else TextTertiary, fontWeight = FontWeight.Medium))
                            }
                            IosSwitch(checked = isActive, onCheckedChange = { isActive = it })
                        }

                        if (isActive) {
                            HorizontalDivider(color = OrbCyan.copy(0.25f), thickness = 0.5.dp)

                            // Start date row
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp))
                                    .background(OrbBlue.copy(0.20f)).border(1.dp, OrbBlue.copy(0.40f), RoundedCornerShape(10.dp)),
                                    contentAlignment = Alignment.Center) {
                                    Icon(Icons.Filled.EventAvailable, null, tint = OrbBlue, modifier = Modifier.size(18.dp))
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(if (isAr) "بداية الإجازة" else "Start Date",
                                        style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary))
                                    Text(fmt.format(Date(startMillis)),
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                }
                                Box(Modifier.clip(RoundedCornerShape(10.dp))
                                    .background(OrbBlue.copy(0.15f)).border(1.dp, OrbBlue.copy(0.35f), RoundedCornerShape(10.dp))
                                    .clickable { showStartPicker = true }.padding(horizontal = 12.dp, vertical = 6.dp)) {
                                    Text(if (isAr) "تغيير" else "Change",
                                        style = MaterialTheme.typography.labelSmall.copy(color = OrbBlue, fontWeight = FontWeight.Bold))
                                }
                            }

                            // End date row
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp))
                                    .background(OrbPink.copy(0.20f)).border(1.dp, OrbPink.copy(0.40f), RoundedCornerShape(10.dp)),
                                    contentAlignment = Alignment.Center) {
                                    Icon(Icons.Filled.EventBusy, null, tint = OrbPink, modifier = Modifier.size(18.dp))
                                }
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(if (isAr) "نهاية الإجازة" else "End Date",
                                        style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary))
                                    Text(fmt.format(Date(endMillis)),
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                }
                                Box(Modifier.clip(RoundedCornerShape(10.dp))
                                    .background(OrbPink.copy(0.15f)).border(1.dp, OrbPink.copy(0.35f), RoundedCornerShape(10.dp))
                                    .clickable { showEndPicker = true }.padding(horizontal = 12.dp, vertical = 6.dp)) {
                                    Text(if (isAr) "تغيير" else "Change",
                                        style = MaterialTheme.typography.labelSmall.copy(color = OrbPink, fontWeight = FontWeight.Bold))
                                }
                            }

                            // Duration summary pill
                            val days = ((endMillis - startMillis) / 86400_000L).coerceAtLeast(0)
                            GlassPill(Modifier.fillMaxWidth(), color = OrbCyan) {
                                Row(Modifier.padding(12.dp).fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center) {
                                    Icon(Icons.Filled.Schedule, null, tint = OrbCyan, modifier = Modifier.size(14.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(if (isAr) "مدة الإجازة: $days أيام"
                                         else "Vacation duration: $days days",
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            color = OrbCyan, fontWeight = FontWeight.Bold))
                                }
                            }
                        }

                        HorizontalDivider(color = GlassBorder, thickness = 0.5.dp)

                        // Save button
                        Box(Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(16.dp))
                            .background(Brush.verticalGradient(
                                if (isActive) listOf(OrbCyan.copy(0.80f), OrbBlue.copy(0.65f))
                                else listOf(OrbBlue.copy(0.80f), OrbPurple.copy(0.65f))))
                            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(0.50f), Color.White.copy(0.08f))), RoundedCornerShape(16.dp))
                            .clickable {
                                viewModel.setVacationMode(VacationMode(
                                    isActive = isActive, startMillis = startMillis, endMillis = endMillis))
                                onBack()
                            }, contentAlignment = Alignment.Center) {
                            Text(if (isAr) "حفظ" else "Save",
                                style = MaterialTheme.typography.titleSmall.copy(color = Color.White, fontWeight = FontWeight.ExtraBold))
                        }

                        if (vm.isActive) {
                            Box(Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(14.dp))
                                .background(OrbPink.copy(0.12f)).border(1.dp, OrbPink.copy(0.40f), RoundedCornerShape(14.dp))
                                .clickable { viewModel.deactivateVacation(); onBack() },
                                contentAlignment = Alignment.Center) {
                                Text(if (isAr) "إنهاء الإجازة الآن" else "End Vacation Now",
                                    style = MaterialTheme.typography.titleSmall.copy(color = OrbPink, fontWeight = FontWeight.Bold))
                            }
                        }
                    }
                }

                // ── Info Card ──────────────────────────────────────────────
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp)) {
                        Box(Modifier.size(32.dp).clip(CircleShape).background(OrbBlue.copy(0.18f)),
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Info, null, tint = OrbBlue, modifier = Modifier.size(16.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(
                            if (isAr) "المنبهات المعفاة تعمل حتى أثناء الإجازة. فعّل خاصية الإعفاء من صفحة تعديل المنبه."
                            else "Exempt alarms still ring during vacation. Enable per-alarm in the Edit Alarm screen.",
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DatePickerDialogSimple(
    initialMillis: Long,
    onDateSelected: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    val state = rememberDatePickerState(initialSelectedDateMillis = initialMillis)
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = { state.selectedDateMillis?.let { onDateSelected(it) }; onDismiss() }) {
                Text("OK", color = OrbBlue)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        colors = DatePickerDefaults.colors(containerColor = DarkNavy)
    ) { DatePicker(state = state) }
}
