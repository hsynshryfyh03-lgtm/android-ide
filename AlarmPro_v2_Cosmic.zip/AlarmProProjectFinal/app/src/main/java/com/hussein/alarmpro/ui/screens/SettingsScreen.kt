package com.hussein.alarmpro.ui.screens

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.hussein.alarmpro.admin.AlarmDeviceAdmin
import com.hussein.alarmpro.util.XiaomiHelper
import com.hussein.alarmpro.ui.components.*
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.ExportImport
import com.hussein.alarmpro.util.TimeUtils
import com.hussein.alarmpro.viewmodel.AlarmViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: AlarmViewModel,
    onBack: () -> Unit,
    onAlarmGroups: () -> Unit = {},
    onVacationMode: () -> Unit = {}
) {
    val isAr = TimeUtils.isArabic()
    val ctx  = LocalContext.current
    val template by viewModel.template.collectAsState()
    var localTemplate by remember(template) { mutableStateOf(template) }
    var showImportDialog by remember { mutableStateOf(false) }
    var importJson by remember { mutableStateOf<String?>(null) }

    val adminLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {}
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) ExportImport.writeToUri(ctx, uri, viewModel.exportJson())
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val json = ExportImport.readFromUri(ctx, uri)
            if (json != null) { importJson = json; showImportDialog = true }
        }
    }

    if (showImportDialog && importJson != null) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            title = { Text(if (isAr) "استيراد المنبهات؟" else "Import Alarms?") },
            text = {
                val count = runCatching { ExportImport.importFromJson(importJson!!).size }.getOrDefault(0)
                Text(if (isAr) "سيتم إضافة $count منبه إلى القائمة" else "Will add $count alarms to your list")
            },
            confirmButton = {
                TextButton(onClick = { viewModel.importFromJson(importJson!!); showImportDialog = false }) {
                    Text(if (isAr) "استيراد" else "Import", color = OrbBlue)
                }
            },
            dismissButton = { TextButton(onClick = { showImportDialog = false }) { Text(if (isAr) "إلغاء" else "Cancel") } },
            containerColor = DarkNavy
        )
    }

    LiquidGlassBackground {
        StarFieldBackground(Modifier.fillMaxSize())
        Scaffold(containerColor = Color.Transparent, topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Icon badge
                        Box(Modifier.size(34.dp).clip(RoundedCornerShape(10.dp))
                            .background(Brush.verticalGradient(listOf(OrbBlue.copy(0.35f), OrbPurple.copy(0.20f))))
                            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(0.45f), OrbBlue.copy(0.20f))), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Settings, null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Text(if (isAr) "الإعدادات" else "Settings",
                            style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.ExtraBold))
                    }
                },
                navigationIcon = {
                    Box(Modifier.padding(start = 8.dp).size(38.dp).clip(CircleShape)
                        .background(GlassBg).border(0.5.dp, GlassBorder, CircleShape)
                        .clickable { onBack() }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.ChevronLeft, null, tint = OrbBlue, modifier = Modifier.size(22.dp))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }) { pd ->
            Column(
                modifier = Modifier.fillMaxSize().padding(pd)
                    .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Spacer(Modifier.height(4.dp))

                // ── Navigation Cards ────────────────────────────────────────
                Text(if (isAr) "أقسام التطبيق" else "SECTIONS",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextTertiary, letterSpacing = 1.sp, fontWeight = FontWeight.ExtraBold))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    // Alarm Groups card
                    NeonCard(Modifier.weight(1f).clickable { onAlarmGroups() }, color = OrbPurple, cornerRadius = 18.dp, pulsing = false) {
                        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(42.dp).clip(CircleShape)
                                .background(OrbPurple.copy(0.22f)).border(1.dp, OrbPurple.copy(0.50f), CircleShape),
                                contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.Layers, null, tint = OrbPurple, modifier = Modifier.size(22.dp))
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(if (isAr) "المجموعات" else "Groups",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = OrbPurple, fontWeight = FontWeight.Bold, fontSize = 12.sp))
                        }
                    }
                    // Vacation Mode card
                    NeonCard(Modifier.weight(1f).clickable { onVacationMode() }, color = OrbCyan, cornerRadius = 18.dp, pulsing = false) {
                        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(42.dp).clip(CircleShape)
                                .background(OrbCyan.copy(0.22f)).border(1.dp, OrbCyan.copy(0.50f), CircleShape),
                                contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.WbSunny, null, tint = OrbCyan, modifier = Modifier.size(22.dp))
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(if (isAr) "الإجازة" else "Vacation",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = OrbCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp))
                        }
                    }
                }

                Spacer(Modifier.height(4.dp))

                // ── Default Template ────────────────────────────────────────
                Text(if (isAr) "القالب الافتراضي" else "DEFAULT TEMPLATE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextTertiary, letterSpacing = 1.sp, fontWeight = FontWeight.ExtraBold))

                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp))
                                .background(OrbBlue.copy(0.20f)).border(1.dp, OrbBlue.copy(0.40f), RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.Tune, null, tint = OrbBlue, modifier = Modifier.size(18.dp))
                            }
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(if (isAr) "الإعدادات الافتراضية" else "Default Settings",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                Text(if (isAr) "تُطبق على كل منبه جديد" else "Applied to every new alarm",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary))
                            }
                        }
                        HorizontalDivider(color = GlassBorder, thickness = 0.5.dp)
                        // Volume
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.VolumeUp, null, tint = OrbBlue, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (isAr) "الصوت" else "Volume",
                                style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            Slider(
                                value = localTemplate.volumePercent.toFloat(),
                                onValueChange = { localTemplate = localTemplate.copy(volumePercent = it.toInt()) },
                                valueRange = 0f..100f, modifier = Modifier.width(140.dp),
                                colors = SliderDefaults.colors(thumbColor = OrbBlue, activeTrackColor = OrbBlue, inactiveTrackColor = GlassBorder))
                            Text("${localTemplate.volumePercent}%",
                                style = MaterialTheme.typography.labelSmall, modifier = Modifier.width(36.dp))
                        }
                        StepSetting(if (isAr) "مدة الغفوة" else "Snooze duration",
                            localTemplate.snoozeMinutes, if (isAr) "د" else "m", 1..60,
                            { localTemplate = localTemplate.copy(snoozeMinutes = it) })
                        StepSetting(if (isAr) "إشعار مسبق" else "Pre-alarm",
                            localTemplate.preAlarmNotifyMinutes, if (isAr) "د" else "m", -1..60,
                            { localTemplate = localTemplate.copy(preAlarmNotifyMinutes = it) })
                        HorizontalDivider(color = GlassBorder, thickness = 0.5.dp)
                        Box(Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(14.dp))
                            .background(Brush.verticalGradient(listOf(OrbBlue.copy(0.80f), OrbPurple.copy(0.65f))))
                            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(0.45f), Color.White.copy(0.08f))), RoundedCornerShape(14.dp))
                            .clickable { viewModel.saveTemplate(localTemplate) },
                            contentAlignment = Alignment.Center) {
                            Text(if (isAr) "حفظ القالب" else "Save Template",
                                style = MaterialTheme.typography.titleSmall.copy(color = Color.White, fontWeight = FontWeight.ExtraBold))
                        }
                    }
                }

                Spacer(Modifier.height(4.dp))

                // ── Export / Import ─────────────────────────────────────────
                Text(if (isAr) "النسخ الاحتياطي" else "BACKUP",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextTertiary, letterSpacing = 1.sp, fontWeight = FontWeight.ExtraBold))

                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // Export
                            Box(Modifier.weight(1f).height(46.dp).clip(RoundedCornerShape(14.dp))
                                .background(OrbBlue.copy(0.15f)).border(1.dp, OrbBlue.copy(0.40f), RoundedCornerShape(14.dp))
                                .clickable { exportLauncher.launch("alarms_${System.currentTimeMillis()}.json") },
                                contentAlignment = Alignment.Center) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Upload, null, tint = OrbBlue, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(if (isAr) "تصدير" else "Export",
                                        style = MaterialTheme.typography.labelMedium.copy(color = OrbBlue, fontWeight = FontWeight.Bold))
                                }
                            }
                            // Import
                            Box(Modifier.weight(1f).height(46.dp).clip(RoundedCornerShape(14.dp))
                                .background(OrbPurple.copy(0.15f)).border(1.dp, OrbPurple.copy(0.40f), RoundedCornerShape(14.dp))
                                .clickable { importLauncher.launch(arrayOf("application/json","*/*")) },
                                contentAlignment = Alignment.Center) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Download, null, tint = OrbPurple, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(if (isAr) "استيراد" else "Import",
                                        style = MaterialTheme.typography.labelMedium.copy(color = OrbPurple, fontWeight = FontWeight.Bold))
                                }
                            }
                        }
                        // Share
                        Box(Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(14.dp))
                            .background(OrbCyan.copy(0.12f)).border(1.dp, OrbCyan.copy(0.35f), RoundedCornerShape(14.dp))
                            .clickable { viewModel.shareExport() },
                            contentAlignment = Alignment.Center) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Share, null, tint = OrbCyan, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(if (isAr) "مشاركة الإعدادات" else "Share Settings",
                                    style = MaterialTheme.typography.labelMedium.copy(color = OrbCyan, fontWeight = FontWeight.Bold))
                            }
                        }
                    }
                }

                Spacer(Modifier.height(4.dp))

                // ── App Protection ──────────────────────────────────────────
                val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                val adminComp = ComponentName(ctx, AlarmDeviceAdmin::class.java)
                val isAdmin = dpm.isAdminActive(adminComp)
                val shieldColor = if (isAdmin) ToggleOn else OrbPink

                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp))
                                .background(shieldColor.copy(0.18f)).border(1.dp, shieldColor.copy(0.40f), RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.Shield, null, tint = shieldColor, modifier = Modifier.size(18.dp))
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(if (isAr) "حماية التطبيق" else "App Protection",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        }
                        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                            .background(shieldColor.copy(0.08f)).border(0.5.dp, shieldColor.copy(0.25f), RoundedCornerShape(10.dp))
                            .padding(10.dp)) {
                            Text(if (isAdmin)
                                (if (isAr) "✅ التطبيق محمي من الحذف" else "✅ App protected from uninstall")
                            else
                                (if (isAr) "⚠️ فعّل مشرف الجهاز لمنع حذف التطبيق" else "⚠️ Enable device admin to prevent uninstall"),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = shieldColor, fontWeight = FontWeight.SemiBold))
                        }
                        if (!isAdmin) {
                            Box(Modifier.fillMaxWidth().height(44.dp).clip(RoundedCornerShape(12.dp))
                                .background(Brush.horizontalGradient(listOf(OrbPink.copy(0.70f), SystemRed.copy(0.60f))))
                                .border(1.dp, Color.White.copy(0.25f), RoundedCornerShape(12.dp))
                                .clickable {
                                    adminLauncher.launch(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                                        putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComp)
                                        putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                            if (isAr) "يحتاج المنبه صلاحية المشرف ليمنع حذفه عن طريق الخطأ"
                                            else "Alarm needs admin rights to prevent accidental uninstall")
                                    })
                                }, contentAlignment = Alignment.Center) {
                                Text(if (isAr) "تفعيل الحماية" else "Enable Protection",
                                    style = MaterialTheme.typography.titleSmall.copy(color = Color.White, fontWeight = FontWeight.ExtraBold))
                            }
                        }
                    }
                }

                // ── Xiaomi Optimization ─────────────────────────────────────
                if (XiaomiHelper.isXiaomi()) {
                    GlassCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp))
                                    .background(OrbCyan.copy(0.18f)).border(1.dp, OrbCyan.copy(0.40f), RoundedCornerShape(10.dp)),
                                    contentAlignment = Alignment.Center) {
                                    Icon(Icons.Filled.PhoneAndroid, null, tint = OrbCyan, modifier = Modifier.size(18.dp))
                                }
                                Spacer(Modifier.width(10.dp))
                                Text(if (isAr) "تحسينات شاومي" else "Xiaomi Optimization",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                            }
                            Text(if (isAr) "فعّل التشغيل التلقائي ومنع البطارية" else "Enable Autostart & disable battery optimization",
                                style = MaterialTheme.typography.bodySmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(12.dp))
                                    .background(OrbCyan.copy(0.70f)).border(1.dp, Color.White.copy(0.20f), RoundedCornerShape(12.dp))
                                    .clickable { XiaomiHelper.openAutoStartSettings(ctx) }, contentAlignment = Alignment.Center) {
                                    Text(if (isAr) "تشغيل تلقائي" else "Autostart",
                                        style = MaterialTheme.typography.labelMedium.copy(color = Color.White, fontWeight = FontWeight.ExtraBold))
                                }
                                Box(Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(12.dp))
                                    .background(OrbPurple.copy(0.70f)).border(1.dp, Color.White.copy(0.20f), RoundedCornerShape(12.dp))
                                    .clickable { XiaomiHelper.openBatteryOptimizationSettings(ctx) }, contentAlignment = Alignment.Center) {
                                    Text(if (isAr) "البطارية" else "Battery",
                                        style = MaterialTheme.typography.labelMedium.copy(color = Color.White, fontWeight = FontWeight.ExtraBold))
                                }
                            }
                        }
                    }
                }

                // ── About ───────────────────────────────────────────────────
                AuroraCard(Modifier.fillMaxWidth(), cornerRadius = 22.dp) {
                    Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Box(Modifier.size(56.dp).clip(RoundedCornerShape(16.dp))
                            .background(Brush.verticalGradient(listOf(OrbBlue.copy(0.40f), OrbPurple.copy(0.30f))))
                            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(0.50f), OrbBlue.copy(0.20f))), RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Alarm, null, tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("AlarmPro", style = MaterialTheme.typography.titleLarge.copy(
                            color = TextPrimary, fontWeight = FontWeight.ExtraBold))
                        Text("v2.0.0 — Cosmic Edition",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary))
                        HorizontalDivider(color = GlassBorder, thickness = 0.5.dp, modifier = Modifier.padding(vertical = 8.dp))
                        Text("برمجة - حسين حميد الشريفي",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = OrbLavender, fontWeight = FontWeight.SemiBold))
                    }
                }

                Spacer(Modifier.height(28.dp))
            }
        }
    }
}
