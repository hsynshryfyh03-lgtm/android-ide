package com.hussein.alarmpro.data.repository

import com.hussein.alarmpro.data.db.AlarmGroupDao
import com.hussein.alarmpro.data.model.AlarmGroup
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AlarmGroupRepository @Inject constructor(private val dao: AlarmGroupDao) {
    val allGroups: Flow<List<AlarmGroup>> = dao.getAllGroups()
    suspend fun insert(group: AlarmGroup): Long = dao.insert(group)
    suspend fun update(group: AlarmGroup) = dao.update(group)
    suspend fun delete(group: AlarmGroup) = dao.delete(group)
    suspend fun deleteById(id: Int) = dao.deleteById(id)
}
