package com.hussein.alarmpro.di

import android.content.Context
import com.hussein.alarmpro.data.db.AlarmDao
import com.hussein.alarmpro.data.db.AlarmDatabase
import com.hussein.alarmpro.data.db.AlarmGroupDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): AlarmDatabase =
        AlarmDatabase.getInstance(ctx)

    @Provides @Singleton
    fun provideAlarmDao(db: AlarmDatabase): AlarmDao = db.alarmDao()

    @Provides @Singleton
    fun provideGroupDao(db: AlarmDatabase): AlarmGroupDao = db.groupDao()
}
