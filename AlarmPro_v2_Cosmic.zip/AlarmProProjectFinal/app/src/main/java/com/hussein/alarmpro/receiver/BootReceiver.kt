package com.hussein.alarmpro.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.hussein.alarmpro.data.repository.AlarmRepository
import com.hussein.alarmpro.util.AlarmScheduler
import com.hussein.alarmpro.util.PreAlarmScheduler
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class BootReceiver : BroadcastReceiver() {

    @Inject lateinit var repository: AlarmRepository
    @Inject lateinit var scheduler: AlarmScheduler
    @Inject lateinit var preAlarmScheduler: PreAlarmScheduler

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.LOCKED_BOOT_COMPLETED",
            Intent.ACTION_MY_PACKAGE_REPLACED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON" -> {
                CoroutineScope(Dispatchers.IO).launch {
                    repository.getEnabledAlarms().forEach { alarm ->
                        scheduler.schedule(alarm)
                        preAlarmScheduler.schedule(alarm)
                    }
                }
            }
        }
    }
}
