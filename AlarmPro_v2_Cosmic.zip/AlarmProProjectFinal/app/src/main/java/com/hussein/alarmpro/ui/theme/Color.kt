package com.hussein.alarmpro.ui.theme

import androidx.compose.ui.graphics.Color

// ═══════════════════════════════════════════════════════════════════════════
// ALARM PRO v2.0 — COSMIC NEBULA COLOR SYSTEM
// ═══════════════════════════════════════════════════════════════════════════

// ── Base Backgrounds ─────────────────────────────────────────────────────────
val DeepBlack        = Color(0xFF000000)
val DarkNavy         = Color(0xFF04040F)
val DarkSurface      = Color(0xFF0A0A1A)
val DeepSpace        = Color(0xFF050510)

// ── Primary Accent Orbs ──────────────────────────────────────────────────────
val OrbBlue          = Color(0xFF0A84FF)   // iOS system blue
val OrbPurple        = Color(0xFF5E5CE6)   // electric violet
val OrbIndigo        = Color(0xFF6B5CFE)   // deep indigo
val OrbCyan          = Color(0xFF32D2FF)   // aurora cyan
val OrbPink          = Color(0xFFFF375F)   // neon rose
val OrbMint          = Color(0xFF00C7BE)   // teal mint
val OrbOrange        = Color(0xFFFF9F0A)   // solar amber
val OrbLavender      = Color(0xFFBF9BFF)   // soft lavender
val OrbAqua          = Color(0xFF0CF2C8)   // deep aqua
val OrbNebula        = Color(0xFF9B59FF)   // nebula purple
val OrbGold          = Color(0xFFFFD700)   // star gold
val OrbSunrise       = Color(0xFFFF6B35)   // sunrise orange

// ── Nebula Gradient Stops ────────────────────────────────────────────────────
val NebulaStart      = Color(0xFF0A0020)   // deepest space
val NebulaMid        = Color(0xFF150038)   // nebula core
val NebulaEnd        = Color(0xFF001A40)   // blue-space horizon

// ── Aurora Colors ────────────────────────────────────────────────────────────
val AuroraGreen      = Color(0xFF39FF14)   // neon green aurora
val AuroraBlue       = Color(0xFF00D4FF)   // ice-blue aurora
val AuroraPurple     = Color(0xFFBF00FF)   // violet aurora
val AuroraPink       = Color(0xFFFF0080)   // pink aurora band

// ── Liquid Glass Material Tokens ─────────────────────────────────────────────
val GlassThin        = Color(0x0DFFFFFF)   // 5%  ultra-thin
val GlassBg          = Color(0x1AFFFFFF)   // 10% card background
val GlassBgHeavy     = Color(0x2BFFFFFF)   // 17% modal/sheet
val GlassBgUltra     = Color(0x3DFFFFFF)   // 24% nav bar
val GlassBorder      = Color(0x33FFFFFF)   // 20% standard border
val GlassBorderLight = Color(0x1AFFFFFF)   // 10% subtle inner ring
val GlassHighlight   = Color(0x3DFFFFFF)   // 24% top-edge specular
val GlassShimmer     = Color(0x0AFFFFFF)   // 4%  shimmer sweep
val GlassInnerShadow = Color(0x1A000000)   // inner bottom shadow

// ── Premium Glass Tints ───────────────────────────────────────────────────────
val GlassBlue        = Color(0x220A84FF)   // blue-tinted glass
val GlassPurple      = Color(0x225E5CE6)   // purple-tinted glass
val GlassCyan        = Color(0x1A32D2FF)   // cyan-tinted glass
val GlassPink        = Color(0x22FF375F)   // pink-tinted glass

// ── Text Hierarchy ────────────────────────────────────────────────────────────
val TextPrimary      = Color(0xFFFFFFFF)   // primary label
val TextSecondary    = Color(0xB3FFFFFF)   // 70% secondary
val TextTertiary     = Color(0x66FFFFFF)   // 40% tertiary
val TextQuaternary   = Color(0x2EFFFFFF)   // 18% quaternary
val TextAccent       = Color(0xFF0A84FF)   // blue accent

// ── System Colors ─────────────────────────────────────────────────────────────
val SystemGreen      = Color(0xFF30D158)
val SystemRed        = Color(0xFFFF453A)
val SystemYellow     = Color(0xFFFFD60A)
val ToggleOn         = Color(0xFF30D158)   // iOS green toggle
val ToggleOff        = Color(0xFF3A3A3C)   // iOS gray toggle

// ── Separators ────────────────────────────────────────────────────────────────
val Separator        = Color(0x29FFFFFF)
val SeparatorOpaque  = Color(0xFF38383A)

// ── Analog Clock Palette ──────────────────────────────────────────────────────
val ClockFaceColor   = Color(0x10FFFFFF)
val ClockRing        = Color(0x33FFFFFF)
val ClockHourHand    = Color(0xFFFFFFFF)
val ClockMinHand     = Color(0xCCFFFFFF)
val ClockSecHand     = Color(0xFFFF375F)
val ClockTick        = Color(0x80FFFFFF)
val ClockCenter      = Color(0xFF0A84FF)
val ClockNumber      = Color(0x99FFFFFF)

// ── Special Effect Colors ─────────────────────────────────────────────────────
val PulseBlue        = Color(0x400A84FF)   // pulse ring blue
val PulsePurple      = Color(0x405E5CE6)   // pulse ring purple
val StarColor        = Color(0xBBFFFFFF)   // star particles
val StarDim          = Color(0x44FFFFFF)   // dim star

// ── Shimmer Gradient ──────────────────────────────────────────────────────────
val ShimmerBase      = Color(0x1AFFFFFF)
val ShimmerHighlight = Color(0x40FFFFFF)
val ShimmerDark      = Color(0x08FFFFFF)
