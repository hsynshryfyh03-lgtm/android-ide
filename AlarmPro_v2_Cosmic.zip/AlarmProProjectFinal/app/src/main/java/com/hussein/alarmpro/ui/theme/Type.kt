package com.hussein.alarmpro.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.googlefonts.Font
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.unit.sp
import com.hussein.alarmpro.R

// ═══════════════════════════════════════════════════════════════════════════
// ALARM PRO v2.0 — GOOGLE FONTS TYPOGRAPHY SYSTEM
// Uses Nunito — the most beautifully rounded, modern typeface for apps
// ═══════════════════════════════════════════════════════════════════════════

private val googleFontProvider = GoogleFont.Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage   = "com.google.android.gms",
    certificates      = R.array.com_google_android_gms_fonts_certs
)

// Nunito — rounded, friendly, extremely legible at all sizes
private val NunitoFont = GoogleFont("Nunito")

private val NunitoFamily = FontFamily(
    Font(NunitoFont, googleFontProvider, FontWeight.Thin),
    Font(NunitoFont, googleFontProvider, FontWeight.Light),
    Font(NunitoFont, googleFontProvider, FontWeight.Normal),
    Font(NunitoFont, googleFontProvider, FontWeight.Medium),
    Font(NunitoFont, googleFontProvider, FontWeight.SemiBold),
    Font(NunitoFont, googleFontProvider, FontWeight.Bold),
    Font(NunitoFont, googleFontProvider, FontWeight.ExtraBold),
    Font(NunitoFont, googleFontProvider, FontWeight.Black),
)

val AlarmTypography = Typography(
    // Hero: ultra-large clock display
    displayLarge  = TextStyle(
        fontFamily    = NunitoFamily,
        fontWeight    = FontWeight.Thin,
        fontSize      = 80.sp,
        lineHeight    = 88.sp,
        color         = TextPrimary,
        letterSpacing = (-3).sp
    ),
    // Large time display (alarm cards)
    displayMedium = TextStyle(
        fontFamily    = NunitoFamily,
        fontWeight    = FontWeight.Light,
        fontSize      = 52.sp,
        lineHeight    = 60.sp,
        color         = TextPrimary,
        letterSpacing = (-1.5).sp
    ),
    // Medium display (section headers)
    displaySmall  = TextStyle(
        fontFamily    = NunitoFamily,
        fontWeight    = FontWeight.Light,
        fontSize      = 40.sp,
        lineHeight    = 48.sp,
        color         = TextPrimary,
        letterSpacing = (-1).sp
    ),
    // Screen titles
    headlineLarge = TextStyle(
        fontFamily    = NunitoFamily,
        fontWeight    = FontWeight.Bold,
        fontSize      = 30.sp,
        lineHeight    = 38.sp,
        color         = TextPrimary,
        letterSpacing = (-0.5).sp
    ),
    headlineMedium = TextStyle(
        fontFamily    = NunitoFamily,
        fontWeight    = FontWeight.SemiBold,
        fontSize      = 24.sp,
        lineHeight    = 32.sp,
        color         = TextPrimary
    ),
    headlineSmall = TextStyle(
        fontFamily    = NunitoFamily,
        fontWeight    = FontWeight.SemiBold,
        fontSize      = 20.sp,
        lineHeight    = 28.sp,
        color         = TextPrimary
    ),
    // Section headers
    titleLarge  = TextStyle(
        fontFamily    = NunitoFamily,
        fontWeight    = FontWeight.Bold,
        fontSize      = 18.sp,
        lineHeight    = 26.sp,
        color         = TextPrimary
    ),
    titleMedium = TextStyle(
        fontFamily    = NunitoFamily,
        fontWeight    = FontWeight.SemiBold,
        fontSize      = 16.sp,
        lineHeight    = 24.sp,
        color         = TextPrimary
    ),
    titleSmall  = TextStyle(
        fontFamily    = NunitoFamily,
        fontWeight    = FontWeight.SemiBold,
        fontSize      = 14.sp,
        lineHeight    = 20.sp,
        color         = TextPrimary
    ),
    // Body text
    bodyLarge   = TextStyle(
        fontFamily    = NunitoFamily,
        fontWeight    = FontWeight.Normal,
        fontSize      = 16.sp,
        lineHeight    = 24.sp,
        color         = TextSecondary
    ),
    bodyMedium  = TextStyle(
        fontFamily    = NunitoFamily,
        fontWeight    = FontWeight.Normal,
        fontSize      = 14.sp,
        lineHeight    = 20.sp,
        color         = TextSecondary
    ),
    bodySmall   = TextStyle(
        fontFamily    = NunitoFamily,
        fontWeight    = FontWeight.Normal,
        fontSize      = 12.sp,
        lineHeight    = 16.sp,
        color         = TextTertiary
    ),
    // Labels & chips
    labelLarge  = TextStyle(
        fontFamily    = NunitoFamily,
        fontWeight    = FontWeight.SemiBold,
        fontSize      = 14.sp,
        lineHeight    = 20.sp,
        color         = TextAccent
    ),
    labelMedium = TextStyle(
        fontFamily    = NunitoFamily,
        fontWeight    = FontWeight.SemiBold,
        fontSize      = 12.sp,
        lineHeight    = 16.sp,
        color         = TextTertiary
    ),
    labelSmall  = TextStyle(
        fontFamily    = NunitoFamily,
        fontWeight    = FontWeight.Medium,
        fontSize      = 10.sp,
        lineHeight    = 14.sp,
        color         = TextTertiary,
        letterSpacing = 0.5.sp
    ),
)
