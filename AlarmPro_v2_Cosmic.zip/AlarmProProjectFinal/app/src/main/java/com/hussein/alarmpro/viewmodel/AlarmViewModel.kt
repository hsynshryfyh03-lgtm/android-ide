package com.hussein.alarmpro.viewmodel

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hussein.alarmpro.data.datastore.AlarmTemplateStore
import com.hussein.alarmpro.data.datastore.VacationStore
import com.hussein.alarmpro.data.datastore.VacationMode
import com.hussein.alarmpro.data.model.Alarm
import com.hussein.alarmpro.data.model.AlarmGroup
import com.hussein.alarmpro.data.repository.AlarmGroupRepository
import com.hussein.alarmpro.data.repository.AlarmRepository
import com.hussein.alarmpro.util.*
import com.hussein.alarmpro.widget.AlarmWidget
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AlarmViewModel @Inject constructor(
    private val repository: AlarmRepository,
    private val groupRepository: AlarmGroupRepository,
    private val scheduler: AlarmScheduler,
    private val preAlarmScheduler: PreAlarmScheduler,
    private val templateStore: AlarmTemplateStore,
    private val vacationStore: VacationStore,
    private val backupManager: BackupManager,
    private val ringingState: RingingStateHolder,
    @ApplicationContext private val context: Context
) : ViewModel() {

    val alarms: StateFlow<List<Alarm>> = repository.allAlarms
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val groups: StateFlow<List<AlarmGroup>> = groupRepository.allGroups
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val template: StateFlow<AlarmTemplateStore.AlarmTemplate> = templateStore.template
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000),
            AlarmTemplateStore.AlarmTemplate())

    val vacationMode: StateFlow<VacationMode> = vacationStore.vacationMode
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), VacationMode())

    // Feature 18: check if alarm should be suppressed by vacation mode
    private fun isOnVacation(alarm: Alarm, vm: VacationMode): Boolean {
        if (alarm.vacationExempt) return false
        return vacationStore.isActiveNow(vm.isActive, vm.startMillis, vm.endMillis)
    }

    private fun refreshWidget() = viewModelScope.launch {
        runCatching { AlarmWidget().updateAll(context) }
    }

    private fun autoBackup() = viewModelScope.launch {
        backupManager.autoBackup(ExportImport.exportToJson(alarms.value))
    }

    fun addAlarm(alarm: Alarm) = viewModelScope.launch {
        val id = repository.insert(alarm).toInt()
        val saved = alarm.copy(id = id)
        val vm = vacationMode.value
        if (!isOnVacation(saved, vm)) {
            scheduler.schedule(saved)
            preAlarmScheduler.schedule(saved)
        }
        refreshWidget(); autoBackup()
    }

    fun updateAlarm(alarm: Alarm) = viewModelScope.launch {
        repository.update(alarm)
        scheduler.cancel(alarm.id)
        preAlarmScheduler.cancel(alarm.id)
        val vm = vacationMode.value
        if (alarm.isEnabled && !isOnVacation(alarm, vm)) {
            scheduler.schedule(alarm)
            preAlarmScheduler.schedule(alarm)
        }
        refreshWidget(); autoBackup()
    }

    /** Feature 5: block delete if alarm is currently ringing */
    fun deleteAlarm(alarm: Alarm, force: Boolean = false) = viewModelScope.launch {
        if (!force && ringingState.isAlarmRinging(alarm.id)) return@launch
        scheduler.cancel(alarm.id)
        preAlarmScheduler.cancel(alarm.id)
        repository.delete(alarm)
        refreshWidget(); autoBackup()
    }

    fun toggleAlarm(alarm: Alarm, enabled: Boolean) = viewModelScope.launch {
        val updated = alarm.copy(isEnabled = enabled, skipToday = false)
        repository.update(updated)
        val vm = vacationMode.value
        if (enabled && !isOnVacation(updated, vm)) {
            scheduler.schedule(updated); preAlarmScheduler.schedule(updated)
        } else {
            scheduler.cancel(alarm.id); preAlarmScheduler.cancel(alarm.id)
        }
        refreshWidget(); autoBackup()
    }

    val isAlarmRinging: (Int) -> Boolean = { id -> ringingState.isAlarmRinging(id) }

    // Feature 8: Group management
    fun addGroup(group: AlarmGroup) = viewModelScope.launch { groupRepository.insert(group) }
    fun updateGroup(group: AlarmGroup) = viewModelScope.launch { groupRepository.update(group) }
    fun deleteGroup(group: AlarmGroup) = viewModelScope.launch { groupRepository.delete(group) }

    /** Toggle all alarms in a group */
    fun toggleGroup(groupId: Int, enabled: Boolean) = viewModelScope.launch {
        alarms.value.filter { it.groupId == groupId }.forEach { alarm ->
            toggleAlarm(alarm, enabled)
        }
    }

    // Feature 18: Vacation mode
    fun setVacationMode(vm: VacationMode) = viewModelScope.launch {
        vacationStore.setVacation(vm)
        alarms.value.forEach { alarm ->
            scheduler.cancel(alarm.id)
            preAlarmScheduler.cancel(alarm.id)
            if (alarm.isEnabled && !isOnVacation(alarm, vm)) {
                scheduler.schedule(alarm)
                preAlarmScheduler.schedule(alarm)
            }
        }
    }

    fun deactivateVacation() = viewModelScope.launch {
        vacationStore.deactivate()
        val noVacation = VacationMode(isActive = false)
        alarms.value.filter { it.isEnabled }.forEach {
            scheduler.schedule(it)
            preAlarmScheduler.schedule(it)
        }
    }

    // Template
    fun saveTemplate(t: AlarmTemplateStore.AlarmTemplate) = viewModelScope.launch {
        templateStore.saveTemplate(t)
    }

    fun newAlarmFromTemplate(hour: Int, minute: Int): Alarm {
        val t = template.value
        return Alarm(
            hour = hour, minute = minute,
            volumePercent = t.volumePercent, isVibrate = t.isVibrate,
            vibrationPattern = t.vibrationPattern, isSnoozeEnabled = t.isSnoozeEnabled,
            snoozeMinutes = t.snoozeMinutes, snoozeReduceMinutes = t.snoozeReduceMinutes,
            snoozeMaxCount = t.snoozeMaxCount, autoSnoozeMinutes = t.autoSnoozeMinutes,
            dismissType = t.dismissType, dismissTask = t.dismissTask,
            dismissTaskDifficulty = t.dismissTaskDifficulty,
            autoDissmissMinutes = t.autoDissmissMinutes,
            wakeCheckEnabled = t.wakeCheckEnabled,
            wakeCheckDelayMinutes = t.wakeCheckDelayMinutes,
            wakeCheckCountdownMinutes = t.wakeCheckCountdownMinutes,
            preAlarmNotifyMinutes = t.preAlarmNotifyMinutes,
            soundUri = t.soundUri, soundName = t.soundName
        )
    }

    // Export/Import
    fun exportJson(): String = ExportImport.exportToJson(alarms.value)

    fun importFromJson(json: String) = viewModelScope.launch {
        ExportImport.importFromJson(json).forEach { alarm ->
            val id = repository.insert(alarm).toInt()
            val saved = alarm.copy(id = id)
            if (alarm.isEnabled) {
                scheduler.schedule(saved); preAlarmScheduler.schedule(saved)
            }
        }
        refreshWidget(); autoBackup()
    }

    fun manualBackup(): String? = backupManager.manualBackup(exportJson())

    fun shareExport() {
        val json = exportJson()
        val tmp = java.io.File(context.cacheDir, "alarms_export.json")
        tmp.writeText(json)
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", tmp)
        context.startActivity(Intent.createChooser(
            Intent(Intent.ACTION_SEND).apply {
                type = "application/json"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }, "تصدير المنبهات"
        ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
    }
}
