package com.hussein.alarmpro.data.db

import androidx.room.*
import com.hussein.alarmpro.data.model.AlarmGroup
import kotlinx.coroutines.flow.Flow

@Dao
interface AlarmGroupDao {
    @Query("SELECT * FROM alarm_groups ORDER BY createdAt ASC")
    fun getAllGroups(): Flow<List<AlarmGroup>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(group: AlarmGroup): Long

    @Update
    suspend fun update(group: AlarmGroup)

    @Delete
    suspend fun delete(group: AlarmGroup)

    @Query("DELETE FROM alarm_groups WHERE id = :id")
    suspend fun deleteById(id: Int)
}
