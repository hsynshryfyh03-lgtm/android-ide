package com.hussein.alarmpro.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hussein.alarmpro.ui.theme.*
import kotlinx.coroutines.delay
import java.util.Calendar
import kotlin.math.*

enum class ClockFaceStyle { CLASSIC, MODERN, DIGITAL, MINIMAL, NEON, RETRO }

@Composable
fun AnalogClockWithFace(
    face: ClockFaceStyle = ClockFaceStyle.CLASSIC,
    size: Dp = 200.dp,
    modifier: Modifier = Modifier
) {
    when (face) {
        ClockFaceStyle.CLASSIC -> AnalogClock(modifier, size)
        ClockFaceStyle.MODERN  -> ModernClock(modifier, size)
        ClockFaceStyle.MINIMAL -> MinimalClock(modifier, size)
        ClockFaceStyle.NEON    -> NeonClock(modifier, size)
        ClockFaceStyle.RETRO   -> RetroClock(modifier, size)
        ClockFaceStyle.DIGITAL -> DigitalClockFace(modifier, size)
    }
}

@Composable
fun AnalogClock(modifier: Modifier = Modifier, size: Dp = 220.dp) {
    var cal by remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) { while (true) { cal = Calendar.getInstance(); delay(1000L) } }
    val inf = rememberInfiniteTransition(label = "ring")
    val ringRot by inf.animateFloat(0f, 360f,
        infiniteRepeatable(tween(20_000, easing = LinearEasing)), "ring")
    Canvas(modifier = modifier.size(size)) {
        val cx = this.size.width / 2f; val cy = this.size.height / 2f
        val r  = this.size.minDimension / 2f * 0.90f
        drawClockFaceClassic(cx, cy, r)
        drawRotatingRing(cx, cy, r, ringRot)
        drawTicks(cx, cy, r, showNumbers = true)
        drawHands(cx, cy, r, cal, ClockFaceStyle.CLASSIC)
        drawCenter(cx, cy, OrbBlue)
    }
}

@Composable
fun ModernClock(modifier: Modifier = Modifier, size: Dp = 200.dp) {
    var cal by remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) { while (true) { cal = Calendar.getInstance(); delay(1000L) } }
    Canvas(modifier = modifier.size(size)) {
        val cx = this.size.width / 2f; val cy = this.size.height / 2f
        val r  = this.size.minDimension / 2f * 0.90f
        drawCircle(brush = Brush.radialGradient(
            listOf(Color.White.copy(0.06f), Color.Transparent),
            center = Offset(cx, cy), radius = r), radius = r, center = Offset(cx, cy))
        drawCircle(color = Color.White.copy(0.22f), radius = r, center = Offset(cx, cy), style = Stroke(1f))
        drawTicks(cx, cy, r, showNumbers = false)
        drawHands(cx, cy, r, cal, ClockFaceStyle.MODERN)
        drawCenter(cx, cy, OrbCyan)
    }
}

@Composable
fun MinimalClock(modifier: Modifier = Modifier, size: Dp = 200.dp) {
    var cal by remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) { while (true) { cal = Calendar.getInstance(); delay(1000L) } }
    Canvas(modifier = modifier.size(size)) {
        val cx = this.size.width / 2f; val cy = this.size.height / 2f
        val r  = this.size.minDimension / 2f * 0.88f
        drawCircle(color = GlassBorder, radius = r, center = Offset(cx, cy), style = Stroke(1f))
        listOf(0, 90, 180, 270).forEach { deg ->
            val ang = Math.toRadians(deg.toDouble() - 90.0)
            drawCircle(Color.White.copy(0.70f), 4f,
                Offset(cx + r*0.88f*cos(ang).toFloat(), cy + r*0.88f*sin(ang).toFloat()))
        }
        drawHands(cx, cy, r, cal, ClockFaceStyle.MINIMAL)
        drawCenter(cx, cy, TextPrimary)
    }
}

@Composable
fun NeonClock(modifier: Modifier = Modifier, size: Dp = 200.dp) {
    var cal by remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) { while (true) { cal = Calendar.getInstance(); delay(1000L) } }
    val inf = rememberInfiniteTransition(label = "neon")
    val pulse by inf.animateFloat(0.65f, 1f,
        infiniteRepeatable(tween(1200, easing = EaseInOutSine), RepeatMode.Reverse), "np")
    Canvas(modifier = modifier.size(size)) {
        val cx = this.size.width / 2f; val cy = this.size.height / 2f
        val r  = this.size.minDimension / 2f * 0.90f
        drawCircle(brush = Brush.radialGradient(
            listOf(Color(0xFF000820).copy(0.95f), Color.Transparent),
            center = Offset(cx, cy), radius = r), radius = r, center = Offset(cx, cy))
        drawCircle(brush = Brush.sweepGradient(
            listOf(OrbBlue.copy(pulse), OrbPurple.copy(pulse*0.6f),
                   OrbCyan.copy(pulse), OrbBlue.copy(pulse)),
            center = Offset(cx, cy)),
            radius = r, center = Offset(cx, cy), style = Stroke(2.5f))
        drawCircle(brush = Brush.radialGradient(
            listOf(OrbBlue.copy(0.12f * pulse), Color.Transparent),
            center = Offset(cx, cy), radius = r * 1.25f),
            radius = r * 1.25f, center = Offset(cx, cy))
        for (i in 0 until 60) {
            val angle = Math.toRadians(i * 6.0 - 90.0)
            val isHour = i % 5 == 0
            val startR = if (isHour) r * 0.78f else r * 0.88f
            val col = if (isHour) when(i) {
                0 -> OrbCyan; 15 -> OrbMint; 30 -> OrbPurple; 45 -> OrbPink; else -> OrbBlue
            } else Color.White.copy(0.25f)
            drawLine(col.copy(if (isHour) pulse else 0.25f),
                Offset(cx + startR*cos(angle).toFloat(), cy + startR*sin(angle).toFloat()),
                Offset(cx + r*0.95f*cos(angle).toFloat(), cy + r*0.95f*sin(angle).toFloat()),
                strokeWidth = if (isHour) 2.5f else 1f, cap = StrokeCap.Round)
            if (isHour) {
                val gx = cx + r*0.87f*cos(angle).toFloat()
                val gy = cy + r*0.87f*sin(angle).toFloat()
                drawCircle(Brush.radialGradient(listOf(col.copy(0.6f*pulse), Color.Transparent),
                    center=Offset(gx,gy), radius=8f), 8f, Offset(gx,gy))
            }
        }
        drawHands(cx, cy, r, cal, ClockFaceStyle.NEON)
        drawCenter(cx, cy, OrbCyan)
    }
}

@Composable
fun RetroClock(modifier: Modifier = Modifier, size: Dp = 200.dp) {
    var cal by remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) { while (true) { cal = Calendar.getInstance(); delay(1000L) } }
    Canvas(modifier = modifier.size(size)) {
        val cx = this.size.width / 2f; val cy = this.size.height / 2f
        val r  = this.size.minDimension / 2f * 0.90f
        val amber = Color(0xFFFFB347)
        val cream = Color(0xFFFFF8DC)
        drawCircle(brush = Brush.radialGradient(
            listOf(Color(0xFF2A1500).copy(0.90f), Color(0xFF1A0D00).copy(0.98f)),
            center = Offset(cx, cy), radius = r), radius = r, center = Offset(cx, cy))
        drawCircle(color = amber.copy(0.55f), radius = r, center = Offset(cx, cy), style = Stroke(3f))
        drawCircle(color = amber.copy(0.20f), radius = r * 0.95f, center = Offset(cx, cy), style = Stroke(1f))
        for (i in 0 until 12) {
            val angle = Math.toRadians(i * 30.0 - 90.0)
            val isCard = i % 3 == 0
            drawLine(if (isCard) cream.copy(0.90f) else amber.copy(0.70f),
                Offset(cx + r*0.75f*cos(angle).toFloat(), cy + r*0.75f*sin(angle).toFloat()),
                Offset(cx + r*0.92f*cos(angle).toFloat(), cy + r*0.92f*sin(angle).toFloat()),
                strokeWidth = if (isCard) 4f else 2f, cap = StrokeCap.Round)
        }
        drawHands(cx, cy, r, cal, ClockFaceStyle.RETRO)
        drawCenter(cx, cy, amber)
    }
}

@Composable
fun DigitalClockFace(modifier: Modifier = Modifier, size: Dp = 200.dp) {
    var cal by remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) { while (true) { cal = Calendar.getInstance(); delay(1000L) } }
    val h   = cal.get(Calendar.HOUR_OF_DAY)
    val min = cal.get(Calendar.MINUTE)
    val sec = cal.get(Calendar.SECOND)
    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.matchParentSize()) {
            val cx = this.size.width/2f; val cy = this.size.height/2f; val r = this.size.minDimension/2f
            drawCircle(brush = Brush.radialGradient(
                listOf(OrbBlue.copy(0.08f), Color.Transparent),
                center = Offset(cx, cy), radius = r), radius = r, center = Offset(cx, cy))
            drawCircle(color = GlassBorder, radius = r, center = Offset(cx, cy), style = Stroke(1f))
            val sweepAngle = sec / 60f * 360f
            drawArc(brush = Brush.sweepGradient(
                listOf(OrbBlue.copy(0f), OrbBlue, OrbCyan.copy(0.5f)),
                center = Offset(cx, cy)),
                startAngle = -90f, sweepAngle = sweepAngle, useCenter = false,
                topLeft = Offset(cx - r*0.95f, cy - r*0.95f),
                size = androidx.compose.ui.geometry.Size(r*1.9f, r*1.9f),
                style = Stroke(width = 3.5f, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            val colonStr = if (sec % 2 == 0) ":" else " "
            Text(
                text = String.format("%02d%s%02d", h, colonStr, min),
                style = MaterialTheme.typography.displaySmall.copy(
                    fontSize = (size.value * 0.22f).sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary, letterSpacing = (-1).sp)
            )
            Text(
                text = String.format("%02d", sec),
                style = MaterialTheme.typography.bodySmall.copy(
                    color = OrbBlue.copy(0.80f),
                    fontSize = (size.value * 0.08f).sp, letterSpacing = 2.sp)
            )
        }
    }
}

// ── Shared drawing helpers ───────────────────────────────────────────────────
private fun DrawScope.drawClockFaceClassic(cx: Float, cy: Float, r: Float) {
    drawCircle(brush = Brush.radialGradient(
        listOf(OrbBlue.copy(0.10f), Color.Transparent),
        center = Offset(cx, cy), radius = r * 1.3f), radius = r * 1.3f, center = Offset(cx, cy))
    drawCircle(brush = Brush.radialGradient(
        listOf(Color.White.copy(0.07f), ClockFaceColor),
        center = Offset(cx, cy - r*0.3f), radius = r), radius = r, center = Offset(cx, cy))
    drawCircle(color = ClockRing, radius = r, center = Offset(cx, cy), style = Stroke(1.5f))
    drawArc(brush = Brush.sweepGradient(
        listOf(Color.White.copy(0.3f), Color.Transparent, Color.Transparent),
        center = Offset(cx, cy)),
        startAngle = 200f, sweepAngle = 140f, useCenter = false,
        topLeft = Offset(cx - r*0.88f, cy - r*0.88f),
        size = androidx.compose.ui.geometry.Size(r*1.76f, r*1.76f), style = Stroke(1f))
}

private fun DrawScope.drawRotatingRing(cx: Float, cy: Float, r: Float, rotation: Float) {
    rotate(rotation, pivot = Offset(cx, cy)) {
        drawCircle(brush = Brush.sweepGradient(
            listOf(OrbBlue.copy(0f), OrbBlue.copy(0.55f), OrbPurple.copy(0.30f), OrbBlue.copy(0f)),
            center = Offset(cx, cy)),
            radius = r + 6f, center = Offset(cx, cy), style = Stroke(2.5f))
    }
}

private fun DrawScope.drawTicks(cx: Float, cy: Float, r: Float, showNumbers: Boolean = true) {
    for (i in 0 until 60) {
        val angle = Math.toRadians(i * 6.0 - 90.0)
        val isHour = i % 5 == 0
        val startR = if (isHour) r * 0.80f else r * 0.88f
        drawLine(Color.White.copy(if (isHour) 0.85f else 0.30f),
            Offset(cx + startR*cos(angle).toFloat(), cy + startR*sin(angle).toFloat()),
            Offset(cx + r*0.95f*cos(angle).toFloat(), cy + r*0.95f*sin(angle).toFloat()),
            strokeWidth = if (isHour) 2.2f else 1f, cap = StrokeCap.Round)
        if (showNumbers && isHour && i % 15 == 0) {
            drawCircle(OrbBlue.copy(0.70f), 3.5f,
                Offset(cx + r*0.67f*cos(angle).toFloat(), cy + r*0.67f*sin(angle).toFloat()))
        }
    }
}

private fun DrawScope.drawHands(cx: Float, cy: Float, r: Float, cal: Calendar, face: ClockFaceStyle) {
    val hr  = cal.get(Calendar.HOUR).toFloat()
    val min = cal.get(Calendar.MINUTE).toFloat()
    val sec = cal.get(Calendar.SECOND).toFloat()
    val hourAngle   = (hr + min / 60f) * 30f - 90f
    val minuteAngle = (min + sec / 60f) * 6f  - 90f
    val secondAngle = sec * 6f - 90f
    val (hc, mc, sc) = when (face) {
        ClockFaceStyle.NEON   -> Triple(OrbCyan, OrbBlue, OrbPink)
        ClockFaceStyle.RETRO  -> Triple(Color(0xFFFFF8DC), Color(0xFFFFB347), Color(0xFFFF4500))
        ClockFaceStyle.MODERN -> Triple(TextPrimary, TextSecondary, OrbMint)
        else -> Triple(ClockHourHand, ClockMinHand, ClockSecHand)
    }
    drawHand(cx, cy, r*0.48f, r*0.10f, hourAngle,   hc, if (face==ClockFaceStyle.NEON) 4.5f else 5f)
    drawHand(cx, cy, r*0.70f, r*0.12f, minuteAngle, mc, if (face==ClockFaceStyle.NEON) 3f else 3.5f)
    drawHand(cx, cy, r*0.80f, r*0.18f, secondAngle, sc, if (face==ClockFaceStyle.NEON) 2f else 1.5f)
    if (face == ClockFaceStyle.NEON) {
        val sA = Math.toRadians(secondAngle.toDouble())
        val sx = cx + r*0.80f*cos(sA).toFloat(); val sy = cy + r*0.80f*sin(sA).toFloat()
        drawCircle(Brush.radialGradient(listOf(OrbPink.copy(0.6f), Color.Transparent),
            center=Offset(sx,sy), radius=12f), 12f, Offset(sx,sy))
    }
}

private fun DrawScope.drawHand(cx: Float, cy: Float, len: Float, back: Float, deg: Float, col: Color, w: Float) {
    val a = Math.toRadians(deg.toDouble())
    val tx = cx+len*cos(a).toFloat(); val ty = cy+len*sin(a).toFloat()
    val bx = cx-back*cos(a).toFloat(); val by = cy-back*sin(a).toFloat()
    drawLine(Color.Black.copy(0.30f), Offset(bx+1f,by+1f), Offset(tx+1f,ty+1f), strokeWidth=w+1.5f, cap=StrokeCap.Round)
    drawLine(col, Offset(bx,by), Offset(tx,ty), strokeWidth=w, cap=StrokeCap.Round)
}

private fun DrawScope.drawCenter(cx: Float, cy: Float, color: Color) {
    drawCircle(color=color, radius=9f, center=Offset(cx,cy))
    drawCircle(color=Color.White.copy(0.95f), radius=4.5f, center=Offset(cx,cy))
    drawCircle(color=color.copy(0.50f), radius=13f, center=Offset(cx,cy), style=Stroke(1.5f))
}
