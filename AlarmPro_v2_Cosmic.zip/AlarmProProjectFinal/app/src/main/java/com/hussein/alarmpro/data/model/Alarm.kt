package com.hussein.alarmpro.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * days bitmask: bit0=Sun bit1=Mon bit2=Tue bit3=Wed bit4=Thu bit5=Fri bit6=Sat
 * days=0 → one-time alarm  |  days=-1 → specific date (use scheduledDate)
 */
@Entity(tableName = "alarms")
data class Alarm(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val hour: Int = 7,
    val minute: Int = 0,
    val label: String = "",
    val isEnabled: Boolean = true,
    // days=0 one-time | days>0 repeat mask | days=-1 specific date
    val days: Int = 0,
    // Feature 3: specific date scheduling (millis). Used when days == -1
    val scheduledDate: Long = 0L,
    // Sound
    val soundUri: String = "",
    val soundName: String = "",
    val volumePercent: Int = 80,
    // Feature 2: force ring even in silent/DND
    val bypassDnd: Boolean = true,
    // Feature 2: gradual volume
    val gradualVolume: Boolean = true,
    val gradualVolumeDurationSec: Int = 30,
    // Vibration  0=off 1=default 2=pulse 3=escalate
    val isVibrate: Boolean = true,
    val vibrationPattern: Int = 1,
    // Snooze
    val isSnoozeEnabled: Boolean = true,
    val snoozeMinutes: Int = 9,
    val snoozeReduceMinutes: Int = 0,
    val snoozeMaxCount: Int = -1,
    val autoSnoozeMinutes: Int = -1,
    // Dismiss  0=screen 1=flip 2=power 3=volume
    val dismissType: Int = 0,
    // Dismiss task  0=none 1=math 2=rewrite 3=steps(tap) 4=walk(accel)
    val dismissTask: Int = 0,
    val dismissTaskDifficulty: Int = 1,
    val autoDissmissMinutes: Int = -1,
    // Wake check
    val wakeCheckEnabled: Boolean = false,
    val wakeCheckDelayMinutes: Int = 5,
    val wakeCheckCountdownMinutes: Int = 2,
    // Ring screen background URI (empty = default glass animation)
    val ringBgUri: String = "",
    // Pre-alarm notification minutes before (-1 = off)
    val preAlarmNotifyMinutes: Int = 5,
    // Skip today
    val skipToday: Boolean = false,
    // Feature 6: bedtime — targetWakeHour/Min is the wake time; app shows when to sleep
    val bedtimeEnabled: Boolean = false,
    val sleepHours: Int = 8,
    // Feature 8: group ID (0 = no group)
    val groupId: Int = 0,
    // Feature 18: exempt from vacation mode
    val vacationExempt: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
