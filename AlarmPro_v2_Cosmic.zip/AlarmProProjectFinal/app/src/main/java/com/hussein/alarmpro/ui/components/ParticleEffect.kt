package com.hussein.alarmpro.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import com.hussein.alarmpro.ui.theme.*
import kotlin.math.*
import kotlin.random.Random

// ═══════════════════════════════════════════════════════════════════════════════
// STAR FIELD — Layered parallax twinkling stars (3 depth layers)
// Creates deep-space atmosphere. Renders on Canvas for peak performance.
// ═══════════════════════════════════════════════════════════════════════════════

data class StarParticle(
    val x: Float,          // 0-1 normalized
    val y: Float,          // 0-1 normalized
    val size: Float,       // px radius
    val baseAlpha: Float,  // 0-1
    val twinkleOffset: Float, // phase offset for twinkling
    val twinkleSpeed: Float,  // relative twinkling speed
    val layer: Int         // 0=far(small), 1=mid, 2=near(large)
)

private val starField = run {
    val rng = Random(42) // deterministic for stable layout
    List(180) {
        val layer = when {
            it < 100 -> 0   // far: 100 tiny dim stars
            it < 150 -> 1   // mid: 50 medium stars
            else     -> 2   // near: 30 bright large stars
        }
        StarParticle(
            x = rng.nextFloat(),
            y = rng.nextFloat(),
            size = when (layer) { 0 -> rng.nextFloat() * 1.2f + 0.4f; 1 -> rng.nextFloat() * 2f + 1f; else -> rng.nextFloat() * 3f + 2f },
            baseAlpha = when (layer) { 0 -> rng.nextFloat() * 0.35f + 0.10f; 1 -> rng.nextFloat() * 0.45f + 0.25f; else -> rng.nextFloat() * 0.5f + 0.45f },
            twinkleOffset = rng.nextFloat() * (2f * PI.toFloat()),
            twinkleSpeed = rng.nextFloat() * 1.8f + 0.6f,
            layer = layer
        )
    }
}

@Composable
fun StarFieldBackground(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "stars")
    val time by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI * 60f).toFloat(), // 60 full cycles
        animationSpec = infiniteRepeatable(tween(60_000, easing = LinearEasing)),
        label = "time"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val t = time

        starField.forEach { star ->
            // Twinkling: sinusoidal alpha modulation
            val twinkle = (sin(t * star.twinkleSpeed * 0.05f + star.twinkleOffset) * 0.5f + 0.5f)
            val alpha = (star.baseAlpha * (0.5f + twinkle * 0.5f)).coerceIn(0f, 1f)

            val cx = star.x * w
            val cy = star.y * h

            if (star.layer == 2 && star.size > 3f) {
                // Bright stars: draw 4-point star cross
                val arms = star.size * 1.8f
                drawLine(StarColor.copy(alpha * 0.35f), Offset(cx - arms, cy), Offset(cx + arms, cy), strokeWidth = 0.8f, cap = StrokeCap.Round)
                drawLine(StarColor.copy(alpha * 0.35f), Offset(cx, cy - arms), Offset(cx, cy + arms), strokeWidth = 0.8f, cap = StrokeCap.Round)
                drawLine(StarColor.copy(alpha * 0.20f), Offset(cx - arms*0.6f, cy - arms*0.6f), Offset(cx + arms*0.6f, cy + arms*0.6f), strokeWidth = 0.5f, cap = StrokeCap.Round)
                drawLine(StarColor.copy(alpha * 0.20f), Offset(cx + arms*0.6f, cy - arms*0.6f), Offset(cx - arms*0.6f, cy + arms*0.6f), strokeWidth = 0.5f, cap = StrokeCap.Round)
                // Halo glow
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(StarColor.copy(alpha * 0.55f), Color.Transparent),
                        center = Offset(cx, cy), radius = star.size * 3.5f
                    ),
                    radius = star.size * 3.5f, center = Offset(cx, cy)
                )
            }

            // Core dot
            drawCircle(
                color = StarColor.copy(alpha),
                radius = star.size,
                center = Offset(cx, cy)
            )
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// FLOATING SPARKLE PARTICLES — 20 drifting light particles
// Used on RingingActivity for premium feel
// ═══════════════════════════════════════════════════════════════════════════════

data class SparkleParticle(
    val startX: Float, val startY: Float,
    val vx: Float, val vy: Float,
    val size: Float,
    val color: Color,
    val phaseOffset: Float,
    val lifetime: Float  // 0-1 normalized
)

private val sparkleParticles = run {
    val rng = Random(99)
    val colors = listOf(OrbBlue, OrbPurple, OrbCyan, OrbPink, OrbMint, OrbLavender)
    List(24) {
        SparkleParticle(
            startX = rng.nextFloat(),
            startY = 0.3f + rng.nextFloat() * 0.7f,
            vx = (rng.nextFloat() - 0.5f) * 0.3f,
            vy = -(rng.nextFloat() * 0.4f + 0.1f),  // float upward
            size = rng.nextFloat() * 4f + 2f,
            color = colors[it % colors.size],
            phaseOffset = rng.nextFloat() * (2f * PI.toFloat()),
            lifetime = rng.nextFloat()
        )
    }
}

@Composable
fun SparkleOverlay(modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "sparkles")
    val t by inf.animateFloat(0f, 1f,
        infiniteRepeatable(tween(8000, easing = LinearEasing)), "st")

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        sparkleParticles.forEach { p ->
            // Each particle has its own 0-1 phase progress
            val progress = ((t + p.phaseOffset / (2f * PI.toFloat())) % 1f)
            // Fade in/out over lifetime
            val alpha = when {
                progress < 0.15f -> progress / 0.15f
                progress > 0.75f -> 1f - (progress - 0.75f) / 0.25f
                else -> 1f
            } * 0.75f

            val cx = (p.startX + p.vx * progress) * w
            val cy = (p.startY + p.vy * progress) * h

            // Twinkle modulation
            val twinkle = (sin(progress * PI.toFloat() * 8f + p.phaseOffset) * 0.3f + 0.7f)
            val finalAlpha = (alpha * twinkle).coerceIn(0f, 1f)

            if (finalAlpha > 0.02f) {
                // Glow
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(p.color.copy(finalAlpha * 0.6f), Color.Transparent),
                        center = Offset(cx, cy), radius = p.size * 3f
                    ),
                    radius = p.size * 3f, center = Offset(cx, cy)
                )
                // Core
                drawCircle(p.color.copy(finalAlpha), radius = p.size * 0.7f, center = Offset(cx, cy))
            }
        }
    }
}
