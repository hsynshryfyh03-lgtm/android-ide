package com.hussein.alarmpro.admin

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class AlarmDeviceAdmin : DeviceAdminReceiver() {
    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        // Admin enabled — app is now protected from uninstall
    }

    override fun onDisabled(context: Context, intent: Intent) {
        super.onDisabled(context, intent)
        // Admin was removed - nothing to do, alarm still functions
    }

    override fun onDisableRequested(context: Context, intent: Intent): CharSequence {
        return if (android.os.Build.VERSION.SDK_INT >= 17) {
            context.getString(com.hussein.alarmpro.R.string.admin_disable_warning)
        } else ""
    }
}
