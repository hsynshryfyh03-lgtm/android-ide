package com.hussein.alarmpro.util

import com.hussein.alarmpro.data.model.Alarm
import java.util.Locale

object TimeUtils {

    fun formatTime(hour: Int, minute: Int): String =
        String.format(Locale.getDefault(), "%02d:%02d", hour, minute)

    fun timeUntilLabel(millis: Long?, isAr: Boolean): String {
        if (millis == null || millis <= System.currentTimeMillis()) return ""
        val diff = millis - System.currentTimeMillis()
        val totalMin = (diff / 60_000L).toInt()
        val h = totalMin / 60
        val m = totalMin % 60
        return if (isAr) when {
            h == 0 -> "بعد $m دقيقة"
            m == 0 -> "بعد $h ساعة"
            else   -> "بعد $h س $m د"
        } else when {
            h == 0 -> "in ${m}m"
            m == 0 -> "in ${h}h"
            else   -> "in ${h}h ${m}m"
        }
    }

    fun daysLabel(days: Int, isAr: Boolean): String {
        if (days == 0)         return if (isAr) "مرة واحدة"              else "Once"
        if (days == 0b1111111) return if (isAr) "كل يوم"                else "Every day"
        if (days == 0b0111110) return if (isAr) "أيام العمل"            else "Weekdays"
        if (days == 0b1000001) return if (isAr) "نهاية الأسبوع"        else "Weekend"
        val ar = listOf("أحد","إثنين","ثلاثاء","أربعاء","خميس","جمعة","سبت")
        val en = listOf("Sun","Mon","Tue","Wed","Thu","Fri","Sat")
        val names = if (isAr) ar else en
        return (0..6).filter { (days shr it) and 1 == 1 }.joinToString(" ") { names[it] }
    }

    fun isArabic(): Boolean = Locale.getDefault().language == "ar"
}
