package com.hussein.alarmpro.util

import javax.inject.Inject
import javax.inject.Singleton

/**
 * Feature 5: Singleton that tracks which alarm is currently ringing.
 * ViewModel checks this before allowing delete.
 */
@Singleton
class RingingStateHolder @Inject constructor() {
    private var _ringingAlarmId: Int = -1

    val ringingAlarmId: Int get() = _ringingAlarmId
    val isRinging: Boolean get() = _ringingAlarmId != -1

    fun setRinging(alarmId: Int) { _ringingAlarmId = alarmId }
    fun clearRinging() { _ringingAlarmId = -1 }
    fun isAlarmRinging(alarmId: Int) = _ringingAlarmId == alarmId
}
