package com.hussein.alarmpro.data.repository

import com.hussein.alarmpro.data.db.AlarmDao
import com.hussein.alarmpro.data.model.Alarm
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AlarmRepository @Inject constructor(private val dao: AlarmDao) {
    val allAlarms: Flow<List<Alarm>> = dao.getAllAlarms()
    suspend fun getById(id: Int): Alarm? = dao.getById(id)
    suspend fun getEnabledAlarms(): List<Alarm> = dao.getEnabledAlarms()
    suspend fun insert(alarm: Alarm): Long = dao.insert(alarm)
    suspend fun update(alarm: Alarm) = dao.update(alarm)
    suspend fun delete(alarm: Alarm) = dao.delete(alarm)
    suspend fun deleteById(id: Int) = dao.deleteById(id)
}
