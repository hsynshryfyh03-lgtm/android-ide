package com.hussein.alarmpro.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
// Divider replaced by custom drawn lines
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.hussein.alarmpro.ui.theme.*
import kotlinx.coroutines.launch
import kotlin.math.abs

private const val EXTRA = 3

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun IosWheelPicker(
    items: List<String>,
    selectedIndex: Int,
    onItemSelected: (Int) -> Unit,
    modifier: Modifier = Modifier,
    visibleItems: Int = 5,
    itemHeight: Dp = 48.dp
) {
    val totalHeight = itemHeight * visibleItems
    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = maxOf(0, selectedIndex + EXTRA - visibleItems / 2)
    )
    val flingBehavior = rememberSnapFlingBehavior(lazyListState = listState)
    val coroutineScope = rememberCoroutineScope()

    // Derive selected index from scroll position
    LaunchedEffect(listState.firstVisibleItemIndex, listState.isScrollInProgress) {
        if (!listState.isScrollInProgress) {
            val centerIdx = listState.firstVisibleItemIndex + visibleItems / 2
            val realIdx = (centerIdx - EXTRA).coerceIn(0, items.lastIndex)
            if (realIdx != selectedIndex) onItemSelected(realIdx)
        }
    }

    Box(
        modifier = modifier
            .height(totalHeight)
            .clip(RoundedCornerShape(16.dp))
            .drawBehind {
                // Selection highlight strip
                val stripTop = (size.height - itemHeight.toPx()) / 2f
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            OrbBlue.copy(alpha = 0.18f),
                            OrbBlue.copy(alpha = 0.10f)
                        ),
                        startY = stripTop,
                        endY = stripTop + itemHeight.toPx()
                    ),
                    topLeft = androidx.compose.ui.geometry.Offset(0f, stripTop),
                    size = androidx.compose.ui.geometry.Size(size.width, itemHeight.toPx())
                )
                // Top fade gradient
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(DeepBlack.copy(alpha = 0.85f), Color.Transparent),
                        endY = stripTop
                    )
                )
                // Bottom fade gradient
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color.Transparent, DeepBlack.copy(alpha = 0.85f)),
                        startY = stripTop + itemHeight.toPx()
                    )
                )
            }
    ) {
        LazyColumn(
            state = listState,
            flingBehavior = flingBehavior,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize()
        ) {
            // Padding items before
            items(EXTRA) {
                Box(Modifier.height(itemHeight).fillMaxWidth())
            }
            itemsIndexed(items) { idx, item ->
                val centerIdx = listState.firstVisibleItemIndex + visibleItems / 2
                val distance = abs(idx + EXTRA - centerIdx)
                val alpha = when (distance) {
                    0 -> 1.0f
                    1 -> 0.65f
                    2 -> 0.35f
                    else -> 0.15f
                }
                val scale = when (distance) {
                    0 -> 1.0f
                    1 -> 0.92f
                    else -> 0.82f
                }
                val fontSize = when (distance) {
                    0 -> 26.sp
                    1 -> 22.sp
                    else -> 18.sp
                }
                val fontWeight = if (distance == 0) FontWeight.SemiBold else FontWeight.Normal

                Box(
                    Modifier.height(itemHeight).fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = item,
                        style = TextStyle(
                            color = if (distance == 0) TextPrimary else TextSecondary,
                            fontSize = fontSize,
                            fontWeight = fontWeight,
                            textAlign = TextAlign.Center
                        ),
                        modifier = Modifier
                            .alpha(alpha)
                            .graphicsLayer(scaleX = scale, scaleY = scale)
                    )
                }
            }
            // Padding items after
            items(EXTRA) {
                Box(Modifier.height(itemHeight).fillMaxWidth())
            }
        }

        // Selection lines
        Box(
            modifier = Modifier.align(Alignment.Center).fillMaxWidth()
        ) {
            val stripTop = (totalHeight - itemHeight) / 2
            HorizontalDivider(
                modifier = Modifier.offset(y = stripTop),
                color = OrbBlue.copy(alpha = 0.50f),
                thickness = 1.dp
            )
            HorizontalDivider(
                modifier = Modifier.offset(y = stripTop + itemHeight),
                color = OrbBlue.copy(alpha = 0.50f),
                thickness = 1.dp
            )
        }
    }
}
