package com.hussein.alarmpro.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.hussein.alarmpro.data.model.Alarm
import com.hussein.alarmpro.receiver.AlarmReceiver
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AlarmScheduler @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun schedule(alarm: Alarm) {
        if (!alarm.isEnabled || alarm.skipToday) return
        val triggerAt = nextTriggerMillis(alarm) ?: return
        val pi = buildPi(alarm.id)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && am.canScheduleExactAlarms()) {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, pi), pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
    }

    fun cancel(alarmId: Int) = am.cancel(buildPi(alarmId))

    fun nextTriggerMillis(alarm: Alarm): Long? {
        // Feature 3: specific date
        if (alarm.days == -1 && alarm.scheduledDate > 0L) {
            val cal = Calendar.getInstance().apply {
                timeInMillis = alarm.scheduledDate
                set(Calendar.HOUR_OF_DAY, alarm.hour)
                set(Calendar.MINUTE, alarm.minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            return if (cal.timeInMillis > System.currentTimeMillis()) cal.timeInMillis else null
        }

        // Regular time-based
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, alarm.hour)
            set(Calendar.MINUTE, alarm.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // One-time
        if (alarm.days == 0) {
            if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
            return cal.timeInMillis
        }

        // Repeat mask
        var found: Long? = null
        repeat(8) {
            if (found != null) return@repeat
            val dow = cal.get(Calendar.DAY_OF_WEEK) - 1
            if ((alarm.days shr dow) and 1 == 1 && cal.timeInMillis > System.currentTimeMillis())
                found = cal.timeInMillis
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return found
    }

    private fun buildPi(alarmId: Int) = PendingIntent.getBroadcast(
        context, alarmId,
        Intent(context, AlarmReceiver::class.java).apply {
            action = "com.hussein.alarmpro.ACTION_ALARM_FIRE"
            putExtra("alarm_id", alarmId)
        },
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
}
