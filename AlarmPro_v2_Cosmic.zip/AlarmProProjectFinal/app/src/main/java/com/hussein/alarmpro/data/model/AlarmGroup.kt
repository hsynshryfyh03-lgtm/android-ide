package com.hussein.alarmpro.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "alarm_groups")
data class AlarmGroup(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String = "",
    val colorHex: String = "#0A84FF",
    val isEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
