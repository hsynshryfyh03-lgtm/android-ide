package com.hussein.alarmpro.util

import android.content.Context
import android.os.Environment
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BackupManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        private const val BACKUP_DIR = "AlarmPro"
        private const val AUTO_BACKUP_FILE = "alarmpro_auto_backup.json"
        private const val MAX_TIMESTAMPED_BACKUPS = 5
    }

    /** Returns the app-specific backup directory in external files (no permission needed API 29+) */
    private fun getBackupDir(): File {
        val dir = File(context.getExternalFilesDir(null), BACKUP_DIR)
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /**
     * Auto-backup: silently overwrites alarmpro_auto_backup.json.
     * Called every time alarms change.
     */
    fun autoBackup(json: String): Boolean = runCatching {
        val file = File(getBackupDir(), AUTO_BACKUP_FILE)
        file.writeText(json, Charsets.UTF_8)
        true
    }.getOrDefault(false)

    /**
     * Manual timestamped backup — called from Settings.
     * Returns the path of the created file, or null on failure.
     */
    fun manualBackup(json: String): String? = runCatching {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val file = File(getBackupDir(), "alarmpro_backup_$stamp.json")
        file.writeText(json, Charsets.UTF_8)
        pruneOldBackups()
        file.absolutePath
    }.getOrNull()

    /** Read the last auto-backup, returns JSON or null */
    fun readAutoBackup(): String? = runCatching {
        val file = File(getBackupDir(), AUTO_BACKUP_FILE)
        if (file.exists()) file.readText(Charsets.UTF_8) else null
    }.getOrNull()

    /** List all backup files sorted by date descending */
    fun listBackups(): List<File> = runCatching {
        getBackupDir().listFiles { f -> f.name.endsWith(".json") }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()
    }.getOrDefault(emptyList())

    /** Keep only MAX_TIMESTAMPED_BACKUPS manual backups */
    private fun pruneOldBackups() {
        val manual = getBackupDir()
            .listFiles { f -> f.name.startsWith("alarmpro_backup_") }
            ?.sortedByDescending { it.lastModified() } ?: return
        manual.drop(MAX_TIMESTAMPED_BACKUPS).forEach { it.delete() }
    }

    val backupDirPath: String get() = getBackupDir().absolutePath
}
