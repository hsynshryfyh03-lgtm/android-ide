package com.hussein.alarmpro.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.hussein.alarmpro.data.model.Alarm
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.TimeUtils
import com.valentinilk.shimmer.shimmer
import com.valentinilk.shimmer.ShimmerBounds
import com.valentinilk.shimmer.rememberShimmer

// ═══════════════════════════════════════════════════════════════════════════════
// PREMIUM ALARM CARD v2.0
// Features: Shimmer on entry, color-coded by time-of-day, neon enabled state,
//           animated status indicator, aurora gradient border, depth shadow
// ═══════════════════════════════════════════════════════════════════════════════
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AlarmCard(
    alarm: Alarm,
    nextTriggerMillis: Long?,
    onToggle: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isAr = TimeUtils.isArabic()
    var showDelete by remember { mutableStateOf(false) }
    var appeared by remember { mutableStateOf(false) }

    // Entry reveal shimmer
    val shimmerInstance = rememberShimmer(shimmerBounds = ShimmerBounds.Window)

    LaunchedEffect(Unit) { appeared = true }

    // Disabled → fade out card
    val cardAlpha by animateFloatAsState(
        targetValue = if (alarm.isEnabled) 1f else 0.50f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "alpha"
    )

    // Time-of-day accent color
    val accentColor = remember(alarm.hour) {
        when {
            alarm.hour in 5..8   -> OrbSunrise  // dawn
            alarm.hour in 9..11  -> OrbOrange   // morning
            alarm.hour in 12..16 -> OrbBlue     // afternoon
            alarm.hour in 17..19 -> OrbPurple   // sunset
            alarm.hour in 20..22 -> OrbNebula   // evening
            else                  -> OrbIndigo  // night
        }
    }

    // Breathing glow for enabled alarms
    val inf = rememberInfiniteTransition(label = "card")
    val glowPulse by inf.animateFloat(0.06f, 0.16f,
        infiniteRepeatable(tween(2800, easing = EaseInOutSine), RepeatMode.Reverse), "glow")

    Box(
        modifier = modifier
            .fillMaxWidth()
            .drawBehind {
                if (alarm.isEnabled) {
                    // Outer ambient glow halo
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            listOf(
                                accentColor.copy(glowPulse),
                                OrbPurple.copy(glowPulse * 0.5f),
                                Color.Transparent
                            )
                        ),
                        cornerRadius = CornerRadius(26.dp.toPx()),
                        topLeft = Offset(-5.dp.toPx(), -2.dp.toPx()),
                        size = size.copy(
                            width  = size.width + 10.dp.toPx(),
                            height = size.height + 4.dp.toPx()
                        )
                    )
                }
            }
    ) {
        // ── Main Glass Card ──────────────────────────────────────────────────
        val shape = RoundedCornerShape(24.dp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .alpha(cardAlpha)
                .combinedClickable(onClick = onEdit, onLongClick = { showDelete = !showDelete })
                .clip(shape)
                // Multi-layer glass fill
                .background(
                    brush = Brush.verticalGradient(
                        listOf(
                            if (alarm.isEnabled) accentColor.copy(0.14f) else Color.White.copy(0.10f),
                            Color.White.copy(if (alarm.isEnabled) 0.06f else 0.04f)
                        )
                    )
                )
                // Aurora gradient border
                .border(
                    width = 1.dp,
                    brush = if (alarm.isEnabled) {
                        Brush.linearGradient(
                            listOf(
                                Color.White.copy(0.60f),
                                accentColor.copy(0.70f),
                                OrbPurple.copy(0.30f),
                                Color.White.copy(0.10f)
                            ),
                            start = Offset(0f, 0f),
                            end   = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
                        )
                    } else {
                        Brush.linearGradient(
                            listOf(Color.White.copy(0.25f), Color.White.copy(0.08f))
                        )
                    },
                    shape = shape
                )
                // Inner specular top highlight
                .drawBehind {
                    drawRect(
                        brush = Brush.verticalGradient(
                            listOf(Color.White.copy(0.12f), Color.Transparent),
                            endY = size.height * 0.28f
                        )
                    )
                    // Bottom inner depth
                    drawRect(
                        brush = Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(0.15f)),
                            startY = size.height * 0.70f
                        )
                    )
                }
        ) {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {

                // ── Row 1: Time display + status dot + toggle ─────────────────
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Status indicator dot
                    Box(
                        Modifier
                            .padding(end = 10.dp)
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(
                                if (alarm.isEnabled) accentColor
                                else Color.White.copy(0.20f)
                            )
                            .drawBehind {
                                if (alarm.isEnabled) {
                                    drawCircle(
                                        brush = Brush.radialGradient(
                                            listOf(accentColor.copy(0.70f), Color.Transparent),
                                            radius = size.minDimension * 2.5f
                                        ),
                                        radius = size.minDimension * 2.5f
                                    )
                                }
                            }
                    )

                    Column(modifier = Modifier.weight(1f)) {
                        // ── Large time display — Nunito Thin ──────────────────
                        Text(
                            text = TimeUtils.formatTime(alarm.hour, alarm.minute),
                            style = MaterialTheme.typography.displayMedium.copy(
                                fontSize = 48.sp,
                                fontWeight = FontWeight.Light,
                                color = if (alarm.isEnabled) TextPrimary else TextTertiary,
                                letterSpacing = (-1.5).sp
                            )
                        )
                        if (alarm.label.isNotBlank()) {
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = alarm.label,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = if (alarm.isEnabled) TextSecondary else TextTertiary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        }
                    }

                    IosSwitch(checked = alarm.isEnabled, onCheckedChange = onToggle)
                }

                Spacer(Modifier.height(12.dp))

                // ── Separator ─────────────────────────────────────────────────
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(0.5.dp)
                        .background(
                            Brush.horizontalGradient(
                                listOf(Color.Transparent, Separator, Separator, Color.Transparent)
                            )
                        )
                )

                Spacer(Modifier.height(10.dp))

                // ── Row 2: Days + Next alarm pill ─────────────────────────────
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val daysLabel = TimeUtils.daysLabel(alarm.days, isAr)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Outlined.Repeat, null,
                            tint = if (alarm.isEnabled) accentColor.copy(0.80f) else TextQuaternary,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            daysLabel,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (alarm.isEnabled) TextTertiary else TextQuaternary,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }

                    // Next alarm remaining time
                    if (alarm.isEnabled && nextTriggerMillis != null) {
                        val remaining = TimeUtils.timeUntilLabel(nextTriggerMillis, isAr)
                        if (remaining.isNotBlank()) {
                            GlassPill(color = accentColor) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        Icons.Filled.AccessTime, null,
                                        tint = accentColor,
                                        modifier = Modifier.size(10.dp)
                                    )
                                    Spacer(Modifier.width(3.dp))
                                    Text(
                                        remaining,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = accentColor,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                // ── Feature badges ────────────────────────────────────────────
                val hasBadges = alarm.isSnoozeEnabled || alarm.isVibrate || alarm.dismissTask > 0 || alarm.soundName.isNotBlank()
                if (hasBadges) {
                    Spacer(Modifier.height(10.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (alarm.isSnoozeEnabled) SmallBadge(Icons.Filled.Snooze,
                            if (isAr) "غفوة ${alarm.snoozeMinutes}د" else "${alarm.snoozeMinutes}m", OrbPurple)
                        if (alarm.isVibrate) SmallBadge(Icons.Filled.Vibration,
                            if (isAr) "اهتزاز" else "Vibrate", OrbCyan)
                        if (alarm.dismissTask > 0) {
                            val t = when(alarm.dismissTask) {
                                1 -> if (isAr) "رياضيات" else "Math"
                                2 -> if (isAr) "كتابة" else "Write"
                                3 -> "QR"; else -> ""
                            }
                            SmallBadge(Icons.Filled.Calculate, t, OrbOrange)
                        }
                        if (alarm.soundName.isNotBlank()) SmallBadge(Icons.Filled.MusicNote,
                            alarm.soundName.take(10), OrbMint)
                    }
                }

                // ── Delete Confirm Row ────────────────────────────────────────
                AnimatedVisibility(
                    visible = showDelete,
                    enter = expandVertically(spring(stiffness = Spring.StiffnessLow)) + fadeIn(tween(200)),
                    exit  = shrinkVertically(tween(150)) + fadeOut(tween(150))
                ) {
                    Column {
                        Spacer(Modifier.height(12.dp))
                        Box(Modifier.fillMaxWidth().height(0.5.dp).background(Separator))
                        Spacer(Modifier.height(8.dp))
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Cancel
                            Box(
                                modifier = Modifier
                                    .weight(1f).height(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(0.08f))
                                    .border(0.5.dp, Color.White.copy(0.18f), RoundedCornerShape(12.dp))
                                    .clickable { showDelete = false },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(if (isAr) "إلغاء" else "Cancel",
                                    style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary))
                            }
                            // Delete
                            Box(
                                modifier = Modifier
                                    .weight(1f).height(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(
                                        Brush.horizontalGradient(
                                            listOf(OrbPink.copy(0.22f), SystemRed.copy(0.15f))
                                        )
                                    )
                                    .border(0.5.dp, OrbPink.copy(0.50f), RoundedCornerShape(12.dp))
                                    .clickable { showDelete = false; onDelete() },
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.DeleteOutline, null, tint = OrbPink, modifier = Modifier.size(14.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text(if (isAr) "حذف" else "Delete",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            color = OrbPink, fontWeight = FontWeight.Bold))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ── SmallBadge ────────────────────────────────────────────────────────────────
@Composable
private fun SmallBadge(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    color: Color
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(0.14f))
            .border(0.5.dp, color.copy(0.40f), RoundedCornerShape(8.dp))
            .padding(horizontal = 7.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = color.copy(0.90f), modifier = Modifier.size(10.dp))
        Spacer(Modifier.width(3.dp))
        Text(label, style = MaterialTheme.typography.labelSmall.copy(
            fontSize = 9.5.sp, color = color.copy(0.90f), fontWeight = FontWeight.Bold))
    }
}

// ── iOS Switch ────────────────────────────────────────────────────────────────
@Composable
fun IosSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        modifier = modifier,
        colors = SwitchDefaults.colors(
            checkedThumbColor   = Color.White,
            checkedTrackColor   = ToggleOn,
            uncheckedThumbColor = Color.White.copy(0.85f),
            uncheckedTrackColor = ToggleOff,
            uncheckedBorderColor = Color.Transparent,
            checkedBorderColor  = Color.Transparent
        )
    )
}

// ── Color operator extension ──────────────────────────────────────────────────
private operator fun Color.plus(other: Color): Color = Color(
    red   = (this.red   * 0.5f + other.red   * 0.5f).coerceIn(0f, 1f),
    green = (this.green * 0.5f + other.green * 0.5f).coerceIn(0f, 1f),
    blue  = (this.blue  * 0.5f + other.blue  * 0.5f).coerceIn(0f, 1f),
    alpha = this.alpha
)
