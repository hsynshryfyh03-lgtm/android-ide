package com.hussein.alarmpro.util

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.view.WindowManager
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Manages WakeLock to:
 * - Keep CPU/screen alive when alarm fires
 * - Prevent the phone from sleeping mid-alarm
 */
@Singleton
class WakeLockManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    private var wakeLock: PowerManager.WakeLock? = null

    fun acquire() {
        release()
        wakeLock = pm.newWakeLock(
            PowerManager.FULL_WAKE_LOCK or
            PowerManager.ACQUIRE_CAUSES_WAKEUP or
            PowerManager.ON_AFTER_RELEASE,
            "AlarmPro::AlarmWakeLock"
        ).apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 1000L) // max 10 minutes
        }
    }

    fun release() {
        runCatching {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        }
        wakeLock = null
    }

    val isHeld: Boolean get() = wakeLock?.isHeld == true
}

/**
 * Apply to RingingActivity window — prevents notification bar pull-down
 * and system UI while alarm is ringing.
 */
fun Activity.lockSystemUI() {
    window.addFlags(
        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON          or
        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD        or
        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED        or
        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON          or
        WindowManager.LayoutParams.FLAG_FULLSCREEN
    )
    // Immersive sticky — hides nav + status bar, prevents swipe-down
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        window.insetsController?.let { ctrl ->
            ctrl.hide(
                android.view.WindowInsets.Type.statusBars() or
                android.view.WindowInsets.Type.navigationBars()
            )
            ctrl.systemBarsBehavior =
                android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    } else {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN          or
            android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION     or
            android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY    or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE       or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN   or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )
    }
}

fun Activity.unlockSystemUI() {
    window.clearFlags(
        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON    or
        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD  or
        WindowManager.LayoutParams.FLAG_FULLSCREEN
    )
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        window.insetsController?.show(
            android.view.WindowInsets.Type.statusBars() or
            android.view.WindowInsets.Type.navigationBars()
        )
    }
}
