package com.kora

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowInsets
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.ServiceWorkerClient
import android.webkit.ServiceWorkerController
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {

    // المتغيرات
    private lateinit var myWebView: WebView
    private lateinit var splashScreen: RelativeLayout
    private var backPressedTime: Long = 0

    // لتتبع الأخطاء (منع ومضة صفحة الخطأ الرسمية)
    private var isErrorOccurred = false

    // إحداثيات اللمس (لقائمة معاينة الصورة)
    private var lastTouchX: Float = 0f
    private var lastTouchY: Float = 0f

    // مراقبة الشبكة
    private lateinit var connectivityManager: ConnectivityManager
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    // SharedPreferences لتتبع هل تم تحميل الـ PWA مرة واحدة بنجاح
    private lateinit var prefs: SharedPreferences
    private val PREFS_NAME = "kora_prefs"
    private val KEY_PWA_CACHED = "pwa_cached"

    // الإعدادات
    private val SECRET_URL = "https://clac-vert.vercel.app"
    private val APP_DOMAIN_KEYWORD = "clac-vert"
    private val APP_NAME_TITLE = "Kora"

    // HTML للأوفلاين
    private val OFFLINE_HTML = """
        <!DOCTYPE html>
        <html lang="ar" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
            <style>
                * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background-color: #f8f9fa;
                    color: #343a40;
                    height: 100vh;
                    margin: 0;
                    display: flex;
                    flex-direction: column;
                    justify-content: center;
                    align-items: center;
                    text-align: center;
                    padding: 20px;
                }
                .icon-container { font-size: 80px; margin-bottom: 20px; animation: float 3s ease-in-out infinite; }
                h2 { font-size: 20px; font-weight: bold; margin-bottom: 10px; }
                p { font-size: 14px; color: #6c757d; margin-bottom: 40px; max-width: 300px; }
                .btn-retry {
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white; border: none; padding: 15px 45px;
                    font-size: 16px; font-weight: bold; border-radius: 50px;
                    box-shadow: 0 10px 20px rgba(118, 75, 162, 0.3);
                    cursor: pointer; outline: none; animation: pulse 2s infinite;
                }
                @keyframes float { 0% { transform: translateY(0px); } 50% { transform: translateY(-15px); } 100% { transform: translateY(0px); } }
                @keyframes pulse { 0% { box-shadow: 0 0 0 0 rgba(118, 75, 162, 0.7); } 70% { box-shadow: 0 0 0 15px rgba(118, 75, 162, 0); } 100% { box-shadow: 0 0 0 0 rgba(118, 75, 162, 0); } }
            </style>
        </head>
        <body>
            <div class="icon-container">📡</div>
            <h2>عذراً، يجب الاتصال بالإنترنت<br>عند الدخول للتطبيق لأول مرة</h2>
            <p>يتم تحميل موارد التطبيق لضمان عمله بكفاءة لاحقاً دون الحاجة للإنترنت.</p>
            <button class="btn-retry" onclick="window.location.href='retry://reload'">إعادة المحاولة</button>
        </body>
        </html>
    """.trimIndent()

    private var mUploadMessageArray: ValueCallback<Array<Uri>>? = null
    private val FILE_CHOOSER_CODE = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        window.setBackgroundDrawable(null)
        enableImmersiveMode()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        )

        setContentView(R.layout.activity_main)

        myWebView = findViewById(R.id.webview)
        splashScreen = findViewById(R.id.splash_screen)

        // [تعديل 17] دعم الكيبورد: ضبط الـ root_view حسب WindowInsets (IME)
        val rootView = findViewById<View>(R.id.root_view)
        rootView.setOnApplyWindowInsetsListener { v, insets ->
            // نأخذ فقط إرتفاع الكيبورد (IME)
            val imeInsets = insets.getInsets(WindowInsets.Type.ime())
            val bottom = imeInsets.bottom
            // نضبط الـ padding السفلي بحيث يرتفع المحتوى فوق الكيبورد
            v.setPadding(v.paddingLeft, v.paddingTop, v.paddingRight, bottom)
            insets
        }
        rootView.requestApplyInsets()

        splashScreen.visibility = View.VISIBLE

        setupEngine()
        setupNetworkMonitoring()

        val hasNet = isNetworkAvailable()
        val pwaCached = prefs.getBoolean(KEY_PWA_CACHED, false)

        // أول مرة + بدون إنترنت → لا loadUrl إطلاقاً
        if (!hasNet && !pwaCached) {
            loadOfflinePage()
        } else {
            myWebView.loadUrl(SECRET_URL)
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enableImmersiveMode()
    }

    override fun onDestroy() {
        networkCallback?.let {
            try { connectivityManager.unregisterNetworkCallback(it) } catch (_: Exception) {}
        }
        myWebView.stopLoading()
        myWebView.clearHistory()
        myWebView.removeAllViews()
        myWebView.destroy()
        super.onDestroy()
    }

    // مراقبة الشبكة
    private fun setupNetworkMonitoring() {
        connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runOnUiThread { myWebView.settings.cacheMode = WebSettings.LOAD_DEFAULT }
            }
            override fun onLost(network: Network) {
                runOnUiThread { myWebView.settings.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK }
            }
        }
        connectivityManager.registerDefaultNetworkCallback(networkCallback!!)
    }

    @Suppress("DEPRECATION")
    private fun showCustomToast(message: String) {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(50, 30, 50, 30)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#CC000000"))
                cornerRadius = 50f
                setStroke(2, Color.parseColor("#555555"))
            }
        }
        val textView = TextView(this).apply {
            text = message
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER
        }
        layout.addView(textView)
        val toast = Toast(applicationContext)
        toast.duration = Toast.LENGTH_SHORT
        toast.view = layout
        toast.show()
    }

    override fun onBackPressed() {
        if (myWebView.canGoBack()) {
            myWebView.goBack()
        } else {
            if (backPressedTime + 2000 > System.currentTimeMillis()) {
                super.onBackPressed()
                return
            } else {
                showCustomToast("اضغط مرة أخرى للخروج")
            }
            backPressedTime = System.currentTimeMillis()
        }
    }

    private fun enableImmersiveMode() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
            )
    }

    private fun setupEngine() {
        val settings = myWebView.settings

        // أولوية عالية للـ renderer (مدعوم من WebView على API 26+ ونحن minSdk 31)
        myWebView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true)

        // تعطيل الـ Scrollbars من جهة الأندرويد
        myWebView.isVerticalScrollBarEnabled = false
        myWebView.isHorizontalScrollBarEnabled = false

        // رسم أجزاء الصفحة مسبقاً لتحسين التمرير
        settings.setOffscreenPreRaster(true)

        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.setSupportZoom(false)
        settings.userAgentString = settings.userAgentString.replace("; wv", "")
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        if (isNetworkAvailable()) {
            settings.cacheMode = WebSettings.LOAD_DEFAULT
        } else {
            settings.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            ServiceWorkerController.getInstance().setServiceWorkerClient(object : ServiceWorkerClient() {
                override fun shouldInterceptRequest(request: WebResourceRequest): WebResourceResponse? {
                    return super.shouldInterceptRequest(request)
                }
            })
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(myWebView, true)

        myWebView.addJavascriptInterface(WebAppInterface(this), "AndroidBridge")

        setupWebChromeClient()
        setupWebViewClient()

        myWebView.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            if (url.startsWith("blob:")) {
                fetchBlobData(url, mimetype, false)
            } else {
                downloadDirectLink(url, userAgent, contentDisposition, mimetype)
            }
        }

        setupLongPressFeatures()
    }

    private fun setupWebChromeClient() {
        myWebView.webChromeClient = object : WebChromeClient() {

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress > 80 && !isErrorOccurred && myWebView.url?.startsWith("http") == true) {
                    splashScreen.visibility = View.GONE
                }
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                AlertDialog.Builder(view?.context).setTitle(APP_NAME_TITLE).setMessage(message)
                    .setPositiveButton("موافق") { _, _ -> result?.confirm() }.setCancelable(false).show()
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                AlertDialog.Builder(view?.context).setTitle(APP_NAME_TITLE).setMessage(message)
                    .setPositiveButton("موافق") { _, _ -> result?.confirm() }
                    .setNegativeButton("إلغاء") { _, _ -> result?.cancel() }.setCancelable(false).show()
                return true
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                mUploadMessageArray?.onReceiveValue(null)
                mUploadMessageArray = filePathCallback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                try {
                    startActivityForResult(Intent.createChooser(intent, "اختر ملف"), FILE_CHOOSER_CODE)
                } catch (e: Exception) {
                    mUploadMessageArray = null
                    return false
                }
                return true
            }
        }
    }

    private fun setupWebViewClient() {
        myWebView.webViewClient = object : WebViewClient() {

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                isErrorOccurred = false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (url != null) {
                    if (url.contains(APP_DOMAIN_KEYWORD)) {
                        prefs.edit().putBoolean(KEY_PWA_CACHED, true).apply()
                    }
                    splashScreen.visibility = View.GONE
                }
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) {
                    isErrorOccurred = true
                    view?.stopLoading()
                    loadOfflinePage()
                }
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean = handleUrl(request?.url.toString())

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean =
                handleUrl(url)
        }
    }

    private fun fetchBlobData(blobUrl: String, mimeType: String, isPreview: Boolean) {
        val jsCode = """
            (function() {
                var xhr = new XMLHttpRequest();
                xhr.open('GET', '$blobUrl', true);
                xhr.responseType = 'blob';
                xhr.onload = function(e) {
                    if (this.status == 200) {
                        var blob = this.response;
                        var reader = new FileReader();
                        reader.readAsDataURL(blob);
                        reader.onloadend = function() {
                            var base64 = reader.result;
                            if ($isPreview) {
                                AndroidBridge.showImagePreview(base64);
                            } else {
                                AndroidBridge.saveBlob(base64, '$mimeType');
                            }
                        }
                    }
                };
                xhr.send();
            })();
        """.trimIndent()
        myWebView.evaluateJavascript(jsCode, null)
    }

    inner class WebAppInterface(private val context: Context) {

        @JavascriptInterface
        fun saveBlob(base64Data: String, mimeType: String) {
            saveBase64ToDownloads(base64Data, mimeType, "Kora_Export")
        }

        @JavascriptInterface
        fun showImagePreview(base64Data: String) {
            runOnUiThread { showAdvancedPreview(base64Data) }
        }
    }

    private fun setupLongPressFeatures() {
        myWebView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN) {
                lastTouchX = event.rawX
                lastTouchY = event.rawY
            }
            false
        }
        myWebView.setOnLongClickListener { v ->
            val result = (v as WebView).hitTestResult
            if (result.type == WebView.HitTestResult.IMAGE_TYPE ||
                result.type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE
            ) {
                val imageUrl = result.extra
                if (imageUrl != null) {
                    fetchBlobData(imageUrl, "image/png", true)
                }
                return@setOnLongClickListener true
            }
            true
        }
    }

    private fun showAdvancedPreview(base64Data: String) {
        val dialog = Dialog(this, android.R.style.Theme_Translucent_NoTitleBar)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            dialog.window?.attributes?.blurBehindRadius = 60
            dialog.window?.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
        }
        dialog.window?.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)

        val container = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { dialog.dismiss() }
        }

        val previewWebView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            setBackgroundColor(Color.TRANSPARENT)
            scaleX = 0.7f; scaleY = 0.7f; alpha = 0f
            animate().scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration(300)
                .setInterpolator(OvershootInterpolator())
                .start()
        }

        val html =
            "<html><body style='margin:0;padding:0;background:transparent;display:flex;justify-content:center;align-items:center;height:100vh;'><img src='$base64Data' style='max-width:100%;max-height:100%;object-fit:contain;box-shadow:0 20px 50px rgba(0,0,0,0.5);border-radius:10px;' /></body></html>"
        previewWebView.loadData(html, "text/html", "UTF-8")

        val menuLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F0111111"))
                cornerRadius = 100f
                setStroke(2, Color.parseColor("#333333"))
            }
            setPadding(15, 10, 15, 10)
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            elevation = 30f
            visibility = View.GONE
        }

        val btnDownload = TextView(this).apply {
            text = "⬇️ تنزيل"
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(30, 15, 30, 15)
            gravity = Gravity.CENTER
            setOnClickListener {
                saveBase64ToDownloads(base64Data, "image/png", "Kora_Img")
                dialog.dismiss()
            }
        }

        menuLayout.addView(btnDownload)
        container.addView(previewWebView)
        container.addView(menuLayout)

        val hideHandler = Handler(Looper.getMainLooper())
        val hideRunnable = Runnable {
            menuLayout.animate().alpha(0f).setDuration(300)
                .withEndAction { menuLayout.visibility = View.GONE }
                .start()
        }

        var startClickTime: Long = 0
        var startX: Float = 0f
        var startY: Float = 0f

        previewWebView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    lastTouchX = event.rawX
                    lastTouchY = event.rawY
                    startX = event.rawX
                    startY = event.rawY
                    startClickTime = System.currentTimeMillis()
                }
                MotionEvent.ACTION_MOVE -> {
                    if (menuLayout.visibility == View.VISIBLE) {
                        val screenWidth = resources.displayMetrics.widthPixels
                        val menuWidth = if (menuLayout.width > 0) menuLayout.width else 300
                        var posX = event.rawX - (menuWidth / 2)
                        var posY = event.rawY - 180
                        if (posX < 20) posX = 20f
                        if (posX + menuWidth > screenWidth)
                            posX = (screenWidth - menuWidth - 20).toFloat()
                        menuLayout.x = posX
                        menuLayout.y = posY
                        hideHandler.removeCallbacks(hideRunnable)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (menuLayout.visibility == View.VISIBLE) {
                        hideHandler.postDelayed(hideRunnable, 3000)
                    } else {
                        val clickDuration = System.currentTimeMillis() - startClickTime
                        val dx = abs(event.rawX - startX)
                        val dy = abs(event.rawY - startY)
                        if (clickDuration < 200 && dx < 10 && dy < 10) {
                            dialog.dismiss()
                        }
                    }
                }
            }
            false
        }

        previewWebView.setOnLongClickListener {
            menuLayout.visibility = View.VISIBLE
            menuLayout.alpha = 0f
            val screenWidth = resources.displayMetrics.widthPixels
            val menuWidth = 300
            var posX = lastTouchX - (menuWidth / 2)
            if (posX < 20) posX = 20f
            if (posX + menuWidth > screenWidth)
                posX = (screenWidth - menuWidth - 20).toFloat()
            menuLayout.x = posX
            menuLayout.y = lastTouchY - 180
            menuLayout.animate().alpha(1f).setDuration(200).start()
            hideHandler.removeCallbacks(hideRunnable)
            true
        }

        dialog.setContentView(container)
        dialog.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT
        )
        dialog.show()
    }

    private fun saveBase64ToDownloads(base64Data: String, mimeType: String, prefix: String) {
        try {
            val cleanBase64 = if (base64Data.contains(",")) base64Data.split(",")[1] else base64Data
            val decodedBytes = Base64.decode(cleanBase64, Base64.DEFAULT)
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val ext = when {
                mimeType.contains("json") -> "json"
                mimeType.contains("png") -> "png"
                mimeType.contains("jpeg") -> "jpg"
                mimeType.contains("pdf") -> "pdf"
                mimeType.contains("csv") -> "csv"
                mimeType.contains("text") -> "txt"
                else -> "txt"
            }
            val fileName = "${prefix}_$timestamp.$ext"
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val resolver = contentResolver
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
            if (uri != null) {
                val outputStream: OutputStream? = resolver.openOutputStream(uri)
                outputStream?.write(decodedBytes)
                outputStream?.close()
                showCustomToast("تم الحفظ: $fileName")
            } else {
                showCustomToast("فشل الحفظ")
            }
        } catch (e: Exception) {
            showCustomToast("حدث خطأ أثناء الحفظ")
        }
    }

    private fun downloadDirectLink(url: String, userAgent: String, contentDisposition: String, mimetype: String) {
        try {
            val request = DownloadManager.Request(Uri.parse(url))
            request.setMimeType(mimetype)
            request.addRequestHeader("cookie", CookieManager.getInstance().getCookie(url))
            request.addRequestHeader("User-Agent", userAgent)
            request.setDescription("جاري الحفظ...")
            request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype))
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            request.setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS,
                URLUtil.guessFileName(url, contentDisposition, mimetype)
            )
            val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(request)
            showCustomToast("بدأ التنزيل...")
        } catch (e: Exception) {
            showCustomToast("خطأ في التنزيل")
        }
    }

    private fun handleUrl(url: String?): Boolean {
        if (url == null) return false

        if (url == "retry://reload") {
            val pwaCached = prefs.getBoolean(KEY_PWA_CACHED, false)
            val hasNet = isNetworkAvailable()

            when {
                hasNet -> {
                    splashScreen.visibility = View.VISIBLE
                    myWebView.settings.cacheMode = WebSettings.LOAD_DEFAULT
                    myWebView.loadUrl(SECRET_URL)
                }
                pwaCached -> {
                    myWebView.settings.cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK
                    myWebView.loadUrl(SECRET_URL)
                }
                else -> {
                    try {
                        startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                    } catch (_: Exception) {}
                    showCustomToast("شغّل الواي فاي ثم اضغط إعادة المحاولة مرة أخرى")
                }
            }
            return true
        }

        if (url.contains(APP_DOMAIN_KEYWORD)) return false
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {}
        return true
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val nw = cm.activeNetwork ?: return false
        val actNw = cm.getNetworkCapabilities(nw) ?: return false
        return actNw.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
    }

    private fun loadOfflinePage() {
        splashScreen.visibility = View.GONE
        myWebView.loadDataWithBaseURL(null, OFFLINE_HTML, "text/html", "UTF-8", null)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == FILE_CHOOSER_CODE) {
            val result = if (data == null || resultCode != Activity.RESULT_OK) null else data.data
            mUploadMessageArray?.onReceiveValue(if (result != null) arrayOf(result) else null)
            mUploadMessageArray = null
        } else super.onActivityResult(requestCode, resultCode, data)
    }
}