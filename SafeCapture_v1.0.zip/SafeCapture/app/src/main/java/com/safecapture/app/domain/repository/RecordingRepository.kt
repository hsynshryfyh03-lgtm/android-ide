package com.safecapture.app.domain.repository

import com.safecapture.app.domain.model.AppSettings
import com.safecapture.app.domain.model.Recording
import kotlinx.coroutines.flow.Flow

interface RecordingRepository {
    fun getAllRecordings(): Flow<List<Recording>>
    suspend fun getRecordingById(id: Long): Recording?
    suspend fun saveRecording(recording: Recording): Long
    suspend fun deleteRecording(id: Long)
    suspend fun deleteAllRecordings()
    suspend fun toggleProtection(id: Long, protect: Boolean)
    fun getTotalStats(): Flow<RecordingStats>
}

data class RecordingStats(
    val totalCount: Int    = 0,
    val totalDurationMs: Long = 0L,
    val totalSizeBytes: Long  = 0L
)
