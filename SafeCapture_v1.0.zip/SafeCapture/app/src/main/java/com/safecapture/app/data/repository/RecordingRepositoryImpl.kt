package com.safecapture.app.data.repository

import com.safecapture.app.data.local.db.RecordingDao
import com.safecapture.app.data.local.db.toDomain
import com.safecapture.app.data.local.db.toEntity
import com.safecapture.app.domain.model.Recording
import com.safecapture.app.domain.repository.RecordingRepository
import com.safecapture.app.domain.repository.RecordingStats
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RecordingRepositoryImpl @Inject constructor(
    private val dao: RecordingDao
) : RecordingRepository {

    override fun getAllRecordings(): Flow<List<Recording>> =
        dao.getAllRecordings().map { list -> list.map { it.toDomain() } }

    override suspend fun getRecordingById(id: Long): Recording? =
        dao.getById(id)?.toDomain()

    override suspend fun saveRecording(recording: Recording): Long =
        dao.insert(recording.toEntity())

    override suspend fun deleteRecording(id: Long) =
        dao.deleteById(id)

    override suspend fun deleteAllRecordings() =
        dao.deleteAll()

    override suspend fun toggleProtection(id: Long, protect: Boolean) =
        dao.updateProtection(id, protect)

    override fun getTotalStats(): Flow<RecordingStats> =
        dao.getStats().map { s ->
            RecordingStats(
                totalCount      = s.totalCount,
                totalDurationMs = s.totalDurationMs,
                totalSizeBytes  = s.totalSizeBytes
            )
        }
}
