package com.safecapture.app.presentation.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.safecapture.app.data.local.datastore.SettingsDataStore
import com.safecapture.app.domain.model.AppSettings
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val settings         : AppSettings = AppSettings(),
    val darkMode         : Boolean     = false,
    val stealthMode      : Boolean     = false,
    val pinEnabled       : Boolean     = false,
    val telegramExpanded : Boolean     = false,
    val tokenInput       : String      = "",
    val chatIdInput      : String      = "",
    val tokenSaved       : Boolean     = false,
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val dataStore: SettingsDataStore
) : ViewModel() {

    private val _telegramExpanded = MutableStateFlow(false)
    private val _tokenInput       = MutableStateFlow("")
    private val _chatIdInput      = MutableStateFlow("")
    private val _tokenSaved       = MutableStateFlow(false)

    val uiState: StateFlow<SettingsUiState> = combine(
        dataStore.settingsFlow,
        dataStore.darkModeFlow,
        dataStore.stealthModeFlow,
        dataStore.pinEnabledFlow,
        combine(_telegramExpanded, _tokenInput, _chatIdInput, _tokenSaved) {
            exp, tok, chat, saved -> listOf<Any>(exp, tok, chat, saved)
        },
    ) { settings, dark, stealth, pin, tgList ->
        SettingsUiState(
            settings         = settings,
            darkMode         = dark,
            stealthMode      = stealth,
            pinEnabled       = pin,
            telegramExpanded = tgList[0] as Boolean,
            tokenInput       = (tgList[1] as String).ifEmpty { settings.telegramBotToken },
            chatIdInput      = (tgList[2] as String).ifEmpty { settings.telegramChatId },
            tokenSaved       = tgList[3] as Boolean,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsUiState())

    fun setDoublePressDelay(ms: Int)          = viewModelScope.launch { dataStore.updateDoublePressDelay(ms) }
    fun setVibration(enabled: Boolean)        = viewModelScope.launch { dataStore.updateVibration(enabled) }
    fun setVideoQuality(q: String)            = viewModelScope.launch { dataStore.updateVideoQuality(q) }
    fun setCameraFacing(f: String)            = viewModelScope.launch { dataStore.updateCameraFacing(f) }
    fun setMaxDuration(m: Int)                = viewModelScope.launch { dataStore.updateMaxDuration(m) }
    fun setAutoDelete(days: Int)              = viewModelScope.launch { dataStore.updateAutoDeleteDays(days) }
    fun setAudioEnabled(enabled: Boolean)     = viewModelScope.launch { dataStore.updateAudioEnabled(enabled) }
    fun setDarkMode(enabled: Boolean)         = viewModelScope.launch { dataStore.updateDarkMode(enabled) }
    fun setStealthMode(enabled: Boolean)      = viewModelScope.launch { dataStore.updateStealthMode(enabled) }
    fun setTimestampOverlay(enabled: Boolean) = viewModelScope.launch { dataStore.updateTimestampOverlay(enabled) }
    fun setDisguiseMode(enabled: Boolean)     = viewModelScope.launch { dataStore.updateDisguiseMode(enabled) }

    fun setTelegramExpanded(v: Boolean)  { _telegramExpanded.value = v }
    fun onTokenInput(v: String)          { _tokenInput.value = v; _tokenSaved.value = false }
    fun onChatIdInput(v: String)         { _chatIdInput.value = v; _tokenSaved.value = false }

    fun saveTelegramConfig() = viewModelScope.launch {
        dataStore.updateTelegramToken(_tokenInput.value.trim())
        dataStore.updateTelegramChatId(_chatIdInput.value.trim())
        _tokenSaved.value = true
    }

    fun setTelegramAutoUpload(enabled: Boolean) =
        viewModelScope.launch { dataStore.updateTelegramAutoUpload(enabled) }
}
