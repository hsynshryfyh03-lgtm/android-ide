package com.husseindev.sentinelprotocol.di

import android.content.Context
import com.husseindev.sentinelprotocol.data.local.datastore.SettingsDataStore
import com.husseindev.sentinelprotocol.data.local.db.SentinelDatabase
import com.husseindev.sentinelprotocol.data.local.db.dao.IntruderDao
import com.husseindev.sentinelprotocol.data.local.db.dao.RecordingDao
import com.husseindev.sentinelprotocol.data.repository.RecordingRepositoryImpl
import com.husseindev.sentinelprotocol.data.repository.SettingsRepositoryImpl
import com.husseindev.sentinelprotocol.domain.repository.RecordingRepository
import com.husseindev.sentinelprotocol.domain.repository.SettingsRepository
import com.husseindev.sentinelprotocol.domain.usecase.*
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Hilt DI Modules
//  برمجة حسين حميد
// ══════════════════════════════════════════

// ── Database Module ───────────────────────
@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): SentinelDatabase =
        SentinelDatabase.build(ctx)

    @Provides @Singleton
    fun provideRecordingDao(db: SentinelDatabase): RecordingDao = db.recordingDao()

    @Provides @Singleton
    fun provideIntruderDao(db: SentinelDatabase): IntruderDao = db.intruderDao()

    @Provides @Singleton
    fun provideSettingsDataStore(@ApplicationContext ctx: Context) = SettingsDataStore(ctx)
}

// ── Repository Module ─────────────────────
@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds @Singleton
    abstract fun bindRecordingRepository(impl: RecordingRepositoryImpl): RecordingRepository

    @Binds @Singleton
    abstract fun bindSettingsRepository(impl: SettingsRepositoryImpl): SettingsRepository
}

// ── UseCase Module ────────────────────────
@Module
@InstallIn(SingletonComponent::class)
object UseCaseModule {

    @Provides fun provideValidatePin(repo: SettingsRepository)          = ValidatePinUseCase(repo)
    @Provides fun provideValidatePanic(repo: SettingsRepository)        = ValidatePanicCodeUseCase(repo)
    @Provides fun provideDeleteAll(r: RecordingRepository, s: SettingsRepository) = DeleteAllDataUseCase(r, s)
    @Provides fun provideStartMonitoring(repo: SettingsRepository)      = StartMonitoringUseCase(repo)
    @Provides fun provideStopMonitoring(repo: SettingsRepository)       = StopMonitoringUseCase(repo)
    @Provides fun provideSaveRecording(repo: RecordingRepository)       = SaveRecordingUseCase(repo)
    @Provides fun provideGetRecordings(repo: RecordingRepository)       = GetAllRecordingsUseCase(repo)
    @Provides fun provideSaveIntruder(repo: RecordingRepository)        = SaveIntruderPhotoUseCase(repo)
    @Provides fun provideGetIntruder(repo: RecordingRepository)         = GetIntruderPhotosUseCase(repo)
    @Provides fun provideDeleteRecording(repo: RecordingRepository)     = DeleteRecordingUseCase(repo)
}
