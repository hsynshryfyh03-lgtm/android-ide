package com.husseindev.sentinelprotocol.presentation.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Typography
//  System font — Tajawal via Google Fonts at runtime
//  برمجة حسين حميد
// ══════════════════════════════════════════

// استخدام Default font للبناء — يمكن استبداله بـ Tajawal لاحقاً
val TajawalFamily = FontFamily.Default

val SentinelTypography = Typography(
    displayLarge  = TextStyle(fontFamily = TajawalFamily, fontWeight = FontWeight.ExtraBold, fontSize = 57.sp, color = TextPrimary),
    displayMedium = TextStyle(fontFamily = TajawalFamily, fontWeight = FontWeight.Bold,      fontSize = 45.sp, color = TextPrimary),
    headlineLarge = TextStyle(fontFamily = TajawalFamily, fontWeight = FontWeight.Bold,      fontSize = 32.sp, color = TextPrimary),
    headlineMedium= TextStyle(fontFamily = TajawalFamily, fontWeight = FontWeight.Bold,      fontSize = 28.sp, color = TextPrimary),
    headlineSmall = TextStyle(fontFamily = TajawalFamily, fontWeight = FontWeight.Bold,      fontSize = 24.sp, color = TextPrimary),
    titleLarge    = TextStyle(fontFamily = TajawalFamily, fontWeight = FontWeight.Bold,      fontSize = 22.sp, color = TextPrimary),
    titleMedium   = TextStyle(fontFamily = TajawalFamily, fontWeight = FontWeight.Medium,    fontSize = 16.sp, color = TextPrimary),
    bodyLarge     = TextStyle(fontFamily = TajawalFamily, fontWeight = FontWeight.Normal,    fontSize = 16.sp, color = TextSecondary),
    bodyMedium    = TextStyle(fontFamily = TajawalFamily, fontWeight = FontWeight.Normal,    fontSize = 14.sp, color = TextSecondary),
    labelLarge    = TextStyle(fontFamily = TajawalFamily, fontWeight = FontWeight.Bold,      fontSize = 14.sp, color = TealLight),
    labelMedium   = TextStyle(fontFamily = TajawalFamily, fontWeight = FontWeight.Medium,    fontSize = 12.sp, color = TextDim),
)
