package com.husseindev.sentinelprotocol.domain.usecase

import com.husseindev.sentinelprotocol.core.constants.AppConstants
import com.husseindev.sentinelprotocol.domain.model.IntruderPhoto
import com.husseindev.sentinelprotocol.domain.model.RecordingEvent
import com.husseindev.sentinelprotocol.domain.repository.RecordingRepository
import com.husseindev.sentinelprotocol.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import javax.inject.Inject

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Use Cases
//  برمجة حسين حميد
// ══════════════════════════════════════════

// ── PIN Validation ────────────────────────
class ValidatePinUseCase @Inject constructor(
    private val settingsRepo: SettingsRepository
) {
    suspend operator fun invoke(inputPin: String): Boolean {
        val config = settingsRepo.getConfig().first()
        return inputPin == config.pin
    }
}

// ── Panic Code Validation ─────────────────
class ValidatePanicCodeUseCase @Inject constructor(
    private val settingsRepo: SettingsRepository
) {
    suspend operator fun invoke(inputCode: String): Boolean {
        val config = settingsRepo.getConfig().first()
        return inputCode == config.panicCode
    }
}

// ── Delete All Data (Panic Wipe) ──────────
class DeleteAllDataUseCase @Inject constructor(
    private val recordingRepo: RecordingRepository,
    private val settingsRepo : SettingsRepository
) {
    suspend operator fun invoke() {
        recordingRepo.deleteAllRecordings()
        recordingRepo.deleteAllIntruderPhotos()
        settingsRepo.setMonitoringActive(false)
        // Physical file deletion handled by ViewModel
    }
}

// ── Start Monitoring ──────────────────────
class StartMonitoringUseCase @Inject constructor(
    private val settingsRepo: SettingsRepository
) {
    suspend operator fun invoke() = settingsRepo.setMonitoringActive(true)
}

// ── Stop Monitoring ───────────────────────
class StopMonitoringUseCase @Inject constructor(
    private val settingsRepo: SettingsRepository
) {
    suspend operator fun invoke() = settingsRepo.setMonitoringActive(false)
}

// ── Save Recording ────────────────────────
class SaveRecordingUseCase @Inject constructor(
    private val recordingRepo: RecordingRepository
) {
    suspend operator fun invoke(event: RecordingEvent): Long =
        recordingRepo.insertRecording(event)
}

// ── Get All Recordings ────────────────────
class GetAllRecordingsUseCase @Inject constructor(
    private val recordingRepo: RecordingRepository
) {
    operator fun invoke(): Flow<List<RecordingEvent>> =
        recordingRepo.getAllRecordings()
}

// ── Save Intruder Photo ───────────────────
class SaveIntruderPhotoUseCase @Inject constructor(
    private val recordingRepo: RecordingRepository
) {
    suspend operator fun invoke(photo: IntruderPhoto): Long =
        recordingRepo.insertIntruderPhoto(photo)
}

// ── Get Intruder Photos ───────────────────
class GetIntruderPhotosUseCase @Inject constructor(
    private val recordingRepo: RecordingRepository
) {
    operator fun invoke(): Flow<List<IntruderPhoto>> =
        recordingRepo.getAllIntruderPhotos()
}

// ── Delete Single Recording ───────────────
class DeleteRecordingUseCase @Inject constructor(
    private val recordingRepo: RecordingRepository
) {
    suspend operator fun invoke(id: Long) = recordingRepo.deleteRecording(id)
}
