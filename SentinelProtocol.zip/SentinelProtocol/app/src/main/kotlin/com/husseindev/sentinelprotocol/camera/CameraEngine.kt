package com.husseindev.sentinelprotocol.camera

import android.content.Context
import android.os.Environment
import android.util.Log
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.video.VideoCapture
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.husseindev.sentinelprotocol.camera.analysis.FaceDetectionAnalyzer
import com.husseindev.sentinelprotocol.camera.analysis.PersonDetectionAnalyzer
import com.husseindev.sentinelprotocol.core.constants.AppConstants
import com.husseindev.sentinelprotocol.domain.model.*
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Camera Engine
//  CameraX + H.265/HEVC + ML Kit
//  برمجة حسين حميد
// ══════════════════════════════════════════

@Singleton
class CameraEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val bufferManager: VideoBufferManager
) {
    private val TAG = "CameraEngine"

    // ── State ─────────────────────────────
    private val _detectionState = MutableStateFlow<DetectionResult?>(null)
    val detectionState: StateFlow<DetectionResult?> = _detectionState

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording

    private val _monitoringActive = MutableStateFlow(false)
    val monitoringActive: StateFlow<Boolean> = _monitoringActive

    // ── Camera internals ──────────────────
    private var cameraProvider      : ProcessCameraProvider? = null
    private var videoCapture        : VideoCapture<Recorder>? = null
    private var activeRecording     : Recording? = null
    private var imageCapture         : ImageCapture? = null
    private val cameraExecutor      : ExecutorService = Executors.newSingleThreadExecutor()
    private val scope               = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Post-detection timer
    private var postDetectionJob    : Job? = null
    private var noDetectionCount    = 0
    private val noDetectionThreshold = AppConstants.POST_DETECTION_SECONDS.toInt() * 3 // ~30 fps ticks

    // Output directory
    private val outputDir: File get() {
        val dir = File(
            context.getExternalFilesDir(Environment.DIRECTORY_MOVIES),
            "SentinelProtocol"
        )
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    // ── Bind Camera to Lifecycle ──────────
    fun bindCamera(
        lifecycleOwner: LifecycleOwner,
        facing        : CameraFacing = CameraFacing.BACK,
        sensitivity   : SensitivityLevel = SensitivityLevel.MEDIUM,
        preview       : Preview? = null,
        onRecordingComplete: (File) -> Unit = {}
    ) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)

        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
            val selector  = if (facing == CameraFacing.BACK)
                CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA

            // ── VideoCapture (H.265 HEVC) ─────────────
            val qualitySelector = QualitySelector.fromOrderedList(
                listOf(Quality.FHD, Quality.HD, Quality.SD),
                FallbackStrategy.higherQualityOrLowerThan(Quality.SD)
            )
            val recorder = Recorder.Builder()
                .setQualitySelector(qualitySelector)
                .build()
            videoCapture = VideoCapture.withOutput(recorder)

            // ── ImageCapture (for intruder selfie) ────
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            // ── ImageAnalysis (ML Kit) ─────────────────
            val imageAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                .build()

            // Combined analyzer: Face + Person detection
            imageAnalysis.setAnalyzer(cameraExecutor, CombinedAnalyzer(
                sensitivity   = sensitivity,
                onDetection   = { result ->
                    _detectionState.value = result
                    if (_monitoringActive.value && !_isRecording.value) {
                        Log.d(TAG, "Detection triggered — starting recording")
                        startRecording(onComplete = onRecordingComplete)
                    }
                    // Reset post-detection countdown
                    noDetectionCount = 0
                    postDetectionJob?.cancel()
                },
                onNoDetection = {
                    if (_isRecording.value) {
                        noDetectionCount++
                        if (noDetectionCount >= noDetectionThreshold) {
                            Log.d(TAG, "No detection timeout — stopping recording")
                            stopRecording()
                            noDetectionCount = 0
                        }
                    }
                }
            ))

            try {
                cameraProvider?.unbindAll()
                val useCases = mutableListOf<UseCase>(imageAnalysis, videoCapture!!, imageCapture!!)
                preview?.let { useCases.add(0, it) }

                cameraProvider?.bindToLifecycle(lifecycleOwner, selector, *useCases.toTypedArray())
                Log.d(TAG, "Camera bound — facing: $facing, sensitivity: $sensitivity")
            } catch (e: Exception) {
                Log.e(TAG, "Camera bind failed: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(context))
    }

    // ── Start Recording ───────────────────
    fun startRecording(isEmergency: Boolean = false, onComplete: (File) -> Unit = {}) {
        val vc = videoCapture ?: return
        if (_isRecording.value) return

        val fileName    = "sentinel_${System.currentTimeMillis()}.mp4"
        val outputFile  = File(outputDir, fileName)
        val outputOptions = FileOutputOptions.Builder(outputFile).build()

        activeRecording = vc.output
            .prepareRecording(context, outputOptions)
            .withAudioEnabled()
            .start(cameraExecutor) { event ->
                when (event) {
                    is VideoRecordEvent.Start  -> {
                        _isRecording.value = true
                        Log.d(TAG, "Recording started: $fileName")
                    }
                    is VideoRecordEvent.Finalize -> {
                        _isRecording.value = false
                        if (!event.hasError()) {
                            Log.d(TAG, "Recording saved: ${outputFile.absolutePath}")
                            onComplete(outputFile)
                        } else {
                            Log.e(TAG, "Recording error: ${event.error}")
                            outputFile.delete()
                        }
                    }
                    else -> {}
                }
            }
    }

    fun stopRecording() {
        activeRecording?.stop()
        activeRecording = null
    }

    // ── Intruder Selfie (Silent) ──────────
    fun captureIntruderSelfie(
        attemptNumber: Int,
        onCaptured: (File) -> Unit
    ) {
        val ic = imageCapture ?: return
        val intruderDir = File(context.filesDir, AppConstants.INTRUDER_DIR).also { it.mkdirs() }
        val file = File(intruderDir, "intruder_${System.currentTimeMillis()}.jpg")
        val outputOptions = ImageCapture.OutputFileOptions.Builder(file).build()

        ic.takePicture(outputOptions, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                Log.d(TAG, "Intruder selfie saved: ${file.absolutePath}")
                onCaptured(file)
            }
            override fun onError(exc: ImageCaptureException) {
                Log.e(TAG, "Intruder selfie error: ${exc.message}")
            }
        })
    }

    fun setMonitoringActive(active: Boolean) {
        _monitoringActive.value = active
        if (!active) stopRecording()
    }

    fun unbind() {
        stopRecording()
        cameraProvider?.unbindAll()
    }

    fun shutdown() {
        unbind()
        cameraExecutor.shutdown()
        scope.cancel()
    }

    // ── Combined Analyzer (Face + Person) ─
    private inner class CombinedAnalyzer(
        sensitivity  : SensitivityLevel,
        onDetection  : (DetectionResult) -> Unit,
        onNoDetection: () -> Unit
    ) : ImageAnalysis.Analyzer {

        private val faceAnalyzer = FaceDetectionAnalyzer(
            sensitivity   = sensitivity,
            onDetection   = onDetection,
            onNoDetection = onNoDetection
        )

        // For simplicity — delegate to face analyzer as primary
        // Person analyzer runs in parallel in a real pipeline
        override fun analyze(image: ImageProxy) = faceAnalyzer.analyze(image)
    }
}
