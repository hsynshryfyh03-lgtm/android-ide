package com.husseindev.sentinelprotocol.presentation.screen.monitoring

import androidx.camera.core.Preview
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.husseindev.sentinelprotocol.camera.CameraEngine
import com.husseindev.sentinelprotocol.domain.model.*
import com.husseindev.sentinelprotocol.domain.usecase.SaveRecordingUseCase
import com.husseindev.sentinelprotocol.presentation.components.CctvWatermarkOverlay
import com.husseindev.sentinelprotocol.presentation.components.RecordingIndicator
import com.husseindev.sentinelprotocol.presentation.theme.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Monitoring Screen
//  Live CameraX Preview + ML Overlay
//  برمجة حسين حميد
// ══════════════════════════════════════════

@HiltViewModel
class MonitoringViewModel @Inject constructor(
    private val cameraEngine  : CameraEngine,
    private val saveRecording : SaveRecordingUseCase,
    private val settingsRepo  : com.husseindev.sentinelprotocol.domain.repository.SettingsRepository
) : ViewModel() {

    val detectionState = cameraEngine.detectionState
    val isRecording    = cameraEngine.isRecording

    fun startManualRecord() {
        cameraEngine.startRecording(onComplete = { file -> onRecordingDone(file) })
    }

    fun stopManualRecord() = cameraEngine.stopRecording()

    private fun onRecordingDone(file: File) {
        viewModelScope.launch {
            saveRecording(RecordingEvent(
                filePath      = file.absolutePath,
                triggerType   = TriggerType.MANUAL,
                fileSizeBytes = file.length()
            ))
        }
    }
}

@Composable
fun MonitoringScreen(
    cameraEngine : CameraEngine,
    onBack       : () -> Unit,
    viewModel    : MonitoringViewModel = hiltViewModel()
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val detection      by viewModel.detectionState.collectAsStateWithLifecycle()
    val isRecording    by viewModel.isRecording.collectAsStateWithLifecycle()

    val preview = remember { Preview.Builder().build() }

    LaunchedEffect(Unit) {
        cameraEngine.bindCamera(
            lifecycleOwner = lifecycleOwner,
            preview        = preview,
            onRecordingComplete = {}
        )
    }

    Box(Modifier.fillMaxSize().background(DeepBlack)) {

        // ── Camera Preview ─────────────────
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory  = { ctx ->
                PreviewView(ctx).apply {
                    implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                    preview.setSurfaceProvider(surfaceProvider)
                }
            }
        )

        // ── Detection Boxes Overlay ─────────
        detection?.let { result ->
            if (result.hasDetection) {
                Box(Modifier.fillMaxSize()) {
                    result.faces.forEach { face ->
                        DetectionBox(
                            rect  = face.boundingBox,
                            label = "وجه",
                            color = TealPrimary
                        )
                    }
                    result.persons.forEach { person ->
                        DetectionBox(
                            rect  = person.boundingBox,
                            label = "شخص ${(person.confidence * 100).toInt()}%",
                            color = ActiveGreen
                        )
                    }
                }
            }
        }

        // ── CCTV Watermark ─────────────────
        CctvWatermarkOverlay(Modifier.align(Alignment.TopStart))

        // ── REC Indicator ──────────────────
        Row(
            Modifier.align(Alignment.TopEnd).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RecordingIndicator(isRecording)
        }

        // ── Bottom Controls ────────────────
        Row(
            modifier = Modifier.align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(DeepBlack.copy(alpha = 0.7f))
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = null, tint = TextPrimary)
            }

            // Record toggle button
            IconButton(
                onClick = { if (isRecording) viewModel.stopManualRecord() else viewModel.startManualRecord() },
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(if (isRecording) RecordingRed else TealPrimary)
                    .border(2.dp, Color.White.copy(0.3f), CircleShape)
            ) {
                Icon(
                    imageVector = if (isRecording) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }

            // Detection status badge
            Box(
                Modifier.size(48.dp).clip(CircleShape)
                    .background(if (detection?.hasDetection == true) TealGlow else Color.Transparent)
                    .border(1.dp, if (detection?.hasDetection == true) TealPrimary else TextDim, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "${(detection?.faces?.size ?: 0) + (detection?.persons?.size ?: 0)}",
                    color = if (detection?.hasDetection == true) TealLight else TextDim,
                    fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = TajawalFamily
                )
            }
        }
    }
}

@Composable
private fun DetectionBox(rect: android.graphics.RectF, label: String, color: Color) {
    // Normalized overlay — simplified for Compose
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(
                start = (rect.left / 10).dp, top = (rect.top / 10).dp,
                end   = (rect.right / 10).dp, bottom = (rect.bottom / 10).dp
            )
            .border(2.dp, color, RoundedCornerShape(4.dp))
    ) {
        Text(
            text = label, color = color, fontSize = 10.sp,
            fontFamily = TajawalFamily,
            modifier = Modifier.background(DeepBlack.copy(0.6f)).padding(2.dp)
        )
    }
}
