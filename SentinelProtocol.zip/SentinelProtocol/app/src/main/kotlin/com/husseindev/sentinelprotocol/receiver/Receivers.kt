package com.husseindev.sentinelprotocol.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.util.Log
import com.husseindev.sentinelprotocol.core.constants.AppConstants
import com.husseindev.sentinelprotocol.service.EmergencyRecordService
import com.husseindev.sentinelprotocol.service.SentinelForegroundService
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import javax.inject.Inject
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Broadcast Receivers
//  برمجة حسين حميد
// ══════════════════════════════════════════

// ── Boot Receiver — Auto-start after reboot ──
class BootReceiver : BroadcastReceiver() {
    private val TAG = "BootReceiver"

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return

        val isBootAction = action in listOf(
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.miui.intent.action.BOOT_COMPLETED"    // HyperOS / MIUI
        )

        if (!isBootAction) return

        Log.d(TAG, "Boot completed — checking auto-start preference")

        // We read preferences synchronously in the receiver using blocking coroutine
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        scope.launch {
            // Read auto-start setting from SharedPreferences (fast path, not DataStore)
            val prefs = context.getSharedPreferences("sentinel_boot_prefs", Context.MODE_PRIVATE)
            val autoStart       = prefs.getBoolean(AppConstants.DS_AUTO_START, false)
            val emergencyEnabled = prefs.getBoolean(AppConstants.DS_EMERGENCY_ENABLED, true)

            if (autoStart) {
                Log.d(TAG, "Auto-start enabled — starting Sentinel service")
                val serviceIntent = Intent(context, SentinelForegroundService::class.java).apply {
                    action = SentinelForegroundService.ACTION_START
                }
                context.startForegroundService(serviceIntent)
            }

            if (emergencyEnabled) {
                val emergencyIntent = Intent(context, EmergencyRecordService::class.java)
                context.startForegroundService(emergencyIntent)
            }
        }
    }
}

// ── Battery Receiver — Auto-stop at 15% ─────
class BatteryReceiver : BroadcastReceiver() {
    private val TAG = "BatteryReceiver"

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return

        if (action != Intent.ACTION_BATTERY_CHANGED && action != Intent.ACTION_BATTERY_LOW) return

        val level   = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale   = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val percent = if (level >= 0 && scale > 0) (level * 100) / scale else return

        Log.d(TAG, "Battery level: $percent%")

        if (percent <= AppConstants.BATTERY_STOP_THRESHOLD && SentinelForegroundService.isRunning) {
            Log.d(TAG, "Battery critical ($percent%) — stopping Sentinel service")
            val stopIntent = Intent(context, SentinelForegroundService::class.java).apply {
                action = SentinelForegroundService.ACTION_STOP
            }
            context.startService(stopIntent)
        }
    }
}
