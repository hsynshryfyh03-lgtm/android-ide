package com.husseindev.sentinelprotocol.presentation.screen.dashboard

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.husseindev.sentinelprotocol.domain.model.*
import com.husseindev.sentinelprotocol.domain.usecase.*
import com.husseindev.sentinelprotocol.service.SentinelForegroundService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Dashboard ViewModel
//  برمجة حسين حميد
// ══════════════════════════════════════════

data class DashboardUiState(
    val isMonitoring  : Boolean         = false,
    val config        : SentinelConfig  = SentinelConfig(),
    val recordingCount: Int             = 0,
    val intruderCount : Int             = 0,
    val isLoading     : Boolean         = false
)

@HiltViewModel
class DashboardViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val startMonitoring  : StartMonitoringUseCase,
    private val stopMonitoring   : StopMonitoringUseCase,
    private val getAllRecordings  : GetAllRecordingsUseCase,
    private val getIntruder      : GetIntruderPhotosUseCase,
    private val settingsRepo     : com.husseindev.sentinelprotocol.domain.repository.SettingsRepository
) : ViewModel() {

    private val _state = MutableStateFlow(DashboardUiState())
    val state: StateFlow<DashboardUiState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                settingsRepo.isMonitoringActive(),
                settingsRepo.getConfig(),
                getAllRecordings(),
                getIntruder()
            ) { active, config, recordings, intruders ->
                DashboardUiState(
                    isMonitoring   = active,
                    config         = config,
                    recordingCount = recordings.size,
                    intruderCount  = intruders.size
                )
            }.collect { _state.value = it }
        }
    }

    fun toggleMonitoring() {
        viewModelScope.launch {
            val current = _state.value.isMonitoring
            if (current) {
                stopMonitoring()
                stopService()
            } else {
                startMonitoring()
                startService()
            }
        }
    }

    private fun startService() {
        val config = _state.value.config
        Intent(context, SentinelForegroundService::class.java).apply {
            action = SentinelForegroundService.ACTION_START
            putExtra(SentinelForegroundService.EXTRA_CAMERA, config.cameraFacing.name)
            putExtra(SentinelForegroundService.EXTRA_SENSITIVITY, config.sensitivityLevel.name)
            context.startForegroundService(this)
        }
    }

    private fun stopService() {
        Intent(context, SentinelForegroundService::class.java).apply {
            action = SentinelForegroundService.ACTION_STOP
            context.startService(this)
        }
    }
}
