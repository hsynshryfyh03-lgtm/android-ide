package com.husseindev.sentinelprotocol.camera.analysis

import android.annotation.SuppressLint
import android.graphics.RectF
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.objects.ObjectDetection
import com.google.mlkit.vision.objects.ObjectDetector
import com.google.mlkit.vision.objects.defaults.ObjectDetectorOptions
import com.husseindev.sentinelprotocol.domain.model.DetectedPerson
import com.husseindev.sentinelprotocol.domain.model.DetectionResult
import com.husseindev.sentinelprotocol.domain.model.SensitivityLevel

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Person Detection
//  ML Kit Object Detection (Stream mode)
//  برمجة حسين حميد
// ══════════════════════════════════════════

class PersonDetectionAnalyzer(
    private val sensitivity  : SensitivityLevel = SensitivityLevel.MEDIUM,
    private val onDetection  : (DetectionResult) -> Unit,
    private val onNoDetection: () -> Unit
) : ImageAnalysis.Analyzer {

    private val detector: ObjectDetector = ObjectDetection.getClient(
        ObjectDetectorOptions.Builder()
            .setDetectorMode(ObjectDetectorOptions.STREAM_MODE)  // Real-time streaming
            .enableClassification()                              // Classify detected objects
            .build()
    )

    // Category IDs that indicate a person (ML Kit Object Detection)
    private val PERSON_CATEGORY_IDS = setOf(1)  // Category 1 = Fashion goods/Person in bundled model

    private var frameCount = 0
    private val processEveryNFrames = when (sensitivity) {
        SensitivityLevel.HIGH   -> 2
        SensitivityLevel.MEDIUM -> 3
        SensitivityLevel.LOW    -> 6
    }

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        frameCount++
        if (frameCount % processEveryNFrames != 0) {
            imageProxy.close()
            return
        }

        val mediaImage = imageProxy.image
        if (mediaImage == null) { imageProxy.close(); return }

        val inputImage = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)

        detector.process(inputImage)
            .addOnSuccessListener { objects ->
                val persons = objects
                    .filter { obj ->
                        obj.labels.any { label ->
                            label.confidence >= sensitivity.minConfidence &&
                            (label.text.contains("Person", ignoreCase = true) ||
                             label.text.contains("Human", ignoreCase = true) ||
                             PERSON_CATEGORY_IDS.contains(label.index))
                        }
                    }
                    .map { obj ->
                        val label  = obj.labels.maxByOrNull { it.confidence }
                        DetectedPerson(
                            boundingBox = RectF(
                                obj.boundingBox.left.toFloat(),
                                obj.boundingBox.top.toFloat(),
                                obj.boundingBox.right.toFloat(),
                                obj.boundingBox.bottom.toFloat()
                            ),
                            confidence  = label?.confidence ?: 0f,
                            label       = label?.text ?: "Person"
                        )
                    }

                if (persons.isNotEmpty()) {
                    onDetection(DetectionResult(persons = persons))
                } else {
                    onNoDetection()
                }
            }
            .addOnFailureListener { /* silent fail */ }
            .addOnCompleteListener { imageProxy.close() }
    }
}
