package com.husseindev.sentinelprotocol.core.utils

import android.graphics.*
import com.husseindev.sentinelprotocol.core.constants.AppConstants
import java.text.SimpleDateFormat
import java.util.*

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — CCTV Watermark
//  Baked into video frames
//  برمجة حسين حميد
// ══════════════════════════════════════════

object WatermarkRenderer {

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

    // Paint for main text (white with black shadow — CCTV style)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color    = Color.WHITE
        textSize = AppConstants.WATERMARK_TEXT_SIZE
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        setShadowLayer(3f, 2f, 2f, Color.BLACK)
    }

    // Paint for REC indicator
    private val recPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color    = Color.RED
        textSize = AppConstants.WATERMARK_TEXT_SIZE * 0.85f
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        setShadowLayer(2f, 1f, 1f, Color.BLACK)
    }

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.RED
        style = Paint.Style.FILL
    }

    /**
     * Draw CCTV watermark onto a Bitmap (for image/frame overlay)
     */
    fun drawOnBitmap(bitmap: Bitmap, isRecording: Boolean = true): Bitmap {
        val result  = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas  = Canvas(result)
        val padding = 16f

        val timestamp = dateFormat.format(Date())
        val author    = AppConstants.WATERMARK_AUTHOR

        // Top-left: REC indicator + timestamp
        if (isRecording) {
            // Blinking red dot
            canvas.drawCircle(padding + 8f, padding + 8f, 7f, dotPaint)
            canvas.drawText("REC", padding + 22f, padding + 16f, recPaint)
        }

        // Top-left: timestamp (below REC)
        canvas.drawText(timestamp, padding, padding + 42f, textPaint)

        // Bottom-left: author
        val yBottom = result.height - padding
        canvas.drawText(author, padding, yBottom, textPaint)

        return result
    }

    /**
     * Returns overlay info as strings (used by Compose overlay layer)
     */
    fun getWatermarkLines(): Pair<String, String> {
        val timestamp = dateFormat.format(Date())
        return Pair(timestamp, AppConstants.WATERMARK_AUTHOR)
    }
}
