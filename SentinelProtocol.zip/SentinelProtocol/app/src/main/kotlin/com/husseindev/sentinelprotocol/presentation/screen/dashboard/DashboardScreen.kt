package com.husseindev.sentinelprotocol.presentation.screen.dashboard

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.husseindev.sentinelprotocol.presentation.components.*
import com.husseindev.sentinelprotocol.presentation.theme.*

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Dashboard Screen
//  برمجة حسين حميد
// ══════════════════════════════════════════

@Composable
fun DashboardScreen(
    onNavigateGallery  : () -> Unit,
    onNavigateSettings : () -> Unit,
    onNavigateIntruder : () -> Unit,
    onNavigateMonitor  : () -> Unit,
    viewModel          : DashboardViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .systemBarsPadding()
    ) {
        // Ambient glow background
        Box(Modifier.align(Alignment.TopCenter).offset(y = (-60).dp)
            .size(300.dp).blur(120.dp)
            .background(TealDark.copy(0.35f), CircleShape))

        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))

            // ── Header ────────────────────────────
            Text(
                text       = "SENTINEL",
                color      = TealLight,
                fontSize   = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = TajawalFamily,
                letterSpacing = 6.sp
            )
            Text(
                text       = "برمجة حسين حميد",
                color      = TextDim,
                fontSize   = 13.sp,
                fontFamily = TajawalFamily
            )

            Spacer(Modifier.height(32.dp))

            // ── Power Toggle ──────────────────────
            MonitoringToggle(
                isActive = state.isMonitoring,
                onToggle = { viewModel.toggleMonitoring() }
            )

            Spacer(Modifier.height(32.dp))

            // ── Stats Row ─────────────────────────
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    modifier = Modifier.weight(1f),
                    icon     = Icons.Default.VideoLibrary,
                    value    = state.recordingCount.toString(),
                    label    = "تسجيلات",
                    onClick  = onNavigateGallery
                )
                StatCard(
                    modifier = Modifier.weight(1f),
                    icon     = Icons.Default.PersonOff,
                    value    = state.intruderCount.toString(),
                    label    = "متطفلون",
                    onClick  = onNavigateIntruder
                )
            }

            Spacer(Modifier.height(12.dp))

            // ── Action Buttons ────────────────────
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ActionButton(
                    icon    = Icons.Default.CameraAlt,
                    label   = "شاشة المراقبة الحية",
                    onClick = onNavigateMonitor
                )
                ActionButton(
                    icon    = Icons.Default.Settings,
                    label   = "الإعدادات",
                    onClick = onNavigateSettings
                )
            }

            // ── Status Card ───────────────────────
            Spacer(Modifier.height(20.dp))
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 32.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("حالة النظام", color = TextSecondary, fontSize = 12.sp, fontFamily = TajawalFamily)
                        Text(
                            text = if (state.isMonitoring) "المراقبة نشطة" else "في وضع الاستعداد",
                            color = if (state.isMonitoring) ActiveGreen else TextDim,
                            fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = TajawalFamily
                        )
                    }
                    RecordingIndicator(isRecording = state.isMonitoring)
                }
            }
        }
    }
}

@Composable
private fun MonitoringToggle(isActive: Boolean, onToggle: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(1000, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "pulse"
    )
    val outerScale = if (isActive) pulseScale else 1f
    val outerColor = if (isActive) TealGlow else Color.Transparent
    val innerColor = if (isActive) TealPrimary else ElevatedBlack

    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(160.dp)) {
        // Outer pulse ring
        Box(modifier = Modifier
            .size(160.dp * outerScale)
            .clip(CircleShape)
            .background(outerColor)
        )
        // Main button
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(130.dp)
                .clip(CircleShape)
                .background(innerColor)
                .border(2.dp, if (isActive) TealPrimary else GlassBorder, CircleShape)
                .drawBehind {
                    drawIntoCanvas { canvas ->
                        val paint = Paint().apply {
                            asFrameworkPaint().setShadowLayer(
                                if (isActive) 30f else 10f, 0f, 0f,
                                if (isActive) TealGlow.toArgb() else Color.Black.copy(0.3f).toArgb()
                            )
                        }
                        canvas.drawCircle(center, 65.dp.toPx(), paint)
                    }
                }
        ) {
            IconButton(onClick = onToggle, modifier = Modifier.size(130.dp)) {
                Icon(
                    imageVector = if (isActive) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint   = if (isActive) TealLight else TextSecondary,
                    modifier = Modifier.size(52.dp)
                )
            }
        }
    }
}

@Composable
private fun StatCard(modifier: Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector, value: String, label: String, onClick: () -> Unit) {
    GlassmorphicCard(modifier = modifier) {
        Column(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = TealLight, modifier = Modifier.size(28.dp))
            Spacer(Modifier.height(8.dp))
            Text(value, color = TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, fontFamily = TajawalFamily)
            Text(label, color = TextSecondary, fontSize = 12.sp, fontFamily = TajawalFamily)
        }
    }
}

@Composable
private fun ActionButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(icon, contentDescription = null, tint = TealPrimary, modifier = Modifier.size(24.dp))
                Text(label, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextDim)
        }
    }
}
