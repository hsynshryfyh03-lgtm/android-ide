package com.husseindev.sentinelprotocol

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Application Class
//  برمجة حسين حميد
// ══════════════════════════════════════════

@HiltAndroidApp
class SentinelApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // SQLCipher init
        net.sqlcipher.database.SQLiteDatabase.loadLibs(this)
    }
}
