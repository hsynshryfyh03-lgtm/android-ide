package com.husseindev.sentinelprotocol.presentation.screen.calculator

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.husseindev.sentinelprotocol.domain.usecase.ValidatePanicCodeUseCase
import com.husseindev.sentinelprotocol.domain.usecase.ValidatePinUseCase
import com.husseindev.sentinelprotocol.domain.usecase.DeleteAllDataUseCase
import com.husseindev.sentinelprotocol.domain.usecase.SaveIntruderPhotoUseCase
import com.husseindev.sentinelprotocol.domain.model.IntruderPhoto
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Calculator ViewModel
//  Real calculator + stealth PIN unlock
//  برمجة حسين حميد
// ══════════════════════════════════════════

sealed class CalcEvent {
    object NavigateToDashboard : CalcEvent()
    object TriggerPanicWipe    : CalcEvent()
    object TriggerIntruderSelfie: CalcEvent()
}

data class CalcUiState(
    val display       : String  = "0",
    val inputBuffer   : String  = "",
    val failedAttempts: Int     = 0,
    val isWiping      : Boolean = false
)

@HiltViewModel
class CalculatorViewModel @Inject constructor(
    private val validatePin   : ValidatePinUseCase,
    private val validatePanic : ValidatePanicCodeUseCase,
    private val deleteAllData : DeleteAllDataUseCase,
    private val saveIntruder  : SaveIntruderPhotoUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow(CalcUiState())
    val uiState = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<CalcEvent>()
    val events = _events.asSharedFlow()

    // Calculator internals
    private var currentValue  = ""
    private var operator      = ""
    private var previousValue = ""
    private var justComputed  = false

    fun onKey(key: String) {
        when (key) {
            "=" -> handleEquals()
            "C" -> clearAll()
            "⌫" -> backspace()
            "+", "-", "×", "÷" -> handleOperator(key)
            "." -> handleDot()
            else -> handleDigit(key)
        }
    }

    private fun handleDigit(d: String) {
        if (justComputed) { currentValue = ""; justComputed = false }
        if (currentValue == "0") currentValue = d else currentValue += d
        updateDisplay(currentValue)
    }

    private fun handleOperator(op: String) {
        if (currentValue.isNotEmpty() && previousValue.isNotEmpty()) compute()
        previousValue = currentValue.ifEmpty { previousValue }
        operator      = op
        currentValue  = ""
        updateDisplay("$previousValue $op")
    }

    private fun handleDot() {
        if (!currentValue.contains(".")) currentValue += "."
        updateDisplay(currentValue)
    }

    private fun handleEquals() {
        val input = currentValue

        // ── Security check: is this a PIN? ──
        viewModelScope.launch {
            when {
                validatePin(input) -> {
                    clearAll()
                    _events.emit(CalcEvent.NavigateToDashboard)
                    return@launch
                }
                validatePanic(input) -> {
                    _uiState.value = _uiState.value.copy(isWiping = true)
                    deleteAllData()
                    _events.emit(CalcEvent.TriggerPanicWipe)
                    return@launch
                }
                else -> {
                    // Normal math computation
                    if (previousValue.isNotEmpty() && operator.isNotEmpty() && input.isNotEmpty()) {
                        compute()
                        justComputed = true
                    }
                    // Track failed PIN attempts
                    if (input.all { it.isDigit() }) {
                        val attempts = _uiState.value.failedAttempts + 1
                        _uiState.value = _uiState.value.copy(failedAttempts = attempts)
                        if (attempts >= 3) {
                            _uiState.value = _uiState.value.copy(failedAttempts = 0)
                            _events.emit(CalcEvent.TriggerIntruderSelfie)
                        }
                    }
                }
            }
        }
    }

    private fun compute() {
        val a   = previousValue.toDoubleOrNull() ?: return
        val b   = currentValue.toDoubleOrNull()  ?: return
        val result = when (operator) {
            "+"  -> a + b
            "-"  -> a - b
            "×"  -> a * b
            "÷"  -> if (b != 0.0) a / b else Double.NaN
            else -> b
        }
        val display = if (result % 1.0 == 0.0) result.toLong().toString() else result.toString()
        currentValue  = display
        previousValue = ""
        operator      = ""
        updateDisplay(display)
    }

    private fun clearAll() {
        currentValue  = ""
        previousValue = ""
        operator      = ""
        justComputed  = false
        _uiState.value = _uiState.value.copy(display = "0", inputBuffer = "")
    }

    private fun backspace() {
        if (currentValue.isNotEmpty()) {
            currentValue = currentValue.dropLast(1)
            updateDisplay(currentValue.ifEmpty { "0" })
        }
    }

    private fun updateDisplay(text: String) {
        _uiState.value = _uiState.value.copy(
            display     = text.ifEmpty { "0" },
            inputBuffer = currentValue
        )
    }

    fun onIntruderCapture(filePath: String) {
        viewModelScope.launch {
            saveIntruder(IntruderPhoto(
                filePath      = filePath,
                attemptNumber = _uiState.value.failedAttempts
            ))
        }
    }
}
