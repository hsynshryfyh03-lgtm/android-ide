package com.husseindev.sentinelprotocol.presentation.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.husseindev.sentinelprotocol.presentation.theme.*

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Glassmorphism Components
//  برمجة حسين حميد
// ══════════════════════════════════════════

// ── Glassmorphic Card ─────────────────────
@Composable
fun GlassmorphicCard(
    modifier      : Modifier = Modifier,
    cornerRadius  : Dp      = 20.dp,
    glowColor     : Color   = TealGlow,
    borderAlpha   : Float   = 0.15f,
    content       : @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)

    Box(
        modifier = modifier
            .clip(shape)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(GlassHighlight, GlassWhite, GlassDark)
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.3f),
                        Color.White.copy(alpha = 0.05f),
                        TealPrimary.copy(alpha = 0.2f)
                    )
                ),
                shape = shape
            )
            .drawBehind {
                // Teal glow shadow
                drawIntoCanvas { canvas ->
                    val paint = Paint().apply {
                        asFrameworkPaint().apply {
                            isAntiAlias = true
                            this.color  = android.graphics.Color.TRANSPARENT
                            setShadowLayer(24f, 0f, 8f, glowColor.toArgb())
                        }
                    }
                    canvas.drawRoundRect(0f, 0f, size.width, size.height, cornerRadius.toPx(), cornerRadius.toPx(), paint)
                }
            },
        content = content
    )
}

// ── Neon Teal Button ──────────────────────
@Composable
fun NeonButton(
    text      : String,
    onClick   : () -> Unit,
    modifier  : Modifier = Modifier,
    enabled   : Boolean  = true,
    isDestructive: Boolean = false
) {
    val bgColor    = if (isDestructive) RecordingRed else TealPrimary
    val glowColor  = if (isDestructive) RecordingRedGlow else TealGlow
    val shape      = RoundedCornerShape(14.dp)

    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.95f else 1f,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "buttonScale"
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(bgColor.copy(alpha = 0.9f), bgColor.copy(alpha = 0.7f))
                )
            )
            .border(1.dp, bgColor.copy(alpha = 0.5f), shape)
            .drawBehind {
                drawIntoCanvas { canvas ->
                    val paint = Paint().apply {
                        asFrameworkPaint().setShadowLayer(16f, 0f, 4f, glowColor.toArgb())
                    }
                    canvas.drawRoundRect(0f,0f,size.width,size.height,14.dp.toPx(),14.dp.toPx(),paint)
                }
            }
            .clickable(enabled = enabled) { onClick() }
            .padding(horizontal = 24.dp, vertical = 14.dp)
    ) {
        Text(
            text       = text,
            color      = DeepBlack,
            fontWeight = FontWeight.Bold,
            fontSize   = 16.sp,
            fontFamily = TajawalFamily
        )
    }
}

// ── Recording Status Indicator ────────────
@Composable
fun RecordingIndicator(isRecording: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "blink")
    val alpha by infiniteTransition.animateFloat(
        initialValue   = 1f,
        targetValue    = 0.2f,
        animationSpec  = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "blinkAlpha"
    )

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .background(
                    color  = RecordingRed.copy(alpha = if (isRecording) alpha else 0.3f),
                    shape  = RoundedCornerShape(50)
                )
        )
        Text(
            text       = if (isRecording) "REC" else "STANDBY",
            color      = if (isRecording) RecordingRed else TextDim,
            fontSize   = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = TajawalFamily
        )
    }
}

// ── CCTV Watermark Overlay ────────────────
@Composable
fun CctvWatermarkOverlay(modifier: Modifier = Modifier) {
    val timeText = remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        while (true) {
            timeText.value = java.text.SimpleDateFormat(
                "yyyy-MM-dd  HH:mm:ss", java.util.Locale.getDefault()
            ).format(java.util.Date())
            kotlinx.coroutines.delay(1000)
        }
    }

    Column(
        modifier = modifier.padding(10.dp)
    ) {
        Text(
            text       = timeText.value,
            color      = WatermarkColor,
            fontSize   = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = TajawalFamily,
            style      = androidx.compose.ui.text.TextStyle(
                shadow = androidx.compose.ui.graphics.Shadow(
                    color  = Color.Black,
                    offset = Offset(1f, 1f),
                    blurRadius = 3f
                )
            )
        )
        Text(
            text       = "برمجة حسين حميد",
            color      = WatermarkColor,
            fontSize   = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = TajawalFamily,
            style      = androidx.compose.ui.text.TextStyle(
                shadow = androidx.compose.ui.graphics.Shadow(
                    color = Color.Black, offset = Offset(1f,1f), blurRadius = 3f
                )
            )
        )
    }
}

// ── Shimmer Effect ─────────────────────────
@Composable
fun ShimmerBox(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "shimmer")
    val shimmerOffset by infiniteTransition.animateFloat(
        initialValue = -1000f,
        targetValue  = 1000f,
        animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing)),
        label = "shimmerOffset"
    )

    Box(modifier = modifier
        .background(
            brush = Brush.linearGradient(
                colors = listOf(TealShimmer, TealGlow, TealShimmer),
                start  = Offset(shimmerOffset, 0f),
                end    = Offset(shimmerOffset + 400f, 400f)
            )
        )
    )
}
