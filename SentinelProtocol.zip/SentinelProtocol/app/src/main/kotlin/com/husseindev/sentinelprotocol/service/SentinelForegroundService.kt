package com.husseindev.sentinelprotocol.service

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.camera.core.Preview
import androidx.lifecycle.LifecycleService
import com.husseindev.sentinelprotocol.camera.CameraEngine
import com.husseindev.sentinelprotocol.core.constants.AppConstants
import com.husseindev.sentinelprotocol.domain.model.CameraFacing
import com.husseindev.sentinelprotocol.domain.model.SensitivityLevel
import com.husseindev.sentinelprotocol.domain.model.TriggerType
import com.husseindev.sentinelprotocol.domain.usecase.SaveRecordingUseCase
import com.husseindev.sentinelprotocol.domain.model.RecordingEvent
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import java.io.File
import javax.inject.Inject

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Foreground Service
//  Camera + Microphone — Stealth Mode
//  برمجة حسين حميد
// ══════════════════════════════════════════

@AndroidEntryPoint
class SentinelForegroundService : LifecycleService() {

    private val TAG = "SentinelFGService"

    @Inject lateinit var cameraEngine     : CameraEngine
    @Inject lateinit var notifManager     : SentinelNotificationManager
    @Inject lateinit var saveRecording    : SaveRecordingUseCase

    private var wakeLock  : PowerManager.WakeLock? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    companion object {
        const val ACTION_START = "ACTION_SENTINEL_START"
        const val ACTION_STOP  = "ACTION_SENTINEL_STOP"
        const val EXTRA_CAMERA = "extra_camera_facing"  // "FRONT" | "BACK"
        const val EXTRA_SENSITIVITY = "extra_sensitivity"

        var isRunning = false
    }

    override fun onCreate() {
        super.onCreate()
        notifManager.createNotificationChannel()
        acquireWakeLock()
        Log.d(TAG, "Service created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            else -> startForegroundCompat()
        }

        val facingStr   = intent?.getStringExtra(EXTRA_CAMERA) ?: CameraFacing.BACK.name
        val sensitStr   = intent?.getStringExtra(EXTRA_SENSITIVITY) ?: SensitivityLevel.MEDIUM.name
        val facing      = CameraFacing.valueOf(facingStr)
        val sensitivity = SensitivityLevel.valueOf(sensitStr)

        isRunning = true

        // Bind camera — LifecycleService is a LifecycleOwner
        cameraEngine.setMonitoringActive(true)
        cameraEngine.bindCamera(
            lifecycleOwner = this,
            facing         = facing,
            sensitivity    = sensitivity,
            preview        = null,              // No preview in background
            onRecordingComplete = { file -> onRecordingFinished(file) }
        )

        Log.d(TAG, "Monitoring started — facing: $facing, sensitivity: $sensitivity")
        return START_STICKY  // Restart if killed
    }

    private fun startForegroundCompat() {
        val notification = notifManager.buildForegroundNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                AppConstants.NOTIFICATION_ID_FOREGROUND,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(AppConstants.NOTIFICATION_ID_FOREGROUND, notification)
        }
    }

    private fun onRecordingFinished(file: File) {
        scope.launch {
            val event = RecordingEvent(
                filePath       = file.absolutePath,
                timestamp      = System.currentTimeMillis(),
                durationMs     = 0L,
                triggerType    = TriggerType.MOTION_FACE,
                fileSizeBytes  = file.length()
            )
            saveRecording(event)
            Log.d(TAG, "Recording saved to DB: ${file.name}")
        }
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "SentinelProtocol::SurveillanceWakeLock"
        ).also { it.acquire(12 * 60 * 60 * 1000L) }  // Max 12 hours
    }

    override fun onDestroy() {
        isRunning = false
        cameraEngine.setMonitoringActive(false)
        cameraEngine.unbind()
        wakeLock?.release()
        scope.cancel()
        Log.d(TAG, "Service destroyed")
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }
}
