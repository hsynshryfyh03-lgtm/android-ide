package com.husseindev.sentinelprotocol.data.local.db.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.husseindev.sentinelprotocol.domain.model.IntruderPhoto
import com.husseindev.sentinelprotocol.domain.model.RecordingEvent
import com.husseindev.sentinelprotocol.domain.model.TriggerType

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Room Entities
//  برمجة حسين حميد
// ══════════════════════════════════════════

@Entity(tableName = "recordings")
data class RecordingEntity(
    @PrimaryKey(autoGenerate = true)
    val id             : Long   = 0,
    val filePath       : String,
    val thumbnailPath  : String? = null,
    val timestamp      : Long,
    val durationMs     : Long,
    val triggerType    : String,   // TriggerType.name
    val detectionCount : Int,
    val fileSizeBytes  : Long,
    val isEmergency    : Boolean
) {
    fun toDomain() = RecordingEvent(
        id             = id,
        filePath       = filePath,
        thumbnailPath  = thumbnailPath,
        timestamp      = timestamp,
        durationMs     = durationMs,
        triggerType    = TriggerType.valueOf(triggerType),
        detectionCount = detectionCount,
        fileSizeBytes  = fileSizeBytes,
        isEmergency    = isEmergency
    )

    companion object {
        fun fromDomain(d: RecordingEvent) = RecordingEntity(
            id             = d.id,
            filePath       = d.filePath,
            thumbnailPath  = d.thumbnailPath,
            timestamp      = d.timestamp,
            durationMs     = d.durationMs,
            triggerType    = d.triggerType.name,
            detectionCount = d.detectionCount,
            fileSizeBytes  = d.fileSizeBytes,
            isEmergency    = d.isEmergency
        )
    }
}

@Entity(tableName = "intruder_photos")
data class IntruderPhotoEntity(
    @PrimaryKey(autoGenerate = true)
    val id            : Long = 0,
    val filePath      : String,
    val timestamp     : Long,
    val attemptNumber : Int
) {
    fun toDomain() = IntruderPhoto(id, filePath, timestamp, attemptNumber)

    companion object {
        fun fromDomain(d: IntruderPhoto) =
            IntruderPhotoEntity(d.id, d.filePath, d.timestamp, d.attemptNumber)
    }
}
