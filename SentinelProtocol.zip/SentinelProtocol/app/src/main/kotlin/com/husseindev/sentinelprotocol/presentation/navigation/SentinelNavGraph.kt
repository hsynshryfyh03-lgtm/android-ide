package com.husseindev.sentinelprotocol.presentation.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.husseindev.sentinelprotocol.camera.CameraEngine
import com.husseindev.sentinelprotocol.presentation.screen.calculator.CalculatorScreen
import com.husseindev.sentinelprotocol.presentation.screen.dashboard.DashboardScreen
import com.husseindev.sentinelprotocol.presentation.screen.gallery.GalleryScreen
import com.husseindev.sentinelprotocol.presentation.screen.intruder.IntruderScreen
import com.husseindev.sentinelprotocol.presentation.screen.monitoring.MonitoringScreen
import com.husseindev.sentinelprotocol.presentation.screen.settings.SettingsScreen

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — NavGraph
//  برمجة حسين حميد
// ══════════════════════════════════════════

@Composable
fun SentinelNavGraph(
    navController : NavHostController,
    cameraEngine  : CameraEngine
) {
    NavHost(
        navController    = navController,
        startDestination = Screen.Calculator.route
    ) {
        composable(Screen.Calculator.route) {
            CalculatorScreen(
                onUnlocked   = { navController.navigate(Screen.Dashboard.route) { popUpTo(Screen.Calculator.route) { inclusive = true } } },
                cameraEngine = cameraEngine
            )
        }

        composable(Screen.Dashboard.route) {
            DashboardScreen(
                onNavigateGallery   = { navController.navigate(Screen.Gallery.route) },
                onNavigateSettings  = { navController.navigate(Screen.Settings.route) },
                onNavigateIntruder  = { navController.navigate(Screen.Intruder.route) },
                onNavigateMonitor   = { navController.navigate(Screen.Monitoring.route) }
            )
        }

        composable(Screen.Monitoring.route) {
            MonitoringScreen(
                cameraEngine = cameraEngine,
                onBack       = { navController.popBackStack() }
            )
        }

        composable(Screen.Gallery.route) {
            GalleryScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.Settings.route) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.Intruder.route) {
            IntruderScreen(onBack = { navController.popBackStack() })
        }
    }
}
