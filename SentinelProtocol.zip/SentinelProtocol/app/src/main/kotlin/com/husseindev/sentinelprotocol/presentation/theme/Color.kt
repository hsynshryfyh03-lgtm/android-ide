package com.husseindev.sentinelprotocol.presentation.theme

import androidx.compose.ui.graphics.Color

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Color Palette
//  Black & Teal Glassmorphism
//  برمجة حسين حميد
// ══════════════════════════════════════════

// ── Deep Blacks ──────────────────────────
val DeepBlack       = Color(0xFF000000)
val SurfaceBlack    = Color(0xFF0A0A0A)
val CardBlack       = Color(0xFF0F1117)
val ElevatedBlack   = Color(0xFF151820)

// ── Teal Spectrum ────────────────────────
val TealPrimary     = Color(0xFF00BFA5)
val TealLight       = Color(0xFF64FFDA)
val TealDark        = Color(0xFF008E76)
val TealGlow        = Color(0x5500BFA5)   // 33% alpha — glow effect
val TealShimmer     = Color(0x2200BFA5)   // 13% alpha — shimmer base

// ── Glass Layer Colors ───────────────────
val GlassWhite      = Color(0x0FFFFFFF)   // 6% white — glass base
val GlassBorder     = Color(0x1AFFFFFF)   // 10% white — border
val GlassHighlight  = Color(0x26FFFFFF)   // 15% white — top edge highlight
val GlassDark       = Color(0x1A000000)   // dark tint glass variant

// ── Text ─────────────────────────────────
val TextPrimary     = Color(0xFFECEFF1)
val TextSecondary   = Color(0xFF90A4AE)
val TextTeal        = Color(0xFF64FFDA)
val TextDim         = Color(0xFF546E7A)

// ── Status Colors ────────────────────────
val RecordingRed    = Color(0xFFFF1744)
val RecordingRedGlow= Color(0x55FF1744)
val ActiveGreen     = Color(0xFF00E676)
val WarningAmber    = Color(0xFFFFAB40)

// ── Calculator Keys ──────────────────────
val KeyNumber       = Color(0xFF1A1F2E)
val KeyOperator     = Color(0xFF00BFA5)
val KeyEquals       = Color(0xFF00897B)
val KeySpecial      = Color(0xFF0D1117)
val KeyText         = Color(0xFFECEFF1)

// ── Notification/Overlay ─────────────────
val OverlayBlack    = Color(0xCC000000)   // 80% black overlay
val WatermarkColor  = Color(0xB3FFFFFF)   // CCTV watermark white
