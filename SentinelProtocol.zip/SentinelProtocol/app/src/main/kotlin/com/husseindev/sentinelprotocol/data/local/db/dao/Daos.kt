package com.husseindev.sentinelprotocol.data.local.db.dao

import androidx.room.*
import com.husseindev.sentinelprotocol.data.local.db.entity.IntruderPhotoEntity
import com.husseindev.sentinelprotocol.data.local.db.entity.RecordingEntity
import kotlinx.coroutines.flow.Flow

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Room DAOs
//  برمجة حسين حميد
// ══════════════════════════════════════════

@Dao
interface RecordingDao {
    @Query("SELECT * FROM recordings ORDER BY timestamp DESC")
    fun getAllRecordings(): Flow<List<RecordingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecording(entity: RecordingEntity): Long

    @Query("DELETE FROM recordings WHERE id = :id")
    suspend fun deleteRecording(id: Long)

    @Query("DELETE FROM recordings")
    suspend fun deleteAllRecordings()

    @Query("SELECT COUNT(*) FROM recordings")
    suspend fun getRecordingsCount(): Int
}

@Dao
interface IntruderDao {
    @Query("SELECT * FROM intruder_photos ORDER BY timestamp DESC")
    fun getAllIntruderPhotos(): Flow<List<IntruderPhotoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIntruderPhoto(entity: IntruderPhotoEntity): Long

    @Query("DELETE FROM intruder_photos")
    suspend fun deleteAllIntruderPhotos()
}
