package com.husseindev.sentinelprotocol.presentation.screen.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.husseindev.sentinelprotocol.domain.model.*
import com.husseindev.sentinelprotocol.domain.repository.SettingsRepository
import com.husseindev.sentinelprotocol.presentation.components.GlassmorphicCard
import com.husseindev.sentinelprotocol.presentation.components.NeonButton
import com.husseindev.sentinelprotocol.presentation.theme.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Settings Screen
//  برمجة حسين حميد
// ══════════════════════════════════════════

@HiltViewModel
class SettingsViewModel @Inject constructor(private val repo: SettingsRepository) : ViewModel() {
    val config = repo.getConfig().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SentinelConfig())

    fun updateConfig(c: SentinelConfig) { viewModelScope.launch { repo.updateConfig(c) } }
    fun updatePin(pin: String)          { viewModelScope.launch { repo.updatePin(pin) } }
    fun updatePanic(code: String)       { viewModelScope.launch { repo.updatePanicCode(code) } }
}

@Composable
fun SettingsScreen(onBack: () -> Unit, viewModel: SettingsViewModel = hiltViewModel()) {
    val config by viewModel.config.collectAsStateWithLifecycle()
    var newPin    by remember { mutableStateOf("") }
    var newPanic  by remember { mutableStateOf("") }
    var saved     by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(DeepBlack).systemBarsPadding()) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            // Header
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = TextPrimary) }
                Text("الإعدادات", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
            }

            // ── Camera Section ─────────────
            SettingsSection(title = "الكاميرا", icon = Icons.Default.CameraAlt) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CameraFacing.values().forEach { f ->
                        val selected = config.cameraFacing == f
                        FilterChip(
                            selected = selected,
                            onClick  = { viewModel.updateConfig(config.copy(cameraFacing = f)) },
                            label    = { Text(if (f == CameraFacing.BACK) "خلفية" else "أمامية", fontFamily = TajawalFamily) },
                            colors   = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = TealPrimary,
                                selectedLabelColor     = DeepBlack
                            )
                        )
                    }
                }
            }

            // ── Sensitivity Section ────────
            SettingsSection(title = "حساسية الاكتشاف", icon = Icons.Default.Tune) {
                SensitivityLevel.values().forEach { level ->
                    val selected = config.sensitivityLevel == level
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = when (level) {
                                SensitivityLevel.HIGH   -> "عالية (كل الحركات)"
                                SensitivityLevel.MEDIUM -> "متوسطة (موصى بها)"
                                SensitivityLevel.LOW    -> "منخفضة (وجوه واضحة فقط)"
                            },
                            color = if (selected) TealLight else TextSecondary,
                            fontFamily = TajawalFamily, fontSize = 14.sp
                        )
                        RadioButton(
                            selected = selected,
                            onClick  = { viewModel.updateConfig(config.copy(sensitivityLevel = level)) },
                            colors   = RadioButtonDefaults.colors(selectedColor = TealPrimary)
                        )
                    }
                }
            }

            // ── Auto-Start + Emergency ─────
            SettingsSection(title = "التشغيل التلقائي", icon = Icons.Default.PowerSettingsNew) {
                SettingToggle("تشغيل عند إعادة تشغيل الهاتف", config.autoStartOnBoot) {
                    viewModel.updateConfig(config.copy(autoStartOnBoot = it))
                }
                SettingToggle("تفعيل زر الطوارئ (رفع الصوت ×٢)", config.emergencyTriggerEnabled) {
                    viewModel.updateConfig(config.copy(emergencyTriggerEnabled = it))
                }
            }

            // ── Security ──────────────────
            SettingsSection(title = "الأمان", icon = Icons.Default.Lock) {
                SentinelTextField("رمز PIN الجديد", newPin, isPassword = true) { newPin = it }
                Spacer(Modifier.height(8.dp))
                SentinelTextField("رمز الطوارئ (Panic) الجديد", newPanic, isPassword = true) { newPanic = it }
                Spacer(Modifier.height(12.dp))
                NeonButton(text = "حفظ الرموز", onClick = {
                    if (newPin.length >= 4)   viewModel.updatePin(newPin)
                    if (newPanic.length >= 4) viewModel.updatePanic(newPanic)
                    saved = true; newPin = ""; newPanic = ""
                })
                if (saved) {
                    Spacer(Modifier.height(8.dp))
                    Text("✓ تم الحفظ", color = ActiveGreen, fontFamily = TajawalFamily, fontSize = 13.sp)
                }
            }

            Spacer(Modifier.height(40.dp))
        }
    }
}

@Composable
private fun SettingsSection(title: String, icon: ImageVector, content: @Composable ColumnScope.() -> Unit) {
    GlassmorphicCard(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(icon, null, tint = TealPrimary, modifier = Modifier.size(20.dp))
                Text(title, color = TealLight, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
            }
            Spacer(Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
private fun SettingToggle(label: String, checked: Boolean, onToggle: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextSecondary, fontFamily = TajawalFamily, fontSize = 14.sp,
            modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onToggle,
            colors = SwitchDefaults.colors(checkedThumbColor = DeepBlack, checkedTrackColor = TealPrimary))
    }
}

@Composable
private fun SentinelTextField(label: String, value: String, isPassword: Boolean = false, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange,
        label = { Text(label, fontFamily = TajawalFamily, fontSize = 13.sp) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        visualTransformation = if (isPassword) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (isPassword) KeyboardType.NumberPassword else KeyboardType.Text),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor   = TealPrimary,
            unfocusedBorderColor = GlassBorder,
            focusedLabelColor    = TealLight,
            cursorColor          = TealPrimary,
            focusedTextColor     = TextPrimary,
            unfocusedTextColor   = TextSecondary
        ),
        shape = RoundedCornerShape(14.dp)
    )
}
