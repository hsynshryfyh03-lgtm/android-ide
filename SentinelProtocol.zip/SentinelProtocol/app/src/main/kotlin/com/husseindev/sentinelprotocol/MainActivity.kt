package com.husseindev.sentinelprotocol

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.remember
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.compose.rememberNavController
import com.husseindev.sentinelprotocol.camera.CameraEngine
import com.husseindev.sentinelprotocol.presentation.navigation.SentinelNavGraph
import com.husseindev.sentinelprotocol.presentation.theme.SentinelTheme
import com.husseindev.sentinelprotocol.service.EmergencyRecordService
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — MainActivity
//  برمجة حسين حميد
// ══════════════════════════════════════════

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var cameraEngine: CameraEngine

    private var lastVolumeUpTime = 0L
    private val doublePressMs   = 500L

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SentinelTheme {
                val navController = rememberNavController()
                SentinelNavGraph(
                    navController = navController,
                    cameraEngine  = cameraEngine
                )
            }
        }
    }

    // ── Volume button hook ────────────────
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            val now  = System.currentTimeMillis()
            val diff = now - lastVolumeUpTime
            if (diff <= doublePressMs) {
                // Double press — forward to EmergencyRecordService
                startService(Intent(this, EmergencyRecordService::class.java).apply {
                    action = EmergencyRecordService.ACTION_VOLUME_UP_PRESSED
                })
                lastVolumeUpTime = 0L
                return true
            }
            lastVolumeUpTime = now
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        super.onDestroy()
        // Don't unbind — service continues in background
    }
}
