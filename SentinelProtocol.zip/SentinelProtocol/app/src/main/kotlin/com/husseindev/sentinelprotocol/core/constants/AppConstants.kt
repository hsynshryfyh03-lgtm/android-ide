package com.husseindev.sentinelprotocol.core.constants

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — App Constants
//  برمجة حسين حميد
// ══════════════════════════════════════════

object AppConstants {

    // ── Security ─────────────────────────
    const val DEFAULT_PIN           = "1234"        // Changed by user in settings
    const val PIN_MAX_ATTEMPTS      = 3
    const val PANIC_CODE            = "0000"        // Triggers data wipe

    // ── Recording Timings ─────────────────
    const val PRE_BUFFER_SECONDS    = 5L            // Circular buffer duration
    const val POST_DETECTION_SECONDS= 10L           // Continue recording after last detection
    const val FRAME_RATE            = 30            // fps
    const val VIDEO_BITRATE         = 8_000_000     // 8 Mbps (H.265 high quality)
    const val AUDIO_BITRATE         = 128_000       // 128 kbps

    // ── Battery ───────────────────────────
    const val BATTERY_STOP_THRESHOLD= 15            // % — auto stop monitoring

    // ── Notifications ─────────────────────
    const val NOTIFICATION_CHANNEL_ID       = "sentinel_system_channel"
    const val NOTIFICATION_ID_FOREGROUND    = 1001
    const val NOTIFICATION_ID_ALERT         = 1002

    // ── Volume Button Emergency ────────────
    const val VOLUME_DOUBLE_PRESS_MS        = 500L  // Max ms between presses
    const val EMERGENCY_RECORD_DURATION_SEC = 30L   // Default emergency recording length

    // ── File Paths ─────────────────────────
    const val RECORDINGS_DIR        = "SentinelProtocol/Recordings"
    const val INTRUDER_DIR          = "SentinelProtocol/Intruder"
    const val DB_NAME               = "sentinel_vault.db"

    // ── Watermark ─────────────────────────
    const val WATERMARK_AUTHOR      = "برمجة حسين حميد"
    const val WATERMARK_TEXT_SIZE   = 28f           // sp

    // ── DataStore Keys ─────────────────────
    const val DS_PIN_KEY            = "user_pin"
    const val DS_PANIC_KEY          = "panic_code"
    const val DS_MONITORING_ACTIVE  = "monitoring_active"
    const val DS_CAMERA_FACING      = "camera_facing"   // "front" | "back"
    const val DS_SENSITIVITY        = "detection_sensitivity"
    const val DS_AUTO_START         = "auto_start_on_boot"
    const val DS_EMERGENCY_ENABLED  = "emergency_volume_trigger"
}
