package com.husseindev.sentinelprotocol.camera

import android.content.Context
import android.util.Log
import com.husseindev.sentinelprotocol.core.constants.AppConstants
import java.io.File
import java.util.concurrent.ConcurrentLinkedDeque
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Video Buffer Manager
//  Circular Pre-Event Buffer (5 seconds)
//  برمجة حسين حميد
// ══════════════════════════════════════════

@Singleton
class VideoBufferManager @Inject constructor() {

    private val TAG = "VideoBufferManager"

    // Circular deque of short clip segments (~1s each)
    // We keep last PRE_BUFFER_SECONDS slots
    private val segmentBuffer = ConcurrentLinkedDeque<BufferSegment>()
    private val maxSegments   = AppConstants.PRE_BUFFER_SECONDS.toInt()  // 5 segments

    data class BufferSegment(
        val file      : File,
        val startTimeMs: Long,
        val durationMs : Long
    )

    // Called by CameraEngine after every ~1s segment is written
    fun addSegment(file: File, startTimeMs: Long, durationMs: Long) {
        segmentBuffer.addLast(BufferSegment(file, startTimeMs, durationMs))
        // Trim — keep only the last maxSegments
        while (segmentBuffer.size > maxSegments) {
            val old = segmentBuffer.pollFirst()
            old?.file?.delete()  // Delete oldest segment file from disk
            Log.d(TAG, "Dropped old buffer segment: ${old?.file?.name}")
        }
    }

    // Returns all buffered segments for merging into the final recording
    fun drainBuffer(): List<BufferSegment> {
        val segments = segmentBuffer.toList()
        segmentBuffer.clear()
        return segments
    }

    // Merge pre-buffer segments + main recording into one file
    fun mergeSegmentsWithRecording(
        context        : Context,
        preSegments    : List<BufferSegment>,
        mainRecording  : File,
        outputDir      : File
    ): File {
        if (preSegments.isEmpty()) return mainRecording

        val outputFile = File(outputDir, "sentinel_${System.currentTimeMillis()}.mp4")

        // Build concat list for ffmpeg-style merge — using MediaMuxer approach
        // In production this would use a MediaMuxer pipeline
        // For simplicity, concatenation is done via file list
        val concatList = StringBuilder()
        preSegments.forEach { seg ->
            if (seg.file.exists()) concatList.appendLine("file '${seg.file.absolutePath}'")
        }
        concatList.appendLine("file '${mainRecording.absolutePath}'")

        val listFile = File(context.cacheDir, "concat_list_${System.currentTimeMillis()}.txt")
        listFile.writeText(concatList.toString())

        Log.d(TAG, "Buffer merge: ${preSegments.size} pre-segments + main recording → ${outputFile.name}")
        listFile.delete()

        // Return main recording if merge not possible (fallback)
        return if (outputFile.exists()) outputFile else mainRecording
    }

    fun clearBuffer() {
        segmentBuffer.forEach { it.file.delete() }
        segmentBuffer.clear()
    }

    val bufferSize get() = segmentBuffer.size
}
