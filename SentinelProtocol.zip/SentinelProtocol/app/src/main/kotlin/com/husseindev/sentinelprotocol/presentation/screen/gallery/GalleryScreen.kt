package com.husseindev.sentinelprotocol.presentation.screen.gallery

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import coil3.video.VideoFrameDecoder
import com.husseindev.sentinelprotocol.domain.model.RecordingEvent
import com.husseindev.sentinelprotocol.domain.model.TriggerType
import com.husseindev.sentinelprotocol.domain.usecase.DeleteRecordingUseCase
import com.husseindev.sentinelprotocol.domain.usecase.GetAllRecordingsUseCase
import com.husseindev.sentinelprotocol.presentation.components.GlassmorphicCard
import com.husseindev.sentinelprotocol.presentation.theme.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import androidx.compose.ui.platform.LocalContext

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Gallery Screen
//  برمجة حسين حميد
// ══════════════════════════════════════════

@HiltViewModel
class GalleryViewModel @Inject constructor(
    getAllRecordings: GetAllRecordingsUseCase,
    private val deleteRecording: DeleteRecordingUseCase
) : ViewModel() {
    val recordings = getAllRecordings()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun delete(id: Long, filePath: String) {
        viewModelScope.launch {
            File(filePath).delete()
            deleteRecording(id)
        }
    }
}

@Composable
fun GalleryScreen(onBack: () -> Unit, viewModel: GalleryViewModel = hiltViewModel()) {
    val recordings by viewModel.recordings.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    Box(Modifier.fillMaxSize().background(DeepBlack).systemBarsPadding()) {
        Column(Modifier.fillMaxSize()) {
            // Header
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, null, tint = TextPrimary)
                }
                Text("معرض التسجيلات", color = TextPrimary, fontSize = 20.sp,
                    fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
                Spacer(Modifier.weight(1f))
                Text("${recordings.size}", color = TealLight, fontSize = 14.sp, fontFamily = TajawalFamily)
            }

            if (recordings.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.VideoLibrary, null, tint = TextDim, modifier = Modifier.size(64.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("لا توجد تسجيلات بعد", color = TextDim, fontFamily = TajawalFamily)
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement   = Arrangement.spacedBy(10.dp)
                ) {
                    items(recordings, key = { it.id }) { rec ->
                        RecordingCard(rec = rec, onDelete = { viewModel.delete(rec.id, rec.filePath) })
                    }
                }
            }
        }
    }
}

@Composable
private fun RecordingCard(rec: RecordingEvent, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    val fmt = remember { SimpleDateFormat("MM/dd HH:mm", Locale.getDefault()) }

    GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
        Box {
            // Thumbnail
            AsyncImage(
                model = ImageRequest.Builder(ctx)
                    .data(rec.filePath)
                    .decoderFactory { res, opt, _ -> VideoFrameDecoder(res.source, opt) }
                    .crossfade(true).build(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(20.dp))
            )
            // Overlay info
            Column(
                Modifier.align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .background(DeepBlack.copy(0.7f), RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp))
                    .padding(8.dp)
            ) {
                Text(fmt.format(Date(rec.timestamp)), color = TextSecondary, fontSize = 10.sp, fontFamily = TajawalFamily)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = when (rec.triggerType) {
                            TriggerType.MOTION_FACE   -> "وجه"
                            TriggerType.MOTION_PERSON -> "شخص"
                            TriggerType.EMERGENCY_VOLUME -> "طارئ"
                            TriggerType.MANUAL        -> "يدوي"
                        },
                        color = if (rec.isEmergency) RecordingRed else TealLight,
                        fontSize = 10.sp, fontFamily = TajawalFamily
                    )
                    Icon(Icons.Default.Delete, null, tint = RecordingRed.copy(0.7f),
                        modifier = Modifier.size(16.dp).clickable { onDelete() })
                }
            }
            // Emergency badge
            if (rec.isEmergency) {
                Box(Modifier.align(Alignment.TopEnd).padding(6.dp)
                    .background(RecordingRed, RoundedCornerShape(4.dp)).padding(2.dp, 1.dp)) {
                    Text("SOS", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
                }
            }
        }
    }
}
