package com.husseindev.sentinelprotocol.presentation.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Theme
//  Dark Glassmorphism — Black & Teal
//  برمجة حسين حميد
// ══════════════════════════════════════════

private val SentinelColorScheme = darkColorScheme(
    primary          = TealPrimary,
    onPrimary        = DeepBlack,
    primaryContainer = TealDark,
    onPrimaryContainer = TealLight,

    secondary        = TealLight,
    onSecondary      = DeepBlack,
    secondaryContainer = Color(0xFF003D33),
    onSecondaryContainer = TealLight,

    background       = DeepBlack,
    onBackground     = TextPrimary,

    surface          = SurfaceBlack,
    onSurface        = TextPrimary,
    surfaceVariant   = CardBlack,
    onSurfaceVariant = TextSecondary,

    outline          = GlassBorder,
    outlineVariant   = Color(0xFF1C2333),

    error            = RecordingRed,
    onError          = DeepBlack,

    inverseSurface   = TextPrimary,
    inverseOnSurface = DeepBlack,
)

@Composable
fun SentinelTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SentinelColorScheme,
        typography  = SentinelTypography,
        content     = content
    )
}
