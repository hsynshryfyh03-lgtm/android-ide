package com.husseindev.sentinelprotocol.camera.analysis

import android.annotation.SuppressLint
import android.graphics.RectF
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.husseindev.sentinelprotocol.domain.model.DetectedFace
import com.husseindev.sentinelprotocol.domain.model.DetectionResult
import com.husseindev.sentinelprotocol.domain.model.SensitivityLevel

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Face Detection
//  ML Kit bundled model — CameraX Analyzer
//  برمجة حسين حميد
// ══════════════════════════════════════════

class FaceDetectionAnalyzer(
    private val sensitivity   : SensitivityLevel = SensitivityLevel.MEDIUM,
    private val onDetection   : (DetectionResult) -> Unit,
    private val onNoDetection : () -> Unit
) : ImageAnalysis.Analyzer {

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)   // Low battery usage
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_NONE)         // Not needed for trigger
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_NONE)
            .setMinFaceSize(0.15f)                                           // Detect faces ≥15% of frame
            .enableTracking()                                                // Track IDs for stability
            .build()
    )

    // Throttle: process every N frames to save CPU
    private var frameCount = 0
    private val processEveryNFrames = when (sensitivity) {
        SensitivityLevel.HIGH   -> 1   // Every frame
        SensitivityLevel.MEDIUM -> 2   // Every 2nd frame
        SensitivityLevel.LOW    -> 4   // Every 4th frame
    }

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        frameCount++
        if (frameCount % processEveryNFrames != 0) {
            imageProxy.close()
            return
        }

        val mediaImage = imageProxy.image
        if (mediaImage == null) { imageProxy.close(); return }

        val inputImage = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)

        detector.process(inputImage)
            .addOnSuccessListener { faces ->
                val filteredFaces = faces
                    .filter { it.trackingId != null }           // Only stable tracked faces
                    .map { face -> face.toDetectedFace() }

                if (filteredFaces.isNotEmpty()) {
                    onDetection(
                        DetectionResult(
                            faces     = filteredFaces,
                            timestamp = System.currentTimeMillis()
                        )
                    )
                } else {
                    onNoDetection()
                }
            }
            .addOnFailureListener { /* silent fail — no crash */ }
            .addOnCompleteListener { imageProxy.close() }
    }

    private fun Face.toDetectedFace() = DetectedFace(
        boundingBox = RectF(
            boundingBox.left.toFloat(),
            boundingBox.top.toFloat(),
            boundingBox.right.toFloat(),
            boundingBox.bottom.toFloat()
        ),
        confidence = 1.0f,     // ML Kit Face doesn't expose raw confidence — tracking implies high confidence
        trackingId = trackingId
    )
}
