package com.husseindev.sentinelprotocol.presentation.screen.calculator

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ripple
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.husseindev.sentinelprotocol.camera.CameraEngine
import com.husseindev.sentinelprotocol.domain.model.CameraFacing
import com.husseindev.sentinelprotocol.presentation.theme.*
import kotlinx.coroutines.flow.collectLatest

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Calculator Screen
//  iOS 26 Glassmorphism — Full Functional
//  برمجة حسين حميد
// ══════════════════════════════════════════

private val calcKeys = listOf(
    listOf("C", "⌫", "%", "÷"),
    listOf("7", "8", "9", "×"),
    listOf("4", "5", "6", "-"),
    listOf("1", "2", "3", "+"),
    listOf("00", "0", ".", "=")
)

@Composable
fun CalculatorScreen(
    onUnlocked     : () -> Unit,
    cameraEngine   : CameraEngine,
    viewModel      : CalculatorViewModel = hiltViewModel()
) {
    val state   by viewModel.uiState.collectAsStateWithLifecycle()
    val haptic  = LocalHapticFeedback.current

    // Handle navigation events
    LaunchedEffect(Unit) {
        viewModel.events.collectLatest { event ->
            when (event) {
                is CalcEvent.NavigateToDashboard   -> onUnlocked()
                is CalcEvent.TriggerIntruderSelfie -> {
                    // Capture silent selfie using front camera
                    cameraEngine.captureIntruderSelfie(
                        attemptNumber = 1,
                        onCaptured    = { file -> viewModel.onIntruderCapture(file.absolutePath) }
                    )
                }
                is CalcEvent.TriggerPanicWipe -> { /* screen handled below */ }
            }
        }
    }

    // Panic wipe overlay
    AnimatedVisibility(
        visible = state.isWiping,
        enter   = fadeIn(), exit = fadeOut()
    ) {
        Box(
            Modifier.fillMaxSize().background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Text("...", color = RecordingRed, fontSize = 24.sp, fontFamily = TajawalFamily)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .systemBarsPadding()
    ) {
        // Background glow blobs
        GlowBlob(Modifier.align(Alignment.TopEnd).offset(x = 60.dp, y = (-40).dp))
        GlowBlob(Modifier.align(Alignment.BottomStart).offset(x = (-40).dp, y = 60.dp), TealDark)

        Column(
            modifier            = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Bottom
        ) {
            // ── Display ───────────────────────────
            Box(
                modifier         = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                contentAlignment = Alignment.BottomEnd
            ) {
                Column(horizontalAlignment = Alignment.End) {
                    // Secondary row (expression)
                    if (state.display != state.inputBuffer && state.inputBuffer.isNotEmpty()) {
                        Text(
                            text       = state.inputBuffer,
                            color      = TextDim,
                            fontSize   = 22.sp,
                            fontFamily = TajawalFamily,
                            modifier   = Modifier.padding(end = 8.dp)
                        )
                    }
                    // Main display
                    val fontSize = when {
                        state.display.length > 12 -> 32.sp
                        state.display.length > 8  -> 46.sp
                        else                      -> 64.sp
                    }
                    Text(
                        text      = state.display,
                        color     = TextPrimary,
                        fontSize  = fontSize,
                        fontWeight= FontWeight.Bold,
                        fontFamily= TajawalFamily,
                        maxLines  = 1,
                        textAlign = TextAlign.End,
                        modifier  = Modifier.padding(horizontal = 8.dp)
                    )
                }
            }

            // ── Keypad ────────────────────────────
            Column(
                modifier            = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                calcKeys.forEach { row ->
                    Row(
                        modifier            = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        row.forEach { key ->
                            CalcKey(
                                label    = key,
                                modifier = Modifier.weight(1f),
                                onClick  = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    viewModel.onKey(key)
                                }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun CalcKey(label: String, modifier: Modifier, onClick: () -> Unit) {
    val isOperator  = label in listOf("+", "-", "×", "÷", "=")
    val isSpecial   = label in listOf("C", "⌫", "%")
    val interSource = remember { MutableInteractionSource() }

    val bgBrush = when {
        isOperator -> Brush.linearGradient(listOf(TealPrimary.copy(0.9f), TealDark.copy(0.8f)))
        isSpecial  -> Brush.linearGradient(listOf(ElevatedBlack, CardBlack))
        else       -> Brush.linearGradient(listOf(CardBlack, ElevatedBlack))
    }

    val textColor = when {
        isOperator -> DeepBlack
        isSpecial  -> TealLight
        else       -> TextPrimary
    }

    val shape = RoundedCornerShape(18.dp)

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .aspectRatio(1f)
            .clip(shape)
            .background(bgBrush)
            .border(
                width  = 1.dp,
                brush  = Brush.linearGradient(
                    colors = listOf(GlassBorder, Color.Transparent)
                ),
                shape  = shape
            )
            .drawBehind {
                if (isOperator) {
                    drawIntoCanvas { canvas ->
                        val paint = Paint().apply {
                            asFrameworkPaint().setShadowLayer(12f, 0f, 4f, TealGlow.toArgb())
                        }
                        canvas.drawRoundRect(0f,0f,size.width,size.height,18.dp.toPx(),18.dp.toPx(),paint)
                    }
                }
            }
            .clickable(
                interactionSource = interSource,
                indication = ripple(color = TealLight.copy(alpha = 0.3f))
            ) { onClick() }
    ) {
        Text(
            text       = label,
            color      = textColor,
            fontSize   = 26.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = TajawalFamily
        )
    }
}

@Composable
private fun GlowBlob(modifier: Modifier, color: Color = TealDark) {
    Box(
        modifier = modifier
            .size(200.dp)
            .blur(100.dp)
            .background(
                brush = Brush.radialGradient(listOf(color.copy(alpha = 0.4f), Color.Transparent)),
                shape = CircleShape
            )
    )
}
