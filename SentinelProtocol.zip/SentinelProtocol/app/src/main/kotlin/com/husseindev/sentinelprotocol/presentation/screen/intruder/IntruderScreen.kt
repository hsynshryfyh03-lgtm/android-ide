package com.husseindev.sentinelprotocol.presentation.screen.intruder

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.husseindev.sentinelprotocol.domain.model.IntruderPhoto
import com.husseindev.sentinelprotocol.domain.usecase.GetIntruderPhotosUseCase
import com.husseindev.sentinelprotocol.presentation.components.GlassmorphicCard
import com.husseindev.sentinelprotocol.presentation.theme.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Intruder Screen
//  برمجة حسين حميد
// ══════════════════════════════════════════

@HiltViewModel
class IntruderViewModel @Inject constructor(getPhotos: GetIntruderPhotosUseCase) : ViewModel() {
    val photos = getPhotos().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
}

@Composable
fun IntruderScreen(onBack: () -> Unit, viewModel: IntruderViewModel = hiltViewModel()) {
    val photos by viewModel.photos.collectAsStateWithLifecycle()
    val ctx = LocalContext.current

    Box(Modifier.fillMaxSize().background(DeepBlack).systemBarsPadding()) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, null, tint = TextPrimary)
                }
                Text("صور المتطفلين", color = RecordingRed, fontSize = 20.sp,
                    fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
                Spacer(Modifier.weight(1f))
                Box(Modifier.background(RecordingRed.copy(0.2f), RoundedCornerShape(8.dp)).padding(horizontal = 10.dp, vertical = 4.dp)) {
                    Text("${photos.size}", color = RecordingRed, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
                }
            }

            if (photos.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Security, null, tint = ActiveGreen, modifier = Modifier.size(64.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("لا يوجد متطفلون", color = ActiveGreen, fontFamily = TajawalFamily, fontSize = 16.sp)
                        Text("النظام محمي", color = TextDim, fontFamily = TajawalFamily, fontSize = 13.sp)
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement   = Arrangement.spacedBy(10.dp)
                ) {
                    items(photos, key = { it.id }) { photo ->
                        IntruderCard(photo = photo, ctx = ctx)
                    }
                }
            }
        }
    }
}

@Composable
private fun IntruderCard(photo: IntruderPhoto, ctx: android.content.Context) {
    val fmt = remember { SimpleDateFormat("MM/dd HH:mm:ss", Locale.getDefault()) }
    GlassmorphicCard(glowColor = RecordingRedGlow) {
        Box {
            AsyncImage(
                model = ImageRequest.Builder(ctx).data(photo.filePath).crossfade(true).build(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(140.dp).clip(RoundedCornerShape(20.dp))
            )
            Box(Modifier.align(Alignment.TopStart).padding(6.dp)
                .background(RecordingRed, RoundedCornerShape(4.dp)).padding(3.dp, 2.dp)) {
                Text("#${photo.attemptNumber}", color = Color.White, fontSize = 9.sp,
                    fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
            }
            Box(Modifier.align(Alignment.BottomStart).fillMaxWidth()
                .background(DeepBlack.copy(0.75f), RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp))
                .padding(8.dp)) {
                Text(fmt.format(Date(photo.timestamp)), color = TextSecondary, fontSize = 10.sp, fontFamily = TajawalFamily)
            }
        }
    }
}
