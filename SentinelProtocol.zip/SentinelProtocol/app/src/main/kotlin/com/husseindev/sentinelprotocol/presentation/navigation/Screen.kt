package com.husseindev.sentinelprotocol.presentation.navigation

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Navigation
//  برمجة حسين حميد
// ══════════════════════════════════════════

sealed class Screen(val route: String) {
    object Calculator : Screen("calculator")
    object Dashboard  : Screen("dashboard")
    object Monitoring : Screen("monitoring")
    object Gallery    : Screen("gallery")
    object Settings   : Screen("settings")
    object Intruder   : Screen("intruder")
}
