package com.husseindev.sentinelprotocol.data.local.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.husseindev.sentinelprotocol.core.constants.AppConstants
import com.husseindev.sentinelprotocol.domain.model.CameraFacing
import com.husseindev.sentinelprotocol.domain.model.SentinelConfig
import com.husseindev.sentinelprotocol.domain.model.SensitivityLevel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Settings DataStore
//  برمجة حسين حميد
// ══════════════════════════════════════════

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "sentinel_prefs")

@Singleton
class SettingsDataStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val PIN               = stringPreferencesKey(AppConstants.DS_PIN_KEY)
        val PANIC_CODE        = stringPreferencesKey(AppConstants.DS_PANIC_KEY)
        val MONITORING_ACTIVE = booleanPreferencesKey(AppConstants.DS_MONITORING_ACTIVE)
        val CAMERA_FACING     = stringPreferencesKey(AppConstants.DS_CAMERA_FACING)
        val SENSITIVITY       = stringPreferencesKey(AppConstants.DS_SENSITIVITY)
        val AUTO_START        = booleanPreferencesKey(AppConstants.DS_AUTO_START)
        val EMERGENCY_ENABLED = booleanPreferencesKey(AppConstants.DS_EMERGENCY_ENABLED)
        val BATTERY_THRESHOLD = intPreferencesKey("battery_threshold")
    }

    val configFlow: Flow<SentinelConfig> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { prefs ->
            SentinelConfig(
                pin                   = prefs[Keys.PIN]               ?: AppConstants.DEFAULT_PIN,
                panicCode             = prefs[Keys.PANIC_CODE]        ?: AppConstants.PANIC_CODE,
                cameraFacing          = CameraFacing.valueOf(prefs[Keys.CAMERA_FACING] ?: CameraFacing.BACK.name),
                sensitivityLevel      = SensitivityLevel.valueOf(prefs[Keys.SENSITIVITY] ?: SensitivityLevel.MEDIUM.name),
                autoStartOnBoot       = prefs[Keys.AUTO_START]        ?: false,
                emergencyTriggerEnabled = prefs[Keys.EMERGENCY_ENABLED] ?: true,
                batteryStopThreshold  = prefs[Keys.BATTERY_THRESHOLD] ?: AppConstants.BATTERY_STOP_THRESHOLD
            )
        }

    val isMonitoringActive: Flow<Boolean> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[Keys.MONITORING_ACTIVE] ?: false }

    suspend fun updatePin(pin: String) {
        context.dataStore.edit { it[Keys.PIN] = pin }
    }

    suspend fun updatePanicCode(code: String) {
        context.dataStore.edit { it[Keys.PANIC_CODE] = code }
    }

    suspend fun setMonitoringActive(active: Boolean) {
        context.dataStore.edit { it[Keys.MONITORING_ACTIVE] = active }
    }

    suspend fun updateConfig(config: SentinelConfig) {
        context.dataStore.edit { prefs ->
            prefs[Keys.PIN]               = config.pin
            prefs[Keys.PANIC_CODE]        = config.panicCode
            prefs[Keys.CAMERA_FACING]     = config.cameraFacing.name
            prefs[Keys.SENSITIVITY]       = config.sensitivityLevel.name
            prefs[Keys.AUTO_START]        = config.autoStartOnBoot
            prefs[Keys.EMERGENCY_ENABLED] = config.emergencyTriggerEnabled
            prefs[Keys.BATTERY_THRESHOLD] = config.batteryStopThreshold
        }
    }
}
