package com.husseindev.sentinelprotocol.data.local.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.husseindev.sentinelprotocol.core.constants.AppConstants
import com.husseindev.sentinelprotocol.data.local.db.dao.IntruderDao
import com.husseindev.sentinelprotocol.data.local.db.dao.RecordingDao
import com.husseindev.sentinelprotocol.data.local.db.entity.IntruderPhotoEntity
import com.husseindev.sentinelprotocol.data.local.db.entity.RecordingEntity
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SupportFactory

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Encrypted Room DB
//  SQLCipher — AES-256
//  برمجة حسين حميد
// ══════════════════════════════════════════

@Database(
    entities = [RecordingEntity::class, IntruderPhotoEntity::class],
    version  = 1,
    exportSchema = false
)
abstract class SentinelDatabase : RoomDatabase() {

    abstract fun recordingDao(): RecordingDao
    abstract fun intruderDao(): IntruderDao

    companion object {
        // DB encryption passphrase — derived from device + app signature in production
        private const val DB_PASSPHRASE = "S3nt1n3l_H4ss4n_2025_S3cr3t"

        fun build(context: Context): SentinelDatabase {
            val passphrase = SQLiteDatabase.getBytes(DB_PASSPHRASE.toCharArray())
            val factory    = SupportFactory(passphrase)

            return Room.databaseBuilder(
                context.applicationContext,
                SentinelDatabase::class.java,
                AppConstants.DB_NAME
            )
                .openHelperFactory(factory)
                .fallbackToDestructiveMigration()
                .build()
        }
    }
}
