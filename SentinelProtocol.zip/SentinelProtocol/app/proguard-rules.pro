# ══════════════════════════════════════════
#  Sentinel Protocol — ProGuard Rules
#  برمجة حسين حميد
# ══════════════════════════════════════════

# Keep Hilt
-keep class dagger.hilt.** { *; }
-keep @dagger.hilt.android.lifecycle.HiltViewModel class * { *; }

# Keep Room entities
-keep class com.husseindev.sentinelprotocol.data.local.db.entity.** { *; }

# Keep domain models
-keep class com.husseindev.sentinelprotocol.domain.model.** { *; }

# SQLCipher
-keep class net.sqlcipher.** { *; }
-dontwarn net.sqlcipher.**

# ML Kit
-keep class com.google.mlkit.** { *; }
-dontwarn com.google.mlkit.**

# CameraX
-keep class androidx.camera.** { *; }
-dontwarn androidx.camera.**

# Kotlin Coroutines
-keepclassmembernames class kotlinx.** { volatile <fields>; }
-dontwarn kotlinx.coroutines.**

# Coil
-dontwarn coil.**

# DataStore
-keepclassmembers class * extends com.google.protobuf.GeneratedMessageLite { <fields>; }
