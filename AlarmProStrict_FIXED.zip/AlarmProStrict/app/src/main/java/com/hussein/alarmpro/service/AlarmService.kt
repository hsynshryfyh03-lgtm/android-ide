package com.hussein.alarmpro.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.*
import com.hussein.alarmpro.data.repository.AlarmRepository
import com.hussein.alarmpro.receiver.AlarmReceiver
import com.hussein.alarmpro.util.*
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import javax.inject.Inject

@AndroidEntryPoint
class AlarmService : Service() {

    companion object {
        const val ACTION_START   = "com.hussein.alarmpro.START"
        const val ACTION_SNOOZE  = "com.hussein.alarmpro.SNOOZE"
        const val ACTION_DISMISS = "com.hussein.alarmpro.DISMISS"
    }

    @Inject lateinit var repository: AlarmRepository
    @Inject lateinit var scheduler: AlarmScheduler
    @Inject lateinit var preAlarmScheduler: PreAlarmScheduler
    @Inject lateinit var notifHelper: NotificationHelper
    @Inject lateinit var soundManager: SoundManager
    @Inject lateinit var wakeLock: WakeLockManager
    @Inject lateinit var dndHelper: DndHelper
    @Inject lateinit var ringingState: RingingStateHolder
    @Inject lateinit var strictModeManager: StrictModeManager   // ← NEW

    private var vibrator: Vibrator? = null
    private var gradualJob: Job? = null
    private var autoSnoozeJob: Job? = null
    private var autoDismissJob: Job? = null
    private var snoozeCount = 0
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        notifHelper.createChannels()
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION") getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getIntExtra("alarm_id", -1) ?: return START_NOT_STICKY
        val isWakeCheck = intent.getBooleanExtra("is_wake_check", false)

        when (intent.action) {
            ACTION_START -> {
                // Must call startForeground within 5 seconds — use placeholder then update
                startForeground(NotificationHelper.FG_ID, notifHelper.buildPlaceholderNotification())
                startAlarm(id, isWakeCheck)
            }
            ACTION_SNOOZE  -> handleSnooze(id)
            ACTION_DISMISS -> handleDismiss(id)
        }
        return START_NOT_STICKY
    }

    private fun startAlarm(alarmId: Int, isWakeCheck: Boolean = false) {
        scope.launch {
            val alarm = repository.getById(alarmId) ?: run { stopSelf(); return@launch }

            ringingState.setRinging(alarmId)
            wakeLock.acquire()

            if (alarm.bypassDnd) dndHelper.prepareForAlarm()

            // ── Strict Mode: engage fortress ──────────────────────────────
            if (alarm.strictMode) {
                strictModeManager.engage(alarmId)
            }

            withContext(Dispatchers.Main) {
                // Update notification with real alarm info
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                nm.notify(NotificationHelper.FG_ID, notifHelper.buildAlarmNotification(alarm))

                startActivity(
                    Intent(this@AlarmService,
                        com.hussein.alarmpro.ui.screens.RingingActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                        putExtra("alarm_id", alarmId)
                        putExtra("dismiss_type", alarm.dismissType)
                    }
                )

                // Gradual volume
                if (alarm.gradualVolume) {
                    val startVol = if (alarm.strictMode) 40 else 5 // strict: never start silent
                    soundManager.play(alarm.soundUri, startVol)
                    gradualJob = scope.launch {
                        val steps = alarm.gradualVolumeDurationSec
                        val targetVol = alarm.volumePercent
                        for (step in 1..steps) {
                            delay(1000L)
                            val vol = (targetVol * step / steps).coerceIn(startVol, targetVol)
                            soundManager.setVolume(vol)
                            // In strict mode: also enforce alarm stream max
                            if (alarm.strictMode) strictModeManager.forceMaxAlarmVolume()
                        }
                    }
                } else {
                    soundManager.play(alarm.soundUri, alarm.volumePercent)
                    if (alarm.strictMode) strictModeManager.forceMaxAlarmVolume()
                }

                if (alarm.isVibrate) vibrate(alarm.vibrationPattern)
            }

            // Auto-snooze (disabled in strict mode — task is the only exit)
            if (!alarm.strictMode && !isWakeCheck && alarm.autoSnoozeMinutes > 0) {
                autoSnoozeJob = scope.launch {
                    delay(alarm.autoSnoozeMinutes * 60_000L)
                    handleSnooze(alarmId)
                }
            }

            // Auto-dismiss
            val autoDismissAfterMin = when {
                isWakeCheck && alarm.wakeCheckCountdownMinutes > 0 -> alarm.wakeCheckCountdownMinutes
                !isWakeCheck && alarm.autoDissmissMinutes > 0      -> alarm.autoDissmissMinutes
                else -> -1
            }
            if (autoDismissAfterMin > 0) {
                autoDismissJob = scope.launch {
                    delay(autoDismissAfterMin * 60_000L)
                    handleDismiss(alarmId, skipWakeCheck = true)
                }
            }
        }
    }

    private fun handleSnooze(alarmId: Int) {
        scope.launch {
            val alarm = repository.getById(alarmId) ?: run { stopSelf(); return@launch }

            // Strict mode: snooze is allowed (just delays, doesn't dismiss)
            // but we still disengage and re-engage when it fires again
            if (alarm.snoozeMaxCount != -1 && snoozeCount >= alarm.snoozeMaxCount) {
                handleDismiss(alarmId)
                return@launch
            }

            gradualJob?.cancel(); autoSnoozeJob?.cancel(); autoDismissJob?.cancel()
            soundManager.stop()
            vibrator?.cancel()
            wakeLock.release()
            if (alarm.bypassDnd) dndHelper.restore()
            ringingState.clearRinging()

            // ── Strict Mode: disengage until next fire ─────────────────────
            if (alarm.strictMode) strictModeManager.disengage()

            snoozeCount++
            val min = maxOf(1, alarm.snoozeMinutes - alarm.snoozeReduceMinutes * (snoozeCount - 1))
            val triggerAt = System.currentTimeMillis() + min * 60_000L
            val pi = PendingIntent.getBroadcast(
                this@AlarmService, alarmId + 99000,
                Intent(this@AlarmService, AlarmReceiver::class.java).apply {
                    action = "com.hussein.alarmpro.ACTION_ALARM_FIRE"
                    putExtra("alarm_id", alarmId)
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            (getSystemService(Context.ALARM_SERVICE) as AlarmManager)
                .setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)

            withContext(Dispatchers.Main) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                sendBroadcast(Intent("com.hussein.alarmpro.ACTION_CLOSE_RING"))
                stopSelf()
            }
        }
    }

    private fun handleDismiss(alarmId: Int, skipWakeCheck: Boolean = false) {
        scope.launch {
            val alarm = repository.getById(alarmId)
            gradualJob?.cancel(); autoSnoozeJob?.cancel(); autoDismissJob?.cancel()
            soundManager.stop()
            vibrator?.cancel()
            wakeLock.release()
            if (alarm?.bypassDnd == true) dndHelper.restore()
            ringingState.clearRinging()

            // ── Strict Mode: full disengage on successful dismiss ──────────
            if (alarm?.strictMode == true) strictModeManager.disengage()

            if (alarm != null) {
                if (alarm.days == 0 && alarm.scheduledDate == 0L) {
                    repository.update(alarm.copy(isEnabled = false))
                } else {
                    repository.update(alarm.copy(skipToday = false))
                    scheduler.schedule(alarm)
                    preAlarmScheduler.schedule(alarm)
                }
                if (!skipWakeCheck && alarm.wakeCheckEnabled && alarm.wakeCheckDelayMinutes > 0) {
                    val wakeCheckTrigger = System.currentTimeMillis() + alarm.wakeCheckDelayMinutes * 60_000L
                    val wakeCheckPi = PendingIntent.getBroadcast(
                        this@AlarmService, alarmId + 88000,
                        Intent(this@AlarmService, AlarmReceiver::class.java).apply {
                            action = "com.hussein.alarmpro.ACTION_WAKE_CHECK_FIRE"
                            putExtra("alarm_id", alarmId)
                        },
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    (getSystemService(Context.ALARM_SERVICE) as AlarmManager)
                        .setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, wakeCheckTrigger, wakeCheckPi)
                }
            }
            withContext(Dispatchers.Main) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                sendBroadcast(Intent("com.hussein.alarmpro.ACTION_CLOSE_RING"))
                stopSelf()
            }
        }
    }

    private fun vibrate(pattern: Int) {
        val p = when (pattern) {
            0 -> return
            2 -> longArrayOf(0, 200, 100, 200, 100, 400)
            3 -> longArrayOf(0, 100, 100, 200, 100, 400, 100, 800)
            else -> longArrayOf(0, 500, 200, 500)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            vibrator?.vibrate(VibrationEffect.createWaveform(p, 0))
        else @Suppress("DEPRECATION") vibrator?.vibrate(p, 0)
    }

    override fun onDestroy() {
        super.onDestroy()
        gradualJob?.cancel(); autoSnoozeJob?.cancel(); autoDismissJob?.cancel()
        soundManager.stop()
        vibrator?.cancel()
        wakeLock.release()
        ringingState.clearRinging()
        // Safety disengage on unexpected service death
        if (StrictModeManager.isStrictActive) strictModeManager.disengage()
        scope.cancel()
    }
}
