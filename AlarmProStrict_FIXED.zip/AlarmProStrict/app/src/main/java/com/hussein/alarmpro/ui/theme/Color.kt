package com.hussein.alarmpro.ui.theme

import androidx.compose.ui.graphics.Color

// ── iOS 26 Liquid Glass — Exact System Palette ────────────────────────────────
// Background system (true OLED black + navy depth)
val DeepBlack        = Color(0xFF000000)
val DarkNavy         = Color(0xFF04040F)
val DarkSurface      = Color(0xFF0A0A1A)

// Orb ambient lights (matches iOS 26 default wallpaper glow)
val OrbBlue          = Color(0xFF0A84FF)
val OrbPurple        = Color(0xFF5E5CE6)
val OrbIndigo        = Color(0xFF6B5CFE)
val OrbCyan          = Color(0xFF32D2FF)
val OrbPink          = Color(0xFFFF375F)
val OrbMint          = Color(0xFF00C7BE)
val OrbOrange        = Color(0xFFFF9F0A)

// ── Liquid Glass Material Tokens ──────────────────────────────────────────────
// iOS 26 glass spec: translucent white layers at precise alpha values
val GlassThin        = Color(0x0DFFFFFF)   // 5%  — ultra-thin visor
val GlassBg          = Color(0x1AFFFFFF)   // 10% — card background (iOS default)
val GlassBgHeavy     = Color(0x2BFFFFFF)   // 17% — modal / sheet
val GlassBgUltra     = Color(0x3DFFFFFF)   // 24% — nav bar / control panel
val GlassBorder      = Color(0x33FFFFFF)   // 20% — standard border
val GlassBorderLight = Color(0x1AFFFFFF)   // 10% — subtle inner ring
val GlassHighlight   = Color(0x3DFFFFFF)   // 24% — top-edge specular
val GlassShimmer     = Color(0x0AFFFFFF)   // 4%  — shimmer sweep
val GlassInnerShadow = Color(0x1A000000)   // inner shadow at bottom

// ── Text hierarchy (iOS 26 spec) ──────────────────────────────────────────────
val TextPrimary      = Color(0xFFFFFFFF)   // SF Pro — primary label
val TextSecondary    = Color(0xB3FFFFFF)   // 70% — secondary label
val TextTertiary     = Color(0x66FFFFFF)   // 40% — tertiary label
val TextQuaternary   = Color(0x2EFFFFFF)   // 18% — quaternary label
val TextAccent       = Color(0xFF0A84FF)   // blue accent (tintColor)

// iOS system colors (dark mode)
val SystemGreen      = Color(0xFF30D158)
val SystemRed        = Color(0xFFFF453A)
val SystemYellow     = Color(0xFFFFD60A)
val ToggleOn         = Color(0xFF30D158)   // iOS green toggle
val ToggleOff        = Color(0xFF3A3A3C)   // iOS gray toggle track

// Separator / dividers
val Separator        = Color(0x29FFFFFF)
val SeparatorOpaque  = Color(0xFF38383A)

// ── Analog clock palette ──────────────────────────────────────────────────────
val ClockFaceColor   = Color(0x10FFFFFF)   // renamed from ClockFace to avoid conflict
val ClockRing        = Color(0x33FFFFFF)
val ClockHourHand    = Color(0xFFFFFFFF)
val ClockMinHand     = Color(0xCCFFFFFF)
val ClockSecHand     = Color(0xFFFF375F)
val ClockTick        = Color(0x80FFFFFF)
val ClockCenter      = Color(0xFF0A84FF)
val ClockNumber      = Color(0x99FFFFFF)

