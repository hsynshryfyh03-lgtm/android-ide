package com.hussein.alarmpro.ui.screens

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.ui.draw.clip
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.hussein.alarmpro.admin.AlarmDeviceAdmin
import com.hussein.alarmpro.util.XiaomiHelper
import com.hussein.alarmpro.data.datastore.AlarmTemplateStore
import com.hussein.alarmpro.ui.components.*
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.ExportImport
import com.hussein.alarmpro.util.TimeUtils
import com.hussein.alarmpro.viewmodel.AlarmViewModel
import androidx.compose.runtime.remember
import androidx.compose.runtime.produceState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: AlarmViewModel,
    onBack: () -> Unit,
    onAlarmGroups: () -> Unit = {},
    onVacationMode: () -> Unit = {}
) {
    val isAr = TimeUtils.isArabic()
    val ctx  = LocalContext.current
    val template by viewModel.template.collectAsState()
    var localTemplate by remember(template) { mutableStateOf(template) }
    var showImportDialog by remember { mutableStateOf(false) }
    var importJson by remember { mutableStateOf<String?>(null) }

    // Admin launcher
    val adminLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { /* result handled in isAdmin check */ }

    // Export file picker
    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            val json = viewModel.exportJson()
            ExportImport.writeToUri(ctx, uri, json)
        }
    }

    // Import file picker
    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val json = ExportImport.readFromUri(ctx, uri)
            if (json != null) { importJson = json; showImportDialog = true }
        }
    }

    if (showImportDialog && importJson != null) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            title = { Text(if (isAr) "استيراد المنبهات؟" else "Import Alarms?") },
            text  = {
                val count = runCatching {
                    ExportImport.importFromJson(importJson!!).size
                }.getOrDefault(0)
                Text(if (isAr) "سيتم إضافة $count منبه إلى القائمة"
                     else "Will add $count alarms to your list")
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.importFromJson(importJson!!)
                    showImportDialog = false
                }) { Text(if (isAr) "استيراد" else "Import", color = OrbBlue) }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text(if (isAr) "إلغاء" else "Cancel")
                }
            },
            containerColor = DarkNavy
        )
    }

    LiquidGlassBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = { Text(if (isAr) "الإعدادات" else "Settings",
                        style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold)) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Filled.ArrowBack, null, tint = TextSecondary)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                )
            }
        ) { pd ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(pd)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // ── Navigation ────────────────────────────────────────────
                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Apps, null, tint = OrbPurple, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(if (isAr) "الأقسام الإضافية" else "More Features",
                                style = MaterialTheme.typography.titleMedium)
                        }
                        HorizontalDivider(color = GlassBorder, thickness = 0.5.dp)

                        // Alarm Groups button
                        OutlinedButton(
                            onClick = onAlarmGroups,
                            modifier = Modifier.fillMaxWidth(),
                            border = BorderStroke(1.dp, OrbPurple),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = OrbPurple)
                        ) {
                            Icon(Icons.Filled.Layers, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                if (isAr) "مجموعات المنبهات" else "Alarm Groups",
                                modifier = Modifier.weight(1f)
                            )
                            Icon(Icons.Filled.ChevronRight, null, modifier = Modifier.size(16.dp))
                        }

                        // Vacation Mode button
                        OutlinedButton(
                            onClick = onVacationMode,
                            modifier = Modifier.fillMaxWidth(),
                            border = BorderStroke(1.dp, OrbCyan),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = OrbCyan)
                        ) {
                            Icon(Icons.Filled.WbSunny, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                if (isAr) "وضع الإجازة" else "Vacation Mode",
                                modifier = Modifier.weight(1f)
                            )
                            Icon(Icons.Filled.ChevronRight, null, modifier = Modifier.size(16.dp))
                        }
                    }
                }

                // ── Default Template ──────────────────────────────────────
                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Tune, null, tint = OrbBlue, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(if (isAr) "القالب الافتراضي" else "Default Template",
                                style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            if (isAr) "هذه الإعدادات تُطبق تلقائياً على كل منبه جديد"
                            else "These settings apply automatically to every new alarm",
                            style = MaterialTheme.typography.bodySmall
                        )
                        HorizontalDivider(color = GlassBorder, thickness = 0.5.dp)

                        // Volume
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.VolumeUp, null, tint = TextTertiary, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (isAr) "الصوت" else "Volume",
                                style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            Slider(
                                value = localTemplate.volumePercent.toFloat(),
                                onValueChange = { localTemplate = localTemplate.copy(volumePercent = it.toInt()) },
                                valueRange = 0f..100f,
                                modifier = Modifier.width(150.dp),
                                colors = SliderDefaults.colors(thumbColor = OrbBlue, activeTrackColor = OrbBlue,
                                    inactiveTrackColor = GlassBorder)
                            )
                            Text("${localTemplate.volumePercent}%", style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.width(36.dp))
                        }

                        // Snooze default
                        StepSetting(
                            label = if (isAr) "مدة الغفوة" else "Snooze duration",
                            value = localTemplate.snoozeMinutes, unit = if (isAr) "د" else "m",
                            range = 1..60,
                            onValueChange = { localTemplate = localTemplate.copy(snoozeMinutes = it) }
                        )

                        // Dismiss task
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (isAr) "مهمة الإيقاف" else "Dismiss task",
                                style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            val tasks = if (isAr) listOf("بدون","رياضيات","كتابة","QR")
                                        else listOf("None","Math","Write","QR")
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                tasks.forEachIndexed { i, t ->
                                    FilterChip(
                                        selected = localTemplate.dismissTask == i,
                                        onClick  = { localTemplate = localTemplate.copy(dismissTask = i) },
                                        label = { Text(t, fontSize = 10.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = OrbBlue.copy(0.3f),
                                            selectedLabelColor = OrbBlue)
                                    )
                                }
                            }
                        }

                        // Pre-alarm
                        StepSetting(
                            label = if (isAr) "إشعار مسبق" else "Pre-alarm",
                            value = localTemplate.preAlarmNotifyMinutes,
                            unit = if (isAr) "د" else "m",
                            range = -1..60,
                            onValueChange = { localTemplate = localTemplate.copy(preAlarmNotifyMinutes = it) }
                        )

                        HorizontalDivider(color = GlassBorder, thickness = 0.5.dp)
                        Button(
                            onClick = { viewModel.saveTemplate(localTemplate) },
                            colors = ButtonDefaults.buttonColors(containerColor = OrbBlue),
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (isAr) "حفظ القالب" else "Save Template") }
                    }
                }

                // ── Export / Import ────────────────────────────────────────
                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.ImportExport, null, tint = OrbBlue, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(if (isAr) "تصدير / استيراد" else "Export / Import",
                                style = MaterialTheme.typography.titleMedium)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    exportLauncher.launch("alarms_${System.currentTimeMillis()}.json")
                                },
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(1.dp, OrbBlue),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = OrbBlue)
                            ) {
                                Icon(Icons.Filled.Upload, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(if (isAr) "تصدير" else "Export")
                            }
                            OutlinedButton(
                                onClick = { importLauncher.launch(arrayOf("application/json","*/*")) },
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(1.dp, OrbPurple),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = OrbPurple)
                            ) {
                                Icon(Icons.Filled.Download, null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text(if (isAr) "استيراد" else "Import")
                            }
                        }

                        OutlinedButton(
                            onClick = { viewModel.shareExport() },
                            modifier = Modifier.fillMaxWidth(),
                            border = BorderStroke(1.dp, OrbCyan),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = OrbCyan)
                        ) {
                            Icon(Icons.Filled.Share, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (isAr) "مشاركة الإعدادات" else "Share Settings")
                        }
                    }
                }

                // ── App Protection ────────────────────────────────────────
                val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                val adminComp = ComponentName(ctx, AlarmDeviceAdmin::class.java)
                val isAdmin = dpm.isAdminActive(adminComp)

                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Shield, null, tint = if (isAdmin) ToggleOn else OrbPink,
                                modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(if (isAr) "حماية التطبيق" else "App Protection",
                                style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            if (isAdmin)
                                (if (isAr) "✅ التطبيق محمي من الحذف" else "✅ App protected from uninstall")
                            else
                                (if (isAr) "⚠️ فعّل مشرف الجهاز لمنع حذف التطبيق"
                                 else "⚠️ Enable device admin to prevent uninstall"),
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (isAdmin) ToggleOn else OrbPink
                            )
                        )
                        if (!isAdmin) {
                            Button(
                                onClick = {
                                    adminLauncher.launch(
                                        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                                            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComp)
                                            putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                                                if (isAr) "يحتاج المنبه صلاحية المشرف ليمنع حذفه عن طريق الخطأ"
                                                else "Alarm needs admin rights to prevent accidental uninstall")
                                        }
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = OrbPink),
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(if (isAr) "تفعيل الحماية" else "Enable Protection") }
                        }
                    }
                }


                // ── Xiaomi / HyperOS Optimization ───────────────────────
                if (XiaomiHelper.isXiaomi()) {
                    GlassCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.PhoneAndroid, null,
                                    tint = OrbCyan, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(if (isAr) "تحسينات شاومي / HyperOS" else "Xiaomi Optimization",
                                    style = MaterialTheme.typography.titleMedium)
                            }
                            Text(
                                if (isAr) "يجب تفعيل التشغيل التلقائي ومنع البطارية من إيقاف التطبيق"
                                else "Enable Autostart and disable battery optimization for reliable alarms",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { XiaomiHelper.openAutoStartSettings(ctx) },
                                    colors = ButtonDefaults.buttonColors(containerColor = OrbCyan),
                                    modifier = Modifier.weight(1f)
                                ) { Text(if (isAr) "تشغيل تلقائي" else "Autostart", fontSize = 12.sp) }
                                Button(
                                    onClick = { XiaomiHelper.openBatteryOptimizationSettings(ctx) },
                                    colors = ButtonDefaults.buttonColors(containerColor = OrbPurple),
                                    modifier = Modifier.weight(1f)
                                ) { Text(if (isAr) "البطارية" else "Battery", fontSize = 12.sp) }
                            }
                        }
                    }
                }

                // ── Strict Mode Guide ─────────────────────────────────────
                val strictServiceName = "${ctx.packageName}/com.hussein.alarmpro.service.StrictAccessibilityService"
                val a11yEnabled = remember {
                    val s = android.provider.Settings.Secure.getString(
                        ctx.contentResolver,
                        android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                    ) ?: ""
                    s.split(':').any { it.trim().equals(strictServiceName, true) }
                }

                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Lock, null, tint = OrbPink, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(if (isAr) "الوضع الصارم — المتطلبات" else "Strict Mode — Requirements",
                                style = MaterialTheme.typography.titleMedium)
                        }
                        Text(
                            if (isAr) "لتفعيل الوضع الصارم في أي منبه، يجب تفعيل المتطلبين التاليين:"
                            else "To use Strict Mode on any alarm, both requirements below must be active:",
                            style = MaterialTheme.typography.bodySmall
                        )
                        HorizontalDivider(color = GlassBorder, thickness = 0.5.dp)

                        // Admin row
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (isAdmin) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                                null, tint = if (isAdmin) ToggleOn else OrbPink, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(if (isAr) "مشرف الجهاز" else "Device Admin",
                                style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                            if (!isAdmin) {
                                TextButton(onClick = {
                                    adminLauncher.launch(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                                        putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComp)
                                    })
                                }) { Text(if (isAr) "تفعيل" else "Enable", color = OrbPink) }
                            }
                        }

                        // Accessibility row
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (a11yEnabled) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                                null, tint = if (a11yEnabled) ToggleOn else OrbPink, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(if (isAr) "خدمة إمكانية الوصول" else "Accessibility Service",
                                style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                            if (!a11yEnabled) {
                                TextButton(onClick = {
                                    ctx.startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                        .apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK })
                                }) { Text(if (isAr) "تفعيل" else "Enable", color = OrbPink) }
                            }
                        }

                        if (isAdmin && a11yEnabled) {
                            Row(
                                modifier = Modifier.fillMaxWidth()
                                    .clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
                                    .background(ToggleOn.copy(0.12f))
                                    .border(1.dp, ToggleOn.copy(0.4f), androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Filled.VerifiedUser, null, tint = ToggleOn, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(if (isAr) "✅ جاهز — يمكنك تفعيل الوضع الصارم في أي منبه"
                                     else "✅ Ready — You can enable Strict Mode on any alarm",
                                    style = MaterialTheme.typography.bodySmall.copy(color = ToggleOn))
                            }
                        }
                    }
                }

                // ── About ────────────────────────────────────────────────
                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("AlarmPro",
                            style = MaterialTheme.typography.titleLarge.copy(color = OrbBlue,
                                fontWeight = FontWeight.Bold))
                        Text("v1.0.0", style = MaterialTheme.typography.bodySmall)
                        HorizontalDivider(color = GlassBorder, thickness = 0.5.dp,
                            modifier = Modifier.padding(vertical = 8.dp))
                        Text("برمجة - حسين حميد الشريفي",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = TextAccent, fontWeight = FontWeight.SemiBold))
                    }
                }

                Spacer(Modifier.height(24.dp))
            }
        }
    }
}
