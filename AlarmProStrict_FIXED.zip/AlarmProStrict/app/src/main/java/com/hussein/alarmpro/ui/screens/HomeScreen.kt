package com.hussein.alarmpro.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.hussein.alarmpro.data.model.Alarm
import com.hussein.alarmpro.ui.components.*
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.AlarmScheduler
import com.hussein.alarmpro.util.TimeUtils
import com.hussein.alarmpro.viewmodel.AlarmViewModel
import kotlinx.coroutines.delay
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: AlarmViewModel,
    scheduler: AlarmScheduler,
    onAddAlarm: () -> Unit,
    onEditAlarm: (Alarm) -> Unit,
    onSettings: () -> Unit
) {
    val alarms by viewModel.alarms.collectAsState()
    val isAr = TimeUtils.isArabic()

    var clockFace by remember { mutableStateOf(ClockFaceStyle.CLASSIC) }
    var showFaceMenu by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val sorted = remember(alarms) {
        alarms.sortedWith(
            compareByDescending<Alarm> { it.isEnabled }.thenBy { it.hour * 60 + it.minute }
        )
    }

    // Detect scroll — shrink FAB on scroll down
    val isScrolled by remember {
        derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 40 }
    }

    LiquidGlassBackground {
        Box(Modifier.fillMaxSize()) {
            // ── Content ──────────────────────────────────────────────────────
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(
                    start = 16.dp, end = 16.dp,
                    top = 0.dp, bottom = 140.dp
                ),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                // Top bar spacer
                item { Spacer(Modifier.height(56.dp)) }

                // ── Clock Header ──────────────────────────────────────────────
                item {
                    ClockHeaderSection(
                        clockFace = clockFace,
                        alarms = sorted,
                        scheduler = scheduler,
                        isAr = isAr,
                        onLongPress = { showFaceMenu = true }
                    )
                }

                // Clock face picker
                item {
                    if (showFaceMenu) {
                        ClockFacePicker(
                            current = clockFace,
                            isAr = isAr,
                            onSelect = { clockFace = it; showFaceMenu = false },
                            onDismiss = { showFaceMenu = false }
                        )
                    }
                }

                // Section header
                if (sorted.isNotEmpty()) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (isAr) "المنبهات" else "ALARMS",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextTertiary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    letterSpacing = 1.sp
                                )
                            )
                            Spacer(Modifier.width(8.dp))
                            // Thin separator line
                            Box(
                                Modifier
                                    .weight(1f)
                                    .height(0.5.dp)
                                    .background(Separator)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "${sorted.size}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextTertiary, fontSize = 12.sp
                                )
                            )
                        }
                    }
                }

                // Alarm cards
                if (sorted.isEmpty()) {
                    item { EmptyAlarmsPlaceholder(isAr = isAr) }
                } else {
                    items(sorted, key = { it.id }) { alarm ->
                        val nextMillis = remember(alarm) { scheduler.nextTriggerMillis(alarm) }
                        AlarmCard(
                            alarm = alarm,
                            nextTriggerMillis = nextMillis,
                            onToggle = { en -> viewModel.toggleAlarm(alarm, en) },
                            onEdit   = { onEditAlarm(alarm) },
                            onDelete = { viewModel.deleteAlarm(alarm) }
                        )
                    }
                }
            }

            // ── iOS 26 Floating Top Bar ───────────────────────────────────────
            IosTopBar(
                isAr = isAr,
                onSettings = onSettings,
                modifier = Modifier.align(Alignment.TopCenter)
            )

            // ── iOS 26 Floating Bottom FAB ────────────────────────────────────
            IosFloatingAddButton(
                isAr = isAr,
                isScrolled = isScrolled,
                onClick = onAddAlarm,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 32.dp)
            )
        }
    }
}

// ── iOS 26 Top Bar — floats over content, glass material ──────────────────────
@Composable
private fun IosTopBar(isAr: Boolean, onSettings: () -> Unit, modifier: Modifier = Modifier) {
    // Live date display
    var now by remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Calendar.getInstance()
            delay(60_000)
        }
    }
    val dateStr = remember(now) {
        val days = arrayOf("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
        val months = arrayOf("January","February","March","April","May","June",
            "July","August","September","October","November","December")
        val arDays = arrayOf("الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت")
        val arMonths = arrayOf("يناير","فبراير","مارس","أبريل","مايو","يونيو",
            "يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر")
        val dow = now.get(Calendar.DAY_OF_WEEK) - 1
        val month = now.get(Calendar.MONTH)
        val day = now.get(Calendar.DAY_OF_MONTH)
        if (isAr) "${arDays[dow]}، $day ${arMonths[month]}"
        else "${days[dow]}, ${months[month]} $day"
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = if (isAr) "المنبه" else "Alarm",
                style = MaterialTheme.typography.headlineLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    fontSize = 34.sp
                )
            )
            Text(
                text = dateStr,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = TextTertiary, fontSize = 12.sp
                )
            )
        }

        // Settings button — iOS 26 glass circle
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(
                    Brush.verticalGradient(
                        listOf(Color.White.copy(0.22f), Color.White.copy(0.10f))
                    )
                )
                .border(
                    1.dp,
                    Brush.linearGradient(
                        listOf(Color.White.copy(0.50f), Color.White.copy(0.10f))
                    ),
                    CircleShape
                )
                .clickable { onSettings() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Filled.Settings, null,
                tint = TextPrimary,
                modifier = Modifier.size(17.dp)
            )
        }
    }
}

// ── Clock Header — large, immersive ───────────────────────────────────────────
@Composable
private fun ClockHeaderSection(
    clockFace: ClockFaceStyle,
    alarms: List<Alarm>,
    scheduler: AlarmScheduler,
    isAr: Boolean,
    onLongPress: () -> Unit
) {
    // Next alarm info
    val nextAlarm = remember(alarms) { alarms.firstOrNull { it.isEnabled } }
    val nextMillis = remember(nextAlarm) {
        nextAlarm?.let { scheduler.nextTriggerMillis(it) }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Clock
        Box(
            modifier = Modifier
                .pointerInput(Unit) {
                    detectTapGestures(onLongPress = { onLongPress() })
                }
                .padding(vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            // Subtle glow behind clock
            Box(
                Modifier
                    .size(220.dp)
                    .drawBehind {
                        drawCircle(
                            brush = Brush.radialGradient(
                                listOf(OrbBlue.copy(0.12f), Color.Transparent),
                                radius = size.minDimension * 0.7f
                            ),
                            radius = size.minDimension * 0.7f
                        )
                    }
            )
            AnalogClockWithFace(face = clockFace, size = 186.dp)
        }

        // Next alarm pill
        if (nextAlarm != null && nextMillis != null) {
            Spacer(Modifier.height(10.dp))
            val remaining = TimeUtils.timeUntilLabel(nextMillis, isAr)
            if (remaining.isNotBlank()) {
                GlassPill(color = OrbBlue) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                    ) {
                        Icon(
                            Icons.Filled.Alarm, null,
                            tint = OrbBlue,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(Modifier.width(5.dp))
                        Text(
                            text = if (isAr) "المنبه القادم: $remaining" else "Next alarm: $remaining",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = OrbBlue, fontSize = 12.sp, fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }
        } else {
            Spacer(Modifier.height(8.dp))
            Text(
                text = if (isAr) "اضغط مطولاً لتغيير وجه الساعة" else "Long press to change clock style",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = TextQuaternary, fontSize = 10.sp
                )
            )
        }
        Spacer(Modifier.height(4.dp))
    }
}

// ── Clock Face Picker — iOS action sheet style ────────────────────────────────
@Composable
private fun ClockFacePicker(
    current: ClockFaceStyle,
    isAr: Boolean,
    onSelect: (ClockFaceStyle) -> Unit,
    onDismiss: () -> Unit
) {
    val faces = listOf(
        ClockFaceStyle.CLASSIC to (if (isAr) "كلاسيكي" else "Classic"),
        ClockFaceStyle.MODERN  to (if (isAr) "حديث"    else "Modern"),
        ClockFaceStyle.DIGITAL to (if (isAr) "رقمي"    else "Digital"),
        ClockFaceStyle.MINIMAL to (if (isAr) "مينيمال" else "Minimal")
    )

    GlassCard(Modifier.fillMaxWidth(), cornerRadius = 20.dp) {
        Column(Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    Icons.Filled.Watch, null, tint = OrbBlue,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    if (isAr) "اختر وجه الساعة" else "Clock Style",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = TextSecondary, fontWeight = FontWeight.SemiBold
                    ),
                    modifier = Modifier.weight(1f)
                )
                Box(
                    Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(GlassBg)
                        .clickable { onDismiss() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Close, null, tint = TextTertiary, modifier = Modifier.size(13.dp))
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                faces.forEach { (face, label) ->
                    val sel = face == current
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (sel) OrbBlue.copy(0.22f)
                                else Color.White.copy(0.06f)
                            )
                            .border(
                                1.dp,
                                if (sel) OrbBlue.copy(0.7f) else Color.White.copy(0.15f),
                                RoundedCornerShape(14.dp)
                            )
                            .clickable { onSelect(face) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            label,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (sel) OrbBlue else TextTertiary,
                                fontSize = 10.sp,
                                fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal
                            )
                        )
                    }
                }
            }
        }
    }
}

// ── iOS 26 Floating Add Button — morphs on scroll ─────────────────────────────
@Composable
private fun IosFloatingAddButton(
    isAr: Boolean,
    isScrolled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "fab")
    val glowAlpha by transition.animateFloat(
        0.30f, 0.65f,
        infiniteRepeatable(tween(2000, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "glow"
    )

    // Width animate: full pill vs. icon-only
    val targetWidth by animateDpAsState(
        targetValue = if (isScrolled) 56.dp else 148.dp,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "width"
    )

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        // Outer ambient glow
        Box(
            Modifier
                .size(targetWidth + 20.dp, 76.dp)
                .drawBehind {
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(OrbBlue.copy(glowAlpha * 0.35f), Color.Transparent),
                            radius = size.minDimension * 1.0f
                        ),
                        radius = size.minDimension * 1.0f
                    )
                }
        )

        // Glass pill button
        Box(
            modifier = Modifier
                .width(targetWidth)
                .height(54.dp)
                .clip(RoundedCornerShape(27.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.White.copy(alpha = 0.28f),
                            OrbBlue.copy(alpha = 0.50f)
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(
                        listOf(
                            Color.White.copy(alpha = 0.60f),
                            Color.White.copy(alpha = 0.20f),
                            OrbBlue.copy(alpha = 0.15f)
                        )
                    ),
                    shape = RoundedCornerShape(27.dp)
                )
                .drawBehind {
                    // Top specular
                    drawRect(
                        brush = Brush.verticalGradient(
                            listOf(Color.White.copy(0.18f), Color.Transparent),
                            endY = size.height * 0.40f
                        )
                    )
                }
                .clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 18.dp)
            ) {
                Icon(
                    Icons.Filled.Add, null,
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
                if (!isScrolled) {
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = if (isAr) "منبه جديد" else "New Alarm",
                        style = MaterialTheme.typography.titleSmall.copy(
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp
                        )
                    )
                }
            }
        }
    }
}

// ── Empty State ──────────────────────────────────────────────────────────────
@Composable
private fun EmptyAlarmsPlaceholder(isAr: Boolean) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulse by transition.animateFloat(
        0.88f, 1.05f,
        infiniteRepeatable(tween(1800, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "pulse"
    )
    val glowA by transition.animateFloat(
        0.08f, 0.22f,
        infiniteRepeatable(tween(2200, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "ga"
    )

    Column(
        modifier = Modifier.fillMaxWidth().padding(vertical = 56.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(100.dp)
                .graphicsLayer(scaleX = pulse, scaleY = pulse)
                .drawBehind {
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(OrbBlue.copy(glowA), Color.Transparent),
                            radius = size.minDimension * 0.9f
                        ),
                        radius = size.minDimension * 0.9f
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            // Glass circle
            Box(
                Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.White.copy(0.14f), Color.White.copy(0.06f))
                        )
                    )
                    .border(1.dp, Color.White.copy(0.25f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Filled.Alarm, null,
                    tint = TextTertiary.copy(0.55f),
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Text(
            if (isAr) "لا توجد منبهات" else "No Alarms Yet",
            style = MaterialTheme.typography.titleMedium.copy(
                color = TextSecondary, fontWeight = FontWeight.SemiBold
            )
        )
        Spacer(Modifier.height(6.dp))
        Text(
            if (isAr) "اضغط «منبه جديد» للبدء"
            else "Tap «New Alarm» to get started",
            style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary),
            textAlign = TextAlign.Center
        )
    }
}
