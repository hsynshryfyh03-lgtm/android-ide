package com.husseindev.sentinelprotocol.core.telegram

import android.util.Log
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Telegram Bot Uploader
//  Multipart POST → api.telegram.org
//  برمجة حسين حميد
// ══════════════════════════════════════════

object TelegramUploader {

    private const val TAG      = "TelegramUploader"
    private const val BASE     = "https://api.telegram.org/bot"
    private const val BOUNDARY = "SentinelBoundary_x9k2"
    private const val CRLF     = "\r\n"

    fun sendPhoto(botToken: String, chatId: String, file: File, caption: String = ""): Boolean =
        sendFile(botToken, chatId, file, "sendPhoto", "photo", caption)

    fun sendVideo(botToken: String, chatId: String, file: File, caption: String = ""): Boolean =
        sendFile(botToken, chatId, file, "sendVideo", "video", caption)

    fun sendMessage(botToken: String, chatId: String, text: String): Boolean {
        return try {
            val url  = URL("$BASE$botToken/sendMessage")
            val body = "chat_id=${enc(chatId)}&text=${enc(text)}&parse_mode=HTML"
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput      = true
                connectTimeout = 10_000
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
                outputStream.write(body.toByteArray(Charsets.UTF_8))
            }
            val code = conn.responseCode.also { conn.disconnect() }
            code == 200
        } catch (e: Exception) { Log.e(TAG, "msg: ${e.message}"); false }
    }

    private fun sendFile(
        botToken : String, chatId: String, file: File,
        method   : String, field: String, caption: String
    ): Boolean {
        if (botToken.isBlank() || chatId.isBlank() || !file.exists()) return false
        return try {
            val conn = (URL("$BASE$botToken/$method").openConnection() as HttpURLConnection).apply {
                requestMethod  = "POST"
                doOutput       = true
                connectTimeout = 30_000
                readTimeout    = 180_000
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$BOUNDARY")
            }
            conn.outputStream.use { out ->
                fun w(s: String) = out.write(s.toByteArray(Charsets.UTF_8))
                fun part(name: String, value: String) {
                    w("--$BOUNDARY$CRLF")
                    w("Content-Disposition: form-data; name=\"$name\"$CRLF$CRLF")
                    w(value)
                    w(CRLF)
                }
                part("chat_id", chatId)
                if (caption.isNotBlank()) part("caption", caption)
                w("--$BOUNDARY$CRLF")
                w("Content-Disposition: form-data; name=\"$field\"; filename=\"${file.name}\"$CRLF")
                w("Content-Type: application/octet-stream$CRLF$CRLF")
                file.inputStream().use { it.copyTo(out) }
                w(CRLF)
                w("--$BOUNDARY--$CRLF")
            }
            val code = conn.responseCode.also { conn.disconnect() }
            if (code != 200) Log.w(TAG, "$method HTTP $code")
            code == 200
        } catch (e: Exception) { Log.e(TAG, "$method failed: ${e.message}"); false }
    }

    private fun enc(s: String) = java.net.URLEncoder.encode(s, "UTF-8")
}
