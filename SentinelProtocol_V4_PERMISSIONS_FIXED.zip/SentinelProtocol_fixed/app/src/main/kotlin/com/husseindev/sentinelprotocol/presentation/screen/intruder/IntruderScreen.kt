package com.husseindev.sentinelprotocol.presentation.screen.intruder

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import coil3.compose.AsyncImage
import coil3.request.ImageRequest
import coil3.request.crossfade
import com.husseindev.sentinelprotocol.domain.model.IntruderPhoto
import com.husseindev.sentinelprotocol.domain.usecase.DeleteIntruderPhotoUseCase
import com.husseindev.sentinelprotocol.domain.usecase.GetIntruderPhotosUseCase
import com.husseindev.sentinelprotocol.presentation.components.GlassmorphicCard
import com.husseindev.sentinelprotocol.presentation.theme.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Intruder Screen
//  صور المتطفلين + حذف فردي + عرض كامل
//  برمجة حسين حميد
// ══════════════════════════════════════════

@HiltViewModel
class IntruderViewModel @Inject constructor(
    getPhotos            : GetIntruderPhotosUseCase,
    private val deletePhoto: DeleteIntruderPhotoUseCase
) : ViewModel() {
    val photos = getPhotos().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun delete(id: Long, filePath: String) {
        viewModelScope.launch { deletePhoto(id, filePath) }
    }
}

@Composable
fun IntruderScreen(onBack: () -> Unit, viewModel: IntruderViewModel = hiltViewModel()) {
    val photos by viewModel.photos.collectAsStateWithLifecycle()
    val ctx    = LocalContext.current

    // Full-screen photo preview
    var expandedPath by remember { mutableStateOf<String?>(null) }

    Box(Modifier.fillMaxSize().background(DeepBlack).systemBarsPadding()) {

        Column(Modifier.fillMaxSize()) {

            // ── Header ──────────────────────
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, null, tint = TextPrimary)
                }
                Text(
                    "صور المتطفلين", color = RecordingRed, fontSize = 20.sp,
                    fontWeight = FontWeight.Bold, fontFamily = TajawalFamily
                )
                Spacer(Modifier.weight(1f))
                Box(
                    Modifier.background(RecordingRed.copy(0.2f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        "${photos.size}", color = RecordingRed, fontSize = 14.sp,
                        fontWeight = FontWeight.Bold, fontFamily = TajawalFamily
                    )
                }
            }

            // ── Empty state ──────────────────
            if (photos.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.Security, null,
                            tint = ActiveGreen, modifier = Modifier.size(64.dp)
                        )
                        Spacer(Modifier.height(12.dp))
                        Text("لا يوجد متطفلون", color = ActiveGreen, fontFamily = TajawalFamily, fontSize = 16.sp)
                        Text("النظام محمي", color = TextDim, fontFamily = TajawalFamily, fontSize = 13.sp)
                    }
                }
            } else {
                // ── Photo Grid ───────────────
                LazyVerticalGrid(
                    columns              = GridCells.Fixed(2),
                    contentPadding       = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement   = Arrangement.spacedBy(10.dp)
                ) {
                    items(photos, key = { it.id }) { photo ->
                        IntruderCard(
                            photo    = photo,
                            onExpand = { expandedPath = photo.filePath },
                            onDelete = { viewModel.delete(photo.id, photo.filePath) }
                        )
                    }
                }
            }
        }

        // ── Full-screen photo overlay ────────
        AnimatedVisibility(
            visible = expandedPath != null,
            enter   = fadeIn(),
            exit    = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(DeepBlack.copy(0.95f))
                    .clickable { expandedPath = null },
                contentAlignment = Alignment.Center
            ) {
                expandedPath?.let { path ->
                    AsyncImage(
                        model = ImageRequest.Builder(ctx).data(path).crossfade(true).build(),
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .clip(RoundedCornerShape(16.dp))
                    )
                }
                // Close hint
                Box(
                    Modifier.align(Alignment.BottomCenter).padding(bottom = 32.dp)
                        .background(GlassBorder.copy(0.5f), RoundedCornerShape(20.dp))
                        .padding(horizontal = 20.dp, vertical = 8.dp)
                ) {
                    Text("اضغط للإغلاق", color = TextSecondary, fontSize = 12.sp, fontFamily = TajawalFamily)
                }
            }
        }
    }
}

// ── Intruder Photo Card ───────────────────────────────────────────────────────
@Composable
private fun IntruderCard(
    photo    : IntruderPhoto,
    onExpand : () -> Unit,
    onDelete : () -> Unit
) {
    val ctx = LocalContext.current
    val fmt = remember { SimpleDateFormat("MM/dd HH:mm:ss", Locale.getDefault()) }

    GlassmorphicCard(
        modifier  = Modifier.fillMaxWidth().clickable { onExpand() },
        glowColor = RecordingRedGlow
    ) {
        Box {
            AsyncImage(
                model = ImageRequest.Builder(ctx).data(photo.filePath).crossfade(true).build(),
                contentDescription = null,
                contentScale       = ContentScale.Crop,
                modifier           = Modifier.fillMaxWidth().height(150.dp)
                    .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            )

            // Attempt badge
            Box(
                Modifier.align(Alignment.TopStart).padding(6.dp)
                    .background(RecordingRed, RoundedCornerShape(4.dp))
                    .padding(3.dp, 2.dp)
            ) {
                Text(
                    "#${photo.attemptNumber}", color = Color.White, fontSize = 9.sp,
                    fontWeight = FontWeight.Bold, fontFamily = TajawalFamily
                )
            }

            // Delete button
            Box(
                Modifier.align(Alignment.TopEnd).padding(6.dp)
                    .size(26.dp)
                    .background(DeepBlack.copy(0.6f), RoundedCornerShape(6.dp))
                    .clickable { onDelete() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Delete, null, tint = RecordingRed.copy(0.85f), modifier = Modifier.size(14.dp))
            }

            // Timestamp + expand hint
            Column(
                Modifier.align(Alignment.BottomStart).fillMaxWidth()
                    .background(
                        DeepBlack.copy(0.78f),
                        RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Text(fmt.format(Date(photo.timestamp)), color = TextSecondary, fontSize = 10.sp, fontFamily = TajawalFamily)
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment     = Alignment.CenterVertically
                ) {
                    Text("اضغط للتكبير", color = TextDim, fontSize = 9.sp, fontFamily = TajawalFamily)
                    Icon(Icons.Default.ZoomIn, null, tint = TextDim, modifier = Modifier.size(12.dp))
                }
            }
        }
    }
}
