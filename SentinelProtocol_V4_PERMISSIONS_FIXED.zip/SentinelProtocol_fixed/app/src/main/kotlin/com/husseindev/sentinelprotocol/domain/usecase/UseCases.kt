package com.husseindev.sentinelprotocol.domain.usecase

import com.husseindev.sentinelprotocol.core.constants.AppConstants
import com.husseindev.sentinelprotocol.domain.model.*
import com.husseindev.sentinelprotocol.domain.repository.RecordingRepository
import com.husseindev.sentinelprotocol.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.io.File
import java.util.concurrent.TimeUnit
import javax.inject.Inject

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Use Cases
//  برمجة حسين حميد
// ══════════════════════════════════════════

class ValidatePinUseCase @Inject constructor(private val repo: SettingsRepository) {
    suspend operator fun invoke(input: String): Boolean =
        input == repo.getConfig().first().pin
}

class ValidatePanicCodeUseCase @Inject constructor(private val repo: SettingsRepository) {
    suspend operator fun invoke(input: String): Boolean =
        input == repo.getConfig().first().panicCode
}

class DeleteAllDataUseCase @Inject constructor(
    private val recordingRepo: RecordingRepository,
    private val settingsRepo : SettingsRepository
) {
    suspend operator fun invoke() {
        recordingRepo.deleteAllRecordings()
        recordingRepo.deleteAllIntruderPhotos()
        settingsRepo.setMonitoringActive(false)
    }
}

class StartMonitoringUseCase @Inject constructor(private val repo: SettingsRepository) {
    suspend operator fun invoke() = repo.setMonitoringActive(true)
}

class StopMonitoringUseCase @Inject constructor(private val repo: SettingsRepository) {
    suspend operator fun invoke() = repo.setMonitoringActive(false)
}

class SaveRecordingUseCase @Inject constructor(private val repo: RecordingRepository) {
    suspend operator fun invoke(event: RecordingEvent): Long = repo.insertRecording(event)
}

class GetAllRecordingsUseCase @Inject constructor(private val repo: RecordingRepository) {
    operator fun invoke(): Flow<List<RecordingEvent>> = repo.getAllRecordings()
}

class SaveIntruderPhotoUseCase @Inject constructor(private val repo: RecordingRepository) {
    suspend operator fun invoke(photo: IntruderPhoto): Long = repo.insertIntruderPhoto(photo)
}

class GetIntruderPhotosUseCase @Inject constructor(private val repo: RecordingRepository) {
    operator fun invoke(): Flow<List<IntruderPhoto>> = repo.getAllIntruderPhotos()
}

class DeleteRecordingUseCase @Inject constructor(private val repo: RecordingRepository) {
    suspend operator fun invoke(id: Long, filePath: String) {
        File(filePath).delete()
        repo.deleteRecording(id)
    }
}

class DeleteIntruderPhotoUseCase @Inject constructor(private val repo: RecordingRepository) {
    suspend operator fun invoke(id: Long, filePath: String) {
        File(filePath).delete()
        repo.deleteIntruderPhoto(id)
    }
}

// ── Auto-cleanup: delete old recordings ──────────────────────────────────────
class CleanupOldRecordingsUseCase @Inject constructor(
    private val repo: RecordingRepository
) {
    suspend operator fun invoke(retentionDays: Long = AppConstants.RETENTION_DAYS): CleanupResult {
        val cutoff = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(retentionDays)
        // Fetch file paths before deleting so we can remove files from disk
        val old = repo.getAllRecordings().first().filter { it.timestamp < cutoff }
        old.forEach { File(it.filePath).delete(); it.thumbnailPath?.let { p -> File(p).delete() } }
        val deletedCount = repo.deleteRecordingsOlderThan(cutoff)
        return CleanupResult(deletedCount, old.sumOf { it.fileSizeBytes })
    }

    data class CleanupResult(val recordingsDeleted: Int, val bytesFreed: Long)
}

// ── Heatmap data ──────────────────────────────────────────────────────────────
class GetHourlyActivityUseCase @Inject constructor(private val repo: RecordingRepository) {
    suspend operator fun invoke(pastDays: Int = 7): List<HourlyActivity> {
        val since = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(pastDays.toLong())
        val rows  = repo.getHourlyActivity(since)
        // Fill missing hours with 0
        val map   = rows.associateBy { it.hour }
        return (0..23).map { h -> map[h] ?: HourlyActivity(h, 0) }
    }
}

// ── Storage stats ─────────────────────────────────────────────────────────────
class GetStorageStatsUseCase @Inject constructor(private val repo: RecordingRepository) {
    suspend operator fun invoke(): StorageStats {
        val bytes = repo.getTotalStorageBytes()
        return StorageStats(
            totalBytes = bytes,
            totalMb    = bytes / (1024 * 1024)
        )
    }
    data class StorageStats(val totalBytes: Long, val totalMb: Long)
}
