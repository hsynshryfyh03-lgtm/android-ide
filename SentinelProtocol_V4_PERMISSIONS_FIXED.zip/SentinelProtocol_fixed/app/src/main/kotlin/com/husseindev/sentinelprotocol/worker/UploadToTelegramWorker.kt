package com.husseindev.sentinelprotocol.worker

import android.content.Context
import android.util.Log
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.husseindev.sentinelprotocol.core.telegram.TelegramUploader
import com.husseindev.sentinelprotocol.domain.repository.SettingsRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Telegram Upload Worker
//  يرفع تسجيل أو صورة للبوت تلقائياً
//  برمجة حسين حميد
// ══════════════════════════════════════════

@HiltWorker
class UploadToTelegramWorker @AssistedInject constructor(
    @Assisted appContext   : Context,
    @Assisted workerParams : WorkerParameters,
    private val settingsRepo: SettingsRepository
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val filePath  = inputData.getString(KEY_FILE_PATH)  ?: return Result.failure()
        val fileType  = inputData.getString(KEY_FILE_TYPE)  ?: TYPE_VIDEO
        val eventDesc = inputData.getString(KEY_CAPTION)    ?: ""

        val config = settingsRepo.getConfig().first()
        val tg     = config.telegram

        if (!tg.enabled || tg.botToken.isBlank() || tg.chatId.isBlank())
            return Result.failure()

        val file = File(filePath)
        if (!file.exists()) return Result.failure()

        val time    = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        val caption = "🔴 <b>Sentinel Alert</b>\n$eventDesc\n🕒 $time"

        return try {
            val ok = when (fileType) {
                TYPE_PHOTO -> tg.sendPhotos && TelegramUploader.sendPhoto(tg.botToken, tg.chatId, file, caption)
                else       -> tg.sendVideos && TelegramUploader.sendVideo(tg.botToken, tg.chatId, file, caption)
            }
            Log.d(TAG, "Upload $fileType → ${if (ok) "OK" else "FAILED"}")
            if (ok) Result.success() else Result.retry()
        } catch (e: Exception) {
            Log.e(TAG, "Worker error: ${e.message}")
            Result.retry()
        }
    }

    companion object {
        private const val TAG          = "TelegramWorker"
        const val KEY_FILE_PATH = "file_path"
        const val KEY_FILE_TYPE = "file_type"
        const val KEY_CAPTION   = "caption"
        const val TYPE_PHOTO    = "photo"
        const val TYPE_VIDEO    = "video"

        fun enqueue(
            context   : Context,
            filePath  : String,
            fileType  : String = TYPE_VIDEO,
            caption   : String = ""
        ) {
            val data = Data.Builder()
                .putString(KEY_FILE_PATH, filePath)
                .putString(KEY_FILE_TYPE, fileType)
                .putString(KEY_CAPTION,   caption)
                .build()

            val request = OneTimeWorkRequestBuilder<UploadToTelegramWorker>()
                .setInputData(data)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build()
                )
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, java.util.concurrent.TimeUnit.SECONDS)
                .build()

            WorkManager.getInstance(context).enqueue(request)
        }
    }
}
