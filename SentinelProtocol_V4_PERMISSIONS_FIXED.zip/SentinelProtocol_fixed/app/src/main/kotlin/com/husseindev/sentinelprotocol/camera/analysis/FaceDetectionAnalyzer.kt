package com.husseindev.sentinelprotocol.camera.analysis

import android.annotation.SuppressLint
import android.graphics.RectF
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.husseindev.sentinelprotocol.domain.model.DetectedFace
import com.husseindev.sentinelprotocol.domain.model.DetectionResult
import com.husseindev.sentinelprotocol.domain.model.SensitivityLevel

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Face Detection (UPGRADED)
//  ML Kit ACCURATE + All Landmarks + Contours
//  برمجة حسين حميد
// ══════════════════════════════════════════

class FaceDetectionAnalyzer(
    private val sensitivity   : SensitivityLevel = SensitivityLevel.MEDIUM,
    private val onDetection   : (DetectionResult) -> Unit,
    private val onNoDetection : () -> Unit
) : ImageAnalysis.Analyzer {

    // ── ACCURATE mode — maximum detection quality ──────────────────────────────
    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)      // Best quality
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)                 // All 7 landmarks
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)     // Eye-open + smile
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)                   // Full face mesh
            .setMinFaceSize(when (sensitivity) {                                     // Smaller = detect further
                SensitivityLevel.HIGH   -> 0.06f  // Very small (far away)
                SensitivityLevel.MEDIUM -> 0.10f  // Medium distance
                SensitivityLevel.LOW    -> 0.15f  // Close only
            })
            .enableTracking()                                                        // Stable IDs across frames
            .build()
    )

    private var frameCount = 0
    private val processEveryNFrames = when (sensitivity) {
        SensitivityLevel.HIGH   -> 1
        SensitivityLevel.MEDIUM -> 2
        SensitivityLevel.LOW    -> 4
    }

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        frameCount++
        if (frameCount % processEveryNFrames != 0) {
            imageProxy.close()
            return
        }

        val mediaImage = imageProxy.image
        if (mediaImage == null) { imageProxy.close(); return }

        val inputImage = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)

        detector.process(inputImage)
            .addOnSuccessListener { faces ->
                val detectedFaces = faces.map { face -> face.toDetectedFace() }

                if (detectedFaces.isNotEmpty()) {
                    onDetection(
                        DetectionResult(
                            faces     = detectedFaces,
                            timestamp = System.currentTimeMillis(),
                            imageWidth  = imageProxy.width,
                            imageHeight = imageProxy.height
                        )
                    )
                } else {
                    onNoDetection()
                }
            }
            .addOnFailureListener { /* silent */ }
            .addOnCompleteListener { imageProxy.close() }
    }

    private fun Face.toDetectedFace() = DetectedFace(
        boundingBox = RectF(
            boundingBox.left.toFloat(),
            boundingBox.top.toFloat(),
            boundingBox.right.toFloat(),
            boundingBox.bottom.toFloat()
        ),
        confidence     = 1.0f,
        trackingId     = trackingId,
        smileProbability   = smilingProbability ?: 0f,
        leftEyeOpenProb    = leftEyeOpenProbability ?: 0f,
        rightEyeOpenProb   = rightEyeOpenProbability ?: 0f,
        headEulerAngleY    = headEulerAngleY   // Left/right rotation
    )
}
