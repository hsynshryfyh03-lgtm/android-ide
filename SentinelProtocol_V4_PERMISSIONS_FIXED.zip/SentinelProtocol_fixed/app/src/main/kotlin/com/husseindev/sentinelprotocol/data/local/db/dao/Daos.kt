package com.husseindev.sentinelprotocol.data.local.db.dao

import androidx.room.*
import com.husseindev.sentinelprotocol.data.local.db.entity.IntruderPhotoEntity
import com.husseindev.sentinelprotocol.data.local.db.entity.RecordingEntity
import com.husseindev.sentinelprotocol.domain.model.HourlyActivity
import kotlinx.coroutines.flow.Flow

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Room DAOs
//  برمجة حسين حميد
// ══════════════════════════════════════════

@Dao
interface RecordingDao {

    @Query("SELECT * FROM recordings ORDER BY timestamp DESC")
    fun getAllRecordings(): Flow<List<RecordingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecording(entity: RecordingEntity): Long

    @Query("DELETE FROM recordings WHERE id = :id")
    suspend fun deleteRecording(id: Long)

    @Query("DELETE FROM recordings")
    suspend fun deleteAllRecordings()

    @Query("SELECT COUNT(*) FROM recordings")
    suspend fun getRecordingsCount(): Int

    // ── Auto-cleanup: delete recordings older than cutoff ─────────────────────
    @Query("SELECT * FROM recordings WHERE timestamp < :cutoffTime ORDER BY timestamp ASC")
    suspend fun getRecordingsOlderThan(cutoffTime: Long): List<RecordingEntity>

    @Query("DELETE FROM recordings WHERE timestamp < :cutoffTime")
    suspend fun deleteRecordingsOlderThan(cutoffTime: Long): Int

    // ── Heatmap: count events per hour of day (0-23) ──────────────────────────
    // Uses integer arithmetic: timestamp/3600000 gives epoch-hours, %24 gives hour-of-day
    @Query("""
        SELECT ((timestamp / 3600000) % 24) AS hour, COUNT(*) AS count 
        FROM recordings 
        WHERE timestamp > :since 
        GROUP BY ((timestamp / 3600000) % 24) 
        ORDER BY hour
    """)
    suspend fun getHourlyActivity(since: Long): List<HourlyActivityRow>

    // ── Total storage used ────────────────────────────────────────────────────
    @Query("SELECT COALESCE(SUM(fileSizeBytes), 0) FROM recordings")
    suspend fun getTotalStorageBytes(): Long
}

// Room data class (not an Entity — just a query result projection)
data class HourlyActivityRow(val hour: Int, val count: Int)

@Dao
interface IntruderDao {

    @Query("SELECT * FROM intruder_photos ORDER BY timestamp DESC")
    fun getAllIntruderPhotos(): Flow<List<IntruderPhotoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIntruderPhoto(entity: IntruderPhotoEntity): Long

    @Query("DELETE FROM intruder_photos WHERE id = :id")
    suspend fun deleteIntruderPhoto(id: Long)

    @Query("DELETE FROM intruder_photos")
    suspend fun deleteAllIntruderPhotos()

    @Query("SELECT COUNT(*) FROM intruder_photos")
    suspend fun getIntruderCount(): Int
}
