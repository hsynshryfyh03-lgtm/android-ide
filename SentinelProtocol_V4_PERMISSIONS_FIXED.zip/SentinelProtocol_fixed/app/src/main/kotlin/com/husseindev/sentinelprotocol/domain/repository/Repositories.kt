package com.husseindev.sentinelprotocol.domain.repository

import com.husseindev.sentinelprotocol.domain.model.HourlyActivity
import com.husseindev.sentinelprotocol.domain.model.IntruderPhoto
import com.husseindev.sentinelprotocol.domain.model.RecordingEvent
import com.husseindev.sentinelprotocol.domain.model.SentinelConfig
import kotlinx.coroutines.flow.Flow

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Repository Interfaces
//  برمجة حسين حميد
// ══════════════════════════════════════════

interface RecordingRepository {
    fun getAllRecordings(): Flow<List<RecordingEvent>>
    suspend fun insertRecording(event: RecordingEvent): Long
    suspend fun deleteRecording(id: Long)
    suspend fun deleteAllRecordings()
    suspend fun deleteRecordingsOlderThan(cutoffTime: Long): Int
    suspend fun getHourlyActivity(since: Long): List<HourlyActivity>
    suspend fun getTotalStorageBytes(): Long
    fun getAllIntruderPhotos(): Flow<List<IntruderPhoto>>
    suspend fun insertIntruderPhoto(photo: IntruderPhoto): Long
    suspend fun deleteIntruderPhoto(id: Long)
    suspend fun deleteAllIntruderPhotos()
}

interface SettingsRepository {
    fun getConfig(): Flow<SentinelConfig>
    suspend fun updatePin(pin: String)
    suspend fun updatePanicCode(code: String)
    suspend fun updateConfig(config: SentinelConfig)
    suspend fun setMonitoringActive(active: Boolean)
    fun isMonitoringActive(): Flow<Boolean>
}
