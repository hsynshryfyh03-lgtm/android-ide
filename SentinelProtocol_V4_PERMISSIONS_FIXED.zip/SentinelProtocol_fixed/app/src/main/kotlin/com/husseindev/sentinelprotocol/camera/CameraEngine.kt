package com.husseindev.sentinelprotocol.camera

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Environment
import android.os.StatFs
import androidx.core.content.ContextCompat
import android.util.Log
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.video.VideoCapture
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.husseindev.sentinelprotocol.camera.analysis.FaceDetectionAnalyzer
import com.husseindev.sentinelprotocol.camera.analysis.PersonDetectionAnalyzer
import com.husseindev.sentinelprotocol.core.constants.AppConstants
import com.husseindev.sentinelprotocol.domain.model.*
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.util.Calendar
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Camera Engine
//  ML Kit Face + Pose | Smart Pre-Buffer 30s
//  Night Mode | Storage-Aware Quality
//  Virtual Fence
//  برمجة حسين حميد
// ══════════════════════════════════════════

@Singleton
class CameraEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val bufferManager: VideoBufferManager
) {
    private val TAG = "CameraEngine"

    val detectionState   = MutableStateFlow<DetectionResult?>(null)
    val isRecording      = MutableStateFlow(false)
    val monitoringActive = MutableStateFlow(false)
    val fenceAlert       = MutableStateFlow(false)   // true = someone entered the fence

    private var cameraProvider    : ProcessCameraProvider? = null
    private var videoCapture      : VideoCapture<Recorder>? = null
    private var activeRecording   : Recording? = null
    private var imageCapture      : ImageCapture? = null

    private val faceExecutor   : ExecutorService = Executors.newSingleThreadExecutor()
    private val personExecutor : ExecutorService = Executors.newSingleThreadExecutor()
    private val scope          = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private var preBufferFile     : File? = null
    private var preBufferJob      : Job? = null
    private var eventDetectedOnce = false
    private var onRecordingCompleteCb: (File) -> Unit = {}

    private val postTicks = (AppConstants.POST_DETECTION_SECONDS * 30).toInt()
    private var noDetectCount = 0

    // Active config (set externally)
    private var activeFence = VirtualFence()

    private val outputDir: File get() {
        val d = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "SentinelProtocol")
        if (!d.exists()) d.mkdirs(); return d
    }
    private val preBufferDir: File get() {
        val d = File(context.cacheDir, AppConstants.PREBUFFER_DIR)
        if (!d.exists()) d.mkdirs(); return d
    }

    // ── Night Mode: is it currently night? ────────────────────────────────────
    private fun isNightTime(startHour: Int, endHour: Int): Boolean {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (startHour > endHour) {
            hour >= startHour || hour < endHour   // e.g. 23-6: wraps midnight
        } else {
            hour in startHour until endHour
        }
    }

    // ── Smart Quality: check available storage ─────────────────────────────────
    private fun pickQualitySelector(): QualitySelector {
        return try {
            val stat      = StatFs(outputDir.path)
            val availableMb = (stat.availableBytes / (1024 * 1024))
            Log.d(TAG, "Available storage: ${availableMb}MB")
            when {
                availableMb > 1000 -> QualitySelector.fromOrderedList(
                    listOf(Quality.FHD, Quality.HD, Quality.SD),
                    FallbackStrategy.higherQualityOrLowerThan(Quality.SD)
                )
                availableMb > 500  -> QualitySelector.fromOrderedList(
                    listOf(Quality.HD, Quality.SD),
                    FallbackStrategy.higherQualityOrLowerThan(Quality.SD)
                )
                availableMb > 200  -> QualitySelector.from(Quality.SD)
                else -> {
                    Log.w(TAG, "Storage critically low (<200MB) — quality minimal")
                    QualitySelector.from(Quality.SD)
                }
            }
        } catch (e: Exception) {
            QualitySelector.from(Quality.HD)
        }
    }

    // ── Bind Camera ───────────────────────────────────────────────────────────
    fun bindCamera(
        lifecycleOwner      : LifecycleOwner,
        facing              : CameraFacing      = CameraFacing.BACK,
        sensitivity         : SensitivityLevel  = SensitivityLevel.MEDIUM,
        nightModeEnabled    : Boolean           = true,
        nightStartHour      : Int               = 23,
        nightEndHour        : Int               = 6,
        virtualFence        : VirtualFence      = VirtualFence(),
        preview             : Preview?          = null,
        onRecordingComplete : (File) -> Unit    = {}
    ) {
        onRecordingCompleteCb = onRecordingComplete
        activeFence           = virtualFence

        // ── Night Mode: downgrade sensitivity automatically ──────────────────
        val effectiveSensitivity = if (nightModeEnabled && isNightTime(nightStartHour, nightEndHour)) {
            Log.d(TAG, "Night mode active — reducing sensitivity")
            when (sensitivity) {
                SensitivityLevel.HIGH   -> SensitivityLevel.MEDIUM
                SensitivityLevel.MEDIUM -> SensitivityLevel.LOW
                SensitivityLevel.LOW    -> SensitivityLevel.LOW
            }
        } else sensitivity

        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)

        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
            val selector = if (facing == CameraFacing.BACK)
                CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA

            // ── Storage-aware quality ─────────────────────────────────────────
            videoCapture = VideoCapture.withOutput(
                Recorder.Builder().setQualitySelector(pickQualitySelector()).build()
            )

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            // ── Face analysis ──────────────────────────────────────────────────
            val faceAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                .build().also {
                    it.setAnalyzer(faceExecutor, FaceDetectionAnalyzer(
                        sensitivity   = effectiveSensitivity,
                        onDetection   = { r -> handleDetection(r) },
                        onNoDetection = { handleNoDetection() }
                    ))
                }

            // ── Pose/person analysis ──────────────────────────────────────────
            val personAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                .build().also {
                    it.setAnalyzer(personExecutor, PersonDetectionAnalyzer(
                        sensitivity  = effectiveSensitivity,
                        onDetection  = { r -> handleDetection(r) },
                        onNoDetection = {}
                    ))
                }

            try {
                cameraProvider?.unbindAll()
                val cases = mutableListOf<UseCase>(
                    faceAnalysis, personAnalysis, videoCapture!!, imageCapture!!
                )
                preview?.let { cases.add(0, it) }
                cameraProvider?.bindToLifecycle(lifecycleOwner, selector, *cases.toTypedArray())
                Log.d(TAG, "Camera bound — $facing | sensitivity: $effectiveSensitivity")
            } catch (e: Exception) {
                Log.e(TAG, "Bind failed: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(context))
    }

    // ── Detection Handler ─────────────────────────────────────────────────────
    private fun handleDetection(incoming: DetectionResult) {
        val current = detectionState.value
        val merged = DetectionResult(
            faces       = if (incoming.faces.isNotEmpty()) incoming.faces else current?.faces ?: emptyList(),
            persons     = if (incoming.persons.isNotEmpty()) incoming.persons else current?.persons ?: emptyList(),
            timestamp   = incoming.timestamp,
            imageWidth  = incoming.imageWidth,
            imageHeight = incoming.imageHeight
        )
        detectionState.value = merged
        noDetectCount = 0

        // ── Virtual Fence check ────────────────────────────────────────────────
        if (activeFence.enabled && merged.imageWidth > 0) {
            val inFence = merged.faces.any { f ->
                activeFence.overlaps(f.boundingBox.left, f.boundingBox.top,
                    f.boundingBox.right, f.boundingBox.bottom,
                    merged.imageWidth, merged.imageHeight)
            } || merged.persons.any { p ->
                activeFence.overlaps(p.boundingBox.left, p.boundingBox.top,
                    p.boundingBox.right, p.boundingBox.bottom,
                    merged.imageWidth, merged.imageHeight)
            }
            fenceAlert.value = inFence
        }

        if (monitoringActive.value && !isRecording.value) {
            eventDetectedOnce = true
            preBufferJob?.cancel()
            Log.d(TAG, "Detection → keeping pre-buffer recording")
        }
    }

    private fun handleNoDetection() {
        fenceAlert.value = false
        if (isRecording.value) {
            noDetectCount++
            if (noDetectCount >= postTicks) {
                val file = preBufferFile
                stopRecordingAndSave(file)
                noDetectCount     = 0
                eventDetectedOnce = false
                scope.launch {
                    delay(1000)
                    if (monitoringActive.value) startPreBuffer()
                }
            }
        }
    }

    // ── Monitoring control ────────────────────────────────────────────────────
    fun setMonitoringActive(active: Boolean) {
        monitoringActive.value = active
        if (active) {
            startPreBuffer()
        } else {
            preBufferJob?.cancel()
            val tmp = preBufferFile
            stopRecording()
            if (!eventDetectedOnce) tmp?.delete()
            eventDetectedOnce = false
            preBufferFile = null
        }
    }

    // ── Pre-Event Buffer ─────────────────────────────────────────────────────
    private fun startPreBuffer() {
        if (isRecording.value) return
        preBufferFile = createOutputFile(preBufferDir, "prebuf")
        startRecordingToFile(preBufferFile!!)
        preBufferJob?.cancel()
        preBufferJob = scope.launch {
            delay(AppConstants.PRE_BUFFER_ROTATE_MS)
            if (isRecording.value && !eventDetectedOnce) {
                val old = preBufferFile
                stopRecording()
                old?.delete()
                delay(500)
                if (monitoringActive.value) startPreBuffer()
            }
        }
    }

    private fun createOutputFile(dir: File, prefix: String): File {
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "${prefix}_${System.currentTimeMillis()}.mp4")
    }

    private fun startRecordingToFile(file: File) {
        val vc = videoCapture ?: return
        if (isRecording.value) return

        val hasAudio = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        val pendingRecording = vc.output
            .prepareRecording(context, FileOutputOptions.Builder(file).build())

        // Only enable audio if permission is granted — avoids SecurityException
        if (hasAudio) pendingRecording.withAudioEnabled()

        activeRecording = pendingRecording.start(faceExecutor) { event ->
            when (event) {
                is VideoRecordEvent.Start    -> isRecording.value = true
                is VideoRecordEvent.Finalize -> {
                    isRecording.value = false
                    if (event.hasError()) { Log.e(TAG, "Rec error: ${event.error}"); file.delete() }
                }
                else -> {}
            }
            }
    }

    // Public manual recording
    fun startRecording(isEmergency: Boolean = false, onComplete: (File) -> Unit = {}) {
        val out = createOutputFile(outputDir, "sentinel")
        preBufferFile         = out
        onRecordingCompleteCb = onComplete
        startRecordingToFile(out)
    }

    private fun stopRecordingAndSave(file: File?) {
        stopRecording()
        if (file != null && file.exists() && file.length() > 0) {
            val dest = createOutputFile(outputDir, "sentinel")
            if (file.renameTo(dest)) onRecordingCompleteCb(dest)
            else onRecordingCompleteCb(file)
        }
    }

    fun stopRecording() { activeRecording?.stop(); activeRecording = null }

    // ── Intruder Selfie ───────────────────────────────────────────────────────
    fun captureIntruderSelfie(attemptNumber: Int, onCaptured: (File) -> Unit) {
        val ic  = imageCapture ?: return
        val dir = File(context.filesDir, AppConstants.INTRUDER_DIR).also { it.mkdirs() }
        val out = File(dir, "intruder_${System.currentTimeMillis()}.jpg")
        ic.takePicture(ImageCapture.OutputFileOptions.Builder(out).build(), faceExecutor,
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) = onCaptured(out)
                override fun onError(e: ImageCaptureException) { Log.e(TAG, "Selfie err: ${e.message}") }
            })
    }

    fun unbind()   { stopRecording(); cameraProvider?.unbindAll() }
    fun shutdown() { unbind(); preBufferJob?.cancel(); faceExecutor.shutdown(); personExecutor.shutdown(); scope.cancel() }
}
