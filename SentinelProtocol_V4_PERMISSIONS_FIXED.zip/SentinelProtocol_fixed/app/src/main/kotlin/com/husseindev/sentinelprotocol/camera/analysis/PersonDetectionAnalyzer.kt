package com.husseindev.sentinelprotocol.camera.analysis

import android.annotation.SuppressLint
import android.graphics.RectF
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.pose.Pose
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseLandmark
import com.google.mlkit.vision.pose.accurate.AccuratePoseDetectorOptions
import com.husseindev.sentinelprotocol.domain.model.DetectedPerson
import com.husseindev.sentinelprotocol.domain.model.DetectionResult
import com.husseindev.sentinelprotocol.domain.model.SensitivityLevel

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Person Detection (UPGRADED)
//  ML Kit Accurate Pose Detection
//  يكشف الجسم البشري بالكامل بدقة عالية
//  برمجة حسين حميد
// ══════════════════════════════════════════

class PersonDetectionAnalyzer(
    private val sensitivity  : SensitivityLevel = SensitivityLevel.MEDIUM,
    private val onDetection  : (DetectionResult) -> Unit,
    private val onNoDetection: () -> Unit
) : ImageAnalysis.Analyzer {

    // ── Accurate Pose Detector — يكشف 33 نقطة على الجسم ──────────────────────
    private val poseDetector = PoseDetection.getClient(
        AccuratePoseDetectorOptions.Builder()
            .setDetectorMode(AccuratePoseDetectorOptions.STREAM_MODE)  // Real-time
            .setPreferredHardwareConfigs(AccuratePoseDetectorOptions.CPU_GPU) // GPU acceleration
            .build()
    )

    // Minimum confidence threshold per sensitivity level
    private val minPoseConfidence = when (sensitivity) {
        SensitivityLevel.HIGH   -> 0.3f
        SensitivityLevel.MEDIUM -> 0.5f
        SensitivityLevel.LOW    -> 0.7f
    }

    private var frameCount = 0
    private val processEveryNFrames = when (sensitivity) {
        SensitivityLevel.HIGH   -> 2
        SensitivityLevel.MEDIUM -> 3
        SensitivityLevel.LOW    -> 5
    }

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        frameCount++
        if (frameCount % processEveryNFrames != 0) {
            imageProxy.close()
            return
        }

        val mediaImage = imageProxy.image
        if (mediaImage == null) { imageProxy.close(); return }

        val inputImage = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)

        poseDetector.process(inputImage)
            .addOnSuccessListener { pose ->
                val person = pose.toDetectedPerson(minPoseConfidence)
                if (person != null) {
                    onDetection(
                        DetectionResult(
                            persons     = listOf(person),
                            timestamp   = System.currentTimeMillis(),
                            imageWidth  = imageProxy.width,
                            imageHeight = imageProxy.height
                        )
                    )
                } else {
                    onNoDetection()
                }
            }
            .addOnFailureListener { onNoDetection() }
            .addOnCompleteListener { imageProxy.close() }
    }

    // ── Convert Pose landmarks → bounding box + confidence ────────────────────
    private fun Pose.toDetectedPerson(minConfidence: Float): DetectedPerson? {
        val landmarks = allPoseLandmarks
        if (landmarks.isEmpty()) return null

        // Filter only confident landmarks
        val confident = landmarks.filter {
            it.inFrameLikelihood >= minConfidence
        }
        if (confident.size < 4) return null // Need at least a few visible points

        val avgConfidence = confident.map { it.inFrameLikelihood }.average().toFloat()

        // Build tight bounding box from visible landmarks
        val xs = confident.map { it.position.x }
        val ys = confident.map { it.position.y }

        val rect = RectF(
            xs.min(),
            ys.min(),
            xs.max(),
            ys.max()
        )

        // Detect body part context for richer label
        val hasUpperBody = getPoseLandmark(PoseLandmark.LEFT_SHOULDER) != null ||
                           getPoseLandmark(PoseLandmark.RIGHT_SHOULDER) != null
        val hasLowerBody = getPoseLandmark(PoseLandmark.LEFT_HIP) != null ||
                           getPoseLandmark(PoseLandmark.RIGHT_HIP) != null
        val label = when {
            hasUpperBody && hasLowerBody -> "جسم كامل"
            hasUpperBody                 -> "جذع"
            else                         -> "شخص"
        }

        return DetectedPerson(
            boundingBox = rect,
            confidence  = avgConfidence,
            label       = label,
            landmarkCount = confident.size
        )
    }
}
