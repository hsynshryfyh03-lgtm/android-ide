package com.husseindev.sentinelprotocol.data.local.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.husseindev.sentinelprotocol.core.constants.AppConstants
import com.husseindev.sentinelprotocol.domain.model.*
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Settings DataStore
//  برمجة حسين حميد
// ══════════════════════════════════════════

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "sentinel_prefs")

@Singleton
class SettingsDataStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val PIN                = stringPreferencesKey(AppConstants.DS_PIN_KEY)
        val PANIC_CODE         = stringPreferencesKey(AppConstants.DS_PANIC_KEY)
        val MONITORING_ACTIVE  = booleanPreferencesKey(AppConstants.DS_MONITORING_ACTIVE)
        val CAMERA_FACING      = stringPreferencesKey(AppConstants.DS_CAMERA_FACING)
        val SENSITIVITY        = stringPreferencesKey(AppConstants.DS_SENSITIVITY)
        val AUTO_START         = booleanPreferencesKey(AppConstants.DS_AUTO_START)
        val EMERGENCY_ENABLED  = booleanPreferencesKey(AppConstants.DS_EMERGENCY_ENABLED)
        val BATTERY_THRESHOLD  = intPreferencesKey("battery_threshold")
        // ── New ──
        val KIOSK_MODE         = booleanPreferencesKey("kiosk_mode")
        val NIGHT_MODE         = booleanPreferencesKey("night_mode_enabled")
        val NIGHT_START        = intPreferencesKey("night_start_hour")
        val NIGHT_END          = intPreferencesKey("night_end_hour")
        // Virtual fence
        val FENCE_ENABLED      = booleanPreferencesKey("fence_enabled")
        val FENCE_LEFT         = floatPreferencesKey("fence_left")
        val FENCE_TOP          = floatPreferencesKey("fence_top")
        val FENCE_RIGHT        = floatPreferencesKey("fence_right")
        val FENCE_BOTTOM       = floatPreferencesKey("fence_bottom")
        // Telegram
        val TG_ENABLED         = booleanPreferencesKey("tg_enabled")
        val TG_BOT_TOKEN       = stringPreferencesKey("tg_bot_token")
        val TG_CHAT_ID         = stringPreferencesKey("tg_chat_id")
        val TG_SEND_PHOTOS     = booleanPreferencesKey("tg_send_photos")
        val TG_SEND_VIDEOS     = booleanPreferencesKey("tg_send_videos")
    }

    val configFlow: Flow<SentinelConfig> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { p ->
            SentinelConfig(
                pin                     = p[Keys.PIN]               ?: AppConstants.DEFAULT_PIN,
                panicCode               = p[Keys.PANIC_CODE]        ?: AppConstants.PANIC_CODE,
                cameraFacing            = CameraFacing.valueOf(p[Keys.CAMERA_FACING] ?: CameraFacing.BACK.name),
                sensitivityLevel        = SensitivityLevel.valueOf(p[Keys.SENSITIVITY] ?: SensitivityLevel.MEDIUM.name),
                autoStartOnBoot         = p[Keys.AUTO_START]        ?: false,
                emergencyTriggerEnabled = p[Keys.EMERGENCY_ENABLED] ?: true,
                batteryStopThreshold    = p[Keys.BATTERY_THRESHOLD] ?: AppConstants.BATTERY_STOP_THRESHOLD,
                kioskModeEnabled        = p[Keys.KIOSK_MODE]        ?: false,
                nightModeEnabled        = p[Keys.NIGHT_MODE]        ?: true,
                nightStartHour          = p[Keys.NIGHT_START]       ?: 23,
                nightEndHour            = p[Keys.NIGHT_END]         ?: 6,
                virtualFence = VirtualFence(
                    enabled = p[Keys.FENCE_ENABLED] ?: false,
                    left    = p[Keys.FENCE_LEFT]    ?: 0f,
                    top     = p[Keys.FENCE_TOP]     ?: 0f,
                    right   = p[Keys.FENCE_RIGHT]   ?: 1f,
                    bottom  = p[Keys.FENCE_BOTTOM]  ?: 1f
                ),
                telegram = TelegramConfig(
                    enabled     = p[Keys.TG_ENABLED]     ?: false,
                    botToken    = p[Keys.TG_BOT_TOKEN]   ?: "",
                    chatId      = p[Keys.TG_CHAT_ID]     ?: "",
                    sendPhotos  = p[Keys.TG_SEND_PHOTOS] ?: true,
                    sendVideos  = p[Keys.TG_SEND_VIDEOS] ?: true
                )
            )
        }

    val isMonitoringActive: Flow<Boolean> = context.dataStore.data
        .catch { emit(emptyPreferences()) }
        .map { it[Keys.MONITORING_ACTIVE] ?: false }

    suspend fun updatePin(pin: String)           { context.dataStore.edit { it[Keys.PIN] = pin } }
    suspend fun updatePanicCode(code: String)    { context.dataStore.edit { it[Keys.PANIC_CODE] = code } }
    suspend fun setMonitoringActive(v: Boolean)  { context.dataStore.edit { it[Keys.MONITORING_ACTIVE] = v } }

    suspend fun updateConfig(c: SentinelConfig) {
        context.dataStore.edit { p ->
            p[Keys.PIN]              = c.pin
            p[Keys.PANIC_CODE]       = c.panicCode
            p[Keys.CAMERA_FACING]    = c.cameraFacing.name
            p[Keys.SENSITIVITY]      = c.sensitivityLevel.name
            p[Keys.AUTO_START]       = c.autoStartOnBoot
            p[Keys.EMERGENCY_ENABLED]= c.emergencyTriggerEnabled
            p[Keys.BATTERY_THRESHOLD]= c.batteryStopThreshold
            p[Keys.KIOSK_MODE]       = c.kioskModeEnabled
            p[Keys.NIGHT_MODE]       = c.nightModeEnabled
            p[Keys.NIGHT_START]      = c.nightStartHour
            p[Keys.NIGHT_END]        = c.nightEndHour
            p[Keys.FENCE_ENABLED]    = c.virtualFence.enabled
            p[Keys.FENCE_LEFT]       = c.virtualFence.left
            p[Keys.FENCE_TOP]        = c.virtualFence.top
            p[Keys.FENCE_RIGHT]      = c.virtualFence.right
            p[Keys.FENCE_BOTTOM]     = c.virtualFence.bottom
            p[Keys.TG_ENABLED]       = c.telegram.enabled
            p[Keys.TG_BOT_TOKEN]     = c.telegram.botToken
            p[Keys.TG_CHAT_ID]       = c.telegram.chatId
            p[Keys.TG_SEND_PHOTOS]   = c.telegram.sendPhotos
            p[Keys.TG_SEND_VIDEOS]   = c.telegram.sendVideos
        }
    }
}
