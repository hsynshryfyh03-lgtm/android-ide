package com.husseindev.sentinelprotocol.service

import android.Manifest
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.husseindev.sentinelprotocol.camera.CameraEngine
import com.husseindev.sentinelprotocol.core.constants.AppConstants
import com.husseindev.sentinelprotocol.domain.model.CameraFacing
import com.husseindev.sentinelprotocol.domain.model.RecordingEvent
import com.husseindev.sentinelprotocol.domain.model.TriggerType
import com.husseindev.sentinelprotocol.domain.usecase.SaveRecordingUseCase
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import java.io.File
import javax.inject.Inject

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Emergency Service
//  Volume Button Double-Press Trigger
//  برمجة حسين حميد
// ══════════════════════════════════════════

@AndroidEntryPoint
class EmergencyRecordService : LifecycleService() {

    private val TAG = "EmergencyService"

    @Inject lateinit var cameraEngine  : CameraEngine
    @Inject lateinit var notifManager  : SentinelNotificationManager
    @Inject lateinit var saveRecording : SaveRecordingUseCase

    private var lastVolumeUpPressTime = 0L
    private var emergencyRecordingJob : Job? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    companion object {
        const val ACTION_VOLUME_UP_PRESSED = "ACTION_VOLUME_UP_PRESSED"
        var isRunning = false
    }

    override fun onCreate() {
        super.onCreate()
        notifManager.createNotificationChannel()
        isRunning = true
        Log.d(TAG, "Emergency service created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        startForegroundCompat()

        if (intent?.action == ACTION_VOLUME_UP_PRESSED) {
            handleVolumeUpPress()
        }

        return START_STICKY
    }

    private fun handleVolumeUpPress() {
        val now = System.currentTimeMillis()
        val timeDiff = now - lastVolumeUpPressTime

        if (timeDiff <= AppConstants.VOLUME_DOUBLE_PRESS_MS) {
            // Double press detected!
            Log.d(TAG, "Double volume-up press — triggering emergency recording")
            triggerEmergencyRecording()
            lastVolumeUpPressTime = 0L  // Reset
        } else {
            lastVolumeUpPressTime = now
        }
    }

    private fun triggerEmergencyRecording() {
        // 1. Haptic feedback — subtle confirmation
        vibrateHaptic()

        // 2. Enable Do Not Disturb (stealth)
        enableDoNotDisturb()

        // 3. Start recording
        if (!cameraEngine.isRecording.value) {
            cameraEngine.bindCamera(
                lifecycleOwner = this,
                facing         = CameraFacing.BACK,
                onRecordingComplete = { file -> onEmergencyRecordingDone(file) }
            )
            cameraEngine.startRecording(isEmergency = true, onComplete = {})

            // Auto-stop after EMERGENCY_RECORD_DURATION_SEC
            emergencyRecordingJob?.cancel()
            emergencyRecordingJob = scope.launch {
                delay(AppConstants.EMERGENCY_RECORD_DURATION_SEC * 1000)
                cameraEngine.stopRecording()
            }
        }
    }

    private fun vibrateHaptic() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vm.defaultVibrator.vibrate(
                    VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
                v.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        } catch (e: Exception) { Log.e(TAG, "Haptic error: ${e.message}") }
    }

    private fun enableDoNotDisturb() {
        try {
            val audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
            audioManager.ringerMode = AudioManager.RINGER_MODE_SILENT
        } catch (e: Exception) { Log.e(TAG, "DND error: ${e.message}") }
    }

    private fun onEmergencyRecordingDone(file: File) {
        scope.launch {
            saveRecording(RecordingEvent(
                filePath      = file.absolutePath,
                triggerType   = TriggerType.EMERGENCY_VOLUME,
                isEmergency   = true,
                fileSizeBytes = file.length()
            ))
        }
    }

    private fun startForegroundCompat() {
        val notification = notifManager.buildForegroundNotification()
        val hasAudio     = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val fgsType = if (hasAudio) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            }
            startForeground(AppConstants.NOTIFICATION_ID_FOREGROUND + 1, notification, fgsType)
        } else {
            startForeground(AppConstants.NOTIFICATION_ID_FOREGROUND + 1, notification)
        }
    }

    override fun onDestroy() {
        isRunning = false
        emergencyRecordingJob?.cancel()
        cameraEngine.stopRecording()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent): IBinder? { super.onBind(intent); return null }
}
