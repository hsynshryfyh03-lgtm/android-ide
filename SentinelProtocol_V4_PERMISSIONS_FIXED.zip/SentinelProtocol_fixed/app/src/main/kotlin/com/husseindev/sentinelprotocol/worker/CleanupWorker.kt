package com.husseindev.sentinelprotocol.worker

import android.content.Context
import android.util.Log
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.husseindev.sentinelprotocol.core.constants.AppConstants
import com.husseindev.sentinelprotocol.domain.usecase.CleanupOldRecordingsUseCase
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.util.concurrent.TimeUnit

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Cleanup Worker
//  Auto-deletes recordings older than RETENTION_DAYS
//  يعمل أسبوعياً في الخلفية بشكل تلقائي
//  برمجة حسين حميد
// ══════════════════════════════════════════

@HiltWorker
class CleanupWorker @AssistedInject constructor(
    @Assisted appContext   : Context,
    @Assisted workerParams : WorkerParameters,
    private val cleanupUseCase: CleanupOldRecordingsUseCase
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            val result = cleanupUseCase(AppConstants.RETENTION_DAYS)
            Log.d(TAG, "Cleanup: deleted ${result.recordingsDeleted} recordings, " +
                    "freed ${result.bytesFreed / (1024*1024)} MB")
            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "Cleanup failed: ${e.message}")
            Result.retry()
        }
    }

    companion object {
        private const val TAG       = "CleanupWorker"
        private const val WORK_NAME = "sentinel_weekly_cleanup"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<CleanupWorker>(
                AppConstants.CLEANUP_INTERVAL_DAYS.toLong(), TimeUnit.DAYS
            )
                .setConstraints(
                    Constraints.Builder()
                        .setRequiresBatteryNotLow(true)
                        .build()
                )
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }
    }
}
