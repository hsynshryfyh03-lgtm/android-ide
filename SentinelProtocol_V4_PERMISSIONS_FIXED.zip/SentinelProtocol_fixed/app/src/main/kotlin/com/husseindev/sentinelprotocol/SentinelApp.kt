package com.husseindev.sentinelprotocol

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.husseindev.sentinelprotocol.worker.CleanupWorker
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Application Class
//  برمجة حسين حميد
// ══════════════════════════════════════════

@HiltAndroidApp
class SentinelApp : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    override fun onCreate() {
        super.onCreate()
        // SQLCipher init
        net.sqlcipher.database.SQLiteDatabase.loadLibs(this)
        // Schedule weekly cleanup
        CleanupWorker.schedule(this)
    }
}
