package com.husseindev.sentinelprotocol.presentation.screen.dashboard

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.husseindev.sentinelprotocol.domain.model.HourlyActivity
import com.husseindev.sentinelprotocol.presentation.components.*
import com.husseindev.sentinelprotocol.presentation.theme.*

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Dashboard Screen
//  برمجة حسين حميد
// ══════════════════════════════════════════

@Composable
fun DashboardScreen(
    onNavigateGallery  : () -> Unit,
    onNavigateSettings : () -> Unit,
    onNavigateIntruder : () -> Unit,
    onNavigateMonitor  : () -> Unit,
    viewModel          : DashboardViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
            .systemBarsPadding()
    ) {
        // Ambient glow
        Box(
            Modifier.align(Alignment.TopCenter).offset(y = (-60).dp)
                .size(300.dp).blur(120.dp)
                .background(TealDark.copy(0.35f), CircleShape)
        )

        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))

            // ── Header ────────────────────────────
            Text(
                text         = "SENTINEL",
                color        = TealLight,
                fontSize     = 28.sp,
                fontWeight   = FontWeight.ExtraBold,
                fontFamily   = TajawalFamily,
                letterSpacing = 6.sp
            )
            Text(
                text       = "برمجة حسين حميد",
                color      = TextDim,
                fontSize   = 13.sp,
                fontFamily = TajawalFamily
            )

            Spacer(Modifier.height(32.dp))

            // ── Power Toggle ──────────────────────
            MonitoringToggle(
                isActive = state.isMonitoring,
                onToggle = { viewModel.toggleMonitoring() }
            )

            Spacer(Modifier.height(32.dp))

            // ── Stats Row ─────────────────────────
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // ✅ FIX: .clickable added to StatCard
                StatCard(
                    modifier = Modifier.weight(1f),
                    icon     = Icons.Default.VideoLibrary,
                    value    = state.recordingCount.toString(),
                    label    = "تسجيلات",
                    onClick  = onNavigateGallery
                )
                StatCard(
                    modifier = Modifier.weight(1f),
                    icon     = Icons.Default.PersonOff,
                    value    = state.intruderCount.toString(),
                    label    = "متطفلون",
                    onClick  = onNavigateIntruder
                )
            }

            Spacer(Modifier.height(12.dp))

            // ── Storage indicator ─────────────────
            if (state.storageMb > 0) {
                GlassmorphicCard(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Storage, null, tint = TealPrimary, modifier = Modifier.size(18.dp))
                            Text("التخزين المستخدم", color = TextSecondary, fontSize = 13.sp, fontFamily = TajawalFamily)
                        }
                        Text(
                            text       = "${state.storageMb} MB",
                            color      = TealLight,
                            fontSize   = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = TajawalFamily
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            // ── Action Buttons (FIXED: .clickable added) ────────────
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // ✅ FIX: ActionButton now properly wires onClick
                ActionButton(
                    icon    = Icons.Default.CameraAlt,
                    label   = "شاشة المراقبة الحية",
                    onClick = onNavigateMonitor
                )
                ActionButton(
                    icon    = Icons.Default.Settings,
                    label   = "الإعدادات",
                    onClick = onNavigateSettings
                )
            }

            // ── Activity Heatmap ──────────────────
            if (state.hourlyActivity.isNotEmpty()) {
                Spacer(Modifier.height(20.dp))
                ActivityHeatmap(
                    modifier  = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    activity  = state.hourlyActivity
                )
            }

            // ── Status Card ───────────────────────
            Spacer(Modifier.height(16.dp))
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 32.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("حالة النظام", color = TextSecondary, fontSize = 12.sp, fontFamily = TajawalFamily)
                        Text(
                            text       = if (state.isMonitoring) "المراقبة نشطة" else "في وضع الاستعداد",
                            color      = if (state.isMonitoring) ActiveGreen else TextDim,
                            fontSize   = 15.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = TajawalFamily
                        )
                    }
                    RecordingIndicator(isRecording = state.isMonitoring)
                }
            }
        }
    }
}

// ── Monitoring Power Toggle ────────────────────────────────────────────────────
@Composable
private fun MonitoringToggle(isActive: Boolean, onToggle: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 1.15f,
        animationSpec = infiniteRepeatable(tween(1000, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "pulse"
    )
    val outerScale = if (isActive) pulseScale else 1f
    val outerColor = if (isActive) TealGlow  else Color.Transparent
    val innerColor = if (isActive) TealPrimary else ElevatedBlack

    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(160.dp)) {
        Box(
            modifier = Modifier
                .size(160.dp * outerScale)
                .clip(CircleShape)
                .background(outerColor)
        )
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(130.dp)
                .clip(CircleShape)
                .background(innerColor)
                .border(2.dp, if (isActive) TealPrimary else GlassBorder, CircleShape)
                .drawBehind {
                    drawIntoCanvas { canvas ->
                        val paint = Paint().apply {
                            asFrameworkPaint().setShadowLayer(
                                if (isActive) 30f else 10f, 0f, 0f,
                                if (isActive) TealGlow.toArgb() else Color.Black.copy(0.3f).toArgb()
                            )
                        }
                        canvas.drawCircle(center, 65.dp.toPx(), paint)
                    }
                }
        ) {
            IconButton(onClick = onToggle, modifier = Modifier.size(130.dp)) {
                Icon(
                    imageVector = if (isActive) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint     = if (isActive) TealLight else TextSecondary,
                    modifier = Modifier.size(52.dp)
                )
            }
        }
    }
}

// ── Stat Card ──────────────────────────────────────────────────────────────────
@Composable
private fun StatCard(
    modifier : Modifier,
    icon     : androidx.compose.ui.graphics.vector.ImageVector,
    value    : String,
    label    : String,
    onClick  : () -> Unit
) {
    // ✅ FIXED: .clickable wired correctly
    GlassmorphicCard(modifier = modifier.clickable { onClick() }) {
        Column(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = TealLight, modifier = Modifier.size(28.dp))
            Spacer(Modifier.height(8.dp))
            Text(value, color = TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, fontFamily = TajawalFamily)
            Text(label, color = TextSecondary, fontSize = 12.sp, fontFamily = TajawalFamily)
        }
    }
}

// ── Action Button ──────────────────────────────────────────────────────────────
@Composable
private fun ActionButton(
    icon    : androidx.compose.ui.graphics.vector.ImageVector,
    label   : String,
    onClick : () -> Unit
) {
    // ✅ FIXED: .clickable applied directly on the card modifier
    GlassmorphicCard(modifier = Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(icon, contentDescription = null, tint = TealPrimary, modifier = Modifier.size(24.dp))
                Text(label, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextDim)
        }
    }
}

// ── 24h Activity Heatmap ──────────────────────────────────────────────────────
@Composable
private fun ActivityHeatmap(modifier: Modifier, activity: List<HourlyActivity>) {
    val maxCount = activity.maxOfOrNull { it.count }?.coerceAtLeast(1) ?: 1

    GlassmorphicCard(modifier = modifier) {
        Column(Modifier.padding(16.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                Text("نشاط آخر 7 أيام (بالساعة)", color = TealLight,
                    fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
                Icon(Icons.Default.BarChart, null, tint = TealPrimary, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.height(12.dp))

            // Hour blocks row: 0-23 split into two rows of 12
            listOf(0..11, 12..23).forEach { range ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    range.forEach { hour ->
                        val a = activity.find { it.hour == hour }
                        val ratio = (a?.count ?: 0).toFloat() / maxCount
                        val cellColor = when {
                            ratio == 0f -> GlassBorder.copy(alpha = 0.3f)
                            ratio < 0.3f -> TealDark.copy(alpha = 0.5f)
                            ratio < 0.6f -> TealPrimary.copy(alpha = 0.7f)
                            else         -> TealLight
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(22.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(cellColor),
                            contentAlignment = Alignment.Center
                        ) {
                            if (a != null && a.count > 0) {
                                Text(
                                    text     = a.count.toString(),
                                    color    = DeepBlack,
                                    fontSize = 7.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(3.dp))
            }

            Spacer(Modifier.height(8.dp))
            // Hour labels
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("12ص", "6ص", "12ظ", "6م", "11م").forEach { label ->
                    Text(label, color = TextDim, fontSize = 9.sp, fontFamily = TajawalFamily)
                }
            }
        }
    }
}
