package com.husseindev.sentinelprotocol.data.repository

import com.husseindev.sentinelprotocol.data.local.datastore.SettingsDataStore
import com.husseindev.sentinelprotocol.data.local.db.dao.IntruderDao
import com.husseindev.sentinelprotocol.data.local.db.dao.RecordingDao
import com.husseindev.sentinelprotocol.data.local.db.entity.IntruderPhotoEntity
import com.husseindev.sentinelprotocol.data.local.db.entity.RecordingEntity
import com.husseindev.sentinelprotocol.domain.model.*
import com.husseindev.sentinelprotocol.domain.repository.RecordingRepository
import com.husseindev.sentinelprotocol.domain.repository.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Repository Implementations
//  برمجة حسين حميد
// ══════════════════════════════════════════

@Singleton
class RecordingRepositoryImpl @Inject constructor(
    private val recordingDao : RecordingDao,
    private val intruderDao  : IntruderDao
) : RecordingRepository {

    override fun getAllRecordings(): Flow<List<RecordingEvent>> =
        recordingDao.getAllRecordings().map { list -> list.map { it.toDomain() } }

    override suspend fun insertRecording(event: RecordingEvent): Long =
        recordingDao.insertRecording(RecordingEntity.fromDomain(event))

    override suspend fun deleteRecording(id: Long) =
        recordingDao.deleteRecording(id)

    override suspend fun deleteAllRecordings() =
        recordingDao.deleteAllRecordings()

    override suspend fun deleteRecordingsOlderThan(cutoffTime: Long): Int =
        recordingDao.deleteRecordingsOlderThan(cutoffTime)

    override suspend fun getHourlyActivity(since: Long): List<HourlyActivity> =
        recordingDao.getHourlyActivity(since).map { HourlyActivity(it.hour, it.count) }

    override suspend fun getTotalStorageBytes(): Long =
        recordingDao.getTotalStorageBytes()

    override fun getAllIntruderPhotos(): Flow<List<IntruderPhoto>> =
        intruderDao.getAllIntruderPhotos().map { list -> list.map { it.toDomain() } }

    override suspend fun insertIntruderPhoto(photo: IntruderPhoto): Long =
        intruderDao.insertIntruderPhoto(IntruderPhotoEntity.fromDomain(photo))

    override suspend fun deleteIntruderPhoto(id: Long) =
        intruderDao.deleteIntruderPhoto(id)

    override suspend fun deleteAllIntruderPhotos() =
        intruderDao.deleteAllIntruderPhotos()
}

@Singleton
class SettingsRepositoryImpl @Inject constructor(
    private val dataStore: SettingsDataStore
) : SettingsRepository {
    override fun getConfig(): Flow<SentinelConfig>              = dataStore.configFlow
    override suspend fun updatePin(pin: String)                 = dataStore.updatePin(pin)
    override suspend fun updatePanicCode(code: String)          = dataStore.updatePanicCode(code)
    override suspend fun updateConfig(config: SentinelConfig)   = dataStore.updateConfig(config)
    override suspend fun setMonitoringActive(active: Boolean)   = dataStore.setMonitoringActive(active)
    override fun isMonitoringActive(): Flow<Boolean>            = dataStore.isMonitoringActive
}
