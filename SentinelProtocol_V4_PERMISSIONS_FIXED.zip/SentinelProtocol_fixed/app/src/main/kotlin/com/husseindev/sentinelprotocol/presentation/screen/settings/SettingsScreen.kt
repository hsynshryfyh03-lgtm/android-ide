package com.husseindev.sentinelprotocol.presentation.screen.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.husseindev.sentinelprotocol.domain.model.*
import com.husseindev.sentinelprotocol.domain.repository.SettingsRepository
import com.husseindev.sentinelprotocol.presentation.components.GlassmorphicCard
import com.husseindev.sentinelprotocol.presentation.components.NeonButton
import com.husseindev.sentinelprotocol.presentation.theme.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Settings Screen
//  + Telegram | Night Mode | Kiosk Mode
//  برمجة حسين حميد
// ══════════════════════════════════════════

@HiltViewModel
class SettingsViewModel @Inject constructor(private val repo: SettingsRepository) : ViewModel() {
    val config = repo.getConfig().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SentinelConfig())
    fun save(c: SentinelConfig)  { viewModelScope.launch { repo.updateConfig(c) } }
    fun updatePin(p: String)     { viewModelScope.launch { repo.updatePin(p) } }
    fun updatePanic(p: String)   { viewModelScope.launch { repo.updatePanicCode(p) } }
}

@Composable
fun SettingsScreen(onBack: () -> Unit, viewModel: SettingsViewModel = hiltViewModel()) {
    val config  by viewModel.config.collectAsStateWithLifecycle()
    var newPin   by remember { mutableStateOf("") }
    var newPanic by remember { mutableStateOf("") }
    var saved    by remember { mutableStateOf(false) }

    // Telegram fields (local state — saved on button press)
    var tgToken  by remember(config.telegram.botToken) { mutableStateOf(config.telegram.botToken) }
    var tgChatId by remember(config.telegram.chatId)   { mutableStateOf(config.telegram.chatId) }
    var tgSaved  by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(DeepBlack).systemBarsPadding()) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {

            // ── Header ──────────────────────────────────────────────────────
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = TextPrimary) }
                Text("الإعدادات", color = TextPrimary, fontSize = 20.sp,
                    fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
            }

            // ── Camera ──────────────────────────────────────────────────────
            SettingsSection("الكاميرا", Icons.Default.CameraAlt) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    CameraFacing.values().forEach { f ->
                        val sel = config.cameraFacing == f
                        FilterChip(
                            selected = sel,
                            onClick  = { viewModel.save(config.copy(cameraFacing = f)) },
                            label    = { Text(if (f == CameraFacing.BACK) "خلفية" else "أمامية", fontFamily = TajawalFamily) },
                            colors   = FilterChipDefaults.filterChipColors(selectedContainerColor = TealPrimary, selectedLabelColor = DeepBlack)
                        )
                    }
                }
            }

            // ── Sensitivity ──────────────────────────────────────────────────
            SettingsSection("حساسية الاكتشاف", Icons.Default.Tune) {
                SensitivityLevel.values().forEach { level ->
                    val sel = config.sensitivityLevel == level
                    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment     = Alignment.CenterVertically) {
                        Text(
                            when (level) {
                                SensitivityLevel.HIGH   -> "عالية (كل الحركات)"
                                SensitivityLevel.MEDIUM -> "متوسطة (موصى بها)"
                                SensitivityLevel.LOW    -> "منخفضة (وجوه واضحة فقط)"
                            },
                            color = if (sel) TealLight else TextSecondary,
                            fontFamily = TajawalFamily, fontSize = 14.sp
                        )
                        RadioButton(selected = sel,
                            onClick = { viewModel.save(config.copy(sensitivityLevel = level)) },
                            colors  = RadioButtonDefaults.colors(selectedColor = TealPrimary))
                    }
                }
            }

            // ── Night Mode (Smart) ────────────────────────────────────────────
            SettingsSection("الوضع الليلي الذكي", Icons.Default.Nightlight) {
                SettingToggle("تقليل الحساسية تلقائياً في الليل", config.nightModeEnabled) {
                    viewModel.save(config.copy(nightModeEnabled = it))
                }
                if (config.nightModeEnabled) {
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(Modifier.weight(1f)) {
                            Text("بداية الليل", color = TextSecondary, fontSize = 12.sp, fontFamily = TajawalFamily)
                            Spacer(Modifier.height(4.dp))
                            HourSelector(config.nightStartHour) {
                                viewModel.save(config.copy(nightStartHour = it))
                            }
                        }
                        Column(Modifier.weight(1f)) {
                            Text("نهاية الليل", color = TextSecondary, fontSize = 12.sp, fontFamily = TajawalFamily)
                            Spacer(Modifier.height(4.dp))
                            HourSelector(config.nightEndHour) {
                                viewModel.save(config.copy(nightEndHour = it))
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "الآن: في وضع ${if (config.nightModeEnabled) "ليلي ذكي" else "عادي"} — " +
                        "يقل الـ frame rate تلقائياً من ${config.nightStartHour}:00 إلى ${config.nightEndHour}:00",
                        color = TealDark, fontSize = 11.sp, fontFamily = TajawalFamily
                    )
                }
            }

            // ── Kiosk Mode ────────────────────────────────────────────────────
            SettingsSection("وضع الكاميرا الثابتة", Icons.Default.Tv) {
                SettingToggle("إبقاء الشاشة مضاءة دائماً عند المراقبة", config.kioskModeEnabled) {
                    viewModel.save(config.copy(kioskModeEnabled = it))
                }
                if (config.kioskModeEnabled) {
                    Spacer(Modifier.height(6.dp))
                    Text("الشاشة لن تُطفأ تلقائياً في شاشة المراقبة الحية",
                        color = TealDark, fontSize = 11.sp, fontFamily = TajawalFamily)
                }
            }

            // ── Telegram ─────────────────────────────────────────────────────
            SettingsSection("إرسال التنبيهات للتيلكرام", Icons.Default.Send) {
                SettingToggle("تفعيل إرسال التيلكرام", config.telegram.enabled) {
                    viewModel.save(config.copy(telegram = config.telegram.copy(enabled = it)))
                }
                if (config.telegram.enabled) {
                    Spacer(Modifier.height(12.dp))
                    SentinelTextField("Bot Token (من BotFather)", tgToken, isPassword = false) { tgToken = it }
                    Spacer(Modifier.height(8.dp))
                    SentinelTextField("Chat ID (رقم المحادثة)", tgChatId, isPassword = false) { tgChatId = it }
                    Spacer(Modifier.height(10.dp))
                    SettingToggle("إرسال صور المتطفلين", config.telegram.sendPhotos) {
                        viewModel.save(config.copy(telegram = config.telegram.copy(sendPhotos = it)))
                    }
                    SettingToggle("إرسال التسجيلات", config.telegram.sendVideos) {
                        viewModel.save(config.copy(telegram = config.telegram.copy(sendVideos = it)))
                    }
                    Spacer(Modifier.height(12.dp))
                    NeonButton("حفظ إعدادات التيلكرام", onClick = {
                        viewModel.save(config.copy(telegram = config.telegram.copy(
                            botToken = tgToken.trim(), chatId = tgChatId.trim()
                        )))
                        tgSaved = true
                    })
                    if (tgSaved) {
                        Spacer(Modifier.height(6.dp))
                        Text("✓ تم الحفظ — سيُرسل التنبيه عند الاكتشاف التالي",
                            color = ActiveGreen, fontSize = 12.sp, fontFamily = TajawalFamily)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("للحصول على Bot Token: افتح BotFather في التيلكرام → /newbot\nللحصول على Chat ID: أرسل رسالة للبوت ثم ادخل:\nhttps://api.telegram.org/bot{TOKEN}/getUpdates",
                        color = TextDim, fontSize = 11.sp, fontFamily = TajawalFamily, lineHeight = 16.sp)
                }
            }

            // ── Auto Start + Emergency ────────────────────────────────────────
            SettingsSection("التشغيل التلقائي", Icons.Default.PowerSettingsNew) {
                SettingToggle("تشغيل عند إعادة تشغيل الهاتف", config.autoStartOnBoot) {
                    viewModel.save(config.copy(autoStartOnBoot = it))
                }
                SettingToggle("تفعيل زر الطوارئ (رفع الصوت ×٢)", config.emergencyTriggerEnabled) {
                    viewModel.save(config.copy(emergencyTriggerEnabled = it))
                }
            }

            // ── Security ──────────────────────────────────────────────────────
            SettingsSection("الأمان", Icons.Default.Lock) {
                SentinelTextField("رمز PIN الجديد", newPin, isPassword = true) { newPin = it }
                Spacer(Modifier.height(8.dp))
                SentinelTextField("رمز الطوارئ (Panic) الجديد", newPanic, isPassword = true) { newPanic = it }
                Spacer(Modifier.height(12.dp))
                NeonButton("حفظ الرموز", onClick = {
                    if (newPin.length >= 4)   viewModel.updatePin(newPin)
                    if (newPanic.length >= 4) viewModel.updatePanic(newPanic)
                    saved = true; newPin = ""; newPanic = ""
                })
                if (saved) {
                    Spacer(Modifier.height(8.dp))
                    Text("✓ تم الحفظ", color = ActiveGreen, fontFamily = TajawalFamily, fontSize = 13.sp)
                }
            }

            Spacer(Modifier.height(48.dp))
        }
    }
}

// ── Hour Selector (0-23) ──────────────────────────────────────────────────────
@Composable
private fun HourSelector(current: Int, onChanged: (Int) -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        IconButton(
            onClick  = { onChanged(if (current == 0) 23 else current - 1) },
            modifier = Modifier.size(28.dp)
        ) {
            Icon(Icons.Default.Remove, null, tint = TealLight, modifier = Modifier.size(16.dp))
        }
        Text(
            "${current.toString().padStart(2, '0')}:00",
            color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = TajawalFamily
        )
        IconButton(
            onClick  = { onChanged(if (current == 23) 0 else current + 1) },
            modifier = Modifier.size(28.dp)
        ) {
            Icon(Icons.Default.Add, null, tint = TealLight, modifier = Modifier.size(16.dp))
        }
    }
}

// ── Shared composables ────────────────────────────────────────────────────────
@Composable
private fun SettingsSection(title: String, icon: ImageVector, content: @Composable ColumnScope.() -> Unit) {
    GlassmorphicCard(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(icon, null, tint = TealPrimary, modifier = Modifier.size(20.dp))
                Text(title, color = TealLight, fontSize = 15.sp, fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
            }
            Spacer(Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
private fun SettingToggle(label: String, checked: Boolean, onToggle: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextSecondary, fontFamily = TajawalFamily, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onToggle,
            colors = SwitchDefaults.colors(checkedThumbColor = DeepBlack, checkedTrackColor = TealPrimary))
    }
}

@Composable
private fun SentinelTextField(label: String, value: String, isPassword: Boolean = false, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value, onValueChange = onChange,
        label = { Text(label, fontFamily = TajawalFamily, fontSize = 13.sp) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        visualTransformation = if (isPassword) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (isPassword) KeyboardType.NumberPassword else KeyboardType.Text),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor   = TealPrimary, unfocusedBorderColor = GlassBorder,
            focusedLabelColor    = TealLight,   cursorColor          = TealPrimary,
            focusedTextColor     = TextPrimary, unfocusedTextColor   = TextSecondary
        ),
        shape = RoundedCornerShape(14.dp)
    )
}
