package com.husseindev.sentinelprotocol.domain.model

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Domain Models
//  برمجة حسين حميد
// ══════════════════════════════════════════

import android.graphics.RectF

// ── Recording Event ───────────────────────
data class RecordingEvent(
    val id            : Long   = 0,
    val filePath      : String,
    val thumbnailPath : String? = null,
    val timestamp     : Long   = System.currentTimeMillis(),
    val durationMs    : Long   = 0L,
    val triggerType   : TriggerType,
    val detectionCount: Int    = 0,
    val fileSizeBytes : Long   = 0L,
    val isEmergency   : Boolean = false
)

enum class TriggerType { MOTION_FACE, MOTION_PERSON, EMERGENCY_VOLUME, MANUAL }

// ── Detection Result ─────────────────────
data class DetectionResult(
    val faces       : List<DetectedFace>   = emptyList(),
    val persons     : List<DetectedPerson> = emptyList(),
    val timestamp   : Long = System.currentTimeMillis(),
    val imageWidth  : Int  = 0,
    val imageHeight : Int  = 0
) {
    val hasDetection  get() = faces.isNotEmpty() || persons.isNotEmpty()
    val totalDetected get() = faces.size + persons.size
}

// ── Detected Face — enriched with ML Kit ACCURATE data ────────────────────
data class DetectedFace(
    val boundingBox       : RectF,
    val confidence        : Float,
    val trackingId        : Int?   = null,
    val smileProbability  : Float  = 0f,
    val leftEyeOpenProb   : Float  = 0f,
    val rightEyeOpenProb  : Float  = 0f,
    val headEulerAngleY   : Float  = 0f  // Left/right head rotation
)

// ── Detected Person — enriched with Pose Detection data ──────────────────
data class DetectedPerson(
    val boundingBox   : RectF,
    val confidence    : Float,
    val label         : String = "شخص",
    val landmarkCount : Int    = 0
)

// ── Virtual Fence ─────────────────────────
// Normalized coordinates 0.0-1.0 relative to preview frame
data class VirtualFence(
    val left   : Float = 0f,
    val top    : Float = 0f,
    val right  : Float = 1f,
    val bottom : Float = 1f,
    val enabled: Boolean = false
) {
    fun overlaps(bboxLeft: Float, bboxTop: Float, bboxRight: Float, bboxBottom: Float,
                 imgW: Int, imgH: Int): Boolean {
        if (!enabled || imgW == 0 || imgH == 0) return false
        val fL = left  * imgW; val fT = top    * imgH
        val fR = right * imgW; val fB = bottom * imgH
        return bboxLeft < fR && bboxRight > fL && bboxTop < fB && bboxBottom > fT
    }
}

// ── Telegram Config ───────────────────────
data class TelegramConfig(
    val botToken    : String  = "",
    val chatId      : String  = "",
    val enabled     : Boolean = false,
    val sendPhotos  : Boolean = true,   // Intruder selfies
    val sendVideos  : Boolean = true    // Recordings
)

// ── Sentinel Config ───────────────────────
data class SentinelConfig(
    val pin                     : String         = "1234",
    val panicCode               : String         = "0000",
    val cameraFacing            : CameraFacing   = CameraFacing.BACK,
    val sensitivityLevel        : SensitivityLevel = SensitivityLevel.MEDIUM,
    val autoStartOnBoot         : Boolean        = false,
    val emergencyTriggerEnabled : Boolean        = true,
    val batteryStopThreshold    : Int            = 15,
    // ── New features ──
    val kioskModeEnabled        : Boolean        = false,
    val nightModeEnabled        : Boolean        = true,   // Smart auto-reduce at night
    val nightStartHour          : Int            = 23,     // 11 PM
    val nightEndHour            : Int            = 6,      // 6 AM
    val virtualFence            : VirtualFence   = VirtualFence(),
    val telegram                : TelegramConfig = TelegramConfig()
)

enum class CameraFacing { FRONT, BACK }
enum class SensitivityLevel(val minConfidence: Float) {
    LOW(0.7f), MEDIUM(0.5f), HIGH(0.3f)
}

// ── Monitoring State ─────────────────────
sealed class MonitoringState {
    object Idle          : MonitoringState()
    object Starting      : MonitoringState()
    data class Active(val detectionResult: DetectionResult? = null) : MonitoringState()
    data class Recording(val secondsElapsed: Int = 0, val trigger: TriggerType) : MonitoringState()
    data class Error(val message: String) : MonitoringState()
}

// ── Intruder Photo ────────────────────────
data class IntruderPhoto(
    val id            : Long   = 0,
    val filePath      : String,
    val timestamp     : Long   = System.currentTimeMillis(),
    val attemptNumber : Int    = 0
)

// ── Hourly Activity (for heatmap) ─────────
data class HourlyActivity(
    val hour  : Int,   // 0-23
    val count : Int
)
