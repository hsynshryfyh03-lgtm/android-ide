package com.husseindev.sentinelprotocol

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.navigation.compose.rememberNavController
import com.husseindev.sentinelprotocol.camera.CameraEngine
import com.husseindev.sentinelprotocol.presentation.components.NeonButton
import com.husseindev.sentinelprotocol.presentation.navigation.SentinelNavGraph
import com.husseindev.sentinelprotocol.presentation.theme.*
import com.husseindev.sentinelprotocol.service.EmergencyRecordService
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — MainActivity
//  Runtime Permission Request + Volume Hook
//  برمجة حسين حميد
// ══════════════════════════════════════════

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var cameraEngine: CameraEngine

    private var lastVolumeUpTime = 0L
    private val doublePressMs   = 500L

    // All permissions the app needs
    private val REQUIRED_PERMISSIONS = arrayOf(
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO
    )

    // State: are all permissions granted?
    private val permissionsGranted = mutableStateOf(false)

    // Permission launcher
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        permissionsGranted.value = results.values.all { it }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Check permissions immediately
        permissionsGranted.value = allPermissionsGranted()

        setContent {
            SentinelTheme {
                val granted by permissionsGranted

                if (granted) {
                    // ── Normal app flow ─────────────────────────────────────
                    val navController = rememberNavController()
                    SentinelNavGraph(
                        navController = navController,
                        cameraEngine  = cameraEngine
                    )
                } else {
                    // ── Permission request screen ───────────────────────────
                    PermissionRequestScreen(
                        onRequest = { permissionLauncher.launch(REQUIRED_PERMISSIONS) }
                    )
                }
            }
        }

        // If not granted yet, request immediately on start
        if (!allPermissionsGranted()) {
            permissionLauncher.launch(REQUIRED_PERMISSIONS)
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    // ── Volume button emergency hook ──────────────────────────────────────────
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            val now  = System.currentTimeMillis()
            val diff = now - lastVolumeUpTime
            if (diff <= doublePressMs) {
                startService(Intent(this, EmergencyRecordService::class.java).apply {
                    action = EmergencyRecordService.ACTION_VOLUME_UP_PRESSED
                })
                lastVolumeUpTime = 0L
                return true
            }
            lastVolumeUpTime = now
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        super.onDestroy()
        // Service continues in background intentionally
    }
}

// ── Permission request UI ─────────────────────────────────────────────────────
@androidx.compose.runtime.Composable
private fun PermissionRequestScreen(onRequest: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize().background(DeepBlack),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Text(
                text       = "SENTINEL",
                color      = TealLight,
                fontSize   = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = TajawalFamily,
                letterSpacing = 6.sp
            )
            Spacer(Modifier.height(32.dp))
            androidx.compose.foundation.layout.Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GlassHighlight, RoundedCornerShape(16.dp))
                    .padding(20.dp)
            ) {
                Column {
                    Text(
                        text       = "يحتاج التطبيق صلاحيتين:",
                        color      = TextPrimary,
                        fontSize   = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = TajawalFamily
                    )
                    Spacer(Modifier.height(12.dp))
                    PermissionRow("الكاميرا", "للمراقبة والتسجيل")
                    Spacer(Modifier.height(8.dp))
                    PermissionRow("الميكروفون", "لتسجيل الصوت مع الفيديو")
                }
            }
            Spacer(Modifier.height(32.dp))
            NeonButton(text = "منح الصلاحيات", onClick = onRequest)
        }
    }
}

@androidx.compose.runtime.Composable
private fun PermissionRow(title: String, desc: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            Modifier
                .size(8.dp)
                .background(TealPrimary, RoundedCornerShape(4.dp))
        )
        Column {
            Text(title, color = TealLight,     fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
            Text(desc,  color = TextSecondary, fontSize = 12.sp, fontFamily = TajawalFamily)
        }
    }
}
