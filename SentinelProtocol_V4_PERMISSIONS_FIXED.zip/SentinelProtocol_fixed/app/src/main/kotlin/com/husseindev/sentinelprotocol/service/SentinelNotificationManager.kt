package com.husseindev.sentinelprotocol.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.husseindev.sentinelprotocol.MainActivity
import com.husseindev.sentinelprotocol.core.constants.AppConstants
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Notification Manager
//  + Quick Stop action in notification
//  برمجة حسين حميد
// ══════════════════════════════════════════

@Singleton
class SentinelNotificationManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun createNotificationChannel() {
        NotificationChannel(
            AppConstants.NOTIFICATION_CHANNEL_ID,
            "System Services",
            NotificationManager.IMPORTANCE_MIN
        ).apply {
            description          = "Background system optimization"
            setShowBadge(false)
            enableLights(false)
            enableVibration(false)
            lockscreenVisibility = Notification.VISIBILITY_SECRET
        }.also { nm.createNotificationChannel(it) }
    }

    fun buildForegroundNotification(): Notification {
        // Tap notification → open app
        val openIntent = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_SINGLE_TOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // ── Quick STOP action ──────────────────────────────────────────────
        val stopIntent = PendingIntent.getService(
            context, 1,
            Intent(context, SentinelForegroundService::class.java).apply {
                action = SentinelForegroundService.ACTION_STOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(context, AppConstants.NOTIFICATION_CHANNEL_ID)
            .setContentTitle(AppConstants.NOTIFICATION_TITLE)
            .setContentText("Running background optimization…")
            .setSmallIcon(android.R.drawable.ic_secure)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setSilent(true)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .setContentIntent(openIntent)
            // Quick stop button in notification drawer
            .addAction(
                android.R.drawable.ic_media_pause,
                "إيقاف",
                stopIntent
            )
            .build()
    }

    fun showIntruderAlert(photoPath: String?) {
        val intent = PendingIntent.getActivity(
            context, 2,
            Intent(context, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_SINGLE_TOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = NotificationCompat.Builder(context, AppConstants.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("System Secure")
            .setContentText("Motion detected")
            .setSmallIcon(android.R.drawable.ic_secure)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(intent)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)

        nm.notify(AppConstants.NOTIFICATION_ID_ALERT, builder.build())
    }

    fun showBatteryWarning() {
        nm.notify(
            AppConstants.NOTIFICATION_ID_ALERT,
            NotificationCompat.Builder(context, AppConstants.NOTIFICATION_CHANNEL_ID)
                .setContentTitle("System Secure")
                .setContentText("Battery low — optimization paused")
                .setSmallIcon(android.R.drawable.ic_secure)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()
        )
    }
}
