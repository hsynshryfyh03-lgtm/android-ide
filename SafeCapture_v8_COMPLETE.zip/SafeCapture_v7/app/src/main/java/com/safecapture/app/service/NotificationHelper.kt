package com.safecapture.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.safecapture.app.MainActivity
import com.safecapture.app.R

/**
 * Centralises every notification used by [RecordingService].
 * Must be called from the service — no Hilt injection needed.
 */
object NotificationHelper {

    const val CHANNEL_ID         = "safecapture_recording"
    const val NOTIFICATION_ID    = 1001

    // ── Action intent extras sent back to RecordingService ────────────────────
    const val ACTION_STOP        = "com.safecapture.app.ACTION_STOP_RECORDING"

    fun createChannel(context: Context) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE)
                as NotificationManager
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return

        val channel = NotificationChannel(
            CHANNEL_ID,
            context.getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_LOW,          // silent — no sound/vibration
        ).apply {
            description    = context.getString(R.string.notification_channel_desc)
            setShowBadge(false)
            enableLights(false)
            enableVibration(false)
        }
        manager.createNotificationChannel(channel)
    }

    /** Notification shown while recording is active. */
    fun buildRecordingNotification(context: Context): Notification {
        val openIntent = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val stopIntent = PendingIntent.getService(
            context, 1,
            Intent(context, RecordingService::class.java).apply {
                action = ACTION_STOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )

        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_splash_icon)
            .setContentTitle(context.getString(R.string.notification_recording_title))
            .setContentText(context.getString(R.string.notification_recording_text))
            .setContentIntent(openIntent)
            .addAction(
                android.R.drawable.ic_media_pause,
                context.getString(R.string.stop_recording),
                stopIntent,
            )
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setSilent(true)
            .build()
    }

    /** Notification shown while the service is idle (ready state). */
    fun buildIdleNotification(context: Context): Notification {
        val openIntent = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_splash_icon)
            .setContentTitle(context.getString(R.string.notification_idle_title))
            .setContentText(context.getString(R.string.notification_idle_text))
            .setContentIntent(openIntent)
            .setOngoing(false)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setSilent(true)
            .build()
    }
}
