package com.safecapture.app.presentation.theme

import androidx.compose.ui.graphics.Color

// ── Neomorphism Base Palette ──────────────────────────────────────────────────
val NeoBackground   = Color(0xFFE8EBF0)
val NeoSurface      = Color(0xFFEEF0F5)
val NeoShadowLight  = Color(0xFFFFFFFF)
val NeoShadowDark   = Color(0xFFC2C8D4)

// ── Accent Colors ─────────────────────────────────────────────────────────────
val AccentPrimary   = Color(0xFF5E81F4)
val AccentSecondary = Color(0xFF9B59B6)
val AccentRecording = Color(0xFFE74C3C)
val AccentSuccess   = Color(0xFF2ECC71)
val AccentWarning   = Color(0xFFF39C12)

// ── Text Colors ───────────────────────────────────────────────────────────────
val TextPrimary     = Color(0xFF1A2035)
val TextSecondary   = Color(0xFF6B7280)
val TextHint        = Color(0xFF9CA3AF)

// ── Overlay & Glass ───────────────────────────────────────────────────────────
val GlassWhite      = Color(0x1AFFFFFF)   // 10% white
val OverlayDark     = Color(0x33000000)   // 20% black scrim
