package com.safecapture.app.di

import android.content.Context
import androidx.room.Room
import com.safecapture.app.data.local.RecordingDatabase
import com.safecapture.app.data.local.dao.RecordingDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(
        @ApplicationContext context: Context,
    ): RecordingDatabase = Room.databaseBuilder(
        context,
        RecordingDatabase::class.java,
        RecordingDatabase.DATABASE_NAME,
    )
        // No migrations for v1 — destructive only during development.
        // Add proper Migration objects here before production release.
        .fallbackToDestructiveMigration()
        .build()

    @Provides
    @Singleton
    fun provideRecordingDao(db: RecordingDatabase): RecordingDao =
        db.recordingDao()
}
