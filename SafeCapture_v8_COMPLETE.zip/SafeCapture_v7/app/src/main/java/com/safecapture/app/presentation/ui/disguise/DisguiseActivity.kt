package com.safecapture.app.presentation.ui.disguise

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.safecapture.app.MainActivity

/**
 * A convincing calculator UI that disguises SafeCapture.
 *
 * Secret unlock: Type 911 then press =
 * Launches MainActivity and finishes this activity.
 *
 * android:excludeFromRecents="true" in the manifest keeps it
 * out of the recent-apps switcher.
 */
class DisguiseActivity : ComponentActivity() {

    internal companion object {
        const val SECRET_CODE = "911"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CalculatorScreen(
                onSecretUnlocked = {
                    startActivity(Intent(this, MainActivity::class.java))
                    finish()
                }
            )
        }
    }
}

@Composable
private fun CalculatorScreen(onSecretUnlocked: () -> Unit) {
    var display  by remember { mutableStateOf("0") }
    var rawInput by remember { mutableStateOf("") }

    val bgColor      = Color(0xFF1C1C1E)
    val buttonDark   = Color(0xFF2C2C2E)
    val buttonMid    = Color(0xFF3A3A3C)
    val buttonOrange = Color(0xFFFF9F0A)

    fun handleKey(key: String) {
        when (key) {
            "AC"  -> { rawInput = ""; display = "0" }
            "+/-" -> {
                val v = display.toDoubleOrNull() ?: return
                display = (-v).toCleanString()
            }
            "%" -> {
                val v = display.toDoubleOrNull() ?: return
                display  = (v / 100.0).toCleanString()
                rawInput = display
            }
            "=" -> {
                if (rawInput == DisguiseActivity.SECRET_CODE) { onSecretUnlocked(); return }
                display = try { evalExpression(rawInput).toCleanString() }
                          catch (_: Exception) { "Error" }
                rawInput = display
            }
            "+", "-", "×", "÷" -> { rawInput += key; display = key }
            "." -> {
                val last = rawInput.split("+", "-", "×", "÷").last()
                if (!last.contains(".")) { rawInput += "."; display += "." }
            }
            else -> {
                val parts    = rawInput.split(Regex("(?<=[+\\-×÷])"))
                val lastPart = parts.lastOrNull() ?: ""
                display  = if (lastPart.isEmpty() || lastPart == "0") key else lastPart + key
                rawInput += key
            }
        }
    }

    Box(
        modifier = Modifier.fillMaxSize().background(bgColor).padding(horizontal = 12.dp),
    ) {
        Column(
            modifier            = Modifier.align(Alignment.BottomCenter),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text       = display,
                color      = Color.White,
                fontSize   = 72.sp,
                fontWeight = FontWeight.Light,
                textAlign  = TextAlign.End,
                maxLines   = 1,
                modifier   = Modifier.fillMaxWidth().padding(bottom = 8.dp, end = 8.dp),
            )

            val rows = listOf(
                listOf("AC", "+/-", "%", "÷"),
                listOf("7",  "8",   "9", "×"),
                listOf("4",  "5",   "6", "-"),
                listOf("1",  "2",   "3", "+"),
                listOf("0",  ".",   "="),
            )
            rows.forEach { row ->
                Row(
                    modifier              = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    row.forEach { key ->
                        val isOrange = key in listOf("÷", "×", "-", "+", "=")
                        val isLight  = key in listOf("AC", "+/-", "%")
                        CalcButton(
                            label   = key,
                            color   = when { isOrange -> buttonOrange; isLight -> buttonMid; else -> buttonDark },
                            weight  = if (key == "0") 2f else 1f,
                            onClick = { handleKey(key) },
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun CalcButton(
    label  : String,
    color  : Color,
    weight : Float,
    onClick: () -> Unit,
) {
    Box(
        modifier = Modifier
            .weight(weight)
            .height(80.dp)
            .clip(RoundedCornerShape(percent = 50))
            .background(color)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication        = null,
                onClick           = onClick,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Text(text = label, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Normal)
    }
}

private fun evalExpression(expr: String): Double {
    if (expr.isBlank()) return 0.0
    val tokens = Regex("([+\\-×÷]|\\d+\\.?\\d*)").findAll(expr).map { it.value }.toList()
    if (tokens.isEmpty()) return expr.toDouble()
    var result = tokens[0].toDouble()
    var i = 1
    while (i < tokens.size - 1) {
        val op    = tokens[i]
        val right = tokens[i + 1].toDouble()
        result    = when (op) { "+" -> result + right; "-" -> result - right
                                "×" -> result * right; "÷" -> result / right; else -> result }
        i += 2
    }
    return result
}

private fun Double.toCleanString(): String =
    if (this == toLong().toDouble()) toLong().toString() else toString()
