package com.safecapture.app.data.repository

import com.safecapture.app.data.local.dao.RecordingDao
import com.safecapture.app.data.local.entity.RecordingEntity
import com.safecapture.app.domain.model.Recording
import com.safecapture.app.domain.repository.IRecordingRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class RecordingRepositoryImpl @Inject constructor(
    private val dao: RecordingDao,
) : IRecordingRepository {

    // ── Observe ───────────────────────────────────────────────────────────────

    override fun observeAll(): Flow<List<Recording>> =
        dao.observeAll().map { list -> list.map { it.toDomain() } }

    override fun search(query: String): Flow<List<Recording>> =
        dao.search(query).map { list -> list.map { it.toDomain() } }

    override fun observeCount(): Flow<Int> =
        dao.observeCount()

    override fun observeTotalDuration(): Flow<Long> =
        dao.observeTotalDuration()

    override fun observeTotalSize(): Flow<Long> =
        dao.observeTotalSize()

    // ── Suspend ───────────────────────────────────────────────────────────────

    override suspend fun insert(recording: Recording): Long =
        dao.insert(RecordingEntity.fromDomain(recording))

    override suspend fun update(recording: Recording) =
        dao.update(RecordingEntity.fromDomain(recording))

    override suspend fun updateDurationAndSize(id: Long, durationMs: Long, sizeBytes: Long) =
        dao.updateDurationAndSize(id, durationMs, sizeBytes)

    override suspend fun markUploaded(id: Long) =
        dao.markUploaded(id)

    override suspend fun setUploadPending(id: Long, pending: Boolean) =
        dao.setUploadPending(id, pending)

    override suspend fun getPendingUploads(): List<Recording> =
        dao.getPendingUploads().map { it.toDomain() }

    override suspend fun getById(id: Long): Recording? =
        dao.getById(id)?.toDomain()

    override suspend fun deleteById(id: Long) =
        dao.deleteById(id)

    override suspend fun deleteAll() =
        dao.deleteAll()

    override suspend fun deleteOldest(keepCount: Int) =
        dao.deleteOldest(keepCount)
}
