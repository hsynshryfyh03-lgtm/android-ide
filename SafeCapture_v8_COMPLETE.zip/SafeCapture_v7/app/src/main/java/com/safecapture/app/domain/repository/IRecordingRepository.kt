package com.safecapture.app.domain.repository

import com.safecapture.app.domain.model.Recording
import kotlinx.coroutines.flow.Flow

/**
 * Domain contract for recording persistence.
 * ViewModels depend on this interface — never on the Room implementation directly.
 */
interface IRecordingRepository {

    // ── Observe (reactive) ────────────────────────────────────────────────────

    /** Emits the full list of recordings, newest first. */
    fun observeAll(): Flow<List<Recording>>

    /** Emits recordings whose filename matches [query] (case-insensitive). */
    fun search(query: String): Flow<List<Recording>>

    /** Emits the total count of recordings. */
    fun observeCount(): Flow<Int>

    /** Emits the sum of all recording durations in milliseconds. */
    fun observeTotalDuration(): Flow<Long>

    /** Emits the total file size used by all recordings in bytes. */
    fun observeTotalSize(): Flow<Long>

    // ── Suspend (one-shot) ────────────────────────────────────────────────────

    /** Inserts a new recording and returns its assigned id. */
    suspend fun insert(recording: Recording): Long

    /** Updates an existing recording (matched by id). */
    suspend fun update(recording: Recording)

    /** Updates the final duration and file size after the recording finishes. */
    suspend fun updateDurationAndSize(id: Long, durationMs: Long, sizeBytes: Long)

    /** Marks the recording as successfully uploaded to Telegram. */
    suspend fun markUploaded(id: Long)

    /** Sets / clears the upload-pending flag. */
    suspend fun setUploadPending(id: Long, pending: Boolean)

    /** Returns all recordings that need to be uploaded and are not already queued. */
    suspend fun getPendingUploads(): List<Recording>

    /** Returns a single recording by id, or null if it has been deleted. */
    suspend fun getById(id: Long): Recording?

    /** Permanently deletes a recording by id. */
    suspend fun deleteById(id: Long)

    /** Permanently deletes all recordings. */
    suspend fun deleteAll()

    /**
     * Deletes oldest recordings, keeping only [keepCount] most recent.
     * Used by the auto-delete WorkManager worker.
     */
    suspend fun deleteOldest(keepCount: Int)
}
