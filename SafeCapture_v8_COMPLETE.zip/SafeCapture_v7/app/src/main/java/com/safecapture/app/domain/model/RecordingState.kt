package com.safecapture.app.domain.model

/**
 * Represents the current state of the recording engine.
 * Shared between [RecordingService] (producer) and ViewModels (consumers)
 * via a companion object StateHolder backed by StateFlow.
 */
sealed class RecordingState {

    /** Camera is ready, nothing is recording. */
    object Idle : RecordingState()

    /**
     * Recording is active.
     * @param recordingId  Room id of the current recording row.
     * @param startedAt    Unix epoch millis when recording began.
     */
    data class Recording(
        val recordingId : Long,
        val startedAt   : Long = System.currentTimeMillis(),
    ) : RecordingState()

    /**
     * Recording has stopped; file is being finalised (mux + metadata update).
     */
    object Saving : RecordingState()

    /**
     * A non-recoverable error occurred.
     * @param message  Human-readable description for debugging.
     */
    data class Error(val message: String) : RecordingState()
}
