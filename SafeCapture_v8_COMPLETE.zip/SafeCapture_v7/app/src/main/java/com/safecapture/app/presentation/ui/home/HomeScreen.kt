package com.safecapture.app.presentation.ui.home

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.safecapture.app.R
import com.safecapture.app.domain.model.RecordingState
import com.safecapture.app.presentation.theme.AccentPrimary
import com.safecapture.app.presentation.theme.AccentRecording
import com.safecapture.app.presentation.theme.NeoBackground
import com.safecapture.app.presentation.theme.TextHint
import com.safecapture.app.presentation.theme.TextPrimary
import com.safecapture.app.presentation.theme.TextSecondary
import com.safecapture.app.presentation.theme.neomorphicShadow

@Composable
fun HomeScreen(vm: HomeViewModel = hiltViewModel()) {
    val state         by vm.recordingState.collectAsStateWithLifecycle()
    val elapsed       by vm.elapsedSeconds.collectAsStateWithLifecycle()
    val count         by vm.recordingCount.collectAsStateWithLifecycle()
    val totalDuration by vm.totalDurationMs.collectAsStateWithLifecycle()
    val totalSize     by vm.totalSizeBytes.collectAsStateWithLifecycle()

    val isRecording = state is RecordingState.Recording
    val isSaving    = state is RecordingState.Saving

    Column(
        modifier            = Modifier
            .fillMaxSize()
            .background(NeoBackground)
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(40.dp))

        Text(
            text       = "SafeCapture",
            style      = MaterialTheme.typography.headlineMedium,
            color      = TextPrimary,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text  = when {
                isRecording -> stringResource(R.string.status_recording)
                isSaving    -> stringResource(R.string.status_saving)
                else        -> stringResource(R.string.status_idle)
            },
            style = MaterialTheme.typography.bodyMedium,
            color = if (isRecording) AccentRecording else TextSecondary,
        )

        Spacer(Modifier.height(48.dp))

        RecordButton(
            isRecording = isRecording,
            isSaving    = isSaving,
            elapsed     = elapsed,
            onClick     = { vm.toggleRecording() },
        )

        Spacer(Modifier.height(16.dp))

        Text(
            text      = stringResource(R.string.double_press_hint),
            style     = MaterialTheme.typography.labelSmall,
            color     = TextHint,
            textAlign = TextAlign.Center,
        )

        Spacer(Modifier.weight(1f))

        StatsRow(
            count           = count,
            totalDurationMs = totalDuration,
            totalSizeBytes  = totalSize,
        )

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun RecordButton(
    isRecording: Boolean,
    isSaving   : Boolean,
    elapsed    : Long,
    onClick    : () -> Unit,
) {
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue  = 1f,
        targetValue   = 1.08f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label         = "scale",
    )
    val btnColor by animateColorAsState(
        targetValue   = if (isRecording) AccentRecording else AccentPrimary,
        animationSpec = tween(400),
        label         = "color",
    )
    val interactionSource = remember { MutableInteractionSource() }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(200.dp)
                .scale(if (isRecording) pulse else 1f)
                .neomorphicShadow(shadowRadius = 16.dp, offset = 8.dp, cornerRadius = 100.dp)
                .clip(CircleShape)
                .background(NeoBackground)
                .then(
                    if (!isSaving) Modifier.clickable(
                        interactionSource = interactionSource,
                        indication        = null,
                        onClick           = onClick,
                    ) else Modifier
                ),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                modifier         = Modifier.size(148.dp).clip(CircleShape).background(btnColor),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector        = if (isRecording) Icons.Filled.Stop else Icons.Filled.FiberManualRecord,
                    contentDescription = null,
                    tint               = Color.White,
                    modifier           = Modifier.size(56.dp),
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        if (isRecording) {
            Text(
                text       = elapsed.toHms(),
                style      = MaterialTheme.typography.headlineMedium,
                color      = AccentRecording,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text  = stringResource(R.string.tap_to_stop),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
            )
        } else {
            Text(
                text       = stringResource(R.string.tap_to_start),
                style      = MaterialTheme.typography.bodyLarge,
                color      = TextSecondary,
                fontWeight = FontWeight.Medium,
            )
        }
    }
}

@Composable
private fun StatsRow(count: Int, totalDurationMs: Long, totalSizeBytes: Long) {
    Row(
        modifier              = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        StatCard(Modifier.weight(1f), count.toString(),                         stringResource(R.string.recordings_count))
        StatCard(Modifier.weight(1f), (totalDurationMs / 1000L).toHms(),        stringResource(R.string.total_duration))
        StatCard(Modifier.weight(1f), totalSizeBytes.toReadableSize(),          stringResource(R.string.storage_used))
    }
}

@Composable
private fun StatCard(modifier: Modifier, value: String, label: String) {
    Column(
        modifier            = modifier
            .neomorphicShadow(shadowRadius = 6.dp, offset = 3.dp, cornerRadius = 16.dp)
            .padding(vertical = 14.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(text = value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextPrimary, textAlign = TextAlign.Center)
        Spacer(Modifier.height(2.dp))
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextHint, textAlign = TextAlign.Center)
    }
}

private fun Long.toHms(): String {
    val h = this / 3600; val m = (this % 3600) / 60; val s = this % 60
    return "%02d:%02d:%02d".format(h, m, s)
}
private fun Long.toReadableSize(): String = when {
    this < 1_024L              -> "${this} B"
    this < 1_048_576L          -> "${"%.1f".format(this / 1_024.0)} KB"
    this < 1_073_741_824L      -> "${"%.1f".format(this / 1_048_576.0)} MB"
    else                       -> "${"%.1f".format(this / 1_073_741_824.0)} GB"
}
