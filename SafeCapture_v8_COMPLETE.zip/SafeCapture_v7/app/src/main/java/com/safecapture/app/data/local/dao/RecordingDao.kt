package com.safecapture.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.safecapture.app.data.local.entity.RecordingEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface RecordingDao {

    // ── INSERT ────────────────────────────────────────────────────────────────

    /**
     * Inserts a new recording row.
     * Returns the auto-generated row id so the service can store it immediately.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: RecordingEntity): Long

    // ── UPDATE ────────────────────────────────────────────────────────────────

    @Update
    suspend fun update(entity: RecordingEntity)

    /** Mark a recording as successfully uploaded to Telegram. */
    @Query("UPDATE recordings SET is_uploaded = 1, upload_pending = 0 WHERE id = :id")
    suspend fun markUploaded(id: Long)

    /** Set / clear the upload-pending flag (used by WorkManager worker). */
    @Query("UPDATE recordings SET upload_pending = :pending WHERE id = :id")
    suspend fun setUploadPending(id: Long, pending: Boolean)

    /** Update the final duration and size after recording stops. */
    @Query("UPDATE recordings SET duration_ms = :durationMs, size_bytes = :sizeBytes WHERE id = :id")
    suspend fun updateDurationAndSize(id: Long, durationMs: Long, sizeBytes: Long)

    // ── SELECT ────────────────────────────────────────────────────────────────

    /** Reactive list — newest first. Used by RecordingsScreen. */
    @Query("SELECT * FROM recordings ORDER BY created_at DESC")
    fun observeAll(): Flow<List<RecordingEntity>>

    /** Search by file name — case-insensitive, newest first. */
    @Query("""
        SELECT * FROM recordings
        WHERE LOWER(file_name) LIKE '%' || LOWER(:query) || '%'
        ORDER BY created_at DESC
    """)
    fun search(query: String): Flow<List<RecordingEntity>>

    /** All recordings that haven't been uploaded yet and are not pending. */
    @Query("SELECT * FROM recordings WHERE is_uploaded = 0 AND upload_pending = 0")
    suspend fun getPendingUploads(): List<RecordingEntity>

    /** Single recording by id — nullable if deleted. */
    @Query("SELECT * FROM recordings WHERE id = :id")
    suspend fun getById(id: Long): RecordingEntity?

    /** Total number of recordings. */
    @Query("SELECT COUNT(*) FROM recordings")
    fun observeCount(): Flow<Int>

    /** Total duration of all recordings in milliseconds. */
    @Query("SELECT COALESCE(SUM(duration_ms), 0) FROM recordings")
    fun observeTotalDuration(): Flow<Long>

    /** Total size used by all recordings in bytes. */
    @Query("SELECT COALESCE(SUM(size_bytes), 0) FROM recordings")
    fun observeTotalSize(): Flow<Long>

    // ── DELETE ────────────────────────────────────────────────────────────────

    @Query("DELETE FROM recordings WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM recordings")
    suspend fun deleteAll()

    /**
     * Auto-delete oldest recordings beyond [keepCount].
     * Called by the auto-delete WorkManager worker.
     */
    @Query("""
        DELETE FROM recordings WHERE id IN (
            SELECT id FROM recordings
            ORDER BY created_at DESC
            LIMIT -1 OFFSET :keepCount
        )
    """)
    suspend fun deleteOldest(keepCount: Int)
}
