package com.safecapture.app.domain.model

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Process-level singleton that holds the live [RecordingState].
 *
 * Why a companion-object singleton instead of Hilt?
 * ─────────────────────────────────────────────────
 * [RecordingService] is a Foreground Service started by the system or by an
 * Accessibility Service. In both cases the service may be alive while NO
 * Activity exists. A regular Hilt ViewModel scoped to a NavBackStack entry
 * cannot survive this. Using a plain object guarantees the StateFlow is
 * accessible from the service, from ViewModels, and from the UI without
 * requiring an Activity context.
 */
object RecordingStateHolder {

    private val _state: MutableStateFlow<RecordingState> =
        MutableStateFlow(RecordingState.Idle)

    /** Read-only state observed by ViewModels and UI. */
    val state: StateFlow<RecordingState> = _state.asStateFlow()

    /** Called exclusively by [RecordingService]. */
    internal fun emit(newState: RecordingState) {
        _state.value = newState
    }
}
