package com.safecapture.app.domain.model

/**
 * Pure domain model — no Android/Room dependencies.
 * Used by ViewModels and UI layer.
 */
data class Recording(
    val id          : Long   = 0L,
    val fileName    : String,
    val filePath    : String,
    val durationMs  : Long   = 0L,   // milliseconds
    val sizeBytes   : Long   = 0L,
    val createdAt   : Long   = System.currentTimeMillis(),
    val isUploaded  : Boolean = false,
    val uploadPending: Boolean = false,
)
