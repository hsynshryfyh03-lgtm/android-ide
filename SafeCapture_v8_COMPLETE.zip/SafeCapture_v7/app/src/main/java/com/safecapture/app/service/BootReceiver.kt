package com.safecapture.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Receives [Intent.ACTION_BOOT_COMPLETED] and [Intent.ACTION_MY_PACKAGE_REPLACED]
 * after the device reboots or the app is updated.
 *
 * What it does:
 * ─────────────
 * • Accessibility Services are automatically re-enabled by the system after reboot
 *   IF the user had previously granted them. No explicit action is needed for that.
 *
 * • This receiver's job is to ensure any pending uploads that were queued in
 *   WorkManager before the reboot are re-scheduled, because WorkManager persists
 *   work across reboots only if REQUIRE_DEVICE_IDLE or REQUIRE_CHARGING constraints
 *   are not set. Our Telegram upload worker uses CONNECTED only, so it survives
 *   reboots automatically — but we re-enqueue as a safety net.
 *
 * • It also logs the boot event for debugging, and can be extended later to
 *   auto-start the RecordingService if the user opts for "always-on monitoring".
 *
 * Manifest config (already in AndroidManifest.xml):
 *   android:exported="true"   ← required: system has a different UID
 *   android:permission="android.permission.RECEIVE_BOOT_COMPLETED"  ← only system can trigger
 *   <action android:name="android.intent.action.BOOT_COMPLETED" />
 *   <action android:name="android.intent.action.MY_PACKAGE_REPLACED" />
 */
class BootReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "BootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED -> {
                Log.d(TAG, "Boot completed — SafeCapture initialising")
                reschedulePendingUploads(context)
            }
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                Log.d(TAG, "Package replaced — re-checking pending uploads")
                reschedulePendingUploads(context)
            }
            else -> {
                Log.w(TAG, "Unexpected action: ${intent.action}")
            }
        }
    }

    /**
     * Asks WorkManager to re-schedule any uploads that were pending when the
     * device shut down.
     *
     * WorkManager uses a Room-backed job store that survives reboots, so jobs
     * are typically re-queued automatically. Calling [pruneWork] here removes
     * completed/cancelled jobs from the internal DB to keep it clean.
     */
    private fun reschedulePendingUploads(context: Context) {
        try {
            androidx.work.WorkManager.getInstance(context).pruneWork()
            Log.d(TAG, "WorkManager prune complete")
        } catch (e: Exception) {
            // WorkManager may not be initialised yet on very early boot events.
            // This is benign — WorkManager initialises on next app launch.
            Log.w(TAG, "WorkManager not ready at boot: ${e.message}")
        }
    }
}
