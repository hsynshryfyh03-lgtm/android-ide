package com.safecapture.app.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.safecapture.app.domain.model.Recording

@Entity(tableName = "recordings")
data class RecordingEntity(

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0L,

    @ColumnInfo(name = "file_name")
    val fileName: String,

    @ColumnInfo(name = "file_path")
    val filePath: String,

    /** Duration in milliseconds. */
    @ColumnInfo(name = "duration_ms")
    val durationMs: Long = 0L,

    /** File size in bytes. */
    @ColumnInfo(name = "size_bytes")
    val sizeBytes: Long = 0L,

    /** Unix epoch millis — used for sorting and display. */
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),

    /** True after a successful Telegram upload. */
    @ColumnInfo(name = "is_uploaded")
    val isUploaded: Boolean = false,

    /** True while a WorkManager upload job is queued / running. */
    @ColumnInfo(name = "upload_pending")
    val uploadPending: Boolean = false,
) {
    // ── Mapper: Entity → Domain ───────────────────────────────────────────────
    fun toDomain(): Recording = Recording(
        id            = id,
        fileName      = fileName,
        filePath      = filePath,
        durationMs    = durationMs,
        sizeBytes     = sizeBytes,
        createdAt     = createdAt,
        isUploaded    = isUploaded,
        uploadPending = uploadPending,
    )

    companion object {
        // ── Mapper: Domain → Entity ───────────────────────────────────────────
        fun fromDomain(domain: Recording): RecordingEntity = RecordingEntity(
            id            = domain.id,
            fileName      = domain.fileName,
            filePath      = domain.filePath,
            durationMs    = domain.durationMs,
            sizeBytes     = domain.sizeBytes,
            createdAt     = domain.createdAt,
            isUploaded    = domain.isUploaded,
            uploadPending = domain.uploadPending,
        )
    }
}
