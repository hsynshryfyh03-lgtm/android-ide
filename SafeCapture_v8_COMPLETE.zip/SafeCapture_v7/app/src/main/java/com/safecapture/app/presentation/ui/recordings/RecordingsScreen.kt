package com.safecapture.app.presentation.ui.recordings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.safecapture.app.R
import com.safecapture.app.domain.model.Recording
import com.safecapture.app.presentation.theme.AccentPrimary
import com.safecapture.app.presentation.theme.AccentRecording
import com.safecapture.app.presentation.theme.AccentSuccess
import com.safecapture.app.presentation.theme.NeoBackground
import com.safecapture.app.presentation.theme.NeoSurface
import com.safecapture.app.presentation.theme.TextHint
import com.safecapture.app.presentation.theme.TextPrimary
import com.safecapture.app.presentation.theme.TextSecondary
import com.safecapture.app.presentation.theme.neomorphicShadow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RecordingsScreen(vm: RecordingsViewModel = hiltViewModel()) {
    val recordings  by vm.recordings.collectAsStateWithLifecycle()
    val query       by vm.query.collectAsStateWithLifecycle()
    val pendingDel  by vm.pendingDelete.collectAsStateWithLifecycle()
    val showDelAll  by vm.showDeleteAll.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier.fillMaxSize().background(NeoBackground).padding(horizontal = 16.dp),
    ) {
        Spacer(Modifier.height(20.dp))

        // ── Header ────────────────────────────────────────────────────────────
        Row(
            modifier       = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text       = stringResource(R.string.nav_recordings),
                style      = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color      = TextPrimary,
            )
            if (recordings.isNotEmpty()) {
                IconButton(onClick = { vm.requestDeleteAll() }) {
                    Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.delete_all), tint = AccentRecording)
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ── Search bar ────────────────────────────────────────────────────────
        SearchBar(query = query, onQueryChange = vm::onQueryChange)

        Spacer(Modifier.height(16.dp))

        // ── List / Empty ──────────────────────────────────────────────────────
        if (recordings.isEmpty()) {
            EmptyState()
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(recordings, key = { it.id }) { recording ->
                    RecordingCard(
                        recording = recording,
                        onShare   = { vm.shareRecording(recording) },
                        onDelete  = { vm.requestDelete(recording) },
                    )
                }
                item { Spacer(Modifier.height(8.dp)) }
            }
        }
    }

    // ── Delete single dialog ──────────────────────────────────────────────────
    pendingDel?.let { r ->
        AlertDialog(
            onDismissRequest  = vm::cancelDelete,
            title             = { Text(stringResource(R.string.delete_recording)) },
            text              = { Text(stringResource(R.string.delete_confirm)) },
            confirmButton     = { TextButton(onClick = vm::confirmDelete)  { Text(stringResource(R.string.confirm), color = AccentRecording) } },
            dismissButton     = { TextButton(onClick = vm::cancelDelete)   { Text(stringResource(R.string.cancel)) } },
            containerColor    = NeoSurface,
        )
    }

    // ── Delete all dialog ─────────────────────────────────────────────────────
    if (showDelAll) {
        AlertDialog(
            onDismissRequest  = vm::cancelDeleteAll,
            title             = { Text(stringResource(R.string.delete_all)) },
            text              = { Text(stringResource(R.string.delete_confirm)) },
            confirmButton     = { TextButton(onClick = vm::confirmDeleteAll) { Text(stringResource(R.string.confirm), color = AccentRecording) } },
            dismissButton     = { TextButton(onClick = vm::cancelDeleteAll)  { Text(stringResource(R.string.cancel)) } },
            containerColor    = NeoSurface,
        )
    }
}

// ── Search Bar ────────────────────────────────────────────────────────────────

@Composable
private fun SearchBar(query: String, onQueryChange: (String) -> Unit) {
    Row(
        modifier          = Modifier
            .fillMaxWidth()
            .neomorphicShadow(shadowRadius = 6.dp, offset = 3.dp, cornerRadius = 14.dp)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Search, contentDescription = null, tint = TextHint, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        BasicTextField(
            value         = query,
            onValueChange = onQueryChange,
            singleLine    = true,
            textStyle     = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary),
            cursorBrush   = SolidColor(AccentPrimary),
            modifier      = Modifier.weight(1f),
            decorationBox = { inner ->
                if (query.isEmpty()) Text(
                    text  = stringResource(R.string.search_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextHint,
                )
                inner()
            },
        )
    }
}

// ── Recording Card ────────────────────────────────────────────────────────────

@Composable
private fun RecordingCard(
    recording: Recording,
    onShare  : () -> Unit,
    onDelete : () -> Unit,
) {
    Row(
        modifier          = Modifier
            .fillMaxWidth()
            .neomorphicShadow(shadowRadius = 8.dp, offset = 4.dp, cornerRadius = 16.dp)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Icon
        Box(
            modifier         = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(AccentPrimary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.VideoFile, contentDescription = null, tint = AccentPrimary, modifier = Modifier.size(26.dp))
        }

        Spacer(Modifier.width(12.dp))

        // Text info
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text       = recording.fileName,
                style      = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color      = TextPrimary,
                maxLines   = 1,
            )
            Spacer(Modifier.height(2.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text  = (recording.durationMs / 1000L).toHms(),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                )
                Text("·", style = MaterialTheme.typography.labelSmall, color = TextHint)
                Text(
                    text  = recording.sizeBytes.toReadableSize(),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                )
                if (recording.isUploaded) {
                    Text("·", style = MaterialTheme.typography.labelSmall, color = TextHint)
                    Text("✓ TG", style = MaterialTheme.typography.labelSmall, color = AccentSuccess)
                } else if (recording.uploadPending) {
                    Text("·", style = MaterialTheme.typography.labelSmall, color = TextHint)
                    Text("↑", style = MaterialTheme.typography.labelSmall, color = AccentPrimary)
                }
            }
            Spacer(Modifier.height(2.dp))
            Text(
                text  = recording.createdAt.toDisplayDate(),
                style = MaterialTheme.typography.labelSmall,
                color = TextHint,
            )
        }

        // Actions
        IconButton(onClick = onShare)  { Icon(Icons.Filled.Share,  contentDescription = stringResource(R.string.share_recording), tint = AccentPrimary, modifier = Modifier.size(20.dp)) }
        IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = stringResource(R.string.delete_recording), tint = AccentRecording, modifier = Modifier.size(20.dp)) }
    }
}

// ── Empty State ───────────────────────────────────────────────────────────────

@Composable
private fun EmptyState() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Filled.VideoFile, contentDescription = null, tint = TextHint, modifier = Modifier.size(64.dp))
            Spacer(Modifier.height(16.dp))
            Text(stringResource(R.string.no_recordings), style = MaterialTheme.typography.titleMedium, color = TextSecondary)
            Spacer(Modifier.height(4.dp))
            Text(stringResource(R.string.no_recordings_sub), style = MaterialTheme.typography.bodyMedium, color = TextHint)
        }
    }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

private fun Long.toHms(): String {
    val h = this / 3600; val m = (this % 3600) / 60; val s = this % 60
    return "%02d:%02d:%02d".format(h, m, s)
}
private fun Long.toReadableSize(): String = when {
    this < 1_024L         -> "${this} B"
    this < 1_048_576L     -> "${"%.1f".format(this / 1_024.0)} KB"
    this < 1_073_741_824L -> "${"%.1f".format(this / 1_048_576.0)} MB"
    else                  -> "${"%.1f".format(this / 1_073_741_824.0)} GB"
}
private fun Long.toDisplayDate(): String =
    SimpleDateFormat("yyyy-MM-dd  HH:mm", Locale.getDefault()).format(Date(this))
