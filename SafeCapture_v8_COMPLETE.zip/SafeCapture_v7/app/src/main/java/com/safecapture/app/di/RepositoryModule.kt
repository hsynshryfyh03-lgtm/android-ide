package com.safecapture.app.di

import com.safecapture.app.data.repository.RecordingRepositoryImpl
import com.safecapture.app.domain.repository.IRecordingRepository
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    /**
     * Binds [RecordingRepositoryImpl] as the implementation of [IRecordingRepository].
     * Using @Binds (abstract) instead of @Provides avoids unnecessary object creation.
     */
    @Binds
    @Singleton
    abstract fun bindRecordingRepository(
        impl: RecordingRepositoryImpl,
    ): IRecordingRepository
}
