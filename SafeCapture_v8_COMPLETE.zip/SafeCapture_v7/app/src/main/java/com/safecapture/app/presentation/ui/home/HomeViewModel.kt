package com.safecapture.app.presentation.ui.home

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.safecapture.app.domain.model.RecordingState
import com.safecapture.app.domain.model.RecordingStateHolder
import com.safecapture.app.domain.repository.IRecordingRepository
import com.safecapture.app.service.RecordingService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val repository: IRecordingRepository,
) : ViewModel() {

    val recordingState: StateFlow<RecordingState> = RecordingStateHolder.state
        .stateIn(viewModelScope, SharingStarted.Eagerly, RecordingState.Idle)

    private val _elapsedSeconds = MutableStateFlow(0L)
    val elapsedSeconds: StateFlow<Long> = _elapsedSeconds.asStateFlow()

    val recordingCount: StateFlow<Int> = repository.observeCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    val totalDurationMs: StateFlow<Long> = repository.observeTotalDuration()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0L)

    val totalSizeBytes: StateFlow<Long> = repository.observeTotalSize()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0L)

    init {
        viewModelScope.launch {
            while (isActive) {
                val state = recordingState.value
                _elapsedSeconds.value = if (state is RecordingState.Recording)
                    (System.currentTimeMillis() - state.startedAt) / 1_000L
                else 0L
                delay(1_000L)
            }
        }
    }

    fun toggleRecording() {
        when (recordingState.value) {
            is RecordingState.Idle      -> context.startForegroundService(RecordingService.startIntent(context))
            is RecordingState.Recording -> context.startService(RecordingService.stopIntent(context))
            else                        -> Unit
        }
    }
}
