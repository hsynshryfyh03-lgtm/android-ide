package com.safecapture.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.safecapture.app.data.local.dao.RecordingDao
import com.safecapture.app.data.local.entity.RecordingEntity

@Database(
    entities  = [RecordingEntity::class],
    version   = 1,
    exportSchema = true,           // schema exported to app/schemas/ for migration tracking
)
abstract class RecordingDatabase : RoomDatabase() {
    abstract fun recordingDao(): RecordingDao

    companion object {
        const val DATABASE_NAME = "safecapture.db"
    }
}
