package com.safecapture.app.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.util.Log
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.safecapture.app.data.preferences.AppPreferences
import com.safecapture.app.domain.model.RecordingState
import com.safecapture.app.domain.model.RecordingStateHolder
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Accessibility Service that intercepts hardware Volume-Up key events.
 *
 * Detection algorithm:
 *  ┌──────────────────────────────────────────────────────────────────┐
 *  │  PRESS 1 → record timestamp                                      │
 *  │  PRESS 2 → if (Δt < doublePressDelayMs) → TRIGGER               │
 *  │           else → treat press 2 as press 1, reset timer           │
 *  └──────────────────────────────────────────────────────────────────┘
 *
 * The service must be enabled by the user in Android Accessibility Settings.
 * It requests [flagRequestFilterKeyEvents] so the system routes key events
 * to [onKeyEvent]; no special permissions beyond the accessibility binding
 * are required at runtime.
 *
 * NOTE: `accessibilityEventTypes` in the XML config is set to `typeAllMask`
 * (fixed from v7) — the service only acts on key events, but the event type
 * must be non-empty for the service to be considered active by the system.
 */
@AndroidEntryPoint
class VolumeKeyAccessibilityService : AccessibilityService() {

    @Inject
    lateinit var preferences: AppPreferences

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // ── Double-press state ────────────────────────────────────────────────────
    private var lastVolumeUpTimeMs: Long = 0L

    companion object {
        private const val TAG = "VolumeKeyA11yService"
    }

    // ── AccessibilityService overrides ────────────────────────────────────────

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "Accessibility service connected")
    }

    /**
     * Called for every AccessibilityEvent matching the configured types.
     * We do not use events here — only [onKeyEvent] matters.
     */
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally empty — we only use key events
    }

    override fun onInterrupt() {
        Log.d(TAG, "Accessibility service interrupted")
    }

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }

    // ── Key event interception ────────────────────────────────────────────────

    /**
     * Returns true to consume the event (prevent system volume change),
     * false to let the system handle it normally.
     *
     * We consume the FIRST Volume-Up press that starts the double-press
     * window, and also the SECOND press that triggers the recording.
     * Any other key falls through to the system.
     */
    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event == null) return false
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_UP) return false
        // Only act on ACTION_DOWN to avoid double-firing on DOWN+UP
        if (event.action != KeyEvent.ACTION_DOWN) return false

        serviceScope.launch {
            val delayMs = preferences.doublePressDelayMs.first().toLong()
            val now     = System.currentTimeMillis()
            val delta   = now - lastVolumeUpTimeMs

            if (delta <= delayMs) {
                // ── Second press within window → TRIGGER ──────────────────
                lastVolumeUpTimeMs = 0L    // reset so a 3rd press starts fresh
                onDoublePressDetected()
            } else {
                // ── First press (or press outside window) ─────────────────
                lastVolumeUpTimeMs = now
            }
        }

        // Consume the key event so the system does not change volume
        return true
    }

    // ── Trigger logic ─────────────────────────────────────────────────────────

    private fun onDoublePressDetected() {
        Log.d(TAG, "Double-press detected → toggling recording")

        when (RecordingStateHolder.state.value) {
            is RecordingState.Idle -> {
                // Start recording
                val intent = RecordingService.startIntent(applicationContext)
                // On API 26+ a foreground service must be started with startForegroundService
                applicationContext.startForegroundService(intent)
            }
            is RecordingState.Recording -> {
                // Stop recording
                val intent = RecordingService.stopIntent(applicationContext)
                applicationContext.startService(intent)
            }
            is RecordingState.Saving,
            is RecordingState.Error -> {
                // Ignore — transitional or error state
                Log.d(TAG, "Double-press ignored in state: ${RecordingStateHolder.state.value}")
            }
        }
    }
}
