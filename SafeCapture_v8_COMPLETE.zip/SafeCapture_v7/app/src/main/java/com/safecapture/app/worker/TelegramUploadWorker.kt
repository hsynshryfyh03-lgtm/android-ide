package com.safecapture.app.worker

import android.content.Context
import android.util.Log
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.safecapture.app.data.preferences.AppPreferences
import com.safecapture.app.domain.repository.IRecordingRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * WorkManager [CoroutineWorker] that uploads a recording to a Telegram bot.
 *
 * Retry strategy:
 *  • WorkManager automatically retries on [Result.retry] with exponential back-off.
 *  • Max 3 attempts (configured at enqueue site in [RecordingService]).
 *  • Requires CONNECTED network — WorkManager re-queues if offline at start.
 *
 * Telegram API used: sendVideo (multipart/form-data).
 * Max file size accepted by Telegram Bot API: 50 MB.
 */
@HiltWorker
class TelegramUploadWorker @AssistedInject constructor(
    @Assisted appContext : Context,
    @Assisted workerParams: WorkerParameters,
    private val repository : IRecordingRepository,
    private val preferences: AppPreferences,
) : CoroutineWorker(appContext, workerParams) {

    companion object {
        private const val TAG = "TelegramUploadWorker"

        /** Input data key — Long recording id from Room. */
        const val KEY_RECORDING_ID = "recording_id"

        private const val TELEGRAM_BASE = "https://api.telegram.org/bot"
        private const val MAX_FILE_SIZE_BYTES = 50L * 1024 * 1024   // 50 MB Telegram limit
    }

    // ── OkHttp client — 60s timeouts for large video uploads ─────────────────
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    override suspend fun doWork(): Result {
        val recordingId = inputData.getLong(KEY_RECORDING_ID, -1L)
        if (recordingId == -1L) {
            Log.e(TAG, "Invalid recording id — aborting")
            return Result.failure()
        }

        val recording = repository.getById(recordingId)
        if (recording == null) {
            Log.e(TAG, "Recording $recordingId not found in DB — it may have been deleted")
            return Result.failure()
        }

        if (recording.isUploaded) {
            Log.d(TAG, "Recording $recordingId already uploaded — skipping")
            return Result.success()
        }

        val botToken = preferences.telegramBotToken.first()
        val chatId   = preferences.telegramChatId.first()

        if (botToken.isBlank() || chatId.isBlank()) {
            Log.w(TAG, "Telegram credentials not configured — clearing pending flag")
            repository.setUploadPending(recordingId, false)
            return Result.failure()
        }

        val file = File(recording.filePath)
        if (!file.exists()) {
            Log.e(TAG, "File not found: ${recording.filePath}")
            repository.setUploadPending(recordingId, false)
            return Result.failure()
        }

        if (file.length() > MAX_FILE_SIZE_BYTES) {
            Log.w(TAG, "File exceeds 50 MB Telegram limit (${file.length()} bytes) — skipping upload")
            repository.setUploadPending(recordingId, false)
            return Result.failure()
        }

        return try {
            uploadToTelegram(botToken, chatId, file, recordingId)
        } catch (e: Exception) {
            Log.e(TAG, "Upload failed: ${e.message}", e)
            // Retry — WorkManager will back off automatically
            Result.retry()
        }
    }

    private suspend fun uploadToTelegram(
        botToken    : String,
        chatId      : String,
        file        : File,
        recordingId : Long,
    ): Result {
        val url = "$TELEGRAM_BASE$botToken/sendVideo"

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("chat_id", chatId)
            .addFormDataPart("caption", "📹 SafeCapture — ${file.nameWithoutExtension}")
            .addFormDataPart(
                "video",
                file.name,
                file.asRequestBody("video/mp4".toMediaTypeOrNull()),
            )
            .build()

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        val response = client.newCall(request).execute()
        return if (response.isSuccessful) {
            Log.d(TAG, "Upload successful for recording $recordingId")
            repository.markUploaded(recordingId)
            Result.success()
        } else {
            val body = response.body?.string() ?: "(empty)"
            Log.e(TAG, "Telegram API error ${response.code}: $body")
            // 4xx = bad credentials/config → don't retry; 5xx = server error → retry
            if (response.code in 400..499) {
                repository.setUploadPending(recordingId, false)
                Result.failure()
            } else {
                Result.retry()
            }
        }
    }
}
