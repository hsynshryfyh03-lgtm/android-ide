package com.safecapture.app.presentation.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// SafeCapture uses a fixed light Neomorphism palette regardless of system theme.
// Dark mode icons are handled separately via WindowInsetsController.
private val SafeLightColorScheme = lightColorScheme(
    primary          = AccentPrimary,
    onPrimary        = Color.White,
    primaryContainer = NeoSurface,
    secondary        = AccentSecondary,
    onSecondary      = Color.White,
    background       = NeoBackground,
    onBackground     = TextPrimary,
    surface          = NeoSurface,
    onSurface        = TextPrimary,
    surfaceVariant   = NeoSurface,
    onSurfaceVariant = TextSecondary,
    error            = AccentRecording,
    onError          = Color.White,
    outline          = NeoShadowDark,
)

@Composable
fun SafeCaptureTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            // Force light status + nav bar icons (safe for Neomorphism light palette)
            val window = (view.context as android.app.Activity).window
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars     = true
                isAppearanceLightNavigationBars = true
            }
        }
    }

    MaterialTheme(
        colorScheme = SafeLightColorScheme,
        typography  = SafeCaptureTypography,
        content     = content,
    )
}
