package com.safecapture.app.service

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.safecapture.app.data.preferences.AppPreferences
import com.safecapture.app.domain.model.RecordingState
import com.safecapture.app.domain.model.RecordingStateHolder
import com.safecapture.app.domain.repository.IRecordingRepository
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import javax.inject.Inject
import com.safecapture.app.domain.model.Recording as DomainRecording

/**
 * Foreground service that owns the CameraX [VideoCapture] pipeline.
 *
 * Extends [LifecycleService] so CameraX can bind its use-cases to this
 * service's lifecycle — the recommended pattern for background camera access.
 *
 * FIXES applied vs previous version:
 * ────────────────────────────────────
 * 1. RACE CONDITION FIX: DB insert now completes on IO thread BEFORE
 *    prepareRecording() is called on Main thread.  Previously both ran
 *    concurrently, so currentRecordingId could still be -1 when
 *    finaliseRecording() fired.
 * 2. Removed unused imports: android.app.Service, android.media.MediaRecorder.
 * 3. Type alias [DomainRecording] avoids name clash with CameraX [Recording].
 * 4. kotlinx.coroutines.Job imported properly (was inlined as FQN).
 */
@AndroidEntryPoint
class RecordingService : LifecycleService() {

    @Inject lateinit var repository  : IRecordingRepository
    @Inject lateinit var preferences : AppPreferences

    private var videoCapture   : VideoCapture<Recorder>? = null
    private var activeRecording: Recording?              = null
    private val cameraExecutor  = Executors.newSingleThreadExecutor()
    private val serviceScope    = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var currentRecordingId: Long = -1L
    private var recordingStartMs  : Long = 0L
    private var maxDurationJob    : Job? = null

    companion object {
        private const val TAG = "RecordingService"

        const val ACTION_START = "com.safecapture.app.ACTION_START_RECORDING"
        const val ACTION_STOP  = "com.safecapture.app.ACTION_STOP_RECORDING"

        fun startIntent(context: Context): Intent =
            Intent(context, RecordingService::class.java).apply { action = ACTION_START }

        fun stopIntent(context: Context): Intent =
            Intent(context, RecordingService::class.java).apply { action = ACTION_STOP }
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createChannel(this)
        startForeground(
            NotificationHelper.NOTIFICATION_ID,
            NotificationHelper.buildIdleNotification(this),
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_START,
            NotificationHelper.ACTION_STOP -> {
                if (intent.action == ACTION_START) handleStart() else handleStop()
            }
            ACTION_STOP -> handleStop()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }

    override fun onDestroy() {
        handleStop()
        serviceScope.cancel()
        cameraExecutor.shutdown()
        super.onDestroy()
    }

    // ── Start ─────────────────────────────────────────────────────────────────

    private fun handleStart() {
        if (RecordingStateHolder.state.value is RecordingState.Recording) {
            Log.w(TAG, "handleStart() ignored — already recording")
            return
        }
        serviceScope.launch {
            val quality       = preferences.videoQuality.first()
            val facing        = preferences.cameraFacing.first()
            val vibrate       = preferences.vibrationFeedback.first()
            val maxDurationMs = preferences.maxDurationMs.first()

            bindCamera(quality, facing, maxDurationMs)
            if (vibrate) vibrateConfirm()
        }
    }

    private fun bindCamera(qualityStr: String, facingStr: String, maxDurationMs: Long) {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val selector = if (facingStr == "front")
                CameraSelector.DEFAULT_FRONT_CAMERA
            else
                CameraSelector.DEFAULT_BACK_CAMERA

            val cxQuality = when (qualityStr) {
                "1080p" -> Quality.FHD
                "480p"  -> Quality.SD
                else    -> Quality.HD
            }

            val recorder = Recorder.Builder()
                .setQualitySelector(QualitySelector.from(cxQuality))
                .setExecutor(cameraExecutor)
                .build()

            videoCapture = VideoCapture.withOutput(recorder)

            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, videoCapture!!)
                // FIX: insert into DB first, then start camera — sequential, not concurrent
                serviceScope.launch { startRecordingAfterInsert(maxDurationMs) }
            } catch (e: Exception) {
                Log.e(TAG, "Camera bind failed: ${e.message}", e)
                RecordingStateHolder.emit(RecordingState.Error("Camera bind failed: ${e.message}"))
            }
        }, ContextCompat.getMainExecutor(this))
    }

    /**
     * Inserts the placeholder DB row on IO, then switches to Main to call
     * [prepareRecording]. This guarantees [currentRecordingId] is valid
     * before [finaliseRecording] can possibly run.
     */
    private suspend fun startRecordingAfterInsert(maxDurationMs: Long) {
        val vc = videoCapture ?: run {
            Log.e(TAG, "startRecordingAfterInsert: videoCapture is null"); return
        }

        val outputDir = withContext(Dispatchers.IO) {
            (getExternalFilesDir(null)
                ?.let { File(it, "SafeCapture").also { d -> d.mkdirs() } }
                ?: File(filesDir, "recordings").also { it.mkdirs() })
        }

        val timestamp  = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName   = "SC_$timestamp.mp4"
        val outputFile = File(outputDir, fileName)

        // ── STEP 1: insert on IO and wait for the id ──────────────────────────
        val newId = withContext(Dispatchers.IO) {
            repository.insert(
                DomainRecording(
                    fileName  = fileName,
                    filePath  = outputFile.absolutePath,
                    createdAt = System.currentTimeMillis(),
                )
            )
        }
        currentRecordingId = newId
        recordingStartMs   = System.currentTimeMillis()

        // ── STEP 2: start recording on Main (CameraX requirement) ─────────────
        val outputOptions = FileOutputOptions.Builder(outputFile).apply {
            if (maxDurationMs > 0L) setDurationLimitMillis(maxDurationMs)
        }.build()

        @Suppress("MissingPermission")
        activeRecording = vc.output
            .prepareRecording(this@RecordingService, outputOptions)
            .withAudioEnabled()
            .start(ContextCompat.getMainExecutor(this@RecordingService)) { event ->
                handleVideoEvent(event)
            }

        RecordingStateHolder.emit(RecordingState.Recording(newId))
        updateNotification(recording = true)

        if (maxDurationMs > 0L) {
            maxDurationJob?.cancel()
            maxDurationJob = serviceScope.launch {
                delay(maxDurationMs + 500L)
                handleStop()
            }
        }

        Log.d(TAG, "Recording started: id=$newId file=$fileName")
    }

    private fun handleVideoEvent(event: VideoRecordEvent) {
        when (event) {
            is VideoRecordEvent.Start    -> Log.d(TAG, "CameraX recording started")
            is VideoRecordEvent.Status   -> Unit
            is VideoRecordEvent.Finalize -> {
                if (event.hasError()) {
                    Log.e(TAG, "CameraX error code=${event.error}")
                    RecordingStateHolder.emit(RecordingState.Error("CameraX error: ${event.error}"))
                } else {
                    finaliseRecording(event)
                }
            }
            else -> Unit
        }
    }

    // ── Stop ──────────────────────────────────────────────────────────────────

    private fun handleStop() {
        maxDurationJob?.cancel()
        maxDurationJob = null
        if (RecordingStateHolder.state.value !is RecordingState.Recording) return
        RecordingStateHolder.emit(RecordingState.Saving)
        updateNotification(recording = false)
        activeRecording?.stop()
        activeRecording = null
    }

    private fun finaliseRecording(event: VideoRecordEvent.Finalize) {
        val id        = currentRecordingId
        val durationMs = System.currentTimeMillis() - recordingStartMs
        // For FileOutputOptions CameraX always produces a file:// URI — .path is safe
        val filePath   = event.outputResults.outputUri.path ?: run {
            Log.e(TAG, "outputUri.path is null"); return
        }

        serviceScope.launch(Dispatchers.IO) {
            val sizeBytes = File(filePath).takeIf { it.exists() }?.length() ?: 0L
            repository.updateDurationAndSize(id, durationMs, sizeBytes)
            enqueueTelegramUpload(id)
            withContext(Dispatchers.Main) {
                RecordingStateHolder.emit(RecordingState.Idle)
                updateNotification(recording = false)
            }
            Log.d(TAG, "Finalised id=$id dur=${durationMs}ms size=$sizeBytes")
        }
    }

    // ── Telegram ──────────────────────────────────────────────────────────────

    private suspend fun enqueueTelegramUpload(recordingId: Long) {
        val autoUpload = preferences.telegramAutoUpload.first()
        val token      = preferences.telegramBotToken.first()
        val chatId     = preferences.telegramChatId.first()
        if (!autoUpload || token.isBlank() || chatId.isBlank()) return

        repository.setUploadPending(recordingId, true)

        val data = androidx.work.Data.Builder()
            .putLong(com.safecapture.app.worker.TelegramUploadWorker.KEY_RECORDING_ID, recordingId)
            .build()
        val request = androidx.work.OneTimeWorkRequestBuilder<
                com.safecapture.app.worker.TelegramUploadWorker>()
            .setInputData(data)
            .setConstraints(
                androidx.work.Constraints.Builder()
                    .setRequiredNetworkType(androidx.work.NetworkType.CONNECTED)
                    .build()
            )
            .build()
        androidx.work.WorkManager.getInstance(applicationContext).enqueue(request)
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun updateNotification(recording: Boolean) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        nm.notify(
            NotificationHelper.NOTIFICATION_ID,
            if (recording) NotificationHelper.buildRecordingNotification(this)
            else           NotificationHelper.buildIdleNotification(this),
        )
    }

    private fun vibrateConfirm() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager)
                    .defaultVibrator
                    .vibrate(VibrationEffect.createOneShot(80L, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
                    .vibrate(VibrationEffect.createOneShot(80L, VibrationEffect.DEFAULT_AMPLITUDE))
            }
        } catch (e: Exception) {
            Log.w(TAG, "Vibrate failed: ${e.message}")
        }
    }
}
