package com.safecapture.app.data.preferences

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Single source of truth for all user-configurable preferences.
 * Wraps DataStore<Preferences> and exposes typed Flows + suspend setters.
 */
@Singleton
class AppPreferences @Inject constructor(
    private val dataStore: DataStore<Preferences>,
) {

    // ── Keys ──────────────────────────────────────────────────────────────────
    companion object Keys {
        // Trigger
        val DOUBLE_PRESS_DELAY_MS   = intPreferencesKey("double_press_delay_ms")
        val VIBRATION_FEEDBACK      = booleanPreferencesKey("vibration_feedback")

        // Recording
        val VIDEO_QUALITY           = stringPreferencesKey("video_quality")      // "480p" | "720p" | "1080p"
        val CAMERA_FACING           = stringPreferencesKey("camera_facing")      // "back" | "front"
        val MAX_DURATION_MS         = longPreferencesKey("max_duration_ms")      // 0 = unlimited
        val TIMESTAMP_OVERLAY       = booleanPreferencesKey("timestamp_overlay")

        // Storage
        val AUTO_DELETE_ENABLED     = booleanPreferencesKey("auto_delete_enabled")
        val AUTO_DELETE_KEEP_COUNT  = intPreferencesKey("auto_delete_keep_count")

        // Telegram
        val TELEGRAM_AUTO_UPLOAD    = booleanPreferencesKey("telegram_auto_upload")
        val TELEGRAM_BOT_TOKEN      = stringPreferencesKey("telegram_bot_token")
        val TELEGRAM_CHAT_ID        = stringPreferencesKey("telegram_chat_id")

        // Disguise
        val DISGUISE_MODE_ENABLED   = booleanPreferencesKey("disguise_mode_enabled")
    }

    // ── Defaults ──────────────────────────────────────────────────────────────
    object Defaults {
        const val DOUBLE_PRESS_DELAY_MS  = 600
        const val VIBRATION_FEEDBACK     = true
        const val VIDEO_QUALITY          = "720p"
        const val CAMERA_FACING          = "back"
        const val MAX_DURATION_MS        = 0L         // unlimited
        const val TIMESTAMP_OVERLAY      = true
        const val AUTO_DELETE_ENABLED    = false
        const val AUTO_DELETE_KEEP_COUNT = 20
        const val TELEGRAM_AUTO_UPLOAD   = false
        const val TELEGRAM_BOT_TOKEN     = ""
        const val TELEGRAM_CHAT_ID       = ""
        const val DISGUISE_MODE_ENABLED  = false
    }

    // ── Flows ─────────────────────────────────────────────────────────────────
    val doublePressDelayMs: Flow<Int> = dataStore.data.map {
        it[DOUBLE_PRESS_DELAY_MS] ?: Defaults.DOUBLE_PRESS_DELAY_MS
    }
    val vibrationFeedback: Flow<Boolean> = dataStore.data.map {
        it[VIBRATION_FEEDBACK] ?: Defaults.VIBRATION_FEEDBACK
    }
    val videoQuality: Flow<String> = dataStore.data.map {
        it[VIDEO_QUALITY] ?: Defaults.VIDEO_QUALITY
    }
    val cameraFacing: Flow<String> = dataStore.data.map {
        it[CAMERA_FACING] ?: Defaults.CAMERA_FACING
    }
    val maxDurationMs: Flow<Long> = dataStore.data.map {
        it[MAX_DURATION_MS] ?: Defaults.MAX_DURATION_MS
    }
    val timestampOverlay: Flow<Boolean> = dataStore.data.map {
        it[TIMESTAMP_OVERLAY] ?: Defaults.TIMESTAMP_OVERLAY
    }
    val autoDeleteEnabled: Flow<Boolean> = dataStore.data.map {
        it[AUTO_DELETE_ENABLED] ?: Defaults.AUTO_DELETE_ENABLED
    }
    val autoDeleteKeepCount: Flow<Int> = dataStore.data.map {
        it[AUTO_DELETE_KEEP_COUNT] ?: Defaults.AUTO_DELETE_KEEP_COUNT
    }
    val telegramAutoUpload: Flow<Boolean> = dataStore.data.map {
        it[TELEGRAM_AUTO_UPLOAD] ?: Defaults.TELEGRAM_AUTO_UPLOAD
    }
    val telegramBotToken: Flow<String> = dataStore.data.map {
        it[TELEGRAM_BOT_TOKEN] ?: Defaults.TELEGRAM_BOT_TOKEN
    }
    val telegramChatId: Flow<String> = dataStore.data.map {
        it[TELEGRAM_CHAT_ID] ?: Defaults.TELEGRAM_CHAT_ID
    }
    val disguiseModeEnabled: Flow<Boolean> = dataStore.data.map {
        it[DISGUISE_MODE_ENABLED] ?: Defaults.DISGUISE_MODE_ENABLED
    }

    // ── Setters ───────────────────────────────────────────────────────────────
    suspend fun setDoublePressDelayMs(value: Int) = dataStore.edit {
        it[DOUBLE_PRESS_DELAY_MS] = value
    }
    suspend fun setVibrationFeedback(value: Boolean) = dataStore.edit {
        it[VIBRATION_FEEDBACK] = value
    }
    suspend fun setVideoQuality(value: String) = dataStore.edit {
        it[VIDEO_QUALITY] = value
    }
    suspend fun setCameraFacing(value: String) = dataStore.edit {
        it[CAMERA_FACING] = value
    }
    suspend fun setMaxDurationMs(value: Long) = dataStore.edit {
        it[MAX_DURATION_MS] = value
    }
    suspend fun setTimestampOverlay(value: Boolean) = dataStore.edit {
        it[TIMESTAMP_OVERLAY] = value
    }
    suspend fun setAutoDeleteEnabled(value: Boolean) = dataStore.edit {
        it[AUTO_DELETE_ENABLED] = value
    }
    suspend fun setAutoDeleteKeepCount(value: Int) = dataStore.edit {
        it[AUTO_DELETE_KEEP_COUNT] = value
    }
    suspend fun setTelegramAutoUpload(value: Boolean) = dataStore.edit {
        it[TELEGRAM_AUTO_UPLOAD] = value
    }
    suspend fun setTelegramBotToken(value: String) = dataStore.edit {
        it[TELEGRAM_BOT_TOKEN] = value
    }
    suspend fun setTelegramChatId(value: String) = dataStore.edit {
        it[TELEGRAM_CHAT_ID] = value
    }
    suspend fun setDisguiseModeEnabled(value: Boolean) = dataStore.edit {
        it[DISGUISE_MODE_ENABLED] = value
    }
}
