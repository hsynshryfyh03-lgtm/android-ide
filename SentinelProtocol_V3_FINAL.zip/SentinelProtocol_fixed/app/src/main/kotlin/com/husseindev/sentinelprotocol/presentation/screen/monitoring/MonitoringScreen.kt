package com.husseindev.sentinelprotocol.presentation.screen.monitoring

import android.view.WindowManager
import androidx.camera.core.Preview
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import com.husseindev.sentinelprotocol.camera.CameraEngine
import com.husseindev.sentinelprotocol.domain.model.*
import com.husseindev.sentinelprotocol.domain.repository.SettingsRepository
import com.husseindev.sentinelprotocol.domain.usecase.SaveRecordingUseCase
import com.husseindev.sentinelprotocol.presentation.components.CctvWatermarkOverlay
import com.husseindev.sentinelprotocol.presentation.components.RecordingIndicator
import com.husseindev.sentinelprotocol.presentation.theme.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject
import androidx.compose.foundation.Canvas
import androidx.activity.ComponentActivity

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Monitoring Screen
//  Virtual Fence Drawing | Kiosk Mode
//  Canvas Detection Overlay
//  برمجة حسين حميد
// ══════════════════════════════════════════

@HiltViewModel
class MonitoringViewModel @Inject constructor(
    private val cameraEngine  : CameraEngine,
    private val saveRecording : SaveRecordingUseCase,
    private val settingsRepo  : SettingsRepository
) : ViewModel() {

    val detectionState = cameraEngine.detectionState
    val isRecording    = cameraEngine.isRecording
    val fenceAlert     = cameraEngine.fenceAlert

    private val _config = MutableStateFlow(SentinelConfig())
    val config: StateFlow<SentinelConfig> = _config.asStateFlow()

    init {
        viewModelScope.launch {
            settingsRepo.getConfig().collect { _config.value = it }
        }
    }

    fun startManualRecord() {
        cameraEngine.startRecording(onComplete = { file -> onDone(file) })
    }
    fun stopManualRecord() = cameraEngine.stopRecording()

    private fun onDone(file: File) {
        viewModelScope.launch {
            saveRecording(RecordingEvent(
                filePath = file.absolutePath, triggerType = TriggerType.MANUAL,
                fileSizeBytes = file.length()
            ))
        }
    }

    // Save the fence drawn by user
    fun saveFence(left: Float, top: Float, right: Float, bottom: Float) {
        viewModelScope.launch {
            val c = _config.value
            settingsRepo.updateConfig(c.copy(
                virtualFence = VirtualFence(left, top, right, bottom, enabled = true)
            ))
        }
    }

    fun clearFence() {
        viewModelScope.launch {
            settingsRepo.updateConfig(_config.value.copy(virtualFence = VirtualFence()))
        }
    }
}

@Composable
fun MonitoringScreen(
    cameraEngine : CameraEngine,
    onBack       : () -> Unit,
    viewModel    : MonitoringViewModel = hiltViewModel()
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val context        = LocalContext.current
    val detection      by viewModel.detectionState.collectAsStateWithLifecycle()
    val isRecording    by viewModel.isRecording.collectAsStateWithLifecycle()
    val fenceAlert     by viewModel.fenceAlert.collectAsStateWithLifecycle()
    val config         by viewModel.config.collectAsStateWithLifecycle()

    val preview = remember { Preview.Builder().build() }

    // ── Kiosk: keep screen on ─────────────────────────────────────────────────
    DisposableEffect(config.kioskModeEnabled) {
        val window = (context as? ComponentActivity)?.window
        if (config.kioskModeEnabled) {
            window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose { window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
    }

    LaunchedEffect(Unit) {
        cameraEngine.bindCamera(
            lifecycleOwner      = lifecycleOwner,
            preview             = preview,
            nightModeEnabled    = config.nightModeEnabled,
            nightStartHour      = config.nightStartHour,
            nightEndHour        = config.nightEndHour,
            virtualFence        = config.virtualFence,
            onRecordingComplete = {}
        )
    }

    // ── Fence drawing state ───────────────────────────────────────────────────
    var drawingFence by remember { mutableStateOf(false) }
    var fenceStart   by remember { mutableStateOf(Offset.Zero) }
    var fenceEnd     by remember { mutableStateOf(Offset.Zero) }
    var previewSize  by remember { mutableStateOf(Size(1f, 1f)) }

    // Fence alert pulse animation
    val fenceAlpha by rememberInfiniteTransition(label = "fenceAlert").animateFloat(
        initialValue = 1f, targetValue = 0.3f,
        animationSpec = infiniteRepeatable(tween(500), RepeatMode.Reverse),
        label = "fenceAlpha"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepBlack)
    ) {
        // ── Camera Preview ──────────────────────────────────────────────────
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory  = { ctx ->
                PreviewView(ctx).apply {
                    implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                    preview.setSurfaceProvider(surfaceProvider)
                }
            },
            update = { view ->
                previewSize = Size(view.width.toFloat().coerceAtLeast(1f),
                                   view.height.toFloat().coerceAtLeast(1f))
            }
        )

        // ── Detection + Fence Canvas ────────────────────────────────────────
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .then(
                    if (drawingFence) Modifier.pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { fenceStart = it; fenceEnd = it },
                            onDrag      = { _, delta -> fenceEnd += delta },
                            onDragEnd   = {
                                // Normalize to 0-1 and save
                                val l = minOf(fenceStart.x, fenceEnd.x) / previewSize.width
                                val t = minOf(fenceStart.y, fenceEnd.y) / previewSize.height
                                val r = maxOf(fenceStart.x, fenceEnd.x) / previewSize.width
                                val b = maxOf(fenceStart.y, fenceEnd.y) / previewSize.height
                                viewModel.saveFence(l.coerceIn(0f,1f), t.coerceIn(0f,1f),
                                                    r.coerceIn(0f,1f), b.coerceIn(0f,1f))
                                drawingFence = false
                            }
                        )
                    } else Modifier
                )
        ) {
            val w = size.width
            val h = size.height

            // Draw detection boxes
            detection?.let { result ->
                if (result.imageWidth > 0) {
                    val sx = w / result.imageWidth
                    val sy = h / result.imageHeight

                    result.faces.forEach { face ->
                        val l = face.boundingBox.left  * sx; val t = face.boundingBox.top   * sy
                        val r = face.boundingBox.right * sx; val b = face.boundingBox.bottom * sy
                        drawRect(TealPrimary, Offset(l, t), Size(r-l, b-t), style = Stroke(3f))
                    }

                    result.persons.forEach { person ->
                        val l = person.boundingBox.left  * sx; val t = person.boundingBox.top    * sy
                        val r = person.boundingBox.right * sx; val b = person.boundingBox.bottom * sy
                        drawRect(ActiveGreen, Offset(l, t), Size(r-l, b-t), style = Stroke(3f))
                        val cl = (r-l)*0.12f
                        // Corner accents
                        drawLine(ActiveGreen, Offset(l,t), Offset(l+cl,t), strokeWidth=5f)
                        drawLine(ActiveGreen, Offset(l,t), Offset(l,t+cl), strokeWidth=5f)
                        drawLine(ActiveGreen, Offset(r,t), Offset(r-cl,t), strokeWidth=5f)
                        drawLine(ActiveGreen, Offset(r,t), Offset(r,t+cl), strokeWidth=5f)
                        drawLine(ActiveGreen, Offset(l,b), Offset(l+cl,b), strokeWidth=5f)
                        drawLine(ActiveGreen, Offset(l,b), Offset(l,b-cl), strokeWidth=5f)
                        drawLine(ActiveGreen, Offset(r,b), Offset(r-cl,b), strokeWidth=5f)
                        drawLine(ActiveGreen, Offset(r,b), Offset(r,b-cl), strokeWidth=5f)
                    }
                }
            }

            // Draw saved fence
            if (config.virtualFence.enabled) {
                val vf = config.virtualFence
                val fl = vf.left * w; val ft = vf.top * h
                val fr = vf.right * w; val fb = vf.bottom * h
                val fColor = if (fenceAlert) Color.Red.copy(alpha = fenceAlpha) else Color.Yellow.copy(alpha = 0.7f)
                drawRect(fColor, Offset(fl, ft), Size(fr-fl, fb-ft), style = Stroke(width = 4f, pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(20f, 10f))))
                drawRect(fColor.copy(alpha = 0.08f), Offset(fl, ft), Size(fr-fl, fb-ft))
            }

            // Draw fence being drawn
            if (drawingFence && fenceStart != fenceEnd) {
                val l = minOf(fenceStart.x, fenceEnd.x)
                val t = minOf(fenceStart.y, fenceEnd.y)
                drawRect(Color.Yellow, Offset(l, t),
                    Size(kotlin.math.abs(fenceEnd.x-fenceStart.x), kotlin.math.abs(fenceEnd.y-fenceStart.y)),
                    style = Stroke(3f)
                )
            }
        }

        // ── CCTV Watermark ──────────────────────────────────────────────────
        CctvWatermarkOverlay(Modifier.align(Alignment.TopStart))

        // ── REC Indicator ────────────────────────────────────────────────────
        Row(Modifier.align(Alignment.TopEnd).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            RecordingIndicator(isRecording)
        }

        // ── Fence alert banner ───────────────────────────────────────────────
        if (fenceAlert) {
            Box(
                Modifier.align(Alignment.TopCenter).padding(top = 10.dp)
                    .background(Color.Red.copy(0.85f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 18.dp, vertical = 7.dp)
            ) {
                Text("⚠ دخول المنطقة المحظورة", color = Color.White, fontSize = 13.sp,
                    fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
            }
        }

        // ── Detection count badge ────────────────────────────────────────────
        val total = (detection?.faces?.size ?: 0) + (detection?.persons?.size ?: 0)
        if (total > 0 && !fenceAlert) {
            Box(
                Modifier.align(Alignment.TopCenter).padding(top = 10.dp)
                    .background(TealDark.copy(0.8f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    detection?.faces?.size?.takeIf { it > 0 }?.let {
                        Text("وجوه: $it", color = TealLight, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
                    }
                    detection?.persons?.size?.takeIf { it > 0 }?.let {
                        Text("أجسام: $it", color = ActiveGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
                    }
                }
            }
        }

        // ── Bottom Controls ──────────────────────────────────────────────────
        Column(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(DeepBlack.copy(0.75f))
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Fence controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Draw fence button
                SmallControlButton(
                    label    = if (drawingFence) "إلغاء الرسم" else "رسم المنطقة المحظورة",
                    icon     = if (drawingFence) Icons.Default.Close else Icons.Default.CropFree,
                    color    = if (drawingFence) RecordingRed else Color(0xFFFFD600),
                    modifier = Modifier.weight(1f),
                    onClick  = { drawingFence = !drawingFence }
                )
                if (config.virtualFence.enabled) {
                    SmallControlButton(
                        label    = "مسح المنطقة",
                        icon     = Icons.Default.DeleteOutline,
                        color    = RecordingRed.copy(0.8f),
                        modifier = Modifier.weight(1f),
                        onClick  = { viewModel.clearFence() }
                    )
                }
            }

            // Main controls row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment     = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, null, tint = TextPrimary)
                }

                // Record button
                IconButton(
                    onClick  = { if (isRecording) viewModel.stopManualRecord() else viewModel.startManualRecord() },
                    modifier = Modifier.size(64.dp).clip(CircleShape)
                        .background(if (isRecording) RecordingRed else TealPrimary)
                        .border(2.dp, Color.White.copy(0.3f), CircleShape)
                ) {
                    Icon(
                        if (isRecording) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                        null, tint = Color.White, modifier = Modifier.size(32.dp)
                    )
                }

                // Detection counter
                Box(
                    Modifier.size(48.dp).clip(CircleShape)
                        .background(if (total > 0) TealGlow else Color.Transparent)
                        .border(1.dp, if (total > 0) TealPrimary else TextDim, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text("$total", color = if (total > 0) TealLight else TextDim,
                        fontSize = 16.sp, fontWeight = FontWeight.Bold, fontFamily = TajawalFamily)
                }
            }
        }
    }
}

@Composable
private fun SmallControlButton(
    label    : String,
    icon     : androidx.compose.ui.graphics.vector.ImageVector,
    color    : Color,
    modifier : Modifier,
    onClick  : () -> Unit
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(color.copy(0.15f))
            .border(0.5.dp, color.copy(0.5f), RoundedCornerShape(10.dp))
            .then(Modifier.clickable(onClick = onClick))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment     = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = color, fontSize = 11.sp, fontFamily = TajawalFamily, fontWeight = FontWeight.Bold)
    }
}

// Extension for clickable on modifier
private fun Modifier.clickable(onClick: () -> Unit) = this.then(
    androidx.compose.foundation.clickable { onClick() }
)
