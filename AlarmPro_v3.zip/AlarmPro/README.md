# ⏰ AlarmPro — منبه برو

**برمجة - حسين حميد الشريفي**

تطبيق منبه احترافي بتصميم iOS 26 Liquid Glass العميق مبني بـ Jetpack Compose.

---

## ✨ المميزات

- 🎨 **تصميم iOS 26 Liquid Glass** — خلفية مجرّة متحركة، بطاقات زجاجية شفافة، إضاءة ديناميكية
- ⏰ **منبهات دقيقة** — AlarmManager.setAlarmClock (أعلى دقة في Android)
- 🔁 **تكرار مرن** — يومي، أيام العمل، أيام مخصصة
- 📳 **اهتزاز** — قابل للتفعيل/التعطيل لكل منبه
- 😴 **غفوة ذكية** — 5/10/15/20 دقيقة
- 🔒 **شاشة الإيقاظ** — يعمل على شاشة القفل ويوقظ الشاشة
- 🔄 **إعادة الجدولة التلقائية** — بعد إعادة تشغيل الجهاز
- 🌙 **Dark mode** — فقط، تصميم مظلم بالكامل
- 🌐 **RTL كامل** — دعم كامل للعربية

---

## 🏗️ التقنيات

| المكتبة | الإصدار |
|---------|---------|
| Jetpack Compose BOM | 2024.09.03 |
| Material 3 | via BOM |
| Hilt (DI) | 2.52 |
| Room (Database) | 2.6.1 |
| Navigation Compose | 2.8.3 |
| Kotlin | 2.0.21 |
| AGP | 8.6.0 |
| Min SDK | 26 (Android 8) |
| Target SDK | 35 (Android 15) |

---

## 🚀 البناء عبر GitHub Actions

### المتطلبات
- حساب GitHub
- لا يلزم أي إعداد إضافي

### الخطوات
```bash
# 1. ارفع المشروع إلى GitHub
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/USERNAME/AlarmPro.git
git push -u origin main

# 2. اذهب إلى Actions → Build AlarmPro APK → Run workflow
# 3. بعد الانتهاء، حمّل الـ APK من Artifacts
```

### APK الناتج
- `AlarmPro-debug-apk` — للتجربة المباشرة
- `AlarmPro-release-unsigned-apk` — للنشر (يحتاج توقيع)

---

## 📱 متوافق مع
- Android 8.0+ (API 26+)
- Android 16 / Xiaomi HyperOS 3 ✅
- RTL (Arabic) ✅

---

## 🏛️ هيكل المشروع

```
AlarmPro/
├── app/src/main/
│   ├── java/com/hussein/alarmpro/
│   │   ├── data/
│   │   │   ├── local/        → Room (Entity, Dao, Database)
│   │   │   └── repository/   → AlarmRepository
│   │   ├── di/               → Hilt modules
│   │   ├── domain/           → AlarmScheduler
│   │   ├── receiver/         → AlarmReceiver, BootReceiver
│   │   ├── service/          → AlarmService (Foreground)
│   │   └── ui/
│   │       ├── components/   → GlassComponents (reusable)
│   │       ├── navigation/   → AppNavigation
│   │       ├── screens/      → AlarmList, AddEdit, Ringing
│   │       ├── theme/        → Theme, Colors, Shapes
│   │       └── viewmodel/    → AlarmViewModel
│   └── res/
│       ├── drawable/         → Vector icons
│       ├── mipmap-*/         → Adaptive launcher icons
│       ├── values/           → strings, themes
│       └── xml/              → backup_rules, data_extraction_rules
├── .github/workflows/        → android.yml (CI/CD)
└── gradle/wrapper/           → Gradle 8.9
```

---

*برمجة - حسين حميد الشريفي*
