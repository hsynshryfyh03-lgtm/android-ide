package com.hussein.alarmpro

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class AlarmProApp : Application()
