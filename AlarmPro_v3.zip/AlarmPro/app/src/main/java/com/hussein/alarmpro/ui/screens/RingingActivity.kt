package com.hussein.alarmpro.ui.screens

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hussein.alarmpro.domain.AlarmScheduler
import com.hussein.alarmpro.receiver.AlarmReceiver
import com.hussein.alarmpro.service.AlarmService
import com.hussein.alarmpro.ui.components.*
import com.hussein.alarmpro.ui.theme.*
import java.util.Calendar
import java.util.Locale

class RingingActivity : ComponentActivity() {

    private var alarmId: Int = -1
    private var alarmLabel: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Allow activity to show on lock screen and turn on screen
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }

        alarmId = intent.getIntExtra(AlarmScheduler.EXTRA_ALARM_ID, -1)
        alarmLabel = intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_LABEL) ?: ""

        enableEdgeToEdge()

        setContent {
            AlarmProTheme {
                RingingScreen(
                    alarmLabel = alarmLabel,
                    onSnooze = { handleSnooze() },
                    onDismiss = { handleDismiss() }
                )
            }
        }
    }

    private fun handleSnooze() {
        val intent = Intent(this, AlarmReceiver::class.java).apply {
            action = AlarmScheduler.ACTION_ALARM_SNOOZE
            putExtra(AlarmScheduler.EXTRA_ALARM_ID, alarmId)
            putExtra(AlarmScheduler.EXTRA_ALARM_LABEL, alarmLabel)
        }
        sendBroadcast(intent)
        finish()
    }

    private fun handleDismiss() {
        // Stop service
        val stopIntent = Intent(this, AlarmService::class.java).apply {
            action = AlarmService.ACTION_STOP_ALARM
        }
        startService(stopIntent)
        finish()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        alarmId = intent.getIntExtra(AlarmScheduler.EXTRA_ALARM_ID, alarmId)
        alarmLabel = intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_LABEL) ?: alarmLabel
    }
}

@Composable
fun RingingScreen(
    alarmLabel: String,
    onSnooze: () -> Unit,
    onDismiss: () -> Unit
) {
    val calendar = remember { Calendar.getInstance() }
    val timeText = remember {
        String.format(
            Locale.getDefault(),
            "%02d:%02d",
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE)
        )
    }
    val amPm = if (calendar.get(Calendar.HOUR_OF_DAY) < 12) "صباحاً" else "مساءً"

    AnimatedGalaxyBackground(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(Modifier.height(48.dp))

            // ── Clock display ─────────────────────────────────────────
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = timeText,
                    fontSize = 80.sp,
                    fontWeight = FontWeight.Thin,
                    color = Color.White,
                    letterSpacing = 4.sp
                )
                Text(
                    text = amPm,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Light,
                    color = ColorOnSurfaceDim
                )
                Spacer(Modifier.height(12.dp))
                if (alarmLabel.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .glassCard(cornerRadius = 16.dp)
                            .padding(horizontal = 20.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = alarmLabel,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.White
                        )
                    }
                }
            }

            // ── Pulsing Alarm Bell ────────────────────────────────────
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(200.dp)
            ) {
                PulsingGlowCircle(
                    modifier = Modifier.fillMaxSize(),
                    color = AccentBlue
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Alarm,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(80.dp)
                    )
                }
            }

            // ── Label ─────────────────────────────────────────────────
            Text(
                text = "حان وقت المنبه",
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            // ── Action Buttons ────────────────────────────────────────
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.padding(bottom = 48.dp)
            ) {
                // Dismiss button
                GlassButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp),
                    cornerRadius = 30.dp,
                    isPrimary = true
                ) {
                    Text(
                        text = "إيقاف",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                }

                // Snooze button
                GlassButton(
                    onClick = onSnooze,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp),
                    cornerRadius = 30.dp
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Rounded.Alarm,
                            contentDescription = null,
                            tint = ColorOnSurfaceDim,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "غفوة 5 دقائق",
                            fontSize = 16.sp,
                            color = ColorOnSurfaceDim,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Credits
                Text(
                    text = "برمجة - حسين حميد الشريفي",
                    fontSize = 11.sp,
                    color = ColorOnSurfaceDim.copy(alpha = 0.5f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
