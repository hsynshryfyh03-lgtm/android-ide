package com.hussein.alarmpro.domain

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.hussein.alarmpro.data.local.AlarmEntity
import com.hussein.alarmpro.receiver.AlarmReceiver
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AlarmScheduler @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    companion object {
        const val ACTION_ALARM_FIRE = "com.hussein.alarmpro.ACTION_ALARM_FIRE"
        const val ACTION_ALARM_SNOOZE = "com.hussein.alarmpro.ACTION_ALARM_SNOOZE"
        const val ACTION_ALARM_DISMISS = "com.hussein.alarmpro.ACTION_ALARM_DISMISS"
        const val EXTRA_ALARM_ID = "extra_alarm_id"
        const val EXTRA_ALARM_LABEL = "extra_alarm_label"
    }

    fun schedule(alarm: AlarmEntity): Long {
        val triggerTime = calculateNextTriggerTime(alarm)

        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_ALARM_FIRE
            putExtra(EXTRA_ALARM_ID, alarm.id)
            putExtra(EXTRA_ALARM_LABEL, alarm.label)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            alarm.id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarmManager.canScheduleExactAlarms()) {
                scheduleExactAlarm(triggerTime, pendingIntent, alarm)
            } else {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerTime,
                    pendingIntent
                )
            }
        } else {
            scheduleExactAlarm(triggerTime, pendingIntent, alarm)
        }

        return triggerTime
    }

    private fun scheduleExactAlarm(
        triggerTime: Long,
        pendingIntent: PendingIntent,
        alarm: AlarmEntity
    ) {
        val alarmInfo = AlarmManager.AlarmClockInfo(
            triggerTime,
            createShowPendingIntent(alarm.id)
        )
        alarmManager.setAlarmClock(alarmInfo, pendingIntent)
    }

    fun cancel(alarmId: Int) {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_ALARM_FIRE
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            alarmId,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        pendingIntent?.let { alarmManager.cancel(it) }
    }

    fun snooze(alarmId: Int, label: String, snoozeMinutes: Int) {
        val triggerTime = System.currentTimeMillis() + (snoozeMinutes * 60 * 1000L)
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_ALARM_FIRE
            putExtra(EXTRA_ALARM_ID, alarmId)
            putExtra(EXTRA_ALARM_LABEL, label)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            alarmId + 10000,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarmManager.canScheduleExactAlarms()) {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerTime,
                pendingIntent
            )
        } else {
            alarmManager.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerTime,
                pendingIntent
            )
        }
    }

    private fun createShowPendingIntent(alarmId: Int): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_ALARM_FIRE
            putExtra(EXTRA_ALARM_ID, alarmId)
        }
        return PendingIntent.getBroadcast(
            context,
            alarmId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun calculateNextTriggerTime(alarm: AlarmEntity): Long {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, alarm.hour)
            set(Calendar.MINUTE, alarm.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        // If the time has already passed today, schedule for next occurrence
        if (calendar.timeInMillis <= System.currentTimeMillis()) {
            if (alarm.repeatDays == 0) {
                // One-time alarm: add one day
                calendar.add(Calendar.DAY_OF_YEAR, 1)
            } else {
                // Repeating alarm: find next valid day
                findNextRepeatDay(calendar, alarm.repeatDays)
            }
        } else if (alarm.repeatDays != 0) {
            // Check if current day is in repeat days
            val currentDayBit = getDayBit(calendar.get(Calendar.DAY_OF_WEEK))
            if ((alarm.repeatDays and currentDayBit) == 0) {
                findNextRepeatDay(calendar, alarm.repeatDays)
            }
        }

        return calendar.timeInMillis
    }

    private fun findNextRepeatDay(calendar: Calendar, repeatDays: Int) {
        for (i in 1..7) {
            calendar.add(Calendar.DAY_OF_YEAR, 1)
            val dayBit = getDayBit(calendar.get(Calendar.DAY_OF_WEEK))
            if ((repeatDays and dayBit) != 0) break
        }
    }

    private fun getDayBit(calendarDayOfWeek: Int): Int {
        // Calendar.SUNDAY=1, MONDAY=2, ..., SATURDAY=7
        // Our bitmask: bit0=Sun, bit1=Mon, ..., bit6=Sat
        return 1 shl (calendarDayOfWeek - 1)
    }
}
