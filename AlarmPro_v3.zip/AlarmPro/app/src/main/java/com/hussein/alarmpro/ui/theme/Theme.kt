package com.hussein.alarmpro.ui.theme

import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

// ──────────────────────────────────────────────────────────────
// iOS 26 Liquid Glass Palette — deep dark navy base
// ──────────────────────────────────────────────────────────────

// Background layers
val ColorBackground       = Color(0xFF000A1A)   // deep navy-black
val ColorSurface          = Color(0xFF020E24)   // slightly lighter navy
val ColorSurfaceVariant   = Color(0xFF061428)

// Glass tints
val GlassWhite            = Color(0x1AFFFFFF)   // 10% white overlay
val GlassWhiteStrong      = Color(0x26FFFFFF)   // 15% white overlay
val GlassBorder           = Color(0x33FFFFFF)   // 20% white border
val GlassBorderBright     = Color(0x55FFFFFF)   // 33% white border highlight
val GlassInner            = Color(0x0DFFFFFF)   // very subtle inner fill

// Accent — iOS blue spectrum
val AccentBlue            = Color(0xFF007AFF)   // iOS primary blue
val AccentBlueLight       = Color(0xFF3395FF)
val AccentBlueMid         = Color(0xFF0056CC)
val AccentTeal            = Color(0xFF5AC8FA)   // iOS teal
val AccentPurple          = Color(0xFF5856D6)   // iOS indigo
val AccentCyan            = Color(0xFF32ADE6)

// Gradient colors for animated background
val GradientDeepNavy      = Color(0xFF000A18)
val GradientMidNavy       = Color(0xFF001233)
val GradientBlueDeep      = Color(0xFF003366)
val GradientPurpleDeep    = Color(0xFF1A0040)
val GradientTealDeep      = Color(0xFF003344)

// Status
val ColorSuccess          = Color(0xFF34C759)   // iOS green
val ColorWarning          = Color(0xFFFF9F0A)   // iOS orange
val ColorError            = Color(0xFFFF3B30)   // iOS red
val ColorOnBackground     = Color(0xFFFFFFFF)
val ColorOnSurface        = Color(0xFFE5E5EA)
val ColorOnSurfaceDim     = Color(0xFF8E8E93)   // iOS secondary label

// Toggle track
val ToggleTrackActive     = Color(0xFF34C759)
val ToggleTrackInactive   = Color(0xFF3A3A3C)

private val DarkColorScheme = darkColorScheme(
    primary          = AccentBlue,
    onPrimary        = Color.White,
    primaryContainer = AccentBlueMid,
    secondary        = AccentTeal,
    onSecondary      = Color.White,
    tertiary         = AccentPurple,
    background       = ColorBackground,
    onBackground     = ColorOnBackground,
    surface          = ColorSurface,
    onSurface        = ColorOnSurface,
    surfaceVariant   = ColorSurfaceVariant,
    onSurfaceVariant = ColorOnSurfaceDim,
    outline          = GlassBorder,
    error            = ColorError,
    onError          = Color.White,
)

val AlarmShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small      = RoundedCornerShape(12.dp),
    medium     = RoundedCornerShape(16.dp),
    large      = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun AlarmProTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        shapes      = AlarmShapes,
        content     = content
    )
}
