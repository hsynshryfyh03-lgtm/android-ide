package com.hussein.alarmpro.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hussein.alarmpro.data.local.AlarmEntity
import com.hussein.alarmpro.data.repository.AlarmRepository
import com.hussein.alarmpro.domain.AlarmScheduler
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AlarmUiState(
    val alarms: List<AlarmEntity> = emptyList(),
    val isLoading: Boolean = true,
    val snackbarMessage: String? = null
)

@HiltViewModel
class AlarmViewModel @Inject constructor(
    private val repository: AlarmRepository,
    private val scheduler: AlarmScheduler
) : ViewModel() {

    private val _uiState = MutableStateFlow(AlarmUiState())
    val uiState: StateFlow<AlarmUiState> = _uiState.asStateFlow()

    init {
        observeAlarms()
    }

    private fun observeAlarms() {
        viewModelScope.launch {
            repository.getAllAlarms()
                .catch { e ->
                    _uiState.update { it.copy(isLoading = false, snackbarMessage = e.message) }
                }
                .collect { alarms ->
                    _uiState.update { it.copy(alarms = alarms, isLoading = false) }
                }
        }
    }

    fun addAlarm(
        hour: Int,
        minute: Int,
        label: String,
        repeatDays: Int,
        vibrateEnabled: Boolean,
        snoozeMinutes: Int
    ) {
        viewModelScope.launch {
            val alarm = AlarmEntity(
                hour = hour,
                minute = minute,
                label = label,
                repeatDays = repeatDays,
                vibrateEnabled = vibrateEnabled,
                snoozeMinutes = snoozeMinutes,
                isEnabled = true
            )
            val newId = repository.insertAlarm(alarm).toInt()
            val newAlarm = alarm.copy(id = newId)
            val triggerTime = scheduler.schedule(newAlarm)
            repository.updateNextTriggerTime(newId, triggerTime)
            _uiState.update { it.copy(snackbarMessage = formatTimeUntil(triggerTime)) }
        }
    }

    fun updateAlarm(alarm: AlarmEntity) {
        viewModelScope.launch {
            repository.updateAlarm(alarm)
            if (alarm.isEnabled) {
                val triggerTime = scheduler.schedule(alarm)
                repository.updateNextTriggerTime(alarm.id, triggerTime)
            } else {
                scheduler.cancel(alarm.id)
                repository.updateNextTriggerTime(alarm.id, 0L)
            }
        }
    }

    fun toggleAlarm(alarm: AlarmEntity, enabled: Boolean) {
        viewModelScope.launch {
            val updated = alarm.copy(isEnabled = enabled)
            repository.updateAlarm(updated)
            if (enabled) {
                val triggerTime = scheduler.schedule(updated)
                repository.updateNextTriggerTime(updated.id, triggerTime)
                _uiState.update { it.copy(snackbarMessage = formatTimeUntil(triggerTime)) }
            } else {
                scheduler.cancel(alarm.id)
                repository.updateNextTriggerTime(alarm.id, 0L)
            }
        }
    }

    fun deleteAlarm(alarm: AlarmEntity) {
        viewModelScope.launch {
            scheduler.cancel(alarm.id)
            repository.deleteAlarm(alarm)
            _uiState.update { it.copy(snackbarMessage = "تم حذف المنبه") }
        }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    private fun formatTimeUntil(triggerTime: Long): String {
        val diff = triggerTime - System.currentTimeMillis()
        if (diff <= 0) return "المنبه نشط"
        val hours = diff / 3_600_000L
        val minutes = (diff % 3_600_000L) / 60_000L
        return when {
            hours > 0 -> "المنبه بعد $hours ساعة و $minutes دقيقة"
            else -> "المنبه بعد $minutes دقيقة"
        }
    }
}
