package com.hussein.alarmpro.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.hussein.alarmpro.ui.components.*
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.ui.viewmodel.AlarmViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditAlarmScreen(
    alarmId: Int?,
    onBack: () -> Unit,
    viewModel: AlarmViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    val existingAlarm = remember(alarmId, uiState.alarms) {
        alarmId?.let { id -> uiState.alarms.find { it.id == id } }
    }

    var hour by remember(existingAlarm) { mutableIntStateOf(existingAlarm?.hour ?: 7) }
    var minute by remember(existingAlarm) { mutableIntStateOf(existingAlarm?.minute ?: 0) }
    var label by remember(existingAlarm) { mutableStateOf(existingAlarm?.label ?: "") }
    var repeatDays by remember(existingAlarm) { mutableIntStateOf(existingAlarm?.repeatDays ?: 0) }
    var vibrateEnabled by remember(existingAlarm) { mutableStateOf(existingAlarm?.vibrateEnabled ?: true) }
    var snoozeMinutes by remember(existingAlarm) { mutableIntStateOf(existingAlarm?.snoozeMinutes ?: 5) }

    val isEditing = existingAlarm != null

    AnimatedGalaxyBackground(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {

            // ── Top Bar ──────────────────────────────────────────────
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                GlassButton(
                    onClick = onBack,
                    modifier = Modifier.size(44.dp),
                    cornerRadius = 22.dp
                ) {
                    Icon(
                        Icons.Rounded.ArrowBack,
                        contentDescription = "رجوع",
                        tint = AccentBlue,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Text(
                    text = if (isEditing) "تعديل المنبه" else "منبه جديد",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White
                )

                GlassButton(
                    onClick = {
                        if (isEditing && existingAlarm != null) {
                            viewModel.updateAlarm(
                                existingAlarm.copy(
                                    hour = hour,
                                    minute = minute,
                                    label = label,
                                    repeatDays = repeatDays,
                                    vibrateEnabled = vibrateEnabled,
                                    snoozeMinutes = snoozeMinutes
                                )
                            )
                        } else {
                            viewModel.addAlarm(
                                hour = hour,
                                minute = minute,
                                label = label,
                                repeatDays = repeatDays,
                                vibrateEnabled = vibrateEnabled,
                                snoozeMinutes = snoozeMinutes
                            )
                        }
                        onBack()
                    },
                    modifier = Modifier
                        .height(44.dp)
                        .defaultMinSize(minWidth = 80.dp),
                    cornerRadius = 22.dp,
                    isPrimary = true
                ) {
                    Text(
                        text = if (isEditing) "حفظ" else "إضافة",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }

            // ── Scrollable Form ──────────────────────────────────────
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                // Time Picker
                DrumRollTimePicker(
                    hour = hour,
                    minute = minute,
                    onHourChange = { hour = it },
                    onMinuteChange = { minute = it }
                )

                // Label
                GlassSettingCard(title = "التسمية") {
                    OutlinedTextField(
                        value = label,
                        onValueChange = { label = it },
                        placeholder = { Text("اختياري", color = ColorOnSurfaceDim) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = AccentBlue,
                            unfocusedBorderColor = GlassBorder,
                            cursorColor = AccentBlue,
                            focusedContainerColor = GlassInner,
                            unfocusedContainerColor = GlassInner
                        ),
                        shape = RoundedCornerShape(14.dp)
                    )
                }

                // Repeat Days
                GlassSettingCard(title = "التكرار") {
                    RepeatDaysPicker(
                        repeatDays = repeatDays,
                        onRepeatDaysChange = { repeatDays = it }
                    )
                }

                // Vibrate toggle
                GlassSettingRow(
                    title = "الاهتزاز",
                    icon = Icons.Rounded.Vibration
                ) {
                    IosToggle(
                        checked = vibrateEnabled,
                        onCheckedChange = { vibrateEnabled = it }
                    )
                }

                // Snooze
                GlassSettingCard(title = "مدة الغفوة") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(5, 10, 15, 20).forEach { mins ->
                            GlassButton(
                                onClick = { snoozeMinutes = mins },
                                modifier = Modifier
                                    .height(44.dp)
                                    .weight(1f),
                                cornerRadius = 14.dp,
                                isPrimary = snoozeMinutes == mins
                            ) {
                                Text(
                                    text = "$mins د",
                                    color = Color.White,
                                    fontWeight = if (snoozeMinutes == mins)
                                        FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(32.dp))
            }
        }
    }
}

// ─── Drum-roll Time Picker ────────────────────────────────────────────────────

@Composable
private fun DrumRollTimePicker(
    hour: Int,
    minute: Int,
    onHourChange: (Int) -> Unit,
    onMinuteChange: (Int) -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .glassCard(cornerRadius = 28.dp)
            .padding(vertical = 24.dp, horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NumberPicker(value = hour, range = 0..23, onValueChange = onHourChange)

            Text(
                text = ":",
                fontSize = 48.sp,
                fontWeight = FontWeight.Thin,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            NumberPicker(value = minute, range = 0..59, onValueChange = onMinuteChange)
        }
    }
}

@Composable
private fun NumberPicker(
    value: Int,
    range: IntRange,
    onValueChange: (Int) -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = {
            onValueChange(if (value >= range.last) range.first else value + 1)
        }) {
            Icon(
                Icons.Rounded.KeyboardArrowUp,
                contentDescription = "زيادة",
                tint = AccentBlue,
                modifier = Modifier.size(32.dp)
            )
        }

        Text(
            text = String.format(java.util.Locale.getDefault(), "%02d", value),
            fontSize = 64.sp,
            fontWeight = FontWeight.Thin,
            color = Color.White,
            textAlign = TextAlign.Center,
            modifier = Modifier.width(90.dp)
        )

        IconButton(onClick = {
            onValueChange(if (value <= range.first) range.last else value - 1)
        }) {
            Icon(
                Icons.Rounded.KeyboardArrowDown,
                contentDescription = "تخفيض",
                tint = AccentBlue,
                modifier = Modifier.size(32.dp)
            )
        }
    }
}

// ─── Repeat Days Picker ───────────────────────────────────────────────────────

@Composable
private fun RepeatDaysPicker(
    repeatDays: Int,
    onRepeatDaysChange: (Int) -> Unit
) {
    val dayLabels = listOf("أح", "إث", "ثل", "أر", "خم", "جم", "سب")

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            dayLabels.forEachIndexed { index, dayLabel ->
                val bit = 1 shl index
                val selected = (repeatDays and bit) != 0
                DayChip(
                    label = dayLabel,
                    selected = selected,
                    onClick = {
                        onRepeatDaysChange(
                            if (selected) repeatDays and bit.inv()
                            else repeatDays or bit
                        )
                    }
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Bit layout: bit0=Sun(أح)..bit6=Sat(سب)
            // Weekdays = Mon(1)+Tue(2)+Wed(3)+Thu(4)+Fri(5) = bits 1-5 = 0b0111110 = 62
            // All days  = bits 0-6 = 0b1111111 = 127
            listOf(
                Triple("لا تكرار", 0, Modifier.weight(1f)),
                Triple("كل يوم", 127, Modifier.weight(1f)),
                Triple("أيام العمل", 62, Modifier.weight(1f))
            ).forEach { (text, bits, mod) ->
                GlassButton(
                    onClick = { onRepeatDaysChange(bits) },
                    modifier = mod.height(36.dp),
                    cornerRadius = 10.dp,
                    isPrimary = repeatDays == bits
                ) {
                    Text(
                        text = text,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = if (repeatDays == bits) FontWeight.SemiBold
                        else FontWeight.Normal
                    )
                }
            }
        }
    }
}

// ─── Glass Setting Wrappers ───────────────────────────────────────────────────

@Composable
private fun GlassSettingCard(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .glassCard(cornerRadius = 20.dp)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = title,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = ColorOnSurfaceDim,
            letterSpacing = 0.5.sp
        )
        content()
    }
}

@Composable
private fun GlassSettingRow(
    title: String,
    icon: ImageVector,
    content: @Composable RowScope.() -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .glassCard(cornerRadius = 20.dp)
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = AccentBlue,
            modifier = Modifier.size(22.dp)
        )
        Spacer(Modifier.width(12.dp))
        Text(
            text = title,
            color = Color.White,
            fontSize = 16.sp,
            modifier = Modifier.weight(1f)
        )
        content()
    }
}
