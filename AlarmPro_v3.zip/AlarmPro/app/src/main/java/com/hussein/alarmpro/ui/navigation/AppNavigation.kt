package com.hussein.alarmpro.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.hussein.alarmpro.ui.screens.AddEditAlarmScreen
import com.hussein.alarmpro.ui.screens.AlarmListScreen

sealed class Screen(val route: String) {
    object AlarmList : Screen("alarm_list")
    object AddAlarm  : Screen("add_alarm")
    object EditAlarm : Screen("edit_alarm/{alarmId}") {
        fun createRoute(alarmId: Int) = "edit_alarm/$alarmId"
    }
}

@Composable
fun AppNavigation(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = Screen.AlarmList.route
    ) {
        composable(Screen.AlarmList.route) {
            AlarmListScreen(
                onAddAlarm   = { navController.navigate(Screen.AddAlarm.route) },
                onEditAlarm  = { id -> navController.navigate(Screen.EditAlarm.createRoute(id)) }
            )
        }

        composable(Screen.AddAlarm.route) {
            AddEditAlarmScreen(
                alarmId  = null,
                onBack   = { navController.popBackStack() }
            )
        }

        composable(
            route     = Screen.EditAlarm.route,
            arguments = listOf(navArgument("alarmId") { type = NavType.IntType })
        ) { backStackEntry ->
            val alarmId = backStackEntry.arguments?.getInt("alarmId")
            AddEditAlarmScreen(
                alarmId = alarmId,
                onBack  = { navController.popBackStack() }
            )
        }
    }
}
