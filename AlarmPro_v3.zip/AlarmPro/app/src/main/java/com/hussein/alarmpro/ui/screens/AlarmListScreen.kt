package com.hussein.alarmpro.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.hussein.alarmpro.data.local.AlarmEntity
import com.hussein.alarmpro.ui.components.*
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.ui.viewmodel.AlarmViewModel
import java.util.Calendar
import java.util.Locale

@Composable
fun AlarmListScreen(
    onAddAlarm: () -> Unit,
    onEditAlarm: (Int) -> Unit,
    viewModel: AlarmViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearSnackbar()
        }
    }

    Scaffold(
        snackbarHost = {
            SnackbarHost(snackbarHostState) { data ->
                Snackbar(
                    modifier = Modifier
                        .padding(16.dp)
                        .clip(RoundedCornerShape(16.dp)),
                    containerColor = Color(0xCC000000),
                    contentColor = Color.White,
                    snackbarData = data
                )
            }
        },
        containerColor = Color.Transparent,
        floatingActionButton = {
            GlassButton(
                onClick = onAddAlarm,
                modifier = Modifier.size(64.dp),
                cornerRadius = 32.dp,
                isPrimary = true
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "إضافة منبه",
                    tint = Color.White,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    ) { paddingValues ->
        AnimatedGalaxyBackground(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {

                Spacer(Modifier.height(16.dp))
                AlarmListHeader()
                Spacer(Modifier.height(8.dp))

                when {
                    uiState.isLoading -> {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = AccentBlue)
                        }
                    }
                    uiState.alarms.isEmpty() -> {
                        EmptyAlarmsView(modifier = Modifier.fillMaxSize())
                    }
                    else -> {
                        LazyColumn(
                            contentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = 0.dp,
                                bottom = 100.dp
                            ),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            itemsIndexed(
                                items = uiState.alarms,
                                key = { _, alarm -> alarm.id }
                            ) { index, alarm ->
                                AnimatedVisibility(
                                    visible = true,
                                    enter = fadeIn(tween(300, delayMillis = index * 60)) +
                                            slideInVertically(
                                                tween(300, delayMillis = index * 60)
                                            ) { it / 2 }
                                ) {
                                    AlarmCard(
                                        alarm = alarm,
                                        onToggle = { enabled ->
                                            viewModel.toggleAlarm(alarm, enabled)
                                        },
                                        onEdit = { onEditAlarm(alarm.id) },
                                        onDelete = { viewModel.deleteAlarm(alarm) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ─── Header ───────────────────────────────────────────────────────────────────

@Composable
private fun AlarmListHeader() {
    val calendar = remember { Calendar.getInstance() }
    val timeText = remember {
        String.format(
            Locale.getDefault(),
            "%02d:%02d",
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE)
        )
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = timeText,
            fontSize = 72.sp,
            fontWeight = FontWeight.Thin,
            color = Color.White,
            letterSpacing = 4.sp
        )
        Text(
            text = "المنبّه",
            fontSize = 34.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = "برمجة - حسين حميد الشريفي",
            fontSize = 11.sp,
            color = ColorOnSurfaceDim,
            letterSpacing = 1.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(16.dp))
    }
}

// ─── Alarm Card ───────────────────────────────────────────────────────────────

@Composable
private fun AlarmCard(
    alarm: AlarmEntity,
    onToggle: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    var showDeleteDialog by remember { mutableStateOf(false) }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            containerColor = Color(0xFF0A1628),
            title = {
                Text("حذف المنبه", color = Color.White, fontWeight = FontWeight.SemiBold)
            },
            text = {
                Text("هل تريد حذف هذا المنبه؟", color = ColorOnSurfaceDim)
            },
            confirmButton = {
                TextButton(onClick = { onDelete(); showDeleteDialog = false }) {
                    Text("حذف", color = ColorError)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("إلغاء", color = AccentBlue)
                }
            }
        )
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .glassCard(cornerRadius = 20.dp)
    ) {
        // Coloured left accent bar
        Box(
            modifier = Modifier
                .width(4.dp)
                .height(60.dp)
                .align(Alignment.CenterStart)
                .background(
                    if (alarm.isEnabled) {
                        Brush.verticalGradient(listOf(AccentBlue, AccentTeal))
                    } else {
                        Brush.verticalGradient(listOf(ColorOnSurfaceDim, ColorOnSurfaceDim))
                    },
                    RoundedCornerShape(topEnd = 2.dp, bottomEnd = 2.dp)
                )
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 16.dp, top = 14.dp, bottom = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Spacer(Modifier.width(8.dp))

            // Time + label
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = String.format(
                            Locale.getDefault(), "%02d:%02d",
                            alarm.hour, alarm.minute
                        ),
                        fontSize = 42.sp,
                        fontWeight = FontWeight.Light,
                        color = if (alarm.isEnabled) Color.White else ColorOnSurfaceDim,
                        letterSpacing = 1.sp
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = if (alarm.hour < 12) "ص" else "م",
                        fontSize = 16.sp,
                        color = if (alarm.isEnabled) AccentBlueLight else ColorOnSurfaceDim,
                        modifier = Modifier.padding(bottom = 8.dp),
                        fontWeight = FontWeight.Medium
                    )
                }

                if (alarm.label.isNotBlank()) {
                    Text(
                        text = alarm.label,
                        fontSize = 14.sp,
                        color = if (alarm.isEnabled) ColorOnSurfaceDim
                        else ColorOnSurfaceDim.copy(alpha = 0.5f)
                    )
                }

                val repeatText = getRepeatText(alarm.repeatDays)
                Spacer(Modifier.height(2.dp))
                Text(
                    text = repeatText,
                    fontSize = 12.sp,
                    color = if (alarm.isEnabled) AccentTeal
                    else ColorOnSurfaceDim.copy(alpha = 0.5f)
                )
            }

            // Toggle + action icons
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IosToggle(checked = alarm.isEnabled, onCheckedChange = onToggle)

                Row {
                    IconButton(
                        onClick = onEdit,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            Icons.Rounded.Edit,
                            contentDescription = "تعديل",
                            tint = AccentBlue,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = { showDeleteDialog = true },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            Icons.Rounded.Delete,
                            contentDescription = "حذف",
                            tint = ColorError,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

// ─── Empty State ──────────────────────────────────────────────────────────────

@Composable
private fun EmptyAlarmsView(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(120.dp)
                .glassCard(cornerRadius = 60.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Rounded.Alarm,
                contentDescription = null,
                tint = AccentBlue.copy(alpha = 0.7f),
                modifier = Modifier.size(60.dp)
            )
        }
        Spacer(Modifier.height(24.dp))
        Text(
            text = "لا توجد منبهات",
            fontSize = 22.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.White
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "اضغط + لإضافة منبه جديد",
            fontSize = 15.sp,
            color = ColorOnSurfaceDim
        )
    }
}

// ─── Helper ───────────────────────────────────────────────────────────────────

/**
 * Bit layout: bit0=Sun(أح), bit1=Mon(إث), bit2=Tue(ثل), bit3=Wed(أر),
 *              bit4=Thu(خم), bit5=Fri(جم), bit6=Sat(سب)
 * All days   = 0b1111111 = 127
 * Weekdays   = bits 1-5  = 0b0111110 = 62
 * Weekend    = bits 0,6  = 0b1000001 = 65
 */
private fun getRepeatText(repeatDays: Int): String {
    if (repeatDays == 0) return "مرة واحدة"
    if (repeatDays == 127) return "كل يوم"
    if (repeatDays == 62) return "أيام العمل"
    if (repeatDays == 65) return "نهاية الأسبوع"
    val days = listOf("أح", "إث", "ثل", "أر", "خم", "جم", "سب")
    val selected = mutableListOf<String>()
    for (i in 0..6) {
        if ((repeatDays and (1 shl i)) != 0) selected.add(days[i])
    }
    return selected.joinToString(" · ")
}
