package com.hussein.alarmpro.data.repository

import com.hussein.alarmpro.data.local.AlarmDao
import com.hussein.alarmpro.data.local.AlarmEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AlarmRepository @Inject constructor(
    private val alarmDao: AlarmDao
) {
    fun getAllAlarms(): Flow<List<AlarmEntity>> = alarmDao.getAllAlarms()

    suspend fun getAlarmById(id: Int): AlarmEntity? = alarmDao.getAlarmById(id)

    suspend fun getEnabledAlarms(): List<AlarmEntity> = alarmDao.getEnabledAlarms()

    suspend fun insertAlarm(alarm: AlarmEntity): Long = alarmDao.insertAlarm(alarm)

    suspend fun updateAlarm(alarm: AlarmEntity) = alarmDao.updateAlarm(alarm)

    suspend fun deleteAlarm(alarm: AlarmEntity) = alarmDao.deleteAlarm(alarm)

    suspend fun deleteAlarmById(id: Int) = alarmDao.deleteAlarmById(id)

    suspend fun setAlarmEnabled(id: Int, isEnabled: Boolean) =
        alarmDao.setAlarmEnabled(id, isEnabled)

    suspend fun updateNextTriggerTime(id: Int, triggerTime: Long) =
        alarmDao.updateNextTriggerTime(id, triggerTime)
}
