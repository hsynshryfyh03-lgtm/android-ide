package com.hussein.alarmpro.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.hussein.alarmpro.ui.theme.*

// ─── Animated Deep Galaxy Background ────────────────────────────────────────

@Composable
fun AnimatedGalaxyBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "galaxy")

    val offset1 by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(12000, easing = LinearEasing), RepeatMode.Reverse),
        label = "o1"
    )
    val offset2 by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse),
        label = "o2"
    )
    val offset3 by infiniteTransition.animateFloat(
        initialValue = 0.3f, targetValue = 0.8f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse),
        label = "o3"
    )

    Box(
        modifier = modifier
            .background(ColorBackground)
            .drawBehind {
                drawGalaxyLayer(offset1, offset2, offset3)
            },
        content = content
    )
}

private fun DrawScope.drawGalaxyLayer(o1: Float, o2: Float, o3: Float) {
    val w = size.width
    val h = size.height

    // Deep blue nebula blob 1
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0x22007AFF), Color.Transparent),
            center = Offset(w * (0.2f + o1 * 0.3f), h * (0.1f + o2 * 0.2f)),
            radius = w * 0.7f
        ),
        radius = w * 0.7f,
        center = Offset(w * (0.2f + o1 * 0.3f), h * (0.1f + o2 * 0.2f))
    )
    // Purple blob
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0x1A5856D6), Color.Transparent),
            center = Offset(w * (0.8f - o2 * 0.3f), h * (0.6f + o1 * 0.2f)),
            radius = w * 0.6f
        ),
        radius = w * 0.6f,
        center = Offset(w * (0.8f - o2 * 0.3f), h * (0.6f + o1 * 0.2f))
    )
    // Teal blob
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0x155AC8FA), Color.Transparent),
            center = Offset(w * (0.5f + o3 * 0.2f), h * (0.8f - o3 * 0.3f)),
            radius = w * 0.5f
        ),
        radius = w * 0.5f,
        center = Offset(w * (0.5f + o3 * 0.2f), h * (0.8f - o3 * 0.3f))
    )
}

// ─── Glass Card ─────────────────────────────────────────────────────────────

fun Modifier.glassCard(
    cornerRadius: Dp = 20.dp,
    borderAlpha: Float = 0.20f
): Modifier = composed {
    this
        .background(
            brush = Brush.linearGradient(
                colors = listOf(
                    Color(0x26FFFFFF),
                    Color(0x0DFFFFFF),
                    Color(0x1AFFFFFF)
                ),
                start = Offset(0f, 0f),
                end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
            ),
            shape = RoundedCornerShape(cornerRadius)
        )
        .border(
            width = 1.dp,
            brush = Brush.linearGradient(
                colors = listOf(
                    Color(0x55FFFFFF),
                    Color(0x1AFFFFFF),
                    Color(0x33FFFFFF)
                )
            ),
            shape = RoundedCornerShape(cornerRadius)
        )
        .clip(RoundedCornerShape(cornerRadius))
}

// ─── iOS-style Toggle (Switch) ───────────────────────────────────────────────

@Composable
fun IosToggle(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        modifier = modifier,
        enabled = enabled,
        colors = SwitchDefaults.colors(
            checkedThumbColor        = Color.White,
            checkedTrackColor        = ToggleTrackActive,
            checkedBorderColor       = Color.Transparent,
            uncheckedThumbColor      = Color.White,
            uncheckedTrackColor      = ToggleTrackInactive,
            uncheckedBorderColor     = Color.Transparent,
            disabledCheckedThumbColor   = Color.White.copy(alpha = 0.5f),
            disabledCheckedTrackColor   = ToggleTrackActive.copy(alpha = 0.5f),
            disabledUncheckedThumbColor = Color.White.copy(alpha = 0.5f),
            disabledUncheckedTrackColor = ToggleTrackInactive.copy(alpha = 0.5f),
        )
    )
}

// ─── Glass Button ────────────────────────────────────────────────────────────

@Composable
fun GlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 16.dp,
    isPrimary: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    val backgroundBrush = if (isPrimary) {
        Brush.linearGradient(
            colors = listOf(Color(0xFF007AFF), Color(0xFF0056CC))
        )
    } else {
        Brush.linearGradient(
            colors = listOf(Color(0x33FFFFFF), Color(0x1AFFFFFF))
        )
    }

    Box(
        modifier = modifier
            .background(backgroundBrush, RoundedCornerShape(cornerRadius))
            .border(
                1.dp,
                if (isPrimary) Color(0x55FFFFFF) else Color(0x33FFFFFF),
                RoundedCornerShape(cornerRadius)
            )
            .clip(RoundedCornerShape(cornerRadius))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center,
        content = content
    )
}

// ─── Glowing Circle (alarm ring animation) ───────────────────────────────────

@Composable
fun PulsingGlowCircle(
    modifier: Modifier = Modifier,
    color: Color = AccentBlue,
    content: @Composable BoxScope.() -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "glow")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            tween(1000, easing = FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "pulse"
    )
    val ringScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            tween(1200, easing = LinearOutSlowInEasing),
            RepeatMode.Restart
        ),
        label = "ring"
    )
    val ringAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            tween(1200, easing = LinearOutSlowInEasing),
            RepeatMode.Restart
        ),
        label = "ringAlpha"
    )

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        // Outer expanding ring
        Box(
            modifier = Modifier
                .matchParentSize()
                .graphicsLayer {
                    scaleX = ringScale
                    scaleY = ringScale
                    alpha = ringAlpha
                }
                .background(color.copy(alpha = 0.25f), CircleShape)
                .border(2.dp, color.copy(alpha = 0.6f), CircleShape)
        )
        // Inner glow circle
        Box(
            modifier = Modifier
                .matchParentSize()
                .graphicsLayer { alpha = pulse }
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            color.copy(alpha = 0.35f),
                            color.copy(alpha = 0.10f),
                            Color.Transparent
                        )
                    ),
                    CircleShape
                )
        )
        content()
    }
}

// ─── Day Chip ─────────────────────────────────────────────────────────────────

@Composable
fun DayChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor = if (selected) AccentBlue else Color(0x1AFFFFFF)
    val borderColor = if (selected) AccentBlueLight else Color(0x33FFFFFF)
    val textColor = if (selected) Color.White else ColorOnSurfaceDim

    Box(
        modifier = modifier
            .size(38.dp)
            .background(bgColor, CircleShape)
            .border(1.dp, borderColor, CircleShape)
            .clip(CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Text(
            text = label,
            color = textColor,
            style = androidx.compose.material3.MaterialTheme.typography.labelSmall,
            fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold
        )
    }
}
