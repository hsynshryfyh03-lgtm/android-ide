package com.hussein.alarmpro.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.hussein.alarmpro.data.repository.AlarmRepository
import com.hussein.alarmpro.domain.AlarmScheduler
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class BootReceiver : BroadcastReceiver() {

    @Inject
    lateinit var alarmRepository: AlarmRepository

    @Inject
    lateinit var alarmScheduler: AlarmScheduler

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                rescheduleAlarms()
            }
        }
    }

    private fun rescheduleAlarms() {
        CoroutineScope(Dispatchers.IO).launch {
            val enabledAlarms = alarmRepository.getEnabledAlarms()
            enabledAlarms.forEach { alarm ->
                val triggerTime = alarmScheduler.schedule(alarm)
                alarmRepository.updateNextTriggerTime(alarm.id, triggerTime)
            }
        }
    }
}
