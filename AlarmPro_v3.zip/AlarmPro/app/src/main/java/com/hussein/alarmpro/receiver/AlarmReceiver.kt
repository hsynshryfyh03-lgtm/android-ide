package com.hussein.alarmpro.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.hussein.alarmpro.domain.AlarmScheduler
import com.hussein.alarmpro.service.AlarmService
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class AlarmReceiver : BroadcastReceiver() {

    @Inject
    lateinit var alarmScheduler: AlarmScheduler

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            AlarmScheduler.ACTION_ALARM_FIRE -> {
                val alarmId = intent.getIntExtra(AlarmScheduler.EXTRA_ALARM_ID, -1)
                val label = intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_LABEL) ?: ""

                if (alarmId != -1) {
                    // Start the alarm service (plays sound + shows notification)
                    val serviceIntent = Intent(context, AlarmService::class.java).apply {
                        action = AlarmService.ACTION_START_ALARM
                        putExtra(AlarmScheduler.EXTRA_ALARM_ID, alarmId)
                        putExtra(AlarmScheduler.EXTRA_ALARM_LABEL, label)
                    }
                    context.startForegroundService(serviceIntent)
                }
            }

            AlarmScheduler.ACTION_ALARM_SNOOZE -> {
                val alarmId = intent.getIntExtra(AlarmScheduler.EXTRA_ALARM_ID, -1)
                val label = intent.getStringExtra(AlarmScheduler.EXTRA_ALARM_LABEL) ?: ""

                // Stop current alarm
                val stopIntent = Intent(context, AlarmService::class.java).apply {
                    action = AlarmService.ACTION_STOP_ALARM
                }
                context.startService(stopIntent)

                // Reschedule with 5-minute snooze
                if (alarmId != -1) {
                    alarmScheduler.snooze(alarmId, label, 5)
                }
            }

            AlarmScheduler.ACTION_ALARM_DISMISS -> {
                // Stop alarm service
                val stopIntent = Intent(context, AlarmService::class.java).apply {
                    action = AlarmService.ACTION_STOP_ALARM
                }
                context.startService(stopIntent)
            }
        }
    }
}
