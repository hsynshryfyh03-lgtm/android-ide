package com.safecapture.app.service

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.media.MediaRecorder
import android.os.*
import android.util.Log
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.safecapture.app.MainActivity
import com.safecapture.app.R
import com.safecapture.app.data.local.datastore.SettingsDataStore
import com.safecapture.app.domain.model.AppSettings
import com.safecapture.app.domain.model.videoBitrate
import com.safecapture.app.domain.model.videoWidthHeight
import com.safecapture.app.domain.model.hasTelegramConfig
import com.safecapture.app.domain.repository.RecordingRepository
import com.safecapture.app.domain.model.Recording
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.CountDownLatch
import javax.inject.Inject

@AndroidEntryPoint
class RecordingService : Service() {

    companion object {
        const val ACTION_START    = "com.safecapture.app.ACTION_START_RECORDING"
        const val ACTION_STOP     = "com.safecapture.app.ACTION_STOP_RECORDING"
        const val ACTION_TOGGLE   = "com.safecapture.app.ACTION_TOGGLE_RECORDING"

        const val CHANNEL_ID      = "safe_capture_recording_channel"
        const val NOTIF_ID        = 1001

        const val EXTRA_IS_RECORDING = "is_recording"

        private const val TAG = "RecordingService"

        @Volatile var isRecording    = false
        @Volatile var recordingStart = 0L

        fun start(context: Context)  = context.startForegroundService(Intent(context, RecordingService::class.java).apply { action = ACTION_START })
        fun stop(context: Context)   = context.startService(Intent(context, RecordingService::class.java).apply { action = ACTION_STOP })
        fun toggle(context: Context) = context.startForegroundService(Intent(context, RecordingService::class.java).apply { action = ACTION_TOGGLE })
    }

    @Inject lateinit var repository: RecordingRepository
    @Inject lateinit var settingsDataStore: SettingsDataStore

    // FIX #3: Use Dispatchers.IO for camera/file work, switch to Main only for broadcasts
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private var cameraManager: CameraManager? = null
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var mediaRecorder: MediaRecorder? = null
    private var dummySurfaceTexture: SurfaceTexture? = null

    // GL timestamp overlay
    private var glRenderer: TimestampOverlayRenderer? = null
    private var glThread: HandlerThread? = null
    private var glHandler: android.os.Handler? = null
    private var useTimestampOverlay = false

    // FIX #1: Dedicated HandlerThread for Camera2 callbacks (avoids null Handler race)
    private var cameraThread: HandlerThread? = null
    private var cameraHandler: android.os.Handler? = null

    private var currentFile: File? = null
    private var recordingStartMs = 0L
    private var maxDurationJob: Job? = null

    private lateinit var vibrator: Vibrator
    private lateinit var wakeLock: PowerManager.WakeLock

    override fun onCreate() {
        super.onCreate()
        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        vibrator      = getSystemService(VIBRATOR_SERVICE) as Vibrator
        val pm        = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock      = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SafeCapture::RecordingWakeLock")

        // FIX #1: Start dedicated camera thread
        cameraThread = HandlerThread("CameraThread").also { it.start() }
        cameraHandler = android.os.Handler(cameraThread!!.looper)

        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START  -> if (!isRecording) startRecording()
            ACTION_STOP   -> if (isRecording)  stopRecording()
            ACTION_TOGGLE -> if (isRecording) stopRecording() else startRecording()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?) = null

    override fun onDestroy() {
        super.onDestroy()
        // FIX #8 (MEMORY LEAK): Previously called stopRecording() (which launches a coroutine)
        // then immediately cancelled the scope — meaning camera/MediaRecorder were never cleaned up.
        // Now we perform synchronous cleanup directly before cancelling the scope.
        if (isRecording) {
            isRecording = false
            maxDurationJob?.cancel()
            try { mediaRecorder?.apply { stop(); reset(); release() } } catch (_: Exception) {}
            mediaRecorder = null
            cleanupCamera()
        }
        scope.cancel()
        cameraThread?.quitSafely()
        if (wakeLock.isHeld) wakeLock.release()
    }

    // ─────────────────────────────────────────────────────────────
    // START
    // ─────────────────────────────────────────────────────────────
    private fun startRecording() {
        scope.launch {
            try {
                val settings = settingsDataStore.settingsFlow.first()

                // FIX #2: ServiceCompat.startForeground with correct type for API 29+
                ServiceCompat.startForeground(
                    this@RecordingService,
                    NOTIF_ID,
                    buildNotification(recording = true),
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                    else 0
                )

                // Acquire WakeLock with recording duration limit
                val maxMs = if (settings.maxDurationMinutes > 0)
                    (settings.maxDurationMinutes * 60 * 1000L) + 30_000L
                else 4 * 60 * 60 * 1000L
                wakeLock.acquire(maxMs) // FIX #4: bounded to actual recording length

                val outputFile = createOutputFile()
                currentFile    = outputFile
                useTimestampOverlay = settings.timestampOverlay

                setupMediaRecorder(outputFile, settings)
                openCamera(settings)

                isRecording    = true
                recordingStart = System.currentTimeMillis()
                recordingStartMs = recordingStart

                if (settings.vibrationEnabled) vibrateStart()

                if (settings.maxDurationMinutes > 0) {
                    maxDurationJob = scope.launch {
                        delay(settings.maxDurationMinutes * 60 * 1000L)
                        stopRecording()
                    }
                }

                withContext(Dispatchers.Main) {
                    sendBroadcast(Intent(ACTION_TOGGLE).putExtra(EXTRA_IS_RECORDING, true))
                }
                Log.d(TAG, "Recording started → ${outputFile.absolutePath}")

            } catch (e: Exception) {
                Log.e(TAG, "Failed to start recording", e)
                cleanupCamera()
                stopSelf()
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    // STOP
    // ─────────────────────────────────────────────────────────────
    private fun stopRecording() {
        scope.launch {
            try {
                maxDurationJob?.cancel()

                // FIX #5: MediaRecorder.stop() is blocking — already on Dispatchers.IO scope ✓
                try {
                    mediaRecorder?.apply { stop(); reset(); release() }
                } catch (e: Exception) {
                    Log.w(TAG, "MediaRecorder stop warning: ${e.message}")
                }
                mediaRecorder = null

                cleanupCamera()

                isRecording    = false
                val durationMs = System.currentTimeMillis() - recordingStartMs

                if (wakeLock.isHeld) wakeLock.release()

                val settings = settingsDataStore.settingsFlow.first()
                if (settings.vibrationEnabled) vibrateStop()

                // FIX #6: File I/O — already on Dispatchers.IO scope ✓
                currentFile?.let { file ->
                    if (file.exists() && file.length() > 0) {
                        val recording = Recording(
                            filePath      = file.absolutePath,
                            fileName      = file.name,
                            durationMs    = durationMs,
                            fileSizeBytes = file.length(),
                            timestampMs   = recordingStartMs
                        )
                        repository.saveRecording(recording)
                        Log.d(TAG, "Recording saved: ${file.name} | ${file.length()} bytes | ${durationMs}ms")

                        if (settings.telegramAutoUpload && settings.hasTelegramConfig) {
                            val tsFormatted = SimpleDateFormat(
                                "yyyy-MM-dd HH:mm:ss", Locale.getDefault()
                            ).format(Date(recordingStartMs))
                            TelegramUploadWorker.enqueue(
                                context            = applicationContext,
                                filePath           = file.absolutePath,
                                fileName           = file.name,
                                durationFormatted  = recording.durationFormatted,
                                sizeFormatted      = recording.sizeFormatted,
                                timestampFormatted = tsFormatted,
                            )
                        }
                    } else {
                        Log.w(TAG, "Recording file empty or missing — not saved")
                    }
                }
                currentFile = null

                withContext(Dispatchers.Main) {
                    sendBroadcast(Intent(ACTION_TOGGLE).putExtra(EXTRA_IS_RECORDING, false))
                }
                // FIX #9: Demote to background after recording stops.
                // Without this the service stays as a foreground service forever,
                // draining battery and preventing the OS from reclaiming resources.
                @Suppress("DEPRECATION")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N)
                    stopForeground(STOP_FOREGROUND_DETACH)
                else
                    stopForeground(true)
                updateNotification(recording = false)

            } catch (e: Exception) {
                Log.e(TAG, "Error stopping recording", e)
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Camera2
    // ─────────────────────────────────────────────────────────────
    @SuppressLint("MissingPermission")
    @Throws(CameraAccessException::class)
    private fun openCamera(settings: AppSettings) {
        val facing = if (settings.cameraFacing == "front")
            CameraCharacteristics.LENS_FACING_FRONT
        else
            CameraCharacteristics.LENS_FACING_BACK

        val cameraId = cameraManager!!.cameraIdList.firstOrNull { id ->
            cameraManager!!.getCameraCharacteristics(id)
                .get(CameraCharacteristics.LENS_FACING) == facing
        } ?: cameraManager!!.cameraIdList.first()

        // FIX #1: Pass cameraHandler so callbacks arrive on dedicated thread, not null
        cameraManager!!.openCamera(cameraId, object : CameraDevice.StateCallback() {
            override fun onOpened(camera: CameraDevice) {
                cameraDevice = camera
                createCaptureSession()
            }
            override fun onDisconnected(camera: CameraDevice) { camera.close(); cameraDevice = null }
            override fun onError(camera: CameraDevice, error: Int) {
                Log.e(TAG, "Camera error: $error")
                camera.close(); cameraDevice = null
            }
        }, cameraHandler) // FIX #1: use dedicated handler instead of null
    }

    private fun createCaptureSession() {
        val recorderSurface = mediaRecorder!!.surface

        val (cameraSurface, surfaces) = if (useTimestampOverlay) {
            val (w, h) = Pair(1280, 720)
            val renderer = TimestampOverlayRenderer(recorderSurface, w, h)

            glThread = HandlerThread("GLRecordThread").also { it.start() }
            glHandler = android.os.Handler(glThread!!.looper)

            // FIX #9: Use CountDownLatch to wait for setup() before accessing inputSurfaceTexture
            val latch = CountDownLatch(1)
            glHandler!!.post {
                renderer.setup()
                latch.countDown()
            }
            latch.await() // CRITICAL FIX: block until EGL/GL is initialized

            glRenderer = renderer

            renderer.inputSurfaceTexture.setOnFrameAvailableListener({
                glHandler?.post { renderer.drawFrame() }
            }, android.os.Handler(glThread!!.looper))

            Pair(renderer.inputSurface, listOf(renderer.inputSurface, recorderSurface))
        } else {
            dummySurfaceTexture = SurfaceTexture(0).also { it.setDefaultBufferSize(1, 1) }
            val dummy = android.view.Surface(dummySurfaceTexture)
            Pair(dummy, listOf(recorderSurface, dummy))
        }

        // FIX #10: Use non-deprecated createCaptureSession for API 28+ with fallback
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val configs = surfaces.map { surface ->
                android.hardware.camera2.params.OutputConfiguration(surface)
            }
            val sessionConfig = android.hardware.camera2.params.SessionConfiguration(
                android.hardware.camera2.params.SessionConfiguration.SESSION_REGULAR,
                configs,
                mainExecutor,
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) = onSessionConfigured(session, cameraSurface)
                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        Log.e(TAG, "CaptureSession configuration failed"); stopRecording()
                    }
                }
            )
            cameraDevice?.createCaptureSession(sessionConfig)
        } else {
            @Suppress("DEPRECATION")
            cameraDevice?.createCaptureSession(
                surfaces,
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) = onSessionConfigured(session, cameraSurface)
                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        Log.e(TAG, "CaptureSession configuration failed"); stopRecording()
                    }
                },
                cameraHandler
            )
        }
    }

    private fun onSessionConfigured(session: CameraCaptureSession, cameraSurface: android.view.Surface) {
        captureSession = session
        val requestBuilder = cameraDevice!!
            .createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
            .apply {
                addTarget(cameraSurface)
                set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
                set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
            }
        session.setRepeatingRequest(requestBuilder.build(), null, cameraHandler)
        mediaRecorder?.start()
        Log.d(TAG, "CaptureSession configured — MediaRecorder started | GL=$useTimestampOverlay")
    }

    private fun cleanupCamera() {
        try { captureSession?.close()        } catch (e: Exception) { /* ignore */ }
        try { cameraDevice?.close()          } catch (e: Exception) { /* ignore */ }
        try { dummySurfaceTexture?.release() } catch (e: Exception) { /* ignore */ }
        try { glRenderer?.release()          } catch (e: Exception) { /* ignore */ }
        try { glThread?.quitSafely()         } catch (e: Exception) { /* ignore */ }
        captureSession      = null
        cameraDevice        = null
        dummySurfaceTexture = null
        glRenderer          = null
        glThread            = null
        glHandler           = null
    }

    // ─────────────────────────────────────────────────────────────
    // MediaRecorder
    // ─────────────────────────────────────────────────────────────
    @Suppress("DEPRECATION")
    private fun setupMediaRecorder(outputFile: File, settings: AppSettings) {
        val (width, height) = settings.videoWidthHeight
        val bitrate         = settings.videoBitrate

        // FIX #8: Calculate orientation from WindowManager dynamically
        val rotation = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            display?.rotation ?: android.view.Surface.ROTATION_0
        } else {
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation
        }
        val orientationHint = when (rotation) {
            android.view.Surface.ROTATION_0   -> if (settings.cameraFacing == "front") 270 else 90
            android.view.Surface.ROTATION_90  -> if (settings.cameraFacing == "front") 180 else 0
            android.view.Surface.ROTATION_180 -> if (settings.cameraFacing == "front") 90  else 270
            android.view.Surface.ROTATION_270 -> if (settings.cameraFacing == "front") 0   else 180
            else -> 90
        }

        mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            MediaRecorder(this) else MediaRecorder()

        mediaRecorder!!.apply {
            if (settings.audioEnabled) setAudioSource(MediaRecorder.AudioSource.MIC)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            if (settings.audioEnabled) {
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128_000)
                setAudioSamplingRate(44_100)
            }
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setVideoEncodingBitRate(bitrate)
            setVideoFrameRate(30)
            setVideoSize(width, height)
            setOutputFile(outputFile.absolutePath)
            setOrientationHint(orientationHint) // FIX #8: dynamic orientation
            prepare()
        }
        Log.d(TAG, "MediaRecorder prepared → ${width}x${height} @ ${bitrate/1000}kbps | hint=$orientationHint")
    }

    // ─────────────────────────────────────────────────────────────
    // Helpers
    // ─────────────────────────────────────────────────────────────
    private fun createOutputFile(): File {
        val dir = File(getExternalFilesDir(null), "SafeCapture").also { it.mkdirs() }
        val ts  = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        return File(dir, "SC_$ts.mp4")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(recording: Boolean): Notification {
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        else PendingIntent.FLAG_UPDATE_CURRENT

        val openIntent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, RecordingService::class.java).apply { action = ACTION_STOP }, flags
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(if (recording) getString(R.string.notification_recording_title) else getString(R.string.notification_idle_title))
            .setContentText(if (recording) getString(R.string.notification_recording_text) else getString(R.string.notification_idle_text))
            .setSmallIcon(R.drawable.ic_splash_icon)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .apply { if (recording) addAction(0, getString(R.string.stop_recording), stopIntent) }
            .build()
    }

    private fun updateNotification(recording: Boolean) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(recording))
    }

    @Suppress("DEPRECATION")
    private fun vibrateStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 80, 80, 80), -1))
        else vibrator.vibrate(longArrayOf(0, 80, 80, 80), -1)
    }

    @Suppress("DEPRECATION")
    private fun vibrateStop() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            vibrator.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
        else vibrator.vibrate(120)
    }
}
