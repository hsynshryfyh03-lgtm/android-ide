package com.safecapture.app.service

import android.content.Context
import android.util.Log
import androidx.hilt.work.HiltWorker
import androidx.work.*
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first
import com.safecapture.app.data.local.datastore.SettingsDataStore
import com.safecapture.app.domain.repository.RecordingRepository
import java.util.concurrent.TimeUnit

@HiltWorker
class AutoDeleteWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted workerParams: WorkerParameters,
    private val settingsDataStore: SettingsDataStore,
    private val repository: RecordingRepository,
) : CoroutineWorker(context, workerParams) {

    companion object {
        private const val TAG       = "AutoDeleteWorker"
        private const val WORK_NAME = "auto_delete_recordings"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<AutoDeleteWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(1, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).build())
                .addTag(TAG)
                .build()
            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)
            Log.d(TAG, "AutoDeleteWorker scheduled (24h)")
        }
    }

    override suspend fun doWork(): Result {
        val settings = settingsDataStore.settingsFlow.first()

        if (settings.autoDeleteDays <= 0) {
            Log.d(TAG, "Auto-delete disabled — skipping")
            return Result.success()
        }

        val cutoffMs = System.currentTimeMillis() -
                (settings.autoDeleteDays.toLong() * 24 * 60 * 60 * 1000L)

        return try {
            // FIX #12: Use direct DAO deleteOlderThan() instead of loading all recordings into memory
            // This is O(1) DB operation vs O(n) load-all approach
            repository.deleteRecordingsOlderThan(cutoffMs)
            Log.d(TAG, "Auto-delete complete — cutoff: $cutoffMs")
            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "Auto-delete error: ${e.message}")
            Result.retry()
        }
    }
}
