package com.safecapture.app.presentation.ui.home

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.safecapture.app.domain.repository.RecordingRepository
import com.safecapture.app.domain.repository.RecordingStats
import com.safecapture.app.service.RecordingService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val isRecording   : Boolean       = false,
    val elapsedSeconds: Long          = 0L,
    val stats         : RecordingStats = RecordingStats(),
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: RecordingRepository,
    @ApplicationContext private val context: Context,
) : ViewModel() {

    private val _isRecording    = MutableStateFlow(RecordingService.isRecording)
    private val _elapsedSeconds = MutableStateFlow(0L)

    val uiState: StateFlow<HomeUiState> = combine(
        _isRecording,
        _elapsedSeconds,
        repository.getTotalStats()
    ) { recording, elapsed, stats ->
        HomeUiState(recording, elapsed, stats)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUiState())

    // Broadcast receiver to sync with service
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            val recording = intent.getBooleanExtra(RecordingService.EXTRA_IS_RECORDING, false)
            _isRecording.value = recording
            if (!recording) _elapsedSeconds.value = 0L
        }
    }

    init {
        // FIX #2 (CRASH on API<33): Context.RECEIVER_NOT_EXPORTED requires API 33.
        // ContextCompat.registerReceiver() handles the version check automatically.
        ContextCompat.registerReceiver(
            context, receiver,
            IntentFilter(RecordingService.ACTION_TOGGLE),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        startElapsedTimer()
    }

    private fun startElapsedTimer() {
        viewModelScope.launch {
            while (true) {
                if (_isRecording.value) {
                    val startMs = RecordingService.recordingStart
                    if (startMs > 0L) {
                        _elapsedSeconds.value = (System.currentTimeMillis() - startMs) / 1000L
                    }
                }
                delay(1_000)
            }
        }
    }

    fun toggleRecording() {
        RecordingService.toggle(context)
    }

    override fun onCleared() {
        super.onCleared()
        try { context.unregisterReceiver(receiver) } catch (_: Exception) {}
    }
}
