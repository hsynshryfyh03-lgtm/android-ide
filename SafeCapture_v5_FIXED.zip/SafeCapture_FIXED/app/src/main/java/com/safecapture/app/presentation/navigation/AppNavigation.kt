package com.safecapture.app.presentation.navigation

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.safecapture.app.R
import com.safecapture.app.presentation.ui.components.neoBackground
import com.safecapture.app.presentation.ui.components.neoCard
import com.safecapture.app.presentation.ui.home.HomeScreen
import com.safecapture.app.presentation.ui.recordings.RecordingsScreen
import com.safecapture.app.presentation.ui.settings.SettingsScreen
import com.safecapture.app.presentation.ui.theme.NeoColors

sealed class Screen(
    val route: String,
    val labelRes: Int,
    val iconSelected: ImageVector,
    val iconUnselected: ImageVector,
) {
    object Home : Screen(
        "home", R.string.nav_home,
        Icons.Filled.Home, Icons.Outlined.Home
    )
    object Recordings : Screen(
        "recordings", R.string.nav_recordings,
        Icons.Filled.VideoLibrary, Icons.Outlined.VideoLibrary
    )
    object Settings : Screen(
        "settings", R.string.nav_settings,
        Icons.Filled.Settings, Icons.Outlined.Settings
    )
}

private val navItems = listOf(Screen.Home, Screen.Recordings, Screen.Settings)

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val bg = neoBackground()

    Scaffold(
        containerColor = bg,
        bottomBar = {
            NeoBottomBar(
                screens    = navItems,
                currentRoute = navController.currentBackStackEntryAsState().value
                    ?.destination?.route,
                onNavigate = { screen ->
                    navController.navigate(screen.route) {
                        popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                        launchSingleTop = true
                        restoreState    = true
                    }
                }
            )
        }
    ) { innerPadding ->
        NavHost(
            navController    = navController,
            startDestination = Screen.Home.route,
            modifier         = Modifier
                .fillMaxSize()
                .background(bg)
                .padding(innerPadding),
            enterTransition  = { fadeIn(tween(200)) + slideInHorizontally(tween(200)) { it / 8 } },
            exitTransition   = { fadeOut(tween(150)) },
            popEnterTransition  = { fadeIn(tween(200)) },
            popExitTransition   = { fadeOut(tween(150)) + slideOutHorizontally(tween(200)) { it / 8 } },
        ) {
            composable(Screen.Home.route)       { HomeScreen() }
            composable(Screen.Recordings.route) { RecordingsScreen() }
            composable(Screen.Settings.route)   { SettingsScreen() }
        }
    }
}

@Composable
private fun NeoBottomBar(
    screens: List<Screen>,
    currentRoute: String?,
    onNavigate: (Screen) -> Unit,
) {
    val bg = neoBackground()

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(bg)
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(bg)
                .padding(vertical = 8.dp, horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment     = Alignment.CenterVertically,
        ) {
            screens.forEach { screen ->
                val selected = currentRoute == screen.route
                NeoNavItem(
                    screen   = screen,
                    selected = selected,
                    onClick  = { onNavigate(screen) }
                )
            }
        }
    }
}

@Composable
private fun NeoNavItem(
    screen: Screen,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val bgColor  = if (selected) NeoColors.Primary.copy(alpha = 0.12f) else androidx.compose.ui.graphics.Color.Transparent
    val iconColor= if (selected) NeoColors.Primary else NeoColors.TextSecondary

    IconButton(
        onClick  = onClick,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(bgColor)
            .size(52.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector        = if (selected) screen.iconSelected else screen.iconUnselected,
                contentDescription = stringResource(screen.labelRes),
                tint               = iconColor,
                modifier           = Modifier.size(24.dp)
            )
        }
    }
}
