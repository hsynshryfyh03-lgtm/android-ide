package com.safecapture.app.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.util.Log
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.safecapture.app.data.local.datastore.SettingsDataStore
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.collectLatest
import javax.inject.Inject

@AndroidEntryPoint
class VolumeKeyAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "VolumeKeyA11y"
        private const val DEFAULT_DELAY_MS = 600L
    }

    @Inject lateinit var settingsDataStore: SettingsDataStore

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // FIX #15: Cache delay in memory — updated via flow, not re-read on every key press
    @Volatile private var doublePressDelayMs: Long = DEFAULT_DELAY_MS

    private var lastVolumeUpTime = 0L
    private var waitingForSecond = false
    private var resetJob: Job? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "VolumeKeyAccessibilityService connected")

        // FIX #15: Collect settings once and cache — no DataStore read on hot key path
        scope.launch {
            settingsDataStore.settingsFlow.collectLatest { settings ->
                doublePressDelayMs = settings.doublePressDelayMs.toLong()
            }
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_UP) return false
        if (event.action  != KeyEvent.ACTION_DOWN)       return false

        // FIX #15: Use cached value directly — NO coroutine launch, NO DataStore read
        val delayMs = doublePressDelayMs
        val now     = SystemClock.elapsedRealtime()

        if (waitingForSecond && (now - lastVolumeUpTime) <= delayMs) {
            // ── DOUBLE PRESS DETECTED ──
            resetJob?.cancel()
            waitingForSecond = false
            lastVolumeUpTime = 0L
            Log.d(TAG, "Double volume-up — toggling recording")
            RecordingService.toggle(applicationContext)
        } else {
            lastVolumeUpTime = now
            waitingForSecond = true
            resetJob?.cancel()
            resetJob = scope.launch {
                delay(delayMs + 100)
                waitingForSecond = false
                lastVolumeUpTime = 0L
            }
        }

        return false // let system handle volume change normally
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { Log.d(TAG, "Accessibility service interrupted") }

    override fun onUnbind(intent: Intent?): Boolean {
        scope.cancel() // FIX: cancel coroutines
        return super.onUnbind(intent)
    }
}
