package com.safecapture.app.di

import android.content.Context
import androidx.room.Room
import com.safecapture.app.data.local.db.RecordingDao
import com.safecapture.app.data.local.db.SafeCaptureDatabase
import com.safecapture.app.data.repository.RecordingRepositoryImpl
import com.safecapture.app.domain.repository.RecordingRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): SafeCaptureDatabase =
        Room.databaseBuilder(ctx, SafeCaptureDatabase::class.java, "safe_capture.db")
            // FIX #19: fallbackToDestructiveMigration removed — prevents silent data wipe on schema change.
            // Add explicit Migration objects here when bumping DB version:
            // .addMigrations(MIGRATION_1_2)
            // For debug/dev only — comment out in production:
            .fallbackToDestructiveMigrationOnDowngrade()
            .build()

    @Provides
    @Singleton
    fun provideRecordingDao(db: SafeCaptureDatabase): RecordingDao = db.recordingDao()
}

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    @Singleton
    abstract fun bindRecordingRepository(
        impl: RecordingRepositoryImpl
    ): RecordingRepository
}
