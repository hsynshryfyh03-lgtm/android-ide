package com.husseindev.sentinelprotocol.camera

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Environment
import android.os.StatFs
import android.util.Log
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.video.VideoCapture
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.husseindev.sentinelprotocol.camera.analysis.CombinedDetectionAnalyzer
import com.husseindev.sentinelprotocol.core.constants.AppConstants
import com.husseindev.sentinelprotocol.domain.model.*
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.util.Calendar
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import javax.inject.Inject
import javax.inject.Singleton

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Camera Engine
//  برمجة حسين حميد
// ══════════════════════════════════════════

@Singleton
class CameraEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val bufferManager: VideoBufferManager
) {
    private val TAG = "CameraEngine"

    // ── Public state ──────────────────────────────────────────────────────────
    val detectionState   = MutableStateFlow<DetectionResult?>(null)
    val isRecording      = MutableStateFlow(false)
    val monitoringActive = MutableStateFlow(false)
    val fenceAlert       = MutableStateFlow(false)

    // ── Camera internals ──────────────────────────────────────────────────────
    private var cameraProvider   : ProcessCameraProvider? = null
    private var videoCapture     : VideoCapture<Recorder>? = null
    private var activeRecording  : Recording? = null
    private var imageCapture     : ImageCapture? = null

    private val cameraExecutor  : ExecutorService = Executors.newSingleThreadExecutor()
    private val scope           = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // Post-detection stop countdown
    private var postDetectionJob : Job? = null
    private var onRecordingCompleteCb: (File) -> Unit = {}

    // Virtual fence
    private var activeFence = VirtualFence()

    // ── Directories ───────────────────────────────────────────────────────────
    private val outputDir: File get() {
        val d = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "SentinelProtocol")
        if (!d.exists()) d.mkdirs()
        return d
    }

    // ── Night Mode ────────────────────────────────────────────────────────────
    private fun isNightTime(startHour: Int, endHour: Int): Boolean {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return if (startHour > endHour) hour >= startHour || hour < endHour
        else hour in startHour until endHour
    }

    // ── Smart storage-aware quality ───────────────────────────────────────────
    private fun pickQualitySelector(): QualitySelector {
        return try {
            val mb = StatFs(outputDir.path).availableBytes / (1024 * 1024)
            when {
                mb > 1000 -> QualitySelector.fromOrderedList(
                    listOf(Quality.FHD, Quality.HD, Quality.SD),
                    FallbackStrategy.higherQualityOrLowerThan(Quality.SD)
                )
                mb > 500  -> QualitySelector.fromOrderedList(
                    listOf(Quality.HD, Quality.SD),
                    FallbackStrategy.higherQualityOrLowerThan(Quality.SD)
                )
                else      -> QualitySelector.from(Quality.SD)
            }
        } catch (e: Exception) {
            QualitySelector.from(Quality.HD)
        }
    }

    // ── Bind Camera ───────────────────────────────────────────────────────────
    fun bindCamera(
        lifecycleOwner      : LifecycleOwner,
        facing              : CameraFacing     = CameraFacing.BACK,
        sensitivity         : SensitivityLevel = SensitivityLevel.MEDIUM,
        nightModeEnabled    : Boolean          = true,
        nightStartHour      : Int              = 23,
        nightEndHour        : Int              = 6,
        virtualFence        : VirtualFence     = VirtualFence(),
        preview             : Preview?         = null,
        onRecordingComplete : (File) -> Unit   = {}
    ) {
        onRecordingCompleteCb = onRecordingComplete
        activeFence           = virtualFence

        val effectiveSensitivity = if (nightModeEnabled && isNightTime(nightStartHour, nightEndHour)) {
            Log.d(TAG, "Night mode — reducing sensitivity")
            when (sensitivity) {
                SensitivityLevel.HIGH   -> SensitivityLevel.MEDIUM
                SensitivityLevel.MEDIUM -> SensitivityLevel.LOW
                SensitivityLevel.LOW    -> SensitivityLevel.LOW
            }
        } else sensitivity

        ProcessCameraProvider.getInstance(context).addListener({
            try {
                cameraProvider = ProcessCameraProvider.getInstance(context).get()
                val selector = if (facing == CameraFacing.BACK)
                    CameraSelector.DEFAULT_BACK_CAMERA
                else
                    CameraSelector.DEFAULT_FRONT_CAMERA

                videoCapture = VideoCapture.withOutput(
                    Recorder.Builder().setQualitySelector(pickQualitySelector()).build()
                )
                imageCapture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .build()

                // ── FIXED: Single combined analyzer (CameraX only supports ONE ImageAnalysis)
                // Previously two separate ImageAnalysis use cases caused a silent
                // IllegalArgumentException → camera never bound → black screen.
                val combinedAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                    .build().also { ia ->
                        ia.setAnalyzer(cameraExecutor, CombinedDetectionAnalyzer(
                            sensitivity   = effectiveSensitivity,
                            onDetection   = { r -> handleDetection(r) },
                            onNoDetection = { handleNoDetection() }
                        ))
                    }

                cameraProvider?.unbindAll()
                // Max 4 use cases: preview + analysis + video + image capture
                val cases = mutableListOf<UseCase>(
                    combinedAnalysis, videoCapture!!, imageCapture!!
                )
                preview?.let { cases.add(0, it) }
                cameraProvider?.bindToLifecycle(lifecycleOwner, selector, *cases.toTypedArray())
                Log.d(TAG, "Camera bound — $facing | $effectiveSensitivity")

                // ── FIXED: camera is NOW bound, safe to start recording ───────
                // If monitoring was activated before bindCamera (e.g. from service),
                // the recording couldn't start then. Start it now.
                if (monitoringActive.value && !isRecording.value) {
                    Log.d(TAG, "Camera bound with monitoring active — starting recording")
                    startInternalRecording()
                }

            } catch (e: Exception) {
                Log.e(TAG, "Camera bind failed: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(context))
    }

    // ── Detection handling ────────────────────────────────────────────────────
    private fun handleDetection(incoming: DetectionResult) {
        // Merge faces and persons from parallel analyzers
        val current = detectionState.value
        val merged = DetectionResult(
            faces       = if (incoming.faces.isNotEmpty()) incoming.faces
                          else current?.faces ?: emptyList(),
            persons     = if (incoming.persons.isNotEmpty()) incoming.persons
                          else current?.persons ?: emptyList(),
            timestamp   = incoming.timestamp,
            imageWidth  = incoming.imageWidth,
            imageHeight = incoming.imageHeight
        )
        detectionState.value = merged

        // Virtual fence check
        if (activeFence.enabled && merged.imageWidth > 0) {
            val inFence = merged.faces.any { f ->
                activeFence.overlaps(f.boundingBox.left, f.boundingBox.top,
                    f.boundingBox.right, f.boundingBox.bottom,
                    merged.imageWidth, merged.imageHeight)
            } || merged.persons.any { p ->
                activeFence.overlaps(p.boundingBox.left, p.boundingBox.top,
                    p.boundingBox.right, p.boundingBox.bottom,
                    merged.imageWidth, merged.imageHeight)
            }
            fenceAlert.value = inFence
        }

        // ── FIXED: actually start recording when detection happens ────────────
        if (monitoringActive.value && !isRecording.value) {
            Log.d(TAG, "Detection → starting recording")
            startInternalRecording()
        }

        // Reset the post-detection stop countdown
        postDetectionJob?.cancel()
        postDetectionJob = scope.launch {
            delay(AppConstants.POST_DETECTION_SECONDS * 1000L)
            if (isRecording.value) {
                Log.d(TAG, "No detection for ${AppConstants.POST_DETECTION_SECONDS}s — stopping")
                stopAndSaveRecording()
            }
        }
    }

    private fun handleNoDetection() {
        fenceAlert.value = false
        // Post-detection countdown is managed by the launched job above
        // No additional action needed here
    }

    // ── Monitoring activation ─────────────────────────────────────────────────
    fun setMonitoringActive(active: Boolean) {
        monitoringActive.value = active
        Log.d(TAG, "setMonitoringActive($active) — videoCapture=${videoCapture != null}")
        if (active) {
            // Only start recording if camera is already bound
            // If camera isn't bound yet, bindCamera() will start it after binding
            if (videoCapture != null && !isRecording.value) {
                startInternalRecording()
            }
        } else {
            postDetectionJob?.cancel()
            stopRecording()
        }
    }

    // ── Internal recording (monitoring mode) ──────────────────────────────────
    private fun startInternalRecording() {
        val file = createOutputFile(outputDir, "sentinel")
        Log.d(TAG, "Starting internal recording: ${file.name}")
        startRecordingToFile(file) { saved ->
            onRecordingCompleteCb(saved)
            // Auto-restart recording if monitoring still active
            if (monitoringActive.value) {
                scope.launch {
                    delay(500)
                    if (monitoringActive.value && !isRecording.value) {
                        startInternalRecording()
                    }
                }
            }
        }
    }

    private fun stopAndSaveRecording() {
        stopRecording()
    }

    // ── Core recording implementation ─────────────────────────────────────────
    private fun startRecordingToFile(file: File, onFinalized: (File) -> Unit = {}) {
        val vc = videoCapture ?: run {
            Log.w(TAG, "startRecordingToFile: videoCapture is null")
            return
        }
        if (isRecording.value) {
            Log.w(TAG, "startRecordingToFile: already recording")
            return
        }

        val hasAudio = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        val pending = vc.output.prepareRecording(
            context, FileOutputOptions.Builder(file).build()
        )
        if (hasAudio) pending.withAudioEnabled()

        activeRecording = pending.start(cameraExecutor) { event ->
            when (event) {
                is VideoRecordEvent.Start -> {
                    isRecording.value = true
                    Log.d(TAG, "Recording started: ${file.name}")
                }
                is VideoRecordEvent.Finalize -> {
                    isRecording.value = false
                    if (event.hasError()) {
                        Log.e(TAG, "Recording error code: ${event.error}")
                        file.delete()
                    } else {
                        Log.d(TAG, "Recording saved: ${file.name} (${file.length()} bytes)")
                        onFinalized(file)
                    }
                }
                else -> {}
            }
        }
    }

    // ── Public: manual recording (from MonitoringScreen button) ──────────────
    fun startRecording(isEmergency: Boolean = false, onComplete: (File) -> Unit = {}) {
        val file = createOutputFile(outputDir, "sentinel_manual")
        startRecordingToFile(file) { saved -> onComplete(saved) }
    }

    fun stopRecording() {
        activeRecording?.stop()
        activeRecording = null
    }

    // ── Intruder selfie ───────────────────────────────────────────────────────
    fun captureIntruderSelfie(attemptNumber: Int, onCaptured: (File) -> Unit) {
        val ic = imageCapture ?: return
        val dir = File(context.filesDir, AppConstants.INTRUDER_DIR).also { it.mkdirs() }
        val out = File(dir, "intruder_${System.currentTimeMillis()}.jpg")
        ic.takePicture(
            ImageCapture.OutputFileOptions.Builder(out).build(),
            cameraExecutor,
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) = onCaptured(out)
                override fun onError(e: ImageCaptureException) {
                    Log.e(TAG, "Selfie error: ${e.message}")
                }
            }
        )
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    private fun createOutputFile(dir: File, prefix: String): File {
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "${prefix}_${System.currentTimeMillis()}.mp4")
    }

    fun unbind() {
        postDetectionJob?.cancel()
        stopRecording()
        cameraProvider?.unbindAll()
        videoCapture = null
    }

    fun shutdown() {
        unbind()
        cameraExecutor.shutdown()
        scope.cancel()
    }
}
