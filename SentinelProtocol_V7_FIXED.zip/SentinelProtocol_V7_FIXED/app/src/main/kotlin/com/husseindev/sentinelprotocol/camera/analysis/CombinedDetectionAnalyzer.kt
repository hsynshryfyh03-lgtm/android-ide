package com.husseindev.sentinelprotocol.camera.analysis

import android.annotation.SuppressLint
import android.graphics.RectF
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.pose.PoseDetection
import com.google.mlkit.vision.pose.PoseLandmark
import com.google.mlkit.vision.pose.accurate.AccuratePoseDetectorOptions
import com.husseindev.sentinelprotocol.domain.model.*

// ══════════════════════════════════════════
//  SENTINEL PROTOCOL — Combined Analyzer
//  BUG FIX: CameraX only allows ONE ImageAnalysis use case.
//  This class merges Face + Person detection into a single
//  ImageAnalysis, running both ML Kit detectors in parallel
//  on the same frame using Tasks.whenAllComplete().
//  برمجة حسين حميد
// ══════════════════════════════════════════

class CombinedDetectionAnalyzer(
    private val sensitivity   : SensitivityLevel = SensitivityLevel.MEDIUM,
    private val onDetection   : (DetectionResult) -> Unit,
    private val onNoDetection : () -> Unit
) : ImageAnalysis.Analyzer {

    // ── Face Detector ─────────────────────────────────────────────────────────
    private val faceDetector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)
            .setMinFaceSize(when (sensitivity) {
                SensitivityLevel.HIGH   -> 0.06f
                SensitivityLevel.MEDIUM -> 0.10f
                SensitivityLevel.LOW    -> 0.15f
            })
            .enableTracking()
            .build()
    )

    // ── Pose Detector ─────────────────────────────────────────────────────────
    private val poseDetector = PoseDetection.getClient(
        AccuratePoseDetectorOptions.Builder()
            .setDetectorMode(AccuratePoseDetectorOptions.STREAM_MODE)
            .setPreferredHardwareConfigs(AccuratePoseDetectorOptions.CPU_GPU)
            .build()
    )

    private val minPoseConfidence = when (sensitivity) {
        SensitivityLevel.HIGH   -> 0.3f
        SensitivityLevel.MEDIUM -> 0.5f
        SensitivityLevel.LOW    -> 0.7f
    }

    private var frameCount = 0
    private val skipFrames = when (sensitivity) {
        SensitivityLevel.HIGH   -> 2
        SensitivityLevel.MEDIUM -> 3
        SensitivityLevel.LOW    -> 5
    }

    @SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        frameCount++
        if (frameCount % skipFrames != 0) {
            imageProxy.close()
            return
        }

        val mediaImage = imageProxy.image
        if (mediaImage == null) { imageProxy.close(); return }

        val inputImage = InputImage.fromMediaImage(
            mediaImage, imageProxy.imageInfo.rotationDegrees
        )
        val width  = imageProxy.width
        val height = imageProxy.height

        // ── Run both detectors in PARALLEL on the same frame ─────────────────
        val faceTask = faceDetector.process(inputImage)
        val poseTask = poseDetector.process(inputImage)

        Tasks.whenAllComplete(faceTask, poseTask).addOnCompleteListener {
            // ── Faces ─────────────────────────────────────────────────────────
            val detectedFaces: List<DetectedFace> = if (faceTask.isSuccessful) {
                faceTask.result?.map { face ->
                    DetectedFace(
                        boundingBox = RectF(
                            face.boundingBox.left.toFloat(),
                            face.boundingBox.top.toFloat(),
                            face.boundingBox.right.toFloat(),
                            face.boundingBox.bottom.toFloat()
                        ),
                        confidence       = 1.0f,
                        trackingId       = face.trackingId,
                        smileProbability = face.smilingProbability     ?: 0f,
                        leftEyeOpenProb  = face.leftEyeOpenProbability  ?: 0f,
                        rightEyeOpenProb = face.rightEyeOpenProbability ?: 0f,
                        headEulerAngleY  = face.headEulerAngleY
                    )
                } ?: emptyList()
            } else emptyList()

            // ── Persons (Pose landmarks → bounding box) ───────────────────────
            val detectedPersons: List<DetectedPerson> = if (poseTask.isSuccessful) {
                val pose       = poseTask.result
                val landmarks  = pose?.allPoseLandmarks ?: emptyList()
                val confident  = landmarks.filter { it.inFrameLikelihood >= minPoseConfidence }

                if (confident.size >= 4) {
                    val xs      = confident.map { it.position.x }
                    val ys      = confident.map { it.position.y }
                    val avgConf = confident.map { it.inFrameLikelihood }.average().toFloat()

                    val hasUpper = pose?.getPoseLandmark(PoseLandmark.LEFT_SHOULDER)  != null ||
                                   pose?.getPoseLandmark(PoseLandmark.RIGHT_SHOULDER) != null
                    val hasLower = pose?.getPoseLandmark(PoseLandmark.LEFT_HIP)  != null ||
                                   pose?.getPoseLandmark(PoseLandmark.RIGHT_HIP) != null
                    val label = when {
                        hasUpper && hasLower -> "جسم كامل"
                        hasUpper             -> "جذع"
                        else                 -> "شخص"
                    }

                    listOf(DetectedPerson(
                        boundingBox   = RectF(xs.min(), ys.min(), xs.max(), ys.max()),
                        confidence    = avgConf,
                        label         = label,
                        landmarkCount = confident.size
                    ))
                } else emptyList()
            } else emptyList()

            // ── Dispatch result ───────────────────────────────────────────────
            if (detectedFaces.isNotEmpty() || detectedPersons.isNotEmpty()) {
                onDetection(DetectionResult(
                    faces       = detectedFaces,
                    persons     = detectedPersons,
                    timestamp   = System.currentTimeMillis(),
                    imageWidth  = width,
                    imageHeight = height
                ))
            } else {
                onNoDetection()
            }

            imageProxy.close()
        }
    }
}
