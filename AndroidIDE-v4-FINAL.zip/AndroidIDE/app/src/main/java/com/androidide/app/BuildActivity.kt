package com.androidide.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.androidide.app.databinding.ActivityBuildBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class BuildActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBuildBinding
    private val prefs by lazy { getSharedPreferences("build_prefs", Context.MODE_PRIVATE) }

    // Last successful artifact download URL
    private var lastArtifactUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBuildBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = "☁️ Cloud Build — GitHub Actions"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Restore saved settings
        binding.etToken.setText(prefs.getString("token", ""))
        binding.etOwner.setText(prefs.getString("owner", ""))
        binding.etRepo.setText(prefs.getString("repo", ""))
        binding.etBranch.setText(prefs.getString("branch", "main"))

        binding.btnBuild.setOnClickListener { triggerBuild() }
        binding.btnStatus.setOnClickListener { checkStatus() }
        binding.btnOpenGitHub.setOnClickListener { openGitHub() }
        binding.btnDownload.setOnClickListener {
            lastArtifactUrl?.let { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) }
        }

        // Initial hint
        log("═══════════════════════════════════")
        log("  AndroidIDE — Cloud Build Console")
        log("═══════════════════════════════════")
        log("")
        log("📋 كيف يعمل:")
        log("  1. أدخل بياناتك أدناه")
        log("  2. اضغط 'بناء APK' لإرسال طلب البناء")
        log("  3. GitHub Actions يبني APK حقيقي مجاناً ☁️")
        log("  4. اضغط 'فحص الحالة' لمتابعة التقدم")
        log("  5. عند النجاح، حمّل APK مباشرة 📱")
        log("")
        log("💡 تحتاج: GitHub Token بصلاحية 'workflow'")
        log("   settings → Developer settings → Personal access tokens")
        log("")
    }

    private fun savePrefs() {
        prefs.edit()
            .putString("token", binding.etToken.text.toString().trim())
            .putString("owner", binding.etOwner.text.toString().trim())
            .putString("repo",  binding.etRepo.text.toString().trim())
            .putString("branch", binding.etBranch.text.toString().trim().ifEmpty { "main" })
            .apply()
    }

    private fun log(msg: String) {
        runOnUiThread {
            binding.tvLog.append("$msg\n")
            binding.scrollLog.post { binding.scrollLog.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun setLoading(loading: Boolean) {
        runOnUiThread {
            binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
            binding.btnBuild.isEnabled   = !loading
            binding.btnStatus.isEnabled  = !loading
        }
    }

    // ─── Trigger workflow_dispatch ───────────────────────────────────────────
    private fun triggerBuild() {
        val token  = binding.etToken.text.toString().trim()
        val owner  = binding.etOwner.text.toString().trim()
        val repo   = binding.etRepo.text.toString().trim()
        val branch = binding.etBranch.text.toString().trim().ifEmpty { "main" }

        if (token.isEmpty() || owner.isEmpty() || repo.isEmpty()) {
            Toast.makeText(this, "⚠️ يرجى ملء جميع الحقول", Toast.LENGTH_SHORT).show()
            return
        }

        savePrefs()
        setLoading(true)
        log("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        log("🚀 إرسال طلب البناء...")
        log("   Repo: $owner/$repo  Branch: $branch")

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val url = URL("https://api.github.com/repos/$owner/$repo/actions/workflows/build.yml/dispatches")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15_000
                    readTimeout = 15_000
                    setRequestProperty("Authorization", "token $token")
                    setRequestProperty("Accept", "application/vnd.github.v3+json")
                    setRequestProperty("Content-Type", "application/json")
                    doOutput = true
                    outputStream.write("""{"ref":"$branch"}""".toByteArray())
                }

                val code = conn.responseCode
                val errBody = if (code != 204) conn.errorStream?.bufferedReader()?.readText() ?: "" else ""
                conn.disconnect()

                when (code) {
                    204 -> {
                        log("✅ طلب البناء أُرسل بنجاح! (HTTP 204)")
                        log("⏳ GitHub يهيّئ البيئة... (حوالي 30-60 ثانية)")
                        delay(5_000)
                        checkStatus()
                    }
                    401 -> {
                        log("❌ خطأ 401: Token غير صحيح أو منتهي الصلاحية")
                        log("   تأكد من صلاحية 'workflow' في الـ Token")
                        setLoading(false)
                    }
                    404 -> {
                        log("❌ خطأ 404: المستودع غير موجود أو الـ workflow غير منشور")
                        log("   تأكد أن build.yml موجود في .github/workflows/")
                        setLoading(false)
                    }
                    422 -> {
                        log("❌ خطأ 422: الـ branch '$branch' غير موجود")
                        setLoading(false)
                    }
                    else -> {
                        log("❌ خطأ غير متوقع (HTTP $code)")
                        if (errBody.isNotEmpty()) log("   $errBody")
                        setLoading(false)
                    }
                }
            } catch (e: Exception) {
                log("❌ خطأ في الاتصال: ${e.message}")
                log("   تحقق من اتصال الإنترنت")
                setLoading(false)
            }
        }
    }

    // ─── Check latest workflow run status ────────────────────────────────────
    fun checkStatus() {
        val token = binding.etToken.text.toString().trim()
        val owner = binding.etOwner.text.toString().trim()
        val repo  = binding.etRepo.text.toString().trim()

        if (token.isEmpty() || owner.isEmpty() || repo.isEmpty()) {
            Toast.makeText(this, "⚠️ أدخل بيانات الـ Token والمستودع", Toast.LENGTH_SHORT).show()
            return
        }

        setLoading(true)
        log("\n🔍 فحص حالة آخر عملية بناء...")

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val url = URL("https://api.github.com/repos/$owner/$repo/actions/runs?per_page=5&event=workflow_dispatch")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 15_000
                    readTimeout = 15_000
                    setRequestProperty("Authorization", "token $token")
                    setRequestProperty("Accept", "application/vnd.github.v3+json")
                }

                val code = conn.responseCode
                if (code != 200) {
                    val err = conn.errorStream?.bufferedReader()?.readText() ?: "HTTP $code"
                    log("❌ خطأ: $err")
                    setLoading(false)
                    return@launch
                }

                val response = conn.inputStream.bufferedReader().readText()
                conn.disconnect()

                val json = JSONObject(response)
                val runs = json.getJSONArray("workflow_runs")

                if (runs.length() == 0) {
                    log("⚠️ لا توجد عمليات بناء بعد في هذا المستودع")
                    log("   اضغط 'بناء APK' لإطلاق أول عملية بناء")
                    setLoading(false)
                    return@launch
                }

                val run = runs.getJSONObject(0)
                val status     = run.getString("status")
                val conclusion = if (run.isNull("conclusion")) null else run.getString("conclusion")
                val runNumber  = run.getInt("run_number")
                val runId      = run.getLong("id")
                val htmlUrl    = run.getString("html_url")
                val createdAt  = run.getString("created_at").replace("T", " ").replace("Z", " UTC")

                log("")
                log("┌─────────────────────────────────┐")
                log("│  Build #$runNumber")
                log("│  📅 $createdAt")
                log("│  ⚡ ${statusLabel(status)}")
                log("│  🏁 ${conclusionLabel(conclusion)}")
                log("└─────────────────────────────────┘")

                withContext(Dispatchers.Main) {
                    binding.btnOpenGitHub.tag = htmlUrl
                    binding.btnOpenGitHub.visibility = View.VISIBLE
                }

                when {
                    status == "completed" && conclusion == "success" -> {
                        log("")
                        log("🎉 البناء ناجح! جاري جلب الـ APK...")
                        fetchArtifacts(token, owner, repo, runId)
                    }
                    status == "completed" && conclusion == "failure" -> {
                        log("")
                        log("❌ فشل البناء — يرجى مراجعة السجل على GitHub")
                        log("   🔗 $htmlUrl")
                    }
                    status == "in_progress" -> {
                        log("")
                        log("🔄 البناء جارٍ الآن... (~2-4 دقائق)")
                        log("   سيتم التحقق مجدداً بعد 30 ثانية...")
                        delay(30_000)
                        withContext(Dispatchers.Main) { checkStatus() }
                        return@launch
                    }
                    status == "queued" -> {
                        log("")
                        log("⏳ في قائمة الانتظار... سيبدأ قريباً")
                        log("   سيتم التحقق مجدداً بعد 15 ثانية...")
                        delay(15_000)
                        withContext(Dispatchers.Main) { checkStatus() }
                        return@launch
                    }
                    else -> {
                        log("❓ حالة غير معروفة: $status / $conclusion")
                    }
                }

                setLoading(false)

            } catch (e: Exception) {
                log("❌ خطأ: ${e.message}")
                setLoading(false)
            }
        }
    }

    // ─── Fetch artifacts (APK links) ─────────────────────────────────────────
    private suspend fun fetchArtifacts(token: String, owner: String, repo: String, runId: Long) {
        try {
            val url = URL("https://api.github.com/repos/$owner/$repo/actions/runs/$runId/artifacts")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15_000
                readTimeout = 15_000
                setRequestProperty("Authorization", "token $token")
                setRequestProperty("Accept", "application/vnd.github.v3+json")
            }

            val response = conn.inputStream.bufferedReader().readText()
            conn.disconnect()

            val json      = JSONObject(response)
            val artifacts = json.getJSONArray("artifacts")

            if (artifacts.length() == 0) {
                log("⚠️ لم يُنتج البناء أي ملفات APK بعد")
                log("   انتظر قليلاً ثم اضغط 'فحص الحالة' مجدداً")
                return
            }

            log("")
            log("📦 ملفات APK المتاحة:")
            log("─────────────────────────────────")

            for (i in 0 until artifacts.length()) {
                val a       = artifacts.getJSONObject(i)
                val name    = a.getString("name")
                val sizeMB  = a.getLong("size_in_bytes") / 1024.0 / 1024.0
                val dlUrl   = a.getString("archive_download_url")
                log("  📱 $name")
                log("     الحجم: ${"%.1f".format(sizeMB)} MB")

                // Save first artifact (Release preferred)
                if (i == 0 || name.contains("Release", ignoreCase = true)) {
                    lastArtifactUrl = dlUrl
                }
            }

            log("─────────────────────────────────")
            log("⬇️  اضغط 'تحميل APK' للحصول على الملف")
            log("   (سيفتح GitHub لتحميل الملف المضغوط)")

            withContext(Dispatchers.Main) {
                binding.btnDownload.visibility = View.VISIBLE
            }

        } catch (e: Exception) {
            log("❌ خطأ في جلب الـ APK: ${e.message}")
        }
    }

    private fun openGitHub() {
        val url = binding.btnOpenGitHub.tag as? String ?: return
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }

    private fun statusLabel(s: String) = when (s) {
        "completed"   -> "✅ مكتمل"
        "in_progress" -> "🔄 جارٍ..."
        "queued"      -> "⏳ في الانتظار"
        "waiting"     -> "⏸️ معلّق"
        else          -> "❓ $s"
    }

    private fun conclusionLabel(c: String?) = when (c) {
        "success"   -> "🎉 نجاح"
        "failure"   -> "❌ فشل"
        "cancelled" -> "⚪ ملغي"
        "skipped"   -> "⏭️ متخطّى"
        null        -> "— جارٍ..."
        else        -> "❓ $c"
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { onBackPressedDispatcher.onBackPressed(); return true }
        return super.onOptionsItemSelected(item)
    }
}
