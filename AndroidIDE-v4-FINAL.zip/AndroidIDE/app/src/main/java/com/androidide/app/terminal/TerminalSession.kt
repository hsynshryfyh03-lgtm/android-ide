package com.androidide.app.terminal

import android.content.Context
import kotlinx.coroutines.*
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

class TerminalSession(
    private val workDir: File,
    private val onOutput: (String) -> Unit,
    private val context: Context? = null
) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var process: Process? = null
    val commandHistory = mutableListOf<String>()
    private var historyIndex = -1

    // ─── Execute any command ──────────────────────────────────────────────────
    fun execute(command: String) {
        val cmd = command.trim()
        if (cmd.isEmpty()) return

        commandHistory.add(0, cmd)
        if (commandHistory.size > 100) commandHistory.removeLastOrNull()
        historyIndex = -1

        // Handle built-in commands first
        if (handleBuiltIn(cmd)) return

        // Otherwise execute as shell command
        scope.launch {
            try {
                val pb = ProcessBuilder("sh", "-c", cmd)
                    .directory(workDir)
                    .redirectErrorStream(true)

                pb.environment().apply {
                    put("HOME", workDir.absolutePath)
                    put("PATH", "/system/bin:/system/xbin:${System.getenv("PATH") ?: ""}")
                    put("TERM", "xterm-256color")
                    put("ANDROID_DATA", workDir.absolutePath)
                }

                process = pb.start()
                val reader = BufferedReader(InputStreamReader(process!!.inputStream))
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    onOutput(line ?: "")
                }
                val exit = process!!.waitFor()
                if (exit != 0) onOutput("\n✗ Exited with code $exit")
            } catch (e: Exception) {
                onOutput("✗ Error: ${e.message}")
            }
        }
    }

    // ─── Built-in IDE commands ────────────────────────────────────────────────
    private fun handleBuiltIn(cmd: String): Boolean {
        val parts = cmd.split(" ")
        return when (parts[0].lowercase()) {

            "help" -> {
                output("""
╔══════════════════════════════════════════╗
║       AndroidIDE Terminal Commands       ║
╚══════════════════════════════════════════╝

📦 Build Commands:
  build          — فتح لوحة Cloud Build
  build debug    — معلومات بناء Debug APK
  build release  — معلومات بناء Release APK
  clean          — حذف مجلد build المؤقت

📁 File Commands:
  ls [path]      — عرض محتويات المجلد
  tree           — شجرة هيكل المشروع
  cat <file>     — عرض محتويات ملف
  find <name>    — البحث عن ملف
  pwd            — المجلد الحالي
  mkdir <name>   — إنشاء مجلد جديد
  rm <file>      — حذف ملف
  mv <src> <dst> — نقل/إعادة تسمية ملف
  cp <src> <dst> — نسخ ملف

📊 Project Commands:
  info           — معلومات المشروع
  deps           — عرض dependencies
  apk            — البحث عن APK مبني
  manifest       — عرض AndroidManifest
  modules        — عرض modules المشروع

🔧 Git Commands:
  git status     — حالة Git
  git log        — سجل Commits
  git diff       — التغييرات غير المحفوظة

⚙️ System:
  env            — متغيرات البيئة
  date           — التاريخ والوقت
  history        — سجل الأوامر
  clear          — مسح الشاشة
  exit           — إغلاق الطرفية
""".trimIndent())
                true
            }

            "clear", "cls" -> {
                onOutput("\u001b[2J\u001b[H") // ANSI clear
                scope.launch { delay(50); onOutput("CLEAR_SCREEN") }
                true
            }

            "pwd" -> {
                output(workDir.absolutePath)
                true
            }

            "info" -> {
                val buildGradle = File(workDir, "app/build.gradle")
                val appName = workDir.name
                val gradleContent = if (buildGradle.exists()) buildGradle.readText() else ""
                val appId   = Regex("applicationId\\s+[\"'](.*?)[\"']").find(gradleContent)?.groupValues?.get(1) ?: "غير معروف"
                val minSdk  = Regex("minSdk\\s+(\\d+)").find(gradleContent)?.groupValues?.get(1) ?: "?"
                val targetSdk = Regex("targetSdk\\s+(\\d+)").find(gradleContent)?.groupValues?.get(1) ?: "?"
                val version = Regex("versionName\\s+[\"'](.*?)[\"']").find(gradleContent)?.groupValues?.get(1) ?: "?"
                val fileCount = workDir.walkTopDown().filter { it.isFile }.count()
                val srcFiles  = workDir.walkTopDown().filter { it.extension == "kt" || it.extension == "java" }.count()
                output("""
╔══════════════════════════════════════════╗
║         Project Information              ║
╚══════════════════════════════════════════╝
  📱 App Name    : $appName
  📦 Package     : $appId
  🔖 Version     : $version
  🎯 Min SDK     : $minSdk
  📡 Target SDK  : $targetSdk
  📂 Total Files : $fileCount
  📝 Source Files: $srcFiles (.kt/.java)
  📁 Location    : ${workDir.absolutePath}
""".trimIndent())
                true
            }

            "tree" -> {
                output("📁 ${workDir.name}/")
                printTree(workDir, "", 0, 3)
                true
            }

            "ls" -> {
                val target = if (parts.size > 1) File(workDir, parts[1]) else workDir
                if (!target.exists()) { output("❌ المجلد غير موجود: ${parts.getOrNull(1)}"); return true }
                val files = target.listFiles()?.sortedWith(compareBy({ !it.isDirectory }, { it.name })) ?: emptyList()
                if (files.isEmpty()) { output("(المجلد فارغ)"); return true }
                val sb = StringBuilder()
                files.forEach { f ->
                    val icon = if (f.isDirectory) "📁" else fileIcon(f.extension)
                    val size = if (f.isFile) " (${formatSize(f.length())})" else ""
                    sb.appendLine("$icon ${f.name}$size")
                }
                output(sb.toString().trimEnd())
                true
            }

            "cat" -> {
                if (parts.size < 2) { output("الاستخدام: cat <filename>"); return true }
                val file = File(workDir, parts[1])
                if (!file.exists()) { output("❌ الملف غير موجود: ${parts[1]}"); return true }
                if (file.length() > 50_000) { output("⚠️ الملف كبير جداً للعرض (${formatSize(file.length())})"); return true }
                output("─── ${file.name} ─────────────────────")
                output(file.readText())
                output("─────────────────────────────────────")
                true
            }

            "find" -> {
                if (parts.size < 2) { output("الاستخدام: find <filename>"); return true }
                val query = parts[1].lowercase()
                val results = workDir.walkTopDown()
                    .filter { it.isFile && it.name.lowercase().contains(query) }
                    .take(20)
                    .toList()
                if (results.isEmpty()) output("لا توجد نتائج لـ \"${parts[1]}\"")
                else results.forEach { output("  ${it.relativeTo(workDir)}") }
                true
            }

            "deps" -> {
                val buildGradle = File(workDir, "app/build.gradle")
                if (!buildGradle.exists()) { output("❌ لم يُعثر على app/build.gradle"); return true }
                val deps = buildGradle.readText().lines()
                    .filter { it.trim().startsWith("implementation") || it.trim().startsWith("kapt") || it.trim().startsWith("api") }
                    .map { it.trim() }
                output("📦 Dependencies (${deps.size}):")
                output("─────────────────────────────────────")
                deps.forEach { output("  $it") }
                output("─────────────────────────────────────")
                true
            }

            "apk" -> {
                val apkFiles = workDir.walkTopDown()
                    .filter { it.extension == "apk" }
                    .toList()
                if (apkFiles.isEmpty()) {
                    output("⚠️ لا توجد APKs مبنية محلياً.")
                    output("💡 استخدم Cloud Build لبناء APK عبر GitHub Actions")
                } else {
                    output("📱 APK Files Found:")
                    apkFiles.forEach { output("  ✅ ${it.relativeTo(workDir)} — ${formatSize(it.length())}") }
                }
                true
            }

            "manifest" -> {
                val manifest = File(workDir, "app/src/main/AndroidManifest.xml")
                if (!manifest.exists()) { output("❌ AndroidManifest.xml غير موجود"); return true }
                output(manifest.readText())
                true
            }

            "modules" -> {
                val settings = File(workDir, "settings.gradle")
                if (!settings.exists()) { output("❌ settings.gradle غير موجود"); return true }
                val modules = Regex("include\\s+[\"':](.*?)[\"']").findAll(settings.readText())
                    .map { it.groupValues[1].trimStart(':') }.toList()
                output("📦 Project Modules (${modules.size}):")
                modules.forEach { m ->
                    val modDir = File(workDir, m)
                    val hasGradle = File(modDir, "build.gradle").exists()
                    output("  ${if (hasGradle) "✅" else "⚠️"} :$m ${if (hasGradle) "" else "(build.gradle missing)"}")
                }
                true
            }

            "history" -> {
                if (commandHistory.isEmpty()) { output("سجل الأوامر فارغ"); return true }
                output("📜 Command History:")
                commandHistory.take(20).forEachIndexed { i, cmd -> output("  ${i + 1}. $cmd") }
                true
            }

            "build" -> {
                val subCmd = parts.getOrNull(1)?.lowercase()
                when (subCmd) {
                    "debug" -> {
                        output("ℹ️  Debug Build Info:")
                        output("  • applicationIdSuffix: .debug")
                        output("  • versionNameSuffix: -debug")
                        output("  • debuggable: true")
                        output("\n💡 لبناء APK حقيقي → اضغط زر 🚀 'بناء APK' في القائمة")
                    }
                    "release" -> {
                        output("ℹ️  Release Build Info:")
                        output("  • minifyEnabled: true")
                        output("  • shrinkResources: true")
                        output("  • ProGuard: enabled")
                        output("\n💡 لبناء APK حقيقي → اضغط زر 🚀 'بناء APK' في القائمة")
                    }
                    else -> {
                        output("🚀 افتح لوحة Cloud Build من القائمة العلوية")
                        output("   أو استخدم: build debug | build release")
                    }
                }
                true
            }

            "clean" -> {
                val buildDir = File(workDir, "build")
                val appBuildDir = File(workDir, "app/build")
                var cleaned = 0L
                listOf(buildDir, appBuildDir).forEach { d ->
                    if (d.exists()) { cleaned += d.walkTopDown().sumOf { it.length() }; d.deleteRecursively() }
                }
                output("🧹 Cleaned: ${formatSize(cleaned)} freed")
                true
            }

            "date" -> {
                output("📅 ${java.text.SimpleDateFormat("EEEE, dd MMMM yyyy  HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())}")
                true
            }

            "env" -> {
                output("🌍 Environment:")
                output("  HOME = ${workDir.absolutePath}")
                output("  PATH = /system/bin:/system/xbin")
                output("  TERM = xterm-256color")
                output("  ANDROID_SDK_INT = ${android.os.Build.VERSION.SDK_INT}")
                output("  DEVICE = ${android.os.Build.MODEL}")
                true
            }

            "mkdir" -> {
                if (parts.size < 2) { output("الاستخدام: mkdir <name>"); return true }
                val newDir = File(workDir, parts[1])
                if (newDir.mkdirs()) output("✅ تم إنشاء: ${parts[1]}")
                else output("❌ فشل الإنشاء أو المجلد موجود بالفعل")
                true
            }

            "rm" -> {
                if (parts.size < 2) { output("الاستخدام: rm <file>"); return true }
                val target = File(workDir, parts[1])
                if (!target.exists()) { output("❌ غير موجود: ${parts[1]}"); return true }
                if (target.deleteRecursively()) output("✅ تم حذف: ${parts[1]}")
                else output("❌ فشل الحذف")
                true
            }

            "cp" -> {
                if (parts.size < 3) { output("الاستخدام: cp <src> <dst>"); return true }
                val src = File(workDir, parts[1]); val dst = File(workDir, parts[2])
                if (!src.exists()) { output("❌ الملف المصدر غير موجود"); return true }
                src.copyTo(dst, overwrite = true)
                output("✅ تم النسخ: ${parts[1]} → ${parts[2]}")
                true
            }

            "mv" -> {
                if (parts.size < 3) { output("الاستخدام: mv <src> <dst>"); return true }
                val src = File(workDir, parts[1]); val dst = File(workDir, parts[2])
                if (!src.exists()) { output("❌ الملف المصدر غير موجود"); return true }
                if (src.renameTo(dst)) output("✅ تم النقل: ${parts[1]} → ${parts[2]}")
                else output("❌ فشل النقل")
                true
            }

            "exit", "quit" -> {
                output("👋 تم إغلاق الطرفية")
                true
            }

            else -> false // Not a built-in, run as shell command
        }
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────
    private fun output(msg: String) { scope.launch(Dispatchers.Main) { onOutput(msg) } }

    private fun printTree(dir: File, prefix: String, depth: Int, maxDepth: Int) {
        if (depth >= maxDepth) return
        val skip = setOf("build", ".gradle", ".idea", "*.iml", "node_modules", ".git")
        val files = dir.listFiles()
            ?.filter { f -> skip.none { s -> f.name == s || (s.startsWith("*") && f.name.endsWith(s.drop(1))) } }
            ?.sortedWith(compareBy({ !it.isDirectory }, { it.name }))
            ?: return

        files.forEachIndexed { i, f ->
            val isLast  = i == files.lastIndex
            val connector = if (isLast) "└── " else "├── "
            val icon = if (f.isDirectory) "📁" else fileIcon(f.extension)
            output("$prefix$connector$icon ${f.name}")
            if (f.isDirectory) {
                val newPrefix = prefix + if (isLast) "    " else "│   "
                printTree(f, newPrefix, depth + 1, maxDepth)
            }
        }
    }

    private fun fileIcon(ext: String) = when (ext.lowercase()) {
        "kt"    -> "🟣"
        "java"  -> "☕"
        "xml"   -> "📄"
        "gradle", "kts" -> "🐘"
        "json"  -> "📋"
        "md"    -> "📝"
        "png", "jpg", "webp" -> "🖼️"
        "apk"   -> "📱"
        "aar"   -> "📦"
        "pro"   -> "🔒"
        "sh"    -> "⚙️"
        else    -> "📄"
    }

    private fun formatSize(bytes: Long): String = when {
        bytes < 1024         -> "${bytes}B"
        bytes < 1024 * 1024  -> "${"%.1f".format(bytes / 1024.0)}KB"
        else                 -> "${"%.1f".format(bytes / 1024.0 / 1024.0)}MB"
    }

    fun previousCommand(): String? {
        if (commandHistory.isEmpty()) return null
        historyIndex = (historyIndex + 1).coerceAtMost(commandHistory.lastIndex)
        return commandHistory.getOrNull(historyIndex)
    }

    fun nextCommand(): String? {
        if (historyIndex <= 0) { historyIndex = -1; return "" }
        historyIndex--
        return commandHistory.getOrNull(historyIndex)
    }

    fun destroy() { process?.destroy(); scope.cancel() }
}
