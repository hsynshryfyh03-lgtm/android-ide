package com.androidide.app.utils

import android.content.Context
import java.io.File

// ─── Project Templates ────────────────────────────────────────────────────────
enum class ProjectTemplate(val displayName: String, val description: String) {
    EMPTY_ACTIVITY    ("Empty Activity",            "شاشة فارغة — نقطة البداية"),
    BASIC_VIEWS       ("Basic Views",               "TextView + EditText + Button"),
    LOGIN_SCREEN      ("Login Screen",              "شاشة تسجيل دخول جاهزة"),
    RECYCLERVIEW      ("RecyclerView App",          "قائمة عناصر قابلة للتمرير"),
    BOTTOM_NAV        ("Bottom Navigation",         "تنقل سفلي بـ 3 تبويبات"),
    MVVM_CLEAN        ("MVVM + Clean Architecture", "ViewModel + LiveData + Repository"),
    COMPOSE_APP       ("Jetpack Compose App",       "واجهة حديثة بـ Compose"),
    MULTI_MODULE      ("Multi-Module Project",      "app + core + data modules"),
    WEAR_OS           ("Wear OS App",               "تطبيق ساعة Android"),
    TV_APP            ("Android TV App",            "تطبيق شاشة تلفاز"),
    GAME_CANVAS       ("Game (Canvas 2D)",          "لعبة ثنائية الأبعاد"),
    WIDGET_APP        ("Home Screen Widget",        "ودجت الشاشة الرئيسية"),
    SERVICE_APP       ("Background Service",        "خدمة خلفية + إشعارات"),
    LIBRARY_AAR       ("Android Library (.aar)",    "مكتبة Android قابلة للنشر")
}

// ─── Libraries ────────────────────────────────────────────────────────────────
enum class AndroidLibrary(
    val displayName: String,
    val category: String,
    val dependency: String,
    val extraPlugins: String = "",
    val extraAndroidConfig: String = "",
    val kapt: String = ""
) {
    RETROFIT(
        "Retrofit 2 — طلبات الشبكة", "🌐 شبكة",
        "    implementation 'com.squareup.retrofit2:retrofit:2.9.0'\n    implementation 'com.squareup.retrofit2:converter-gson:2.9.0'\n    implementation 'com.squareup.okhttp3:okhttp:4.12.0'\n    implementation 'com.squareup.okhttp3:logging-interceptor:4.12.0'"
    ),
    GLIDE(
        "Glide — تحميل الصور", "🖼️ صور",
        "    implementation 'com.github.bumptech.glide:glide:4.16.0'",
        kapt = "    kapt 'com.github.bumptech.glide:compiler:4.16.0'"
    ),
    COIL(
        "Coil — تحميل الصور (Kotlin)", "🖼️ صور",
        "    implementation 'io.coil-kt:coil:2.5.0'"
    ),
    ROOM(
        "Room — قاعدة بيانات محلية", "🗄️ قاعدة بيانات",
        "    implementation 'androidx.room:room-runtime:2.6.1'\n    implementation 'androidx.room:room-ktx:2.6.1'",
        kapt = "    kapt 'androidx.room:room-compiler:2.6.1'"
    ),
    HILT(
        "Hilt — Dependency Injection", "⚙️ معمارية",
        "    implementation 'com.google.dagger:hilt-android:2.50'",
        extraPlugins = "    id 'com.google.dagger.hilt.android'",
        kapt = "    kapt 'com.google.dagger:hilt-android-compiler:2.50'"
    ),
    VIEWMODEL(
        "ViewModel + LiveData", "⚙️ معمارية",
        "    implementation 'androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0'\n    implementation 'androidx.lifecycle:lifecycle-livedata-ktx:2.7.0'\n    implementation 'androidx.lifecycle:lifecycle-runtime-ktx:2.7.0'"
    ),
    NAVIGATION(
        "Navigation Component", "🧭 تنقل",
        "    implementation 'androidx.navigation:navigation-fragment-ktx:2.7.6'\n    implementation 'androidx.navigation:navigation-ui-ktx:2.7.6'"
    ),
    DATASTORE(
        "DataStore — تخزين البيانات", "🗄️ قاعدة بيانات",
        "    implementation 'androidx.datastore:datastore-preferences:1.0.0'"
    ),
    COMPOSE(
        "Jetpack Compose — واجهة حديثة", "🎨 واجهة",
        "    implementation platform('androidx.compose:compose-bom:2024.01.00')\n    implementation 'androidx.compose.ui:ui'\n    implementation 'androidx.compose.material3:material3'\n    implementation 'androidx.activity:activity-compose:1.8.2'\n    debugImplementation 'androidx.compose.ui:ui-tooling'",
        extraPlugins = "    id 'kotlin-kapt'",
        extraAndroidConfig = "    buildFeatures { compose true }\n    composeOptions { kotlinCompilerExtensionVersion '1.5.8' }"
    ),
    COROUTINES(
        "Coroutines — البرمجة المتزامنة", "⚙️ معمارية",
        "    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3'\n    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3'"
    ),
    FIREBASE_AUTH(
        "Firebase Authentication", "🔥 Firebase",
        "    implementation platform('com.google.firebase:firebase-bom:32.7.0')\n    implementation 'com.google.firebase:firebase-auth'",
        extraPlugins = "    id 'com.google.gms.google-services'"
    ),
    FIREBASE_FIRESTORE(
        "Firebase Firestore", "🔥 Firebase",
        "    implementation platform('com.google.firebase:firebase-bom:32.7.0')\n    implementation 'com.google.firebase:firebase-firestore'",
        extraPlugins = "    id 'com.google.gms.google-services'"
    ),
    FIREBASE_FCM(
        "Firebase Cloud Messaging", "🔥 Firebase",
        "    implementation platform('com.google.firebase:firebase-bom:32.7.0')\n    implementation 'com.google.firebase:firebase-messaging'",
        extraPlugins = "    id 'com.google.gms.google-services'"
    ),
    GSON(
        "Gson — تحليل JSON", "🔧 أدوات",
        "    implementation 'com.google.code.gson:gson:2.10.1'"
    ),
    LOTTIE(
        "Lottie — الرسوم المتحركة", "🎨 واجهة",
        "    implementation 'com.airbnb.android:lottie:6.3.0'"
    ),
    SPLASHSCREEN(
        "SplashScreen API", "🎨 واجهة",
        "    implementation 'androidx.core:core-splashscreen:1.0.1'"
    ),
    PAGING(
        "Paging 3 — تحميل تدريجي", "⚙️ معمارية",
        "    implementation 'androidx.paging:paging-runtime:3.2.1'"
    ),
    WORK_MANAGER(
        "WorkManager — مهام خلفية", "⚙️ معمارية",
        "    implementation 'androidx.work:work-runtime-ktx:2.9.0'"
    ),
    MAPS(
        "Google Maps SDK", "🗺️ خرائط",
        "    implementation 'com.google.android.gms:play-services-maps:18.2.0'\n    implementation 'com.google.android.gms:play-services-location:21.1.0'"
    )
}

// ─── Project Manager ──────────────────────────────────────────────────────────
class ProjectManager(private val context: Context) {

    private val projectsRoot = File(context.getExternalFilesDir(null), "Projects").also { it.mkdirs() }

    fun getAllProjects(): List<File> =
        projectsRoot.listFiles { f -> f.isDirectory }?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun deleteProject(project: File): Boolean = project.deleteRecursively()

    fun createProject(
        name: String,
        packageName: String,
        template: ProjectTemplate,
        libraries: Set<AndroidLibrary> = emptySet()
    ): File? = try {
        val dir = File(projectsRoot, name).also { it.mkdirs() }
        when (template) {
            ProjectTemplate.MULTI_MODULE -> generateMultiModuleProject(dir, name, packageName, libraries)
            ProjectTemplate.LIBRARY_AAR  -> generateLibraryProject(dir, name, packageName)
            else                         -> generateAppProject(dir, name, packageName, packageName.replace('.', '/'), template, libraries)
        }
        dir
    } catch (e: Exception) { e.printStackTrace(); null }

    // ═══════════════════════════════════════════════════════════════
    // STANDARD APP PROJECT
    // ═══════════════════════════════════════════════════════════════
    private fun generateAppProject(dir: File, name: String, pkg: String, pkgPath: String, template: ProjectTemplate, libs: Set<AndroidLibrary>) {
        val needsHilt     = AndroidLibrary.HILT in libs
        val needsFirebase = libs.any { it.name.startsWith("FIREBASE") }
        val needsKapt     = libs.any { it.kapt.isNotEmpty() }
        val isCompose     = template == ProjectTemplate.COMPOSE_APP || AndroidLibrary.COMPOSE in libs
        val isWear        = template == ProjectTemplate.WEAR_OS
        val isTV          = template == ProjectTemplate.TV_APP

        // ── Root files ──
        writeFile(dir, "settings.gradle", "rootProject.name = \"$name\"\ninclude ':app'")
        val rootClasspath = buildString {
            append("classpath 'com.android.tools.build:gradle:8.2.2'\n        classpath 'org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.22'")
            if (needsHilt)     append("\n        classpath 'com.google.dagger:hilt-android-gradle-plugin:2.50'")
            if (needsFirebase) append("\n        classpath 'com.google.gms:google-services:4.4.0'")
        }
        writeFile(dir, "build.gradle", "buildscript {\n    repositories { google(); mavenCentral() }\n    dependencies { $rootClasspath }\n}\nallprojects { repositories { google(); mavenCentral() } }")
        writeFile(dir, "gradle.properties", "org.gradle.jvmargs=-Xmx2048m\nandroid.useAndroidX=true\nkotlin.code.style=official")
        writeFile(dir, "gradle/wrapper/gradle-wrapper.properties", "distributionBase=GRADLE_USER_HOME\ndistributionPath=wrapper/dists\ndistributionUrl=https\\://services.gradle.org/distributions/gradle-8.4-bin.zip\nzipStoreBase=GRADLE_USER_HOME\nzipStorePath=wrapper/dists")

        // ── App build.gradle ──
        val extraPlugins = buildString {
            if (needsKapt || isCompose) append("    id 'kotlin-kapt'\n")
            libs.filter { it.extraPlugins.isNotEmpty() }.map { it.extraPlugins }.toSet().forEach { append("$it\n") }
        }.trimEnd()
        val extraAndroid = libs.filter { it.extraAndroidConfig.isNotEmpty() }.joinToString("\n    ") { it.extraAndroidConfig }
        val composeAndroid = if (isCompose && AndroidLibrary.COMPOSE !in libs)
            "\n    buildFeatures { compose true }\n    composeOptions { kotlinCompilerExtensionVersion '1.5.8' }" else ""

        val minSdk = when { isWear -> "26"; isTV -> "21"; else -> "24" }
        val appType = when { isWear -> "com.android.application\"\n    id \"com.android.wear"; isTV -> "com.android.application"; else -> "com.android.application" }

        val baseDeps = buildString {
            when {
                isWear -> {
                    append("    implementation 'androidx.wear:wear:1.3.0'\n")
                    append("    implementation 'com.google.android.gms:play-services-wearable:18.1.0'\n")
                    append("    implementation 'androidx.wear.compose:compose-material:1.3.0'\n")
                    append("    implementation 'androidx.wear.compose:compose-foundation:1.3.0'\n")
                    append("    implementation 'androidx.activity:activity-compose:1.8.2'\n")
                    append("    implementation platform('androidx.compose:compose-bom:2024.01.00')\n")
                    append("    implementation 'androidx.compose.ui:ui'\n")
                    append("    implementation 'androidx.compose.material3:material3'\n")
                }
                isTV -> {
                    append("    implementation 'androidx.leanback:leanback:1.2.0'\n")
                    append("    implementation 'androidx.core:core-ktx:1.12.0'\n")
                    append("    implementation 'androidx.appcompat:appcompat:1.6.1'\n")
                    append("    implementation 'com.github.bumptech.glide:glide:4.16.0'\n")
                }
                isCompose -> {
                    append("    implementation 'androidx.core:core-ktx:1.12.0'\n")
                    append("    implementation 'androidx.lifecycle:lifecycle-runtime-ktx:2.7.0'\n")
                    append("    implementation 'androidx.activity:activity-compose:1.8.2'\n")
                    append("    implementation platform('androidx.compose:compose-bom:2024.01.00')\n")
                    append("    implementation 'androidx.compose.ui:ui'\n")
                    append("    implementation 'androidx.compose.ui:ui-graphics'\n")
                    append("    implementation 'androidx.compose.ui:ui-tooling-preview'\n")
                    append("    implementation 'androidx.compose.material3:material3'\n")
                    append("    implementation 'androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0'\n")
                    append("    debugImplementation 'androidx.compose.ui:ui-tooling'\n")
                    append("    debugImplementation 'androidx.compose.ui:ui-test-manifest'\n")
                }
                else -> {
                    append("    implementation 'androidx.core:core-ktx:1.12.0'\n")
                    append("    implementation 'androidx.appcompat:appcompat:1.6.1'\n")
                    append("    implementation 'com.google.android.material:material:1.11.0'\n")
                    append("    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'\n")
                    append("    implementation 'androidx.activity:activity-ktx:1.8.2'\n")
                }
            }
            libs.forEach { append("${it.dependency}\n") }
            libs.filter { it.kapt.isNotEmpty() }.forEach { append("${it.kapt}\n") }
            append("    testImplementation 'junit:junit:4.13.2'\n")
            append("    androidTestImplementation 'androidx.test.ext:junit:1.1.5'")
        }

        val flavorsBlock = when (template) {
            ProjectTemplate.GAME_CANVAS -> """
    flavorDimensions "version"
    productFlavors {
        free { dimension "version"; applicationIdSuffix ".free"; versionNameSuffix "-free" }
        paid { dimension "version"; applicationIdSuffix ".paid"; versionNameSuffix "-paid" }
    }"""
            else -> ""
        }

        writeFile(dir, "app/build.gradle", """
plugins {
    id 'com.android.application'
    id 'kotlin-android'
${if (extraPlugins.isNotEmpty()) "$extraPlugins" else ""}}

android {
    namespace '$pkg'
    compileSdk 34
    defaultConfig {
        applicationId "$pkg"
        minSdk $minSdk
        targetSdk 34
        versionCode 1
        versionName "1.0"
    }
    buildTypes {
        debug   { applicationIdSuffix ".debug"; versionNameSuffix "-debug" }
        release { minifyEnabled true; shrinkResources true; proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro' }
    }
    compileOptions { sourceCompatibility JavaVersion.VERSION_17; targetCompatibility JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = '17' }
    buildFeatures { viewBinding ${if (!isCompose) "true" else "false"}; buildConfig true }
    ${if (extraAndroid.isNotEmpty()) extraAndroid else ""}$composeAndroid$flavorsBlock
}

dependencies {
$baseDeps
}""".trim())

        // ── AndroidManifest ──
        val hiltApp  = if (needsHilt) "\n        android:name=\".App\"" else ""
        val tvFeature = if (isTV) "\n    <uses-feature android:name=\"android.software.leanback\" android:required=\"true\"/>\n    <uses-feature android:name=\"android.hardware.touchscreen\" android:required=\"false\"/>" else ""
        val wearFeature = if (isWear) "\n    <uses-feature android:name=\"android.hardware.type.watch\"/>" else ""
        val internetPerm = if (libs.any { it.name.startsWith("FIREBASE") || it == AndroidLibrary.RETROFIT || it == AndroidLibrary.MAPS }) "\n    <uses-permission android:name=\"android.permission.INTERNET\"/>" else ""
        val locationPerm = if (AndroidLibrary.MAPS in libs) "\n    <uses-permission android:name=\"android.permission.ACCESS_FINE_LOCATION\"/>" else ""
        val theme = when { isTV -> "@style/Theme.Leanback"; isWear -> "@android:style/Theme.DeviceDefault"; else -> "@style/Theme.$name" }
        val activityAttr = when { isTV -> "\n            android:banner=\"@mipmap/ic_launcher\""; else -> "" }
        val extraManifestActivities = generateExtraActivities(template, pkg)
        val extraServices = generateServices(template, pkg, dir, pkgPath)

        writeFile(dir, "app/src/main/AndroidManifest.xml", """
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">$internetPerm$locationPerm$tvFeature$wearFeature
    <application
        android:allowBackup="true"
        android:label="$name"$hiltApp
        android:supportsRtl="true"
        android:theme="$theme">
        <activity android:name=".MainActivity"$activityAttr android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
                <category android:name="android.intent.category.LAUNCHER"/>
                ${if (isTV) "<category android:name=\"android.intent.category.LEANBACK_LAUNCHER\"/>" else ""}
            </intent-filter>
        </activity>$extraManifestActivities
    </application>
</manifest>""".trim())

        // ── Hilt App ──
        if (needsHilt) writeFile(dir, "app/src/main/java/$pkgPath/App.kt",
            "package $pkg\nimport android.app.Application\nimport dagger.hilt.android.HiltAndroidApp\n\n@HiltAndroidApp\nclass App : Application()")

        // ── MainActivity ──
        writeFile(dir, "app/src/main/java/$pkgPath/MainActivity.kt", generateMainActivity(pkg, pkgPath, template, libs, needsHilt))

        // ── Extra source files ──
        generateExtraSourceFiles(dir, pkg, pkgPath, template, libs)

        // ── Layout ──
        if (!isCompose && template != ProjectTemplate.WEAR_OS) {
            writeFile(dir, "app/src/main/res/layout/activity_main.xml", generateLayout(template))
        }

        // ── Resources ──
        writeFile(dir, "app/src/main/res/values/strings.xml", "<resources>\n    <string name=\"app_name\">$name</string>\n</resources>")
        writeFile(dir, "app/src/main/res/values/colors.xml", "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n    <color name=\"purple_500\">#FF6200EE</color>\n    <color name=\"purple_700\">#FF3700B3</color>\n    <color name=\"teal_200\">#FF03DAC5</color>\n    <color name=\"white\">#FFFFFFFF</color>\n    <color name=\"black\">#FF000000</color>\n</resources>")

        val parentTheme = when { isTV -> "Theme.AppCompat.Leanback"; else -> "Theme.MaterialComponents.DayNight.DarkActionBar" }
        writeFile(dir, "app/src/main/res/values/themes.xml", "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n    <style name=\"Theme.$name\" parent=\"$parentTheme\">\n        <item name=\"colorPrimary\">#6200EE</item>\n        <item name=\"colorPrimaryVariant\">#3700B3</item>\n        <item name=\"colorOnPrimary\">#FFFFFF</item>\n    </style>\n</resources>")
        writeFile(dir, "app/proguard-rules.pro", "# Add project specific ProGuard rules here.")
        writeFile(dir, "README.md", generateReadme(name, pkg, template, libs))
    }

    // ═══════════════════════════════════════════════════════════════
    // MULTI-MODULE PROJECT
    // ═══════════════════════════════════════════════════════════════
    private fun generateMultiModuleProject(dir: File, name: String, pkg: String, libs: Set<AndroidLibrary>) {
        val pkgPath = pkg.replace('.', '/')
        writeFile(dir, "settings.gradle", "rootProject.name = \"$name\"\ninclude ':app'\ninclude ':core'\ninclude ':data'")
        writeFile(dir, "build.gradle", """
buildscript {
    ext { kotlin_version = '1.9.22'; agp_version = '8.2.2' }
    repositories { google(); mavenCentral() }
    dependencies {
        classpath "com.android.tools.build:gradle:\$agp_version"
        classpath "org.jetbrains.kotlin:kotlin-gradle-plugin:\$kotlin_version"
    }
}
allprojects { repositories { google(); mavenCentral() } }""".trim())
        writeFile(dir, "gradle.properties", "org.gradle.jvmargs=-Xmx2048m\nandroid.useAndroidX=true\nkotlin.code.style=official")
        writeFile(dir, "gradle/wrapper/gradle-wrapper.properties", "distributionBase=GRADLE_USER_HOME\ndistributionPath=wrapper/dists\ndistributionUrl=https\\://services.gradle.org/distributions/gradle-8.4-bin.zip\nzipStoreBase=GRADLE_USER_HOME\nzipStorePath=wrapper/dists")

        // ── :app module ──
        writeFile(dir, "app/build.gradle", """
plugins { id 'com.android.application'; id 'kotlin-android' }
android {
    namespace '$pkg'
    compileSdk 34
    defaultConfig { applicationId "$pkg"; minSdk 24; targetSdk 34; versionCode 1; versionName "1.0" }
    buildTypes {
        debug { applicationIdSuffix ".debug" }
        release { minifyEnabled true; proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro' }
    }
    compileOptions { sourceCompatibility JavaVersion.VERSION_17; targetCompatibility JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = '17' }
    buildFeatures { viewBinding true }
}
dependencies {
    implementation project(':core')
    implementation project(':data')
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
    implementation 'androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0'
    implementation 'androidx.lifecycle:lifecycle-livedata-ktx:2.7.0'
}""".trim())

        // ── :core module ──
        writeFile(dir, "core/build.gradle", """
plugins { id 'com.android.library'; id 'kotlin-android' }
android {
    namespace '$pkg.core'
    compileSdk 34
    defaultConfig { minSdk 24; consumerProguardFiles "consumer-rules.pro" }
    compileOptions { sourceCompatibility JavaVersion.VERSION_17; targetCompatibility JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = '17' }
}
dependencies {
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3'
}""".trim())

        // ── :data module ──
        writeFile(dir, "data/build.gradle", """
plugins { id 'com.android.library'; id 'kotlin-android'; id 'kotlin-kapt' }
android {
    namespace '$pkg.data'
    compileSdk 34
    defaultConfig { minSdk 24; consumerProguardFiles "consumer-rules.pro" }
    compileOptions { sourceCompatibility JavaVersion.VERSION_17; targetCompatibility JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = '17' }
}
dependencies {
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.room:room-runtime:2.6.1'
    implementation 'androidx.room:room-ktx:2.6.1'
    kapt 'androidx.room:room-compiler:2.6.1'
    implementation 'com.squareup.retrofit2:retrofit:2.9.0'
    implementation 'com.squareup.retrofit2:converter-gson:2.9.0'
    implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3'
}""".trim())

        // ── Source files ──
        writeFile(dir, "app/src/main/AndroidManifest.xml", "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\">\n    <uses-permission android:name=\"android.permission.INTERNET\"/>\n    <application android:allowBackup=\"true\" android:label=\"$name\" android:supportsRtl=\"true\" android:theme=\"@style/Theme.AppCompat.Light.DarkActionBar\">\n        <activity android:name=\".MainActivity\" android:exported=\"true\">\n            <intent-filter>\n                <action android:name=\"android.intent.action.MAIN\"/>\n                <category android:name=\"android.intent.category.LAUNCHER\"/>\n            </intent-filter>\n        </activity>\n    </application>\n</manifest>")
        writeFile(dir, "app/src/main/java/$pkgPath/MainActivity.kt", "package $pkg\n\nimport androidx.appcompat.app.AppCompatActivity\nimport android.os.Bundle\nimport androidx.activity.viewModels\nimport $pkg.databinding.ActivityMainBinding\n\nclass MainActivity : AppCompatActivity() {\n    private lateinit var binding: ActivityMainBinding\n\n    override fun onCreate(savedInstanceState: Bundle?) {\n        super.onCreate(savedInstanceState)\n        binding = ActivityMainBinding.inflate(layoutInflater)\n        setContentView(binding.root)\n    }\n}")
        writeFile(dir, "app/src/main/res/layout/activity_main.xml", "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<FrameLayout xmlns:android=\"http://schemas.android.com/apk/res/android\" android:layout_width=\"match_parent\" android:layout_height=\"match_parent\">\n    <TextView android:layout_width=\"wrap_content\" android:layout_height=\"wrap_content\" android:layout_gravity=\"center\" android:text=\"Multi-Module App\" android:textSize=\"24sp\"/>\n</FrameLayout>")
        writeFile(dir, "app/src/main/res/values/strings.xml", "<resources><string name=\"app_name\">$name</string></resources>")
        writeFile(dir, "core/src/main/AndroidManifest.xml", "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\"/>")
        writeFile(dir, "core/src/main/java/$pkgPath/core/Result.kt", "package $pkg.core\n\nsealed class Result<out T> {\n    data class Success<T>(val data: T) : Result<T>()\n    data class Error(val exception: Exception) : Result<Nothing>()\n    object Loading : Result<Nothing>()\n}\n\ninline fun <T> Result<T>.onSuccess(action: (T) -> Unit): Result<T> { if (this is Result.Success) action(data); return this }\ninline fun <T> Result<T>.onError(action: (Exception) -> Unit): Result<T> { if (this is Result.Error) action(exception); return this }")
        writeFile(dir, "core/src/main/java/$pkgPath/core/Extensions.kt", "package $pkg.core\n\nimport kotlinx.coroutines.Dispatchers\nimport kotlinx.coroutines.withContext\n\nsuspend fun <T> ioDispatcher(block: suspend () -> T): T = withContext(Dispatchers.IO) { block() }")
        writeFile(dir, "data/src/main/AndroidManifest.xml", "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\"/>")
        writeFile(dir, "data/src/main/java/$pkgPath/data/local/AppDatabase.kt", "package $pkg.data.local\n\nimport androidx.room.*\nimport android.content.Context\n\n@Database(entities = [], version = 1, exportSchema = false)\nabstract class AppDatabase : RoomDatabase() {\n    companion object {\n        @Volatile private var INSTANCE: AppDatabase? = null\n        fun getInstance(context: Context): AppDatabase =\n            INSTANCE ?: synchronized(this) { Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, \"app_db\").build().also { INSTANCE = it } }\n    }\n}")
        writeFile(dir, "data/src/main/java/$pkgPath/data/remote/ApiService.kt", "package $pkg.data.remote\n\nimport retrofit2.http.GET\n\ninterface ApiService {\n    @GET(\"posts\")\n    suspend fun getPosts(): List<Any>\n}")
        writeFile(dir, "README.md", "# $name — Multi-Module\n\nهيكل المشروع:\n- `:app` — طبقة العرض (UI)\n- `:core` — الأدوات والـ utilities المشتركة\n- `:data` — قاعدة البيانات (Room) + الشبكة (Retrofit)")
    }

    // ═══════════════════════════════════════════════════════════════
    // LIBRARY PROJECT
    // ═══════════════════════════════════════════════════════════════
    private fun generateLibraryProject(dir: File, name: String, pkg: String) {
        val pkgPath = pkg.replace('.', '/')
        writeFile(dir, "settings.gradle", "rootProject.name = \"$name\"\ninclude ':library'")
        writeFile(dir, "build.gradle", "buildscript {\n    repositories { google(); mavenCentral() }\n    dependencies { classpath 'com.android.tools.build:gradle:8.2.2'; classpath 'org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.22' }\n}\nallprojects { repositories { google(); mavenCentral() } }")
        writeFile(dir, "gradle.properties", "org.gradle.jvmargs=-Xmx2048m\nandroid.useAndroidX=true\nkotlin.code.style=official")
        writeFile(dir, "gradle/wrapper/gradle-wrapper.properties", "distributionBase=GRADLE_USER_HOME\ndistributionPath=wrapper/dists\ndistributionUrl=https\\://services.gradle.org/distributions/gradle-8.4-bin.zip\nzipStoreBase=GRADLE_USER_HOME\nzipStorePath=wrapper/dists")
        writeFile(dir, "library/build.gradle", "plugins { id 'com.android.library'; id 'kotlin-android'; id 'maven-publish' }\n\nandroid {\n    namespace '$pkg'\n    compileSdk 34\n    defaultConfig { minSdk 21; consumerProguardFiles \"consumer-rules.pro\" }\n    compileOptions { sourceCompatibility JavaVersion.VERSION_17; targetCompatibility JavaVersion.VERSION_17 }\n    kotlinOptions { jvmTarget = '17' }\n    publishing { singleVariant('release') { withSourcesJar() } }\n}\n\nafterevaluate {\n    publishing {\n        publications {\n            release(MavenPublication) {\n                from components.release\n                groupId = '$pkg'\n                artifactId = '${name.lowercase()}'\n                version = '1.0.0'\n            }\n        }\n    }\n}\n\ndependencies {\n    implementation 'androidx.core:core-ktx:1.12.0'\n    testImplementation 'junit:junit:4.13.2'\n}")
        writeFile(dir, "library/src/main/AndroidManifest.xml", "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\"/>")
        writeFile(dir, "library/src/main/java/$pkgPath/${name}Library.kt", "package $pkg\n\n/**\n * ${name} Android Library\n * \n * Usage:\n * ```kotlin\n * val lib = ${name}Library(context)\n * lib.initialize()\n * ```\n */\nclass ${name}Library(private val context: android.content.Context) {\n\n    fun initialize() {\n        // TODO: Initialize your library\n    }\n\n    fun doSomething(): String {\n        return \"Hello from ${name} Library!\"\n    }\n\n    companion object {\n        const val VERSION = \"1.0.0\"\n        const val TAG = \"${name}Library\"\n    }\n}")
        writeFile(dir, "README.md", "# $name Library\n\nمكتبة Android قابلة للنشر كـ `.aar`\n\n## البناء\n```\n./gradlew :library:assembleRelease\n```\nالملف الناتج: `library/build/outputs/aar/library-release.aar`\n\n## النشر على Maven\n```\n./gradlew :library:publish\n```")
    }

    // ═══════════════════════════════════════════════════════════════
    // MAIN ACTIVITY GENERATOR
    // ═══════════════════════════════════════════════════════════════
    private fun generateMainActivity(pkg: String, pkgPath: String, template: ProjectTemplate, libs: Set<AndroidLibrary>, needsHilt: Boolean): String {
        val hiltAnnot = if (needsHilt) "@AndroidEntryPoint\n" else ""
        val hiltImp   = if (needsHilt) "import dagger.hilt.android.AndroidEntryPoint\n" else ""
        val hasVM     = AndroidLibrary.VIEWMODEL in libs || template == ProjectTemplate.MVVM_CLEAN

        return when (template) {
            ProjectTemplate.COMPOSE_APP -> """
package $pkg

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
$hiltImp
${hiltAnnot}class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    MainScreen()
                }
            }
        }
    }
}

@Composable
fun MainScreen() {
    var count by remember { mutableStateOf(0) }
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(text = "مرحباً بك!", fontSize = 28.sp, style = MaterialTheme.typography.headlineMedium)
        Spacer(modifier = Modifier.height(16.dp))
        Text(text = "عدد النقرات: ${'$'}count", fontSize = 18.sp)
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { count++ }) {
            Text("اضغط هنا")
        }
    }
}""".trim()

            ProjectTemplate.WEAR_OS -> """
package $pkg

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.wear.compose.material.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WearApp()
        }
    }
}

@Composable
fun WearApp() {
    MaterialTheme {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Wear OS", style = MaterialTheme.typography.title1)
                Spacer(modifier = Modifier.height(8.dp))
                Chip(
                    onClick = {},
                    label = { Text("اضغط") }
                )
            }
        }
    }
}""".trim()

            ProjectTemplate.TV_APP -> """
package $pkg

import android.os.Bundle
import androidx.fragment.app.FragmentActivity

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}""".trim()

            ProjectTemplate.GAME_CANVAS -> """
package $pkg

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(GameView(this))
    }
}

class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback, Runnable {

    private var gameThread: Thread? = null
    private var running = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    // Game state
    private var ballX = 400f
    private var ballY = 400f
    private var ballSpeedX = 8f
    private var ballSpeedY = 8f
    private val ballRadius = 40f
    private var score = 0

    // Player
    private var paddleX = 300f
    private val paddleY get() = height - 80f
    private val paddleWidth = 200f
    private val paddleHeight = 30f

    init { holder.addCallback(this) }

    override fun surfaceCreated(h: SurfaceHolder) { running = true; gameThread = Thread(this).apply { start() } }
    override fun surfaceDestroyed(h: SurfaceHolder) { running = false; gameThread?.join() }
    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, ht: Int) {}

    override fun run() {
        while (running) {
            update()
            draw()
            Thread.sleep(16) // ~60fps
        }
    }

    private fun update() {
        ballX += ballSpeedX
        ballY += ballSpeedY
        if (ballX < ballRadius || ballX > width - ballRadius) ballSpeedX = -ballSpeedX
        if (ballY < ballRadius) ballSpeedY = -ballSpeedY
        // Check paddle collision
        if (ballY + ballRadius >= paddleY && ballX in paddleX..(paddleX + paddleWidth)) {
            ballSpeedY = -Math.abs(ballSpeedY); score++
        }
        if (ballY > height + ballRadius) {
            ballX = width / 2f; ballY = 200f; score = 0
        }
    }

    private fun draw() {
        val canvas = holder.lockCanvas() ?: return
        canvas.drawColor(Color.rgb(15, 15, 30))
        // Ball
        paint.color = Color.rgb(100, 200, 255)
        canvas.drawCircle(ballX, ballY, ballRadius, paint)
        // Paddle
        paint.color = Color.rgb(100, 255, 150)
        canvas.drawRoundRect(paddleX, paddleY, paddleX + paddleWidth, paddleY + paddleHeight, 15f, 15f, paint)
        // Score
        paint.color = Color.WHITE; paint.textSize = 60f
        canvas.drawText("Score: ${'$'}score", 40f, 80f, paint)
        holder.unlockCanvasAndPost(canvas)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        paddleX = event.x - paddleWidth / 2; return true
    }
}""".trim()

            ProjectTemplate.WIDGET_APP -> """
package $pkg

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}

class MainWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateWidget(context, manager, it) }
    }

    private fun updateWidget(context: Context, manager: AppWidgetManager, id: Int) {
        val views = RemoteViews(context.packageName, R.layout.widget_main)
        views.setTextViewText(R.id.tvWidgetText, "مرحباً من الـ Widget!")
        val intent = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        views.setOnClickPendingIntent(R.id.tvWidgetText, intent)
        manager.updateAppWidget(id, views)
    }
}""".trim()

            ProjectTemplate.SERVICE_APP -> """
package $pkg

import android.app.*
import android.content.*
import android.os.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import android.os.Bundle
import $pkg.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnStartService.setOnClickListener {
            startForegroundService(Intent(this, MainService::class.java).apply { action = "START" })
            binding.tvStatus.text = "الخدمة تعمل..."
        }
        binding.btnStopService.setOnClickListener {
            stopService(Intent(this, MainService::class.java))
            binding.tvStatus.text = "الخدمة متوقفة"
        }
    }
}""".trim()

            ProjectTemplate.MVVM_CLEAN -> """
package $pkg

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import $pkg.databinding.ActivityMainBinding
$hiltImp
${hiltAnnot}class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        viewModel.uiState.observe(this) { state ->
            binding.progressBar.visibility = if (state.isLoading) View.VISIBLE else View.GONE
            binding.tvMessage.text = state.message
            state.error?.let { binding.tvMessage.text = "خطأ: ${'$'}it" }
        }
        binding.btnLoad.setOnClickListener { viewModel.loadData() }
    }
}""".trim()

            else -> """
package $pkg

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
${if (hasVM) "import androidx.activity.viewModels\n" else ""}import $pkg.databinding.ActivityMainBinding
$hiltImp
${hiltAnnot}class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    ${if (hasVM) "private val viewModel: MainViewModel by viewModels()" else ""}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ${if (hasVM) "viewModel.message.observe(this) { msg -> binding.tvMessage.text = msg }\n        binding.btnLoad.setOnClickListener { viewModel.loadData() }" else "// TODO: Setup views"}
    }
}""".trim()
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // EXTRA SOURCE FILES (ViewModel, Service, Widget, etc.)
    // ═══════════════════════════════════════════════════════════════
    private fun generateExtraSourceFiles(dir: File, pkg: String, pkgPath: String, template: ProjectTemplate, libs: Set<AndroidLibrary>) {
        val hasVM = AndroidLibrary.VIEWMODEL in libs || template == ProjectTemplate.MVVM_CLEAN

        // ViewModel
        when {
            template == ProjectTemplate.MVVM_CLEAN -> {
                writeFile(dir, "app/src/main/java/$pkgPath/UiState.kt", "package $pkg\n\ndata class UiState(\n    val isLoading: Boolean = false,\n    val message: String = \"اضغط الزر لتحميل البيانات\",\n    val error: String? = null\n)")
                writeFile(dir, "app/src/main/java/$pkgPath/MainViewModel.kt", "package $pkg\n\nimport androidx.lifecycle.*\nimport kotlinx.coroutines.launch\n\nclass MainViewModel : ViewModel() {\n    private val _uiState = MutableLiveData(UiState())\n    val uiState: LiveData<UiState> = _uiState\n\n    fun loadData() {\n        _uiState.value = UiState(isLoading = true)\n        viewModelScope.launch {\n            try {\n                kotlinx.coroutines.delay(1500)\n                _uiState.value = UiState(message = \"✅ تم تحميل البيانات بنجاح!\")\n            } catch (e: Exception) {\n                _uiState.value = UiState(error = e.message)\n            }\n        }\n    }\n}")
            }
            hasVM -> writeFile(dir, "app/src/main/java/$pkgPath/MainViewModel.kt", "package $pkg\n\nimport androidx.lifecycle.*\nimport kotlinx.coroutines.launch\n\nclass MainViewModel : ViewModel() {\n    val message = MutableLiveData<String>()\n    val isLoading = MutableLiveData<Boolean>()\n\n    fun loadData() {\n        viewModelScope.launch {\n            isLoading.value = true\n            kotlinx.coroutines.delay(1000)\n            message.value = \"مرحباً من ViewModel!\"\n            isLoading.value = false\n        }\n    }\n}")
        }

        // Service files
        if (template == ProjectTemplate.SERVICE_APP) {
            writeFile(dir, "app/src/main/java/$pkgPath/MainService.kt", "package $pkg\n\nimport android.app.*\nimport android.content.Intent\nimport android.os.IBinder\nimport androidx.core.app.NotificationCompat\n\nclass MainService : Service() {\n    companion object { const val CHANNEL_ID = \"main_channel\" }\n\n    override fun onCreate() {\n        super.onCreate()\n        createNotificationChannel()\n    }\n\n    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {\n        val notification = NotificationCompat.Builder(this, CHANNEL_ID)\n            .setContentTitle(\"$pkg\")\n            .setContentText(\"الخدمة تعمل في الخلفية\")\n            .setSmallIcon(android.R.drawable.ic_dialog_info)\n            .build()\n        startForeground(1, notification)\n        return START_STICKY\n    }\n\n    override fun onBind(intent: Intent?): IBinder? = null\n\n    private fun createNotificationChannel() {\n        val channel = NotificationChannel(CHANNEL_ID, \"Main Channel\", NotificationManager.IMPORTANCE_LOW)\n        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)\n    }\n}")
        }

        // Widget files
        if (template == ProjectTemplate.WIDGET_APP) {
            writeFile(dir, "app/src/main/res/layout/widget_main.xml", "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\"\n    android:layout_width=\"match_parent\" android:layout_height=\"match_parent\"\n    android:background=\"#1E1E2E\" android:gravity=\"center\" android:padding=\"16dp\">\n    <TextView android:id=\"@+id/tvWidgetText\" android:layout_width=\"wrap_content\" android:layout_height=\"wrap_content\"\n        android:text=\"Widget\" android:textColor=\"#FFFFFF\" android:textSize=\"16sp\"/>\n</LinearLayout>")
            writeFile(dir, "app/src/main/res/xml/widget_info.xml", "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<appwidget-provider xmlns:android=\"http://schemas.android.com/apk/res/android\"\n    android:minWidth=\"250dp\" android:minHeight=\"110dp\"\n    android:updatePeriodMillis=\"86400000\"\n    android:initialLayout=\"@layout/widget_main\"\n    android:resizeMode=\"horizontal|vertical\"\n    android:widgetCategory=\"home_screen\"/>")
        }

        // Room + Retrofit
        if (AndroidLibrary.ROOM in libs) {
            writeFile(dir, "app/src/main/java/$pkgPath/db/ItemEntity.kt", "package $pkg.db\nimport androidx.room.*\n\n@Entity(tableName = \"items\")\ndata class ItemEntity(@PrimaryKey(autoGenerate = true) val id: Int = 0, val title: String, val createdAt: Long = System.currentTimeMillis())")
            writeFile(dir, "app/src/main/java/$pkgPath/db/ItemDao.kt", "package $pkg.db\nimport androidx.room.*\nimport kotlinx.coroutines.flow.Flow\n\n@Dao\ninterface ItemDao {\n    @Query(\"SELECT * FROM items ORDER BY createdAt DESC\") fun getAll(): Flow<List<ItemEntity>>\n    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(item: ItemEntity)\n    @Delete suspend fun delete(item: ItemEntity)\n}")
            writeFile(dir, "app/src/main/java/$pkgPath/db/AppDatabase.kt", "package $pkg.db\nimport androidx.room.*\nimport android.content.Context\n\n@Database(entities = [ItemEntity::class], version = 1, exportSchema = false)\nabstract class AppDatabase : RoomDatabase() {\n    abstract fun itemDao(): ItemDao\n    companion object {\n        @Volatile private var INSTANCE: AppDatabase? = null\n        fun getInstance(context: Context) = INSTANCE ?: synchronized(this) { Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, \"app_db\").build().also { INSTANCE = it } }\n    }\n}")
        }
        if (AndroidLibrary.RETROFIT in libs) {
            writeFile(dir, "app/src/main/java/$pkgPath/network/ApiService.kt", "package $pkg.network\nimport retrofit2.http.*\n\ninterface ApiService {\n    @GET(\"posts\") suspend fun getPosts(): List<Post>\n    @GET(\"posts/{id}\") suspend fun getPost(@Path(\"id\") id: Int): Post\n}\ndata class Post(val id: Int, val userId: Int, val title: String, val body: String)")
            writeFile(dir, "app/src/main/java/$pkgPath/network/RetrofitClient.kt", "package $pkg.network\nimport okhttp3.OkHttpClient\nimport okhttp3.logging.HttpLoggingInterceptor\nimport retrofit2.Retrofit\nimport retrofit2.converter.gson.GsonConverterFactory\nimport java.util.concurrent.TimeUnit\n\nobject RetrofitClient {\n    private const val BASE_URL = \"https://jsonplaceholder.typicode.com/\"\n    private val client = OkHttpClient.Builder().addInterceptor(HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BODY }).connectTimeout(30, TimeUnit.SECONDS).build()\n    val api: ApiService by lazy { Retrofit.Builder().baseUrl(BASE_URL).client(client).addConverterFactory(GsonConverterFactory.create()).build().create(ApiService::class.java) }\n}")
        }
        if (AndroidLibrary.WORK_MANAGER in libs) {
            writeFile(dir, "app/src/main/java/$pkgPath/workers/SyncWorker.kt", "package $pkg.workers\nimport android.content.Context\nimport androidx.work.*\n\nclass SyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {\n    override suspend fun doWork(): Result {\n        return try {\n            // TODO: do background work\n            Result.success()\n        } catch (e: Exception) { Result.retry() }\n    }\n    companion object {\n        fun schedule(context: Context) {\n            val request = PeriodicWorkRequestBuilder<SyncWorker>(1, java.util.concurrent.TimeUnit.HOURS).build()\n            WorkManager.getInstance(context).enqueueUniquePeriodicWork(\"sync\", ExistingPeriodicWorkPolicy.KEEP, request)\n        }\n    }\n}")
        }
    }

    private fun generateExtraActivities(template: ProjectTemplate, pkg: String): String = when (template) {
        ProjectTemplate.SERVICE_APP -> "\n        <service android:name=\".MainService\" android:exported=\"false\" android:foregroundServiceType=\"dataSync\"/>"
        ProjectTemplate.WIDGET_APP  -> "\n        <receiver android:name=\".MainWidget\" android:exported=\"true\">\n            <intent-filter><action android:name=\"android.appwidget.action.APPWIDGET_UPDATE\"/></intent-filter>\n            <meta-data android:name=\"android.appwidget.provider\" android:resource=\"@xml/widget_info\"/>\n        </receiver>"
        else -> ""
    }

    private fun generateServices(template: ProjectTemplate, pkg: String, dir: File, pkgPath: String): String = ""

    private fun generateLayout(template: ProjectTemplate): String = when (template) {
        ProjectTemplate.MVVM_CLEAN -> "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\" android:layout_width=\"match_parent\" android:layout_height=\"match_parent\" android:orientation=\"vertical\" android:gravity=\"center\" android:padding=\"24dp\">\n    <ProgressBar android:id=\"@+id/progressBar\" android:layout_width=\"wrap_content\" android:layout_height=\"wrap_content\" android:visibility=\"gone\" android:layout_marginBottom=\"16dp\"/>\n    <TextView android:id=\"@+id/tvMessage\" android:layout_width=\"wrap_content\" android:layout_height=\"wrap_content\" android:text=\"اضغط الزر\" android:textSize=\"18sp\" android:layout_marginBottom=\"24dp\"/>\n    <Button android:id=\"@+id/btnLoad\" android:layout_width=\"wrap_content\" android:layout_height=\"48dp\" android:paddingHorizontal=\"32dp\" android:text=\"تحميل البيانات\"/>\n</LinearLayout>"
        ProjectTemplate.LOGIN_SCREEN -> "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\" android:layout_width=\"match_parent\" android:layout_height=\"match_parent\" android:orientation=\"vertical\" android:padding=\"32dp\" android:gravity=\"center\">\n    <TextView android:layout_width=\"wrap_content\" android:layout_height=\"wrap_content\" android:text=\"تسجيل الدخول\" android:textSize=\"28sp\" android:textStyle=\"bold\" android:layout_marginBottom=\"32dp\"/>\n    <EditText android:id=\"@+id/etEmail\" android:layout_width=\"match_parent\" android:layout_height=\"wrap_content\" android:hint=\"البريد الإلكتروني\" android:inputType=\"textEmailAddress\" android:layout_marginBottom=\"12dp\"/>\n    <EditText android:id=\"@+id/etPassword\" android:layout_width=\"match_parent\" android:layout_height=\"wrap_content\" android:hint=\"كلمة المرور\" android:inputType=\"textPassword\" android:layout_marginBottom=\"24dp\"/>\n    <Button android:id=\"@+id/btnLogin\" android:layout_width=\"match_parent\" android:layout_height=\"56dp\" android:text=\"دخول\"/>\n</LinearLayout>"
        ProjectTemplate.RECYCLERVIEW -> "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<FrameLayout xmlns:android=\"http://schemas.android.com/apk/res/android\" android:layout_width=\"match_parent\" android:layout_height=\"match_parent\">\n    <androidx.recyclerview.widget.RecyclerView android:id=\"@+id/rvItems\" android:layout_width=\"match_parent\" android:layout_height=\"match_parent\" android:padding=\"8dp\"/>\n</FrameLayout>"
        ProjectTemplate.BOTTOM_NAV  -> "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\" android:layout_width=\"match_parent\" android:layout_height=\"match_parent\" android:orientation=\"vertical\">\n    <FrameLayout android:id=\"@+id/navHostFragment\" android:layout_width=\"match_parent\" android:layout_height=\"0dp\" android:layout_weight=\"1\"/>\n    <com.google.android.material.bottomnavigation.BottomNavigationView android:id=\"@+id/bottomNav\" android:layout_width=\"match_parent\" android:layout_height=\"wrap_content\"/>\n</LinearLayout>"
        ProjectTemplate.TV_APP      -> "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<FrameLayout xmlns:android=\"http://schemas.android.com/apk/res/android\" android:layout_width=\"match_parent\" android:layout_height=\"match_parent\" android:background=\"#000000\">\n    <TextView android:layout_width=\"wrap_content\" android:layout_height=\"wrap_content\" android:layout_gravity=\"center\" android:text=\"Android TV App\" android:textColor=\"#FFFFFF\" android:textSize=\"36sp\"/>\n</FrameLayout>"
        ProjectTemplate.SERVICE_APP -> "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\" android:layout_width=\"match_parent\" android:layout_height=\"match_parent\" android:orientation=\"vertical\" android:gravity=\"center\" android:padding=\"24dp\">\n    <TextView android:id=\"@+id/tvStatus\" android:layout_width=\"wrap_content\" android:layout_height=\"wrap_content\" android:text=\"الخدمة متوقفة\" android:textSize=\"18sp\" android:layout_marginBottom=\"24dp\"/>\n    <Button android:id=\"@+id/btnStartService\" android:layout_width=\"wrap_content\" android:layout_height=\"48dp\" android:text=\"▶ تشغيل الخدمة\" android:layout_marginBottom=\"12dp\"/>\n    <Button android:id=\"@+id/btnStopService\" android:layout_width=\"wrap_content\" android:layout_height=\"48dp\" android:text=\"⏹ إيقاف الخدمة\"/>\n</LinearLayout>"
        ProjectTemplate.WIDGET_APP  -> "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\" android:layout_width=\"match_parent\" android:layout_height=\"match_parent\" android:orientation=\"vertical\" android:gravity=\"center\" android:padding=\"24dp\">\n    <TextView android:layout_width=\"wrap_content\" android:layout_height=\"wrap_content\" android:text=\"أضف الـ Widget إلى الشاشة الرئيسية\" android:textSize=\"18sp\" android:textStyle=\"bold\"/>\n</LinearLayout>"
        ProjectTemplate.BASIC_VIEWS -> "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\" android:layout_width=\"match_parent\" android:layout_height=\"match_parent\" android:orientation=\"vertical\" android:padding=\"24dp\" android:gravity=\"center\">\n    <EditText android:id=\"@+id/etInput\" android:layout_width=\"match_parent\" android:layout_height=\"wrap_content\" android:hint=\"أدخل نصاً\" android:inputType=\"text\"/>\n    <Button android:id=\"@+id/btnAction\" android:layout_width=\"match_parent\" android:layout_height=\"wrap_content\" android:layout_marginTop=\"12dp\" android:text=\"موافق\"/>\n    <TextView android:id=\"@+id/tvOutput\" android:layout_width=\"wrap_content\" android:layout_height=\"wrap_content\" android:layout_marginTop=\"16dp\" android:textSize=\"18sp\" android:text=\"\"/>\n</LinearLayout>"
        else -> "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<FrameLayout xmlns:android=\"http://schemas.android.com/apk/res/android\" android:layout_width=\"match_parent\" android:layout_height=\"match_parent\">\n    <TextView android:layout_width=\"wrap_content\" android:layout_height=\"wrap_content\" android:layout_gravity=\"center\" android:text=\"Hello World!\" android:textSize=\"24sp\"/>\n</FrameLayout>"
    }

    private fun generateReadme(name: String, pkg: String, template: ProjectTemplate, libs: Set<AndroidLibrary>) = "# $name\n\nمشروع Android — **${template.displayName}**\n\n- **الحزمة:** `$pkg`\n- **المكتبات:** ${if (libs.isEmpty()) "لا توجد" else libs.joinToString(", ") { it.displayName }}\n\n## البناء\nارفع المشروع على GitHub وسيبني APK تلقائياً عبر GitHub Actions ☁️"

    private fun writeFile(root: File, path: String, content: String) {
        File(root, path).also { it.parentFile?.mkdirs() }.writeText(content)
    }
}
