package com.androidide.app

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.androidide.app.databinding.ActivityNewProjectBinding
import com.androidide.app.editor.EditorActivity
import com.androidide.app.utils.AndroidLibrary
import com.androidide.app.utils.ProjectManager
import com.androidide.app.utils.ProjectTemplate
import com.google.android.material.snackbar.Snackbar

class NewProjectActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNewProjectBinding
    private lateinit var projectManager: ProjectManager

    private val templates = ProjectTemplate.entries.toTypedArray()
    private val selectedLibraries = mutableSetOf<AndroidLibrary>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewProjectBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "مشروع جديد"

        projectManager = ProjectManager(this)
        setupTemplateSpinner()
        setupLibraryCheckboxes()
        setupCreateButton()
    }

    private fun setupTemplateSpinner() {
        val names = templates.map { "${it.displayName} — ${it.description}" }
        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, names)
        binding.spinnerTemplate.setAdapter(adapter)
        binding.spinnerTemplate.setText(names[0], false)
    }

    private fun setupLibraryCheckboxes() {
        // Group libraries by category
        val grouped = AndroidLibrary.entries.groupBy { it.category }

        grouped.forEach { (category, libs) ->
            // Category header
            val header = TextView(this).apply {
                text = category
                textSize = 13f
                setTextColor(0xFF8B949E.toInt())
                setPadding(0, 24, 0, 8)
            }
            binding.librariesContainer.addView(header)

            // Checkboxes
            libs.forEach { lib ->
                val cb = CheckBox(this).apply {
                    text = lib.displayName
                    textSize = 13f
                    setTextColor(0xFFE6EDF3.toInt())
                    setPadding(4, 6, 0, 6)
                    buttonTintList = android.content.res.ColorStateList.valueOf(0xFF58A6FF.toInt())
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    setOnCheckedChangeListener { _, checked ->
                        if (checked) selectedLibraries.add(lib)
                        else selectedLibraries.remove(lib)
                        updateLibraryCount()
                    }
                }
                binding.librariesContainer.addView(cb)
            }
        }
    }

    private fun updateLibraryCount() {
        val count = selectedLibraries.size
        binding.tvLibCount.text = if (count == 0) "لم تُحدَّد مكتبات"
                                  else "$count ${if (count == 1) "مكتبة" else "مكتبات"} محددة"
    }

    private fun setupCreateButton() {
        binding.btnCreate.setOnClickListener {
            val name = binding.etProjectName.text?.toString()?.trim() ?: ""
            val pkg  = binding.etPackageName.text?.toString()?.trim() ?: ""
            val templateName = binding.spinnerTemplate.text?.toString() ?: ""
            val template = templates.find { templateName.startsWith(it.displayName) } ?: ProjectTemplate.EMPTY_ACTIVITY

            if (name.isEmpty()) { binding.tilProjectName.error = "أدخل اسم المشروع"; return@setOnClickListener }
            if (pkg.isEmpty() || !pkg.contains('.')) { binding.tilPackageName.error = "مثال: com.example.myapp"; return@setOnClickListener }

            binding.tilProjectName.error = null
            binding.tilPackageName.error = null
            binding.btnCreate.isEnabled = false
            binding.btnCreate.text = "⏳ جاري الإنشاء..."

            val safeName = name.replace(Regex("[^A-Za-z0-9_]"), "").ifEmpty { "MyApp" }
            val project = projectManager.createProject(safeName, pkg, template, selectedLibraries.toSet())

            if (project != null) {
                startActivity(
                    Intent(this, EditorActivity::class.java).apply {
                        putExtra(EditorActivity.EXTRA_PROJECT_PATH, project.absolutePath)
                        putExtra(EditorActivity.EXTRA_PROJECT_NAME, project.name)
                    }
                )
                finish()
            } else {
                binding.btnCreate.isEnabled = true
                binding.btnCreate.text = "إنشاء المشروع"
                Snackbar.make(binding.root, "❌ خطأ في إنشاء المشروع", Snackbar.LENGTH_LONG).show()
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) { finish(); return true }
        return super.onOptionsItemSelected(item)
    }
}
