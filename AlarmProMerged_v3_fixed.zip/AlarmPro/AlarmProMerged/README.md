# AlarmPro 🔔
## برمجة - حسين حميد الشريفي

تطبيق منبه احترافي بتصميم iOS 26 Liquid Glass لأجهزة Android.

---

## متطلبات البناء / Build Requirements

- Android Studio Hedgehog 2023.1.1+ أو Ladybug
- JDK 17
- Gradle 8.9 (يُنزّل تلقائياً)
- SDK: minSdk 26 | targetSdk 35

---

## إضافة الأغاني المدمجة / Adding Built-in Sounds

ضع الملفات في المجلد — التطبيق يكتشفها تلقائياً:
```
app/src/main/assets/sounds/
```
**لا يلزم أي تعديل في الكود** — كل ملف يُضاف يظهر فوراً في قائمة الأصوات.

الصيغ المدعومة: mp3, ogg, wav, m4a, aac, flac

الاسم المعروض في الواجهة يُشتق من اسم الملف:
- `gentle_morning.mp3` → **Gentle Morning**
- `عزف_عود.mp3` → **عزف عود**

---

## الميزات / Features

| ميزة | التفاصيل |
|------|---------|
| تصميم iOS 26 | Liquid Glass - أضواء متحركة + زجاج عميق |
| ساعة تناظرية | Canvas مخصص مع تأثيرات ضوئية |
| عجلة iOS | Drum-roll picker بنمط iOS |
| مهام الإيقاظ | رياضيات / إعادة كتابة / نقرات |
| غفوة متقدمة | تقليل تدريجي + حد أقصى + تلقائية |
| ضباب حقيقي | RenderEffect API31+ + StackBlur fallback |
| حماية من الحذف | DeviceAdminReceiver |
| شاومي HyperOS | تفعيل Autostart تلقائي |
| استيراد/تصدير | JSON + مشاركة الملف |
| ويدجت | Jetpack Glance |
| القالب الافتراضي | إعدادات مطبّقة على كل منبه جديد |
| WakeLock | يمنع نوم الهاتف أثناء الرنين |

---

## أذونات شاومي / Xiaomi Setup

بعد التثبيت، افتح التطبيق → الإعدادات → تحسينات شاومي:
1. فعّل **التشغيل التلقائي**
2. اضبط البطارية على **بلا قيود**

---

## Package
`com.hussein.alarmpro`
