package com.hussein.alarmpro.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.viewmodel.LapEntry
import com.hussein.alarmpro.viewmodel.StopwatchViewModel
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.Card
import java.util.Locale

@Composable
fun StopwatchScreen(vm: StopwatchViewModel = hiltViewModel()) {
    val state by vm.state.collectAsState()
    val isAr = com.hussein.alarmpro.util.TimeUtils.isArabic()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HyperBg)
            .navigationBarsPadding(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))

        // ── Circular Display ──────────────────────────────────────────────
        StopwatchCircle(
            elapsedMs = state.elapsedMs,
            isRunning = state.isRunning
        )

        Spacer(Modifier.height(32.dp))

        // ── Controls ──────────────────────────────────────────────────────
        Row(
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Lap / Reset
            if (state.isRunning || state.elapsedMs > 0) {
                FilledTonalIconButton(
                    onClick = {
                        if (state.isRunning) vm.lap() else vm.reset()
                    },
                    modifier = Modifier.size(56.dp),
                    colors = IconButtonDefaults.filledTonalIconButtonColors(
                        containerColor = HyperSurface2
                    )
                ) {
                    Icon(
                        if (state.isRunning) Icons.Rounded.Flag else Icons.Rounded.RestartAlt,
                        contentDescription = null,
                        tint = HyperTextSecondary
                    )
                }
            } else {
                Spacer(Modifier.size(56.dp))
            }

            // Start / Pause — large primary button
            val btnColor = if (state.isRunning) MiOrange else StopwatchAccent
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(btnColor),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = { if (state.isRunning) vm.pause() else vm.start() }) {
                    Icon(
                        if (state.isRunning) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Spacer(Modifier.size(56.dp))
        }

        Spacer(Modifier.height(24.dp))

        // ── Laps ──────────────────────────────────────────────────────────
        if (state.laps.isNotEmpty()) {
            SmallTitle(
                text = if (isAr) "الدورات" else "LAPS",
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                reverseLayout = true
            ) {
                items(state.laps) { lap ->
                    LapRow(lap = lap, isAr = isAr)
                }
            }
        }
    }
}

@Composable
private fun StopwatchCircle(elapsedMs: Long, isRunning: Boolean) {
    val sweepAngle = ((elapsedMs % 60_000L) / 60_000f) * 360f
    val minuteAngle = ((elapsedMs % 3_600_000L) / 3_600_000f) * 360f

    val animSweep by animateFloatAsState(
        targetValue = sweepAngle,
        animationSpec = if (isRunning) tween(16, easing = LinearEasing) else snap(),
        label = "sweep"
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.size(220.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = 10.dp.toPx()
            val outerStroke = 4.dp.toPx()
            val inset = stroke / 2
            val insetOuter = outerStroke / 2

            // Background track
            drawArc(
                color = HyperSurface2,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(stroke, cap = StrokeCap.Round),
                topLeft = Offset(inset, inset),
                size = androidx.compose.ui.geometry.Size(size.width - stroke, size.height - stroke)
            )
            // Progress arc (seconds)
            drawArc(
                brush = Brush.sweepGradient(
                    listOf(StopwatchAccent, StopwatchLap, StopwatchAccent)
                ),
                startAngle = -90f,
                sweepAngle = animSweep,
                useCenter = false,
                style = Stroke(stroke, cap = StrokeCap.Round),
                topLeft = Offset(inset, inset),
                size = androidx.compose.ui.geometry.Size(size.width - stroke, size.height - stroke)
            )
            // Outer minute track
            drawArc(
                color = HyperSurface2,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(outerStroke, cap = StrokeCap.Round),
                topLeft = Offset(insetOuter - 12.dp.toPx(), insetOuter - 12.dp.toPx()),
                size = androidx.compose.ui.geometry.Size(
                    size.width + 24.dp.toPx() - outerStroke,
                    size.height + 24.dp.toPx() - outerStroke
                )
            )
            drawArc(
                color = MiOrange.copy(alpha = 0.8f),
                startAngle = -90f,
                sweepAngle = minuteAngle,
                useCenter = false,
                style = Stroke(outerStroke, cap = StrokeCap.Round),
                topLeft = Offset(insetOuter - 12.dp.toPx(), insetOuter - 12.dp.toPx()),
                size = androidx.compose.ui.geometry.Size(
                    size.width + 24.dp.toPx() - outerStroke,
                    size.height + 24.dp.toPx() - outerStroke
                )
            )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = formatTime(elapsedMs),
                fontSize = 48.sp,
                fontWeight = FontWeight.Light,
                color = HyperTextPrimary,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp
            )
            Text(
                text = ".${((elapsedMs % 1000) / 10).toString().padStart(2, '0')}",
                fontSize = 22.sp,
                fontWeight = FontWeight.Light,
                color = StopwatchAccent,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun LapRow(lap: LapEntry, isAr: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (isAr) "دورة ${lap.lapNumber}" else "Lap ${lap.lapNumber}",
                color = HyperTextSecondary,
                fontSize = 14.sp
            )
            Text(
                text = formatTime(lap.lapTime),
                color = StopwatchAccent,
                fontSize = 16.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = formatTime(lap.totalTime),
                color = HyperTextTertiary,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

private fun formatTime(ms: Long): String {
    val h = ms / 3_600_000
    val m = (ms % 3_600_000) / 60_000
    val s = (ms % 60_000) / 1_000
    return if (h > 0) {
        String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
    } else {
        String.format(Locale.US, "%02d:%02d", m, s)
    }
}
