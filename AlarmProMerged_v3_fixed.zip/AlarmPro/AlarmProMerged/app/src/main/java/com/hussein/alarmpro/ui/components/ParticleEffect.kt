package com.hussein.alarmpro.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.hussein.alarmpro.ui.theme.*
import kotlin.math.*
import kotlin.random.Random

private data class Particle(
    val id: Int,
    var x: Float,
    var y: Float,
    val vx: Float,
    val vy: Float,
    val radius: Float,
    val color: Color,
    var life: Float,          // 0.0 → 1.0 (dead at 0)
    val decayRate: Float
)

@Composable
fun AlarmParticleEffect(modifier: Modifier = Modifier) {
    val particleColors = listOf(OrbBlue, OrbPurple, OrbCyan, Color.White, OrbPink)
    val particles = remember { mutableStateListOf<Particle>() }
    var frameTime by remember { mutableStateOf(0L) }

    // Spawn particles at 60fps
    val infiniteTransition = rememberInfiniteTransition(label = "particles")
    val ticker by infiniteTransition.animateFloat(
        0f, 1f,
        animationSpec = infiniteRepeatable(tween(16, easing = LinearEasing)),
        label = "tick"
    )

    LaunchedEffect(ticker) {
        // Spawn 2 new particles per frame
        repeat(2) {
            val angle = Random.nextFloat() * 2f * PI.toFloat()
            val speed = Random.nextFloat() * 3f + 1f
            particles.add(
                Particle(
                    id = Random.nextInt(),
                    x = 0.5f,  // normalized center
                    y = 0.5f,
                    vx = cos(angle) * speed * 0.002f,
                    vy = sin(angle) * speed * 0.002f,
                    radius = Random.nextFloat() * 6f + 2f,
                    color = particleColors.random(),
                    life = 1.0f,
                    decayRate = Random.nextFloat() * 0.015f + 0.008f
                )
            )
        }
        // Update all particles
        val toRemove = mutableListOf<Particle>()
        particles.forEach { p ->
            p.x += p.vx
            p.y += p.vy
            p.life -= p.decayRate
            if (p.life <= 0f) toRemove.add(p)
        }
        particles.removeAll(toRemove)
        // Cap at 120 particles for performance
        while (particles.size > 120) particles.removeAt(0)
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        particles.forEach { p ->
            drawCircle(
                color = p.color.copy(alpha = p.life * 0.8f),
                radius = p.radius * p.life,
                center = Offset(p.x * size.width, p.y * size.height)
            )
            // Trailing sparkle
            if (p.life > 0.5f) {
                drawCircle(
                    color = Color.White.copy(alpha = (p.life - 0.5f) * 0.6f),
                    radius = p.radius * 0.3f * p.life,
                    center = Offset(p.x * size.width, p.y * size.height)
                )
            }
        }
    }
}
