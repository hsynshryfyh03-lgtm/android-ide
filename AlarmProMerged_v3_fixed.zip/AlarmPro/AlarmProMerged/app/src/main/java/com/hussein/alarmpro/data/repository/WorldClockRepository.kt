package com.hussein.alarmpro.data.repository

import com.hussein.alarmpro.data.db.WorldClockDao
import com.hussein.alarmpro.data.model.WorldClockCity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WorldClockRepository @Inject constructor(private val dao: WorldClockDao) {
    val allCities: Flow<List<WorldClockCity>> = dao.allCities()
    suspend fun insert(c: WorldClockCity): Long = dao.insert(c)
    suspend fun delete(c: WorldClockCity) = dao.delete(c)
    suspend fun update(c: WorldClockCity) = dao.update(c)
}
