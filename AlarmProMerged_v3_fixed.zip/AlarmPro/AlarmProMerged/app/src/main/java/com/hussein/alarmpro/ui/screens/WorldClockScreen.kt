package com.hussein.alarmpro.ui.screens

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.*
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import com.hussein.alarmpro.data.model.CityInfo
import com.hussein.alarmpro.data.model.WorldClockCity
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.TimeUtils
import com.hussein.alarmpro.viewmodel.WorldClockViewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.Card

@Composable
fun WorldClockScreen(vm: WorldClockViewModel = hiltViewModel()) {
    val cities by vm.cities.collectAsState()
    val isAr = TimeUtils.isArabic()
    var showSearch by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HyperBg)
            .navigationBarsPadding()
    ) {
        Spacer(Modifier.height(12.dp))

        // ── Local time header ─────────────────────────────────────────────
        LocalTimeHeader(isAr = isAr)

        Spacer(Modifier.height(12.dp))

        if (cities.isEmpty() && !showSearch) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Rounded.Public, null,
                        tint = HyperTextTertiary, modifier = Modifier.size(64.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        if (isAr) "أضف مدينة لمتابعة وقتها" else "Add a city to track its time",
                        color = HyperTextTertiary, fontSize = 15.sp
                    )
                    Spacer(Modifier.height(24.dp))
                    Button(
                        onClick = { showSearch = true },
                        colors = ButtonDefaults.buttonColors(containerColor = ClockAccent)
                    ) {
                        Icon(Icons.Rounded.Add, null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (isAr) "إضافة مدينة" else "Add City")
                    }
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(cities, key = { it.id }) { city ->
                    WorldClockCard(
                        city = city,
                        onDelete = { vm.removeCity(city) }
                    )
                }
                item {
                    OutlinedButton(
                        onClick = { showSearch = true; query = "" },
                        modifier = Modifier.fillMaxWidth(),
                        border = BorderStroke(1.dp, HyperSurface2),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Rounded.Add, null, tint = ClockAccent)
                        Spacer(Modifier.width(8.dp))
                        Text(if (isAr) "إضافة مدينة" else "Add City", color = ClockAccent)
                    }
                }
            }
        }
    }

    // ── City Search Sheet ──────────────────────────────────────────────────
    if (showSearch) {
        CitySearchSheet(
            isAr = isAr,
            existingTimeZones = cities.map { it.timeZoneId }.toSet(),
            onAdd = { info ->
                vm.addCity(WorldClockCity(
                    cityName = info.city,
                    countryName = info.country,
                    timeZoneId = info.timeZoneId,
                    sortOrder = cities.size
                ))
                showSearch = false
            },
            onDismiss = { showSearch = false }
        )
    }
}

@Composable
private fun LocalTimeHeader(isAr: Boolean) {
    var time by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    val tz = TimeZone.getDefault()

    LaunchedEffect(Unit) {
        while (true) {
            val now = System.currentTimeMillis()
            time = SimpleDateFormat("HH:mm:ss", Locale.US).apply { timeZone = tz }.format(now)
            date = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).apply { timeZone = tz }.format(now)
            delay(1000)
        }
    }

    Card(modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    if (isAr) "الوقت المحلي" else "Local Time",
                    color = HyperTextTertiary, fontSize = 12.sp
                )
                Text(date, color = HyperTextSecondary, fontSize = 13.sp)
            }
            Text(
                time,
                fontSize = 34.sp,
                fontWeight = FontWeight.Light,
                color = ClockAccent,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun WorldClockCard(city: WorldClockCity, onDelete: () -> Unit) {
    var time by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var diff by remember { mutableStateOf("") }
    val tz = remember(city.timeZoneId) { TimeZone.getTimeZone(city.timeZoneId) }

    LaunchedEffect(city.timeZoneId) {
        while (true) {
            val now = System.currentTimeMillis()
            time = SimpleDateFormat("HH:mm", Locale.US).apply { timeZone = tz }.format(now)
            date = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).apply { timeZone = tz }.format(now)
            val offsetMs = tz.getOffset(now) - TimeZone.getDefault().getOffset(now)
            val offsetH = offsetMs / 3_600_000
            val offsetM = Math.abs((offsetMs % 3_600_000) / 60_000)
            diff = when {
                offsetH == 0 && offsetM == 0 -> if (TimeUtils.isArabic()) "نفس الوقت" else "Same time"
                offsetM == 0 -> if (offsetH > 0) "+${offsetH}h" else "${offsetH}h"
                else -> if (offsetH >= 0) "+${offsetH}h ${offsetM}m" else "${offsetH}h ${offsetM}m"
            }
            delay(30_000)
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    city.cityName,
                    color = HyperTextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(city.countryName, color = HyperTextSecondary, fontSize = 13.sp)
                Spacer(Modifier.height(2.dp))
                Text(diff, color = ClockAccent, fontSize = 12.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    time,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Light,
                    color = HyperTextPrimary,
                    fontFamily = FontFamily.Monospace
                )
                Text(date, color = HyperTextTertiary, fontSize = 12.sp)
            }
            IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Rounded.Close, null, tint = HyperTextTertiary, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CitySearchSheet(
    isAr: Boolean,
    existingTimeZones: Set<String>,
    onAdd: (CityInfo) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val allCities = remember { buildCityList() }
    val filtered = remember(query) {
        if (query.isBlank()) allCities
        else allCities.filter {
            it.city.contains(query, ignoreCase = true) ||
            it.country.contains(query, ignoreCase = true)
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = HyperSurface
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Text(
                if (isAr) "اختر مدينة" else "Choose a City",
                color = HyperTextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text(if (isAr) "ابحث عن مدينة..." else "Search city...") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ClockAccent,
                    focusedLabelColor  = ClockAccent
                )
            )
            Spacer(Modifier.height(8.dp))
            LazyColumn(modifier = Modifier.heightIn(max = 400.dp)) {
                items(filtered.filter { it.timeZoneId !in existingTimeZones }) { city ->
                    ListItem(
                        headlineContent = {
                            Text(city.city, color = HyperTextPrimary)
                        },
                        supportingContent = {
                            Text(city.country, color = HyperTextSecondary)
                        },
                        trailingContent = {
                            Text(
                                SimpleDateFormat("HH:mm", Locale.US)
                                    .apply { timeZone = TimeZone.getTimeZone(city.timeZoneId) }
                                    .format(System.currentTimeMillis()),
                                color = ClockAccent,
                                fontFamily = FontFamily.Monospace
                            )
                        },
                        modifier = Modifier.clickable { onAdd(city) },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent)
                    )
                    HorizontalDivider(color = HyperSeparator, thickness = 0.5.dp)
                }
            }
        }
    }
}

private fun buildCityList(): List<CityInfo> = listOf(
    CityInfo("New York",      "United States",  "America/New_York"),
    CityInfo("Los Angeles",   "United States",  "America/Los_Angeles"),
    CityInfo("Chicago",       "United States",  "America/Chicago"),
    CityInfo("London",        "United Kingdom", "Europe/London"),
    CityInfo("Paris",         "France",         "Europe/Paris"),
    CityInfo("Berlin",        "Germany",        "Europe/Berlin"),
    CityInfo("Madrid",        "Spain",          "Europe/Madrid"),
    CityInfo("Rome",          "Italy",          "Europe/Rome"),
    CityInfo("Moscow",        "Russia",         "Europe/Moscow"),
    CityInfo("Istanbul",      "Turkey",         "Europe/Istanbul"),
    CityInfo("Dubai",         "UAE",            "Asia/Dubai"),
    CityInfo("Riyadh",        "Saudi Arabia",   "Asia/Riyadh"),
    CityInfo("Baghdad",       "Iraq",           "Asia/Baghdad"),
    CityInfo("Cairo",         "Egypt",          "Africa/Cairo"),
    CityInfo("Tehran",        "Iran",           "Asia/Tehran"),
    CityInfo("Karachi",       "Pakistan",       "Asia/Karachi"),
    CityInfo("Mumbai",        "India",          "Asia/Kolkata"),
    CityInfo("Delhi",         "India",          "Asia/Kolkata"),
    CityInfo("Bangkok",       "Thailand",       "Asia/Bangkok"),
    CityInfo("Singapore",     "Singapore",      "Asia/Singapore"),
    CityInfo("Hong Kong",     "Hong Kong",      "Asia/Hong_Kong"),
    CityInfo("Shanghai",      "China",          "Asia/Shanghai"),
    CityInfo("Beijing",       "China",          "Asia/Shanghai"),
    CityInfo("Tokyo",         "Japan",          "Asia/Tokyo"),
    CityInfo("Seoul",         "South Korea",    "Asia/Seoul"),
    CityInfo("Sydney",        "Australia",      "Australia/Sydney"),
    CityInfo("Melbourne",     "Australia",      "Australia/Melbourne"),
    CityInfo("Auckland",      "New Zealand",    "Pacific/Auckland"),
    CityInfo("São Paulo",     "Brazil",         "America/Sao_Paulo"),
    CityInfo("Mexico City",   "Mexico",         "America/Mexico_City"),
    CityInfo("Toronto",       "Canada",         "America/Toronto"),
    CityInfo("Vancouver",     "Canada",         "America/Vancouver"),
    CityInfo("Johannesburg",  "South Africa",   "Africa/Johannesburg"),
    CityInfo("Lagos",         "Nigeria",        "Africa/Lagos"),
    CityInfo("Nairobi",       "Kenya",          "Africa/Nairobi"),
    CityInfo("Casablanca",    "Morocco",        "Africa/Casablanca"),
    CityInfo("Tunis",         "Tunisia",        "Africa/Tunis"),
    CityInfo("Algiers",       "Algeria",        "Africa/Algiers"),
    CityInfo("Amman",         "Jordan",         "Asia/Amman"),
    CityInfo("Beirut",        "Lebanon",        "Asia/Beirut"),
    CityInfo("Damascus",      "Syria",          "Asia/Damascus"),
    CityInfo("Kuwait City",   "Kuwait",         "Asia/Kuwait"),
    CityInfo("Doha",          "Qatar",          "Asia/Qatar"),
    CityInfo("Muscat",        "Oman",           "Asia/Muscat"),
    CityInfo("Kabul",         "Afghanistan",    "Asia/Kabul"),
    CityInfo("Dhaka",         "Bangladesh",     "Asia/Dhaka"),
    CityInfo("Colombo",       "Sri Lanka",      "Asia/Colombo"),
    CityInfo("Kuala Lumpur",  "Malaysia",       "Asia/Kuala_Lumpur"),
    CityInfo("Jakarta",       "Indonesia",      "Asia/Jakarta"),
    CityInfo("Manila",        "Philippines",    "Asia/Manila"),
    CityInfo("Taipei",        "Taiwan",         "Asia/Taipei"),
    CityInfo("Amsterdam",     "Netherlands",    "Europe/Amsterdam"),
    CityInfo("Brussels",      "Belgium",        "Europe/Brussels"),
    CityInfo("Vienna",        "Austria",        "Europe/Vienna"),
    CityInfo("Warsaw",        "Poland",         "Europe/Warsaw"),
    CityInfo("Prague",        "Czech Republic", "Europe/Prague"),
    CityInfo("Stockholm",     "Sweden",         "Europe/Stockholm"),
    CityInfo("Oslo",          "Norway",         "Europe/Oslo"),
    CityInfo("Helsinki",      "Finland",        "Europe/Helsinki"),
    CityInfo("Athens",        "Greece",         "Europe/Athens"),
    CityInfo("Bucharest",     "Romania",        "Europe/Bucharest"),
)
