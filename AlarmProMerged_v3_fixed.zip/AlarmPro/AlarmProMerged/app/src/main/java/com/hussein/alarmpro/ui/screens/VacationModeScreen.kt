package com.hussein.alarmpro.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.hussein.alarmpro.data.datastore.VacationMode
import com.hussein.alarmpro.ui.components.*
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.TimeUtils
import com.hussein.alarmpro.viewmodel.AlarmViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VacationModeScreen(viewModel: AlarmViewModel, onBack: () -> Unit) {
    val isAr = TimeUtils.isArabic()
    val vm by viewModel.vacationMode.collectAsState()
    val fmt = remember { SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()) }

    // Local editable state
    var isActive by remember(vm) { mutableStateOf(vm.isActive) }
    var startMillis by remember(vm) { mutableStateOf(if (vm.startMillis > 0) vm.startMillis else System.currentTimeMillis()) }
    var endMillis by remember(vm) { mutableStateOf(if (vm.endMillis > 0) vm.endMillis else System.currentTimeMillis() + 7 * 86400_000L) }

    // Date pickers state
    var showStartPicker by remember { mutableStateOf(false) }
    var showEndPicker by remember { mutableStateOf(false) }

    if (showStartPicker) {
        DatePickerDialogSimple(
            initialMillis = startMillis,
            onDateSelected = { startMillis = it; showStartPicker = false },
            onDismiss = { showStartPicker = false }
        )
    }
    if (showEndPicker) {
        DatePickerDialogSimple(
            initialMillis = endMillis,
            onDateSelected = { endMillis = it; showEndPicker = false },
            onDismiss = { showEndPicker = false }
        )
    }

    LiquidGlassBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = { Text(if (isAr) "وضع الإجازة" else "Vacation Mode",
                        style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold)) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Filled.ArrowBack, null, tint = TextSecondary)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                )
            }
        ) { pd ->
            Column(
                Modifier.fillMaxSize().padding(pd).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Spacer(Modifier.height(8.dp))

                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        // Toggle
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.WbSunny, null,
                                tint = if (isActive) OrbCyan else TextTertiary,
                                modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(if (isAr) "تفعيل وضع الإجازة" else "Activate Vacation Mode",
                                    style = MaterialTheme.typography.titleMedium)
                                Text(
                                    if (isAr) "توقف جميع المنبهات (عدا المعفاة)" else "Pauses all alarms (except exempt ones)",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            IosSwitch(checked = isActive, onCheckedChange = { isActive = it })
                        }

                        if (isActive) {
                            HorizontalDivider(color = GlassBorder, thickness = 0.5.dp)

                            // Start date
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Filled.EventAvailable, null,
                                    tint = OrbBlue, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(if (isAr) "تاريخ البداية" else "Start Date",
                                        style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary))
                                    Text(fmt.format(Date(startMillis)),
                                        style = MaterialTheme.typography.titleMedium)
                                }
                                TextButton(onClick = { showStartPicker = true }) {
                                    Text(if (isAr) "تغيير" else "Change", color = OrbBlue)
                                }
                            }

                            // End date
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Filled.EventBusy, null,
                                    tint = OrbPink, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(if (isAr) "تاريخ النهاية" else "End Date",
                                        style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary))
                                    Text(fmt.format(Date(endMillis)),
                                        style = MaterialTheme.typography.titleMedium)
                                }
                                TextButton(onClick = { showEndPicker = true }) {
                                    Text(if (isAr) "تغيير" else "Change", color = OrbBlue)
                                }
                            }

                            // Duration summary
                            val days = ((endMillis - startMillis) / 86400_000L).coerceAtLeast(0)
                            GlassPill(Modifier.fillMaxWidth(), color = OrbCyan) {
                                Text(
                                    if (isAr) "مدة الإجازة: $days أيام"
                                    else "Vacation duration: $days days",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = OrbCyan),
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }

                        HorizontalDivider(color = GlassBorder, thickness = 0.5.dp)

                        // Save button
                        Button(
                            onClick = {
                                viewModel.setVacationMode(VacationMode(
                                    isActive = isActive,
                                    startMillis = startMillis,
                                    endMillis = endMillis
                                ))
                                onBack()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = OrbBlue),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (isAr) "حفظ" else "Save",
                                style = MaterialTheme.typography.titleMedium)
                        }

                        if (vm.isActive) {
                            OutlinedButton(
                                onClick = { viewModel.deactivateVacation(); onBack() },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = OrbPink)
                            ) {
                                Text(if (isAr) "إنهاء الإجازة الآن" else "End Vacation Now")
                            }
                        }
                    }
                }

                // Note about exempt alarms
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp)) {
                        Icon(Icons.Filled.Info, null, tint = OrbBlue, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (isAr) "المنبهات المعفاة تعمل حتى أثناء الإجازة. فعّل خاصية الإعفاء من صفحة تعديل المنبه."
                            else "Exempt alarms still ring during vacation. Enable per-alarm in Edit Alarm screen.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DatePickerDialogSimple(
    initialMillis: Long,
    onDateSelected: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    val state = rememberDatePickerState(initialSelectedDateMillis = initialMillis)
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                state.selectedDateMillis?.let { onDateSelected(it) }
                onDismiss()
            }) { Text("OK", color = OrbBlue) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        },
        colors = DatePickerDefaults.colors(containerColor = DarkNavy)
    ) {
        DatePicker(state = state)
    }
}
