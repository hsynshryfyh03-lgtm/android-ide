package com.hussein.alarmpro.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.hussein.alarmpro.data.model.Alarm
import com.hussein.alarmpro.ui.components.*
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.AlarmScheduler
import com.hussein.alarmpro.util.TimeUtils
import com.hussein.alarmpro.viewmodel.AlarmViewModel
import kotlinx.coroutines.delay
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.basic.rememberTopAppBarState
import top.yukonga.miuix.kmp.extra.SuperArrow
import top.yukonga.miuix.kmp.extra.SuperSwitch
import top.yukonga.miuix.kmp.theme.MiuixTheme
import java.util.Calendar
import java.util.Locale

// ─────────────────────────────────────────────────────────────────────────────
// Clock face styles — kept in HomeScreen for locality
// ─────────────────────────────────────────────────────────────────────────────
enum class ClockFaceStyle { CLASSIC, MINIMAL, NEON, DIGITAL }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: AlarmViewModel,
    scheduler: AlarmScheduler,
    onAddAlarm: () -> Unit,
    onEditAlarm: (Alarm) -> Unit,
    onSettings: () -> Unit
) {
    val alarms  by viewModel.alarms.collectAsState()
    val isAr     = TimeUtils.isArabic()
    val listState = rememberLazyListState()

    var clockFace    by remember { mutableStateOf(ClockFaceStyle.CLASSIC) }
    var showFaceMenu by remember { mutableStateOf(false) }

    val sorted = remember(alarms) {
        alarms.sortedWith(
            compareByDescending<Alarm> { it.isEnabled }.thenBy { it.hour * 60 + it.minute }
        )
    }
    val isScrolled by remember {
        derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 40 }
    }

    // ── Miuix CollapsingTopAppBar scroll behaviour ──────────────────────────
    val scrollBehavior = MiuixScrollBehavior(rememberTopAppBarState())

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(HyperBg)
    ) {
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(bottom = 110.dp),
            modifier = Modifier
                .fillMaxSize()
                .nestedScroll(scrollBehavior.nestedScrollConnection)
        ) {
            // Top-bar spacer
            item { Spacer(Modifier.height(8.dp)) }

            // ── Clock header ───────────────────────────────────────────────
            item {
                ClockHeaderSection(
                    clockFace  = clockFace,
                    alarms     = sorted,
                    scheduler  = scheduler,
                    isAr       = isAr,
                    onLongPress = { showFaceMenu = true }
                )
            }

            // Face picker
            if (showFaceMenu) {
                item {
                    ClockFacePicker(
                        current   = clockFace,
                        isAr      = isAr,
                        onSelect  = { clockFace = it; showFaceMenu = false },
                        onDismiss = { showFaceMenu = false }
                    )
                }
            }

            // Section header
            if (sorted.isNotEmpty()) {
                item {
                    SmallTitle(
                        text     = if (isAr) "المنبهات" else "ALARMS",
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
                items(sorted, key = { it.id }) { alarm ->
                    AnimatedVisibility(
                        visible  = true,
                        enter    = fadeIn() + slideInVertically { it / 2 },
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp)
                    ) {
                        AlarmCard(
                            alarm             = alarm,
                            nextTriggerMillis = scheduler.getNextTriggerMillis(alarm),
                            onToggle          = { en -> viewModel.updateAlarm(alarm.copy(isEnabled = en)) },
                            onEdit            = { onEditAlarm(alarm) },
                            onDelete          = { viewModel.deleteAlarm(alarm) }
                        )
                    }
                }
            } else {
                item { MiuixEmptyState(isAr = isAr) }
            }
        }

        // ── Miuix TopAppBar (collapses on scroll) ──────────────────────────
        TopAppBar(
            title              = if (isAr) "AlarmPro" else "AlarmPro",
            scrollBehavior     = scrollBehavior,
            navigationIcon     = {},
            actions            = {
                IconButton(onClick = onSettings) {
                    Icon(
                        Icons.Rounded.Settings, null,
                        tint = HyperTextSecondary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            },
            color              = HyperBg
        )

        // ── FAB ────────────────────────────────────────────────────────────
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(end = 20.dp, bottom = 16.dp)
        ) {
            MiuixFab(
                isScrolled = isScrolled,
                isAr       = isAr,
                onClick    = onAddAlarm
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Miuix-style FAB — pill when idle, circle when scrolled
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun MiuixFab(isScrolled: Boolean, isAr: Boolean, onClick: () -> Unit) {
    val targetWidth by animateDpAsState(
        targetValue    = if (isScrolled) 56.dp else 144.dp,
        animationSpec  = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label          = "fabWidth"
    )
    Box(
        modifier = Modifier
            .width(targetWidth)
            .height(52.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(MiBlue)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(Icons.Rounded.Add, null, tint = Color.White, modifier = Modifier.size(22.dp))
            AnimatedVisibility(visible = !isScrolled) {
                Row {
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (isAr) "منبه جديد" else "New Alarm",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Empty state — Miuix card style
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun MiuixEmptyState(isAr: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            Icons.Rounded.Alarm, null,
            tint = HyperTextTertiary,
            modifier = Modifier.size(64.dp)
        )
        Spacer(Modifier.height(16.dp))
        Text(
            if (isAr) "لا توجد منبهات" else "No Alarms Yet",
            fontSize = 17.sp,
            fontWeight = FontWeight.Medium,
            color = HyperTextSecondary
        )
        Spacer(Modifier.height(6.dp))
        Text(
            if (isAr) "اضغط «منبه جديد» للبدء" else "Tap «New Alarm» to get started",
            fontSize = 14.sp,
            color = HyperTextTertiary,
            textAlign = TextAlign.Center
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Clock Header — lives below the TopAppBar
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun ClockHeaderSection(
    clockFace: ClockFaceStyle,
    alarms: List<Alarm>,
    scheduler: AlarmScheduler,
    isAr: Boolean,
    onLongPress: () -> Unit
) {
    var timeStr  by remember { mutableStateOf("") }
    var dateStr  by remember { mutableStateOf("") }
    var nextStr  by remember { mutableStateOf("") }

    LaunchedEffect(alarms) {
        while (true) {
            val now  = Calendar.getInstance()
            val h    = now.get(Calendar.HOUR_OF_DAY)
            val m    = now.get(Calendar.MINUTE)
            val s    = now.get(Calendar.SECOND)
            timeStr  = String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
            val dow  = now.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.getDefault()) ?: ""
            val day  = now.get(Calendar.DAY_OF_MONTH)
            val mon  = now.getDisplayName(Calendar.MONTH, Calendar.SHORT, Locale.getDefault()) ?: ""
            dateStr  = "$dow, $day $mon"

            val next = alarms.filter { it.isEnabled }
                .mapNotNull { scheduler.getNextTriggerMillis(it) }
                .minOrNull()
            nextStr  = if (next != null) {
                val diff = next - System.currentTimeMillis()
                val hh   = (diff / 3_600_000).toInt()
                val mm   = ((diff % 3_600_000) / 60_000).toInt()
                if (hh > 0) {
                    if (isAr) "المنبه القادم خلال ${hh}س ${mm}د" else "Next alarm in ${hh}h ${mm}m"
                } else {
                    if (isAr) "المنبه القادم خلال ${mm}د" else "Next alarm in ${mm}m"
                }
            } else ""
            delay(1_000)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .pointerInput(Unit) { detectTapGestures(onLongPress = { onLongPress() }) }
    ) {
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Analog or Digital clock
                when (clockFace) {
                    ClockFaceStyle.CLASSIC  -> AnalogClock(modifier = Modifier.size(180.dp))
                    ClockFaceStyle.MINIMAL  -> MinimalClockFace(modifier = Modifier.size(180.dp))
                    ClockFaceStyle.NEON     -> NeonClockFace(modifier = Modifier.size(180.dp))
                    ClockFaceStyle.DIGITAL  -> {
                        Text(
                            timeStr,
                            fontSize = 52.sp,
                            fontWeight = FontWeight.Thin,
                            color = MiBlue,
                            letterSpacing = 2.sp
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    dateStr,
                    fontSize = 14.sp,
                    color = HyperTextSecondary
                )
                if (nextStr.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        nextStr,
                        fontSize = 12.sp,
                        color = MiBlue
                    )
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Clock face picker — Miuix card style
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun ClockFacePicker(
    current: ClockFaceStyle,
    isAr: Boolean,
    onSelect: (ClockFaceStyle) -> Unit,
    onDismiss: () -> Unit
) {
    val faces = listOf(
        ClockFaceStyle.CLASSIC  to if (isAr) "كلاسيك"   else "Classic",
        ClockFaceStyle.MINIMAL  to if (isAr) "مبسط"     else "Minimal",
        ClockFaceStyle.NEON     to if (isAr) "نيون"     else "Neon",
        ClockFaceStyle.DIGITAL  to if (isAr) "رقمي"     else "Digital"
    )
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                if (isAr) "نمط الساعة" else "Clock Style",
                fontWeight = FontWeight.SemiBold,
                color = HyperTextPrimary,
                fontSize = 15.sp
            )
            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                faces.forEach { (face, label) ->
                    val sel = face == current
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (sel) MiBlue else HyperSurface2)
                            .clickable { onSelect(face) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            label,
                            fontSize   = 12.sp,
                            color      = if (sel) Color.White else HyperTextTertiary,
                            fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}
