package com.hussein.alarmpro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.hussein.alarmpro.data.model.AlarmGroup
import com.hussein.alarmpro.ui.components.*
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.TimeUtils
import com.hussein.alarmpro.viewmodel.AlarmViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlarmGroupsScreen(viewModel: AlarmViewModel, onBack: () -> Unit) {
    val isAr = TimeUtils.isArabic()
    val groups by viewModel.groups.collectAsState()
    val alarms by viewModel.alarms.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var newGroupName by remember { mutableStateOf("") }
    var newGroupColor by remember { mutableStateOf("#0A84FF") }

    val colorOptions = listOf(
        "#0A84FF", "#5E5CE6", "#32D2FF", "#FF375F",
        "#00C7BE", "#FF9F0A", "#30D158", "#FF6B35"
    )

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false; newGroupName = "" },
            title = { Text(if (isAr) "مجموعة جديدة" else "New Group") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = newGroupName,
                        onValueChange = { newGroupName = it },
                        label = { Text(if (isAr) "اسم المجموعة" else "Group name") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary, unfocusedTextColor = TextSecondary,
                            focusedBorderColor = OrbBlue, unfocusedBorderColor = GlassBorder,
                            cursorColor = OrbBlue
                        )
                    )
                    // Color picker row
                    Text(
                        if (isAr) "اللون" else "Color",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary)
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        colorOptions.forEach { hex ->
                            val col = runCatching {
                                androidx.compose.ui.graphics.Color(android.graphics.Color.parseColor(hex))
                            }.getOrElse { OrbBlue }
                            val selected = newGroupColor == hex
                            Box(
                                Modifier.size(28.dp)
                                    .clip(CircleShape)
                                    .background(col)
                                    .then(
                                        if (selected) Modifier.border(2.dp, Color.White, CircleShape)
                                        else Modifier
                                    )
                                    .clickable { newGroupColor = hex }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newGroupName.isNotBlank()) {
                        viewModel.addGroup(AlarmGroup(name = newGroupName, colorHex = newGroupColor))
                        newGroupName = ""
                        newGroupColor = "#0A84FF"
                        showAddDialog = false
                    }
                }) { Text(if (isAr) "إضافة" else "Add", color = OrbBlue) }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false; newGroupName = "" }) {
                    Text(if (isAr) "إلغاء" else "Cancel")
                }
            },
            containerColor = DarkNavy
        )
    }

    LiquidGlassBackground {
        Scaffold(
            containerColor = Color.Transparent,
            topBar = {
                TopAppBar(
                    title = { Text(if (isAr) "مجموعات المنبه" else "Alarm Groups",
                        style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold)) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Filled.ArrowBack, null, tint = TextSecondary)
                        }
                    },
                    actions = {
                        IconButton(onClick = { showAddDialog = true }) {
                            Icon(Icons.Filled.Add, null, tint = OrbBlue)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                )
            }
        ) { pd ->
            if (groups.isEmpty()) {
                Box(Modifier.fillMaxSize().padding(pd), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.FolderOpen, null, tint = TextTertiary,
                            modifier = Modifier.size(64.dp))
                        Spacer(Modifier.height(12.dp))
                        Text(if (isAr) "لا توجد مجموعات" else "No groups yet",
                            style = MaterialTheme.typography.bodyLarge.copy(color = TextTertiary))
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(pd).padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp, top = 8.dp)
                ) {
                    items(groups, key = { it.id }) { group ->
                        val groupAlarms = alarms.filter { it.groupId == group.id }
                        GlassCard(Modifier.fillMaxWidth()) {
                            Row(
                                Modifier.padding(16.dp).fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Real color dot from group.colorHex
                                val dotColor = runCatching {
                                    Color(android.graphics.Color.parseColor(group.colorHex))
                                }.getOrElse { OrbBlue }
                                Box(
                                    Modifier.size(14.dp)
                                        .clip(CircleShape)
                                        .background(dotColor)
                                        .border(1.dp, Color.White.copy(0.3f), CircleShape)
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(group.name,
                                        style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        if (isAr) "${groupAlarms.size} منبه" else "${groupAlarms.size} alarms",
                                        style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary)
                                    )
                                }
                                // Toggle all in group
                                IosSwitch(
                                    checked = groupAlarms.any { it.isEnabled },
                                    onCheckedChange = { en ->
                                        viewModel.toggleGroup(group.id, en)
                                    }
                                )
                                IconButton(onClick = { viewModel.deleteGroup(group) },
                                    modifier = Modifier.size(36.dp)) {
                                    Icon(Icons.Filled.DeleteOutline, null,
                                        tint = OrbPink, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
