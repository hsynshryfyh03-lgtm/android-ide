package com.hussein.alarmpro.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.hussein.alarmpro.util.StrictModeManager

/**
 * StrictAccessibilityService — The outer fortress wall.
 *
 * Activated when Strict Mode fires. Provides three protections:
 *
 *  1. Key Guard   — intercepts VOLUME_DOWN / VOLUME_MUTE / POWER before the OS processes them
 *  2. Nav Blocker — detects Settings/SystemUI entering foreground → forces them back
 *  3. Volume Restore — immediately re-sets alarm volume to max on any key intercept
 *
 * Reads StrictModeManager companion object directly (same process, no IPC needed).
 */
class StrictAccessibilityService : AccessibilityService() {

    /** Packages that must never appear on screen while strict mode is active */
    private val BLOCKED_PACKAGES = setOf(
        "com.android.settings",
        "com.android.systemui",
        "com.samsung.android.lool",       // Samsung Device Care
        "com.samsung.android.settings",   // Samsung Settings
        "com.miui.securitycenter",         // Xiaomi Security
        "com.huawei.systemmanager",        // Huawei optimizer
        "com.oppo.safe",                   // OPPO security
        "com.coloros.safecenter",          // ColorOS
        "com.vivo.permissionmanager"       // Vivo
    )

    // ── Service lifecycle ─────────────────────────────────────────────────────

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = (serviceInfo ?: AccessibilityServiceInfo()).apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                         AccessibilityEvent.TYPE_WINDOWS_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS or
                    AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
            notificationTimeout = 50
        }
    }

    // ── Key Events (called BEFORE the OS processes the key) ───────────────────

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (!StrictModeManager.isStrictActive) return false
        if (event.action != KeyEvent.ACTION_DOWN) return false

        return when (event.keyCode) {
            KeyEvent.KEYCODE_VOLUME_DOWN,
            KeyEvent.KEYCODE_VOLUME_MUTE -> {
                // Block the key AND restore volume immediately
                restoreAlarmVolume()
                true  // consume — OS never sees this key press
            }
            KeyEvent.KEYCODE_POWER -> {
                // Best-effort block: AccessibilityService cannot always prevent power-off,
                // but the screen guard in StrictModeManager handles the aftermath.
                // We still try to consume it here.
                bringAlarmToFront()
                true
            }
            else -> false
        }
    }

    // ── Window Events ─────────────────────────────────────────────────────────

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (!StrictModeManager.isStrictActive) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOWS_CHANGED) return

        val pkg = event.packageName?.toString() ?: return

        // Never interfere with our own app
        if (pkg == applicationContext.packageName) return

        if (pkg in BLOCKED_PACKAGES) {
            // Close the intruder and return to alarm screen
            performGlobalAction(GLOBAL_ACTION_BACK)
            Handler(Looper.getMainLooper()).postDelayed({
                if (StrictModeManager.isStrictActive) bringAlarmToFront()
            }, 120)
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private fun restoreAlarmVolume() {
        runCatching {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            am.setStreamVolume(AudioManager.STREAM_ALARM, max, 0)
        }
    }

    private fun bringAlarmToFront() {
        val alarmId = StrictModeManager.strictAlarmId
        if (alarmId == -1) return
        runCatching {
            startActivity(
                Intent(this, com.hussein.alarmpro.ui.screens.RingingActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("alarm_id", alarmId)
                }
            )
        }
    }

    override fun onInterrupt() { /* no-op */ }
}
