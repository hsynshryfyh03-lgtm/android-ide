package com.hussein.alarmpro.data.db

import androidx.room.*
import com.hussein.alarmpro.data.model.WorldClockCity
import kotlinx.coroutines.flow.Flow

@Dao
interface WorldClockDao {
    @Query("SELECT * FROM world_clocks ORDER BY sortOrder ASC, id ASC")
    fun allCities(): Flow<List<WorldClockCity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(city: WorldClockCity): Long

    @Delete
    suspend fun delete(city: WorldClockCity)

    @Update
    suspend fun update(city: WorldClockCity)
}
