package com.hussein.alarmpro.tiles

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.hussein.alarmpro.MainActivity

class TimerTileService : TileService() {
    override fun onStartListening() {
        qsTile?.apply { state = Tile.STATE_INACTIVE; updateTile() }
    }
    override fun onClick() {
        startActivityAndCollapse(
            Intent(this, MainActivity::class.java)
                .putExtra("openTab", 2) // Timer tab
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
