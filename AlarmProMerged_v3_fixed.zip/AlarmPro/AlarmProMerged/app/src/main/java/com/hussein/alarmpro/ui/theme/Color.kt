package com.hussein.alarmpro.ui.theme

import androidx.compose.ui.graphics.Color

// ── Xiaomi HyperOS / MIUI Color System ───────────────────────────────────────

// Primary: MIUI Blue (classic Xiaomi signature blue)
val MiBlue           = Color(0xFF1296DB)
val MiBlueDark       = Color(0xFF0D7AB8)
val MiBlueLight      = Color(0xFF40AADF)

// Xiaomi Orange (accent for timer/alerts)
val MiOrange         = Color(0xFFFF6900)
val MiOrangeLight    = Color(0xFFFF8C3A)

// HyperOS Backgrounds (dark)
val HyperBg          = Color(0xFF0A0A0A)   // true dark
val HyperSurface     = Color(0xFF1C1C1E)   // card background
val HyperSurface2    = Color(0xFF2C2C2E)   // elevated surface
val HyperSurface3    = Color(0xFF3A3A3C)   // input/dividers

// Text
val HyperTextPrimary    = Color(0xFFFFFFFF)
val HyperTextSecondary  = Color(0xFFAEAEB2)
val HyperTextTertiary   = Color(0xFF636366)
val HyperTextDisabled   = Color(0xFF48484A)

// Separator
val HyperSeparator   = Color(0xFF38383A)
val HyperSeparatorSub = Color(0xFF2C2C2E)

// Status colors (MIUI system colors)
val MiGreen          = Color(0xFF34C759)
val MiRed            = Color(0xFFFF3B30)
val MiYellow         = Color(0xFFFFCC00)
val MiPurple         = Color(0xFFAF52DE)
val MiCyan           = Color(0xFF32ADE6)
val MiPink           = Color(0xFFFF2D55)

// HyperOS Toggle
val HyperToggleOn    = Color(0xFF1296DB)   // MIUI blue when ON
val HyperToggleOff   = Color(0xFF3A3A3C)

// Stopwatch — teal/cyan accent
val StopwatchAccent  = Color(0xFF00C7BE)
val StopwatchLap     = Color(0xFF32ADE6)

// Timer — orange accent
val TimerAccent      = Color(0xFFFF6900)
val TimerExpired     = Color(0xFFFF3B30)

// World Clock — blue accent
val ClockAccent      = Color(0xFF1296DB)

// Analog clock
val ClockFaceColor   = Color(0xFF1C1C1E)
val ClockRing        = Color(0xFF3A3A3C)
val ClockHourHand    = Color(0xFFFFFFFF)
val ClockMinHand     = Color(0xCCFFFFFF)
val ClockSecHand     = Color(0xFFFF6900)   // Xiaomi orange seconds hand
val ClockTick        = Color(0x80FFFFFF)
val ClockCenter      = Color(0xFF1296DB)
val ClockNumber      = Color(0xB3FFFFFF)

// Legacy aliases (for files not yet migrated)
val DeepBlack        = HyperBg
val DarkNavy         = HyperSurface
val DarkSurface      = HyperSurface2
val OrbBlue          = MiBlue
val OrbPurple        = MiPurple
val OrbIndigo        = Color(0xFF6B5CFE)
val OrbCyan          = MiCyan
val OrbPink          = MiPink
val OrbMint          = StopwatchAccent
val OrbOrange        = MiOrange
val GlassBg          = Color(0x1AFFFFFF)
val GlassBgHeavy     = Color(0x2BFFFFFF)
val GlassBorder      = Color(0x33FFFFFF)
val GlassBorderLight = Color(0x1AFFFFFF)
val GlassHighlight   = Color(0x3DFFFFFF)
val GlassThin        = Color(0x0DFFFFFF)
val GlassBgUltra     = Color(0x3DFFFFFF)
val GlassShimmer     = Color(0x0AFFFFFF)
val GlassInnerShadow = Color(0x1A000000)
val TextPrimary      = HyperTextPrimary
val TextSecondary    = HyperTextSecondary
val TextTertiary     = HyperTextTertiary
val TextQuaternary   = Color(0x2EFFFFFF)
val TextAccent       = MiBlue
val SystemGreen      = MiGreen
val SystemRed        = MiRed
val SystemYellow     = MiYellow
val ToggleOn         = HyperToggleOn
val ToggleOff        = HyperToggleOff
val Separator        = HyperSeparator
val SeparatorOpaque  = HyperSeparator
