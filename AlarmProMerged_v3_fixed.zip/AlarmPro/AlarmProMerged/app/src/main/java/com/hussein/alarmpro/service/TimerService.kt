package com.hussein.alarmpro.service

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.hussein.alarmpro.MainActivity
import com.hussein.alarmpro.R

class TimerService : Service() {

    companion object {
        const val CHANNEL_ID = "timer_channel"
        const val NOTIF_ID   = 8001
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action   = intent?.action ?: "START"
        val timerId  = intent?.getIntExtra("timerId", -1) ?: -1

        when (action) {
            "START" -> startFg(timerId)
            "STOP"  -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startFg(timerId: Int) {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).putExtra("openTab", 2),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_alarm_notif)
            .setContentTitle("Timer Running")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        startForeground(NOTIF_ID, notif)
    }

    private fun createChannel() {
        val ch = NotificationChannel(
            CHANNEL_ID, "Timer", NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java)?.createNotificationChannel(ch)
    }
}
