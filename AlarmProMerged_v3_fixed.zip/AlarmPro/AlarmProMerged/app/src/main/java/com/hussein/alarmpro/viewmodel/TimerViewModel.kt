package com.hussein.alarmpro.viewmodel

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hussein.alarmpro.data.model.TimerItem
import com.hussein.alarmpro.data.model.TimerState
import com.hussein.alarmpro.data.repository.TimerRepository
import com.hussein.alarmpro.service.TimerService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

@HiltViewModel
class TimerViewModel @Inject constructor(
    private val repo: TimerRepository,
    @ApplicationContext private val context: Context
) : ViewModel() {

    val timers: StateFlow<List<TimerItem>> = repo.allTimers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // In-memory countdown jobs keyed by timer id
    private val jobs = mutableMapOf<Int, Job>()

    fun addTimer(hours: Int, minutes: Int, seconds: Int, label: String = "") {
        val totalMs = ((hours * 3600) + (minutes * 60) + seconds) * 1000L
        if (totalMs <= 0) return
        viewModelScope.launch {
            repo.insert(TimerItem(totalMillis = totalMs, remainingMillis = totalMs, label = label))
        }
    }

    fun startTimer(timer: TimerItem) {
        if (timer.state == TimerState.RUNNING) return
        val updated = timer.copy(state = TimerState.RUNNING)
        viewModelScope.launch { repo.update(updated) }
        scheduleCountdown(updated)
        startForegroundService(timer.id)
    }

    fun pauseTimer(timer: TimerItem) {
        jobs[timer.id]?.cancel()
        viewModelScope.launch {
            repo.update(timer.copy(state = TimerState.PAUSED))
        }
        stopForegroundService(timer.id)
    }

    fun resetTimer(timer: TimerItem) {
        jobs[timer.id]?.cancel()
        viewModelScope.launch {
            repo.update(timer.copy(state = TimerState.IDLE, remainingMillis = timer.totalMillis))
        }
        stopForegroundService(timer.id)
    }

    fun deleteTimer(timer: TimerItem) {
        jobs[timer.id]?.cancel()
        viewModelScope.launch { repo.delete(timer) }
        stopForegroundService(timer.id)
    }

    private fun scheduleCountdown(timer: TimerItem) {
        jobs[timer.id]?.cancel()
        jobs[timer.id] = viewModelScope.launch {
            var remaining = timer.remainingMillis
            val tick = 100L
            while (remaining > 0 && isActive) {
                delay(tick)
                remaining -= tick
                val currentTimers = timers.value
                val t = currentTimers.find { it.id == timer.id } ?: break
                if (t.state != TimerState.RUNNING) break
                repo.update(t.copy(remainingMillis = remaining.coerceAtLeast(0)))
            }
            if (remaining <= 0) {
                val t = timers.value.find { it.id == timer.id }
                if (t != null) repo.update(t.copy(state = TimerState.EXPIRED, remainingMillis = 0))
            }
        }
    }

    private fun startForegroundService(timerId: Int) {
        runCatching {
            context.startService(
                Intent(context, TimerService::class.java)
                    .putExtra("timerId", timerId)
                    .setAction("START")
            )
        }
    }

    private fun stopForegroundService(timerId: Int) {
        runCatching {
            context.startService(
                Intent(context, TimerService::class.java)
                    .putExtra("timerId", timerId)
                    .setAction("STOP")
            )
        }
    }
}
