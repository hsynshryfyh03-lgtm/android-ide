package com.hussein.alarmpro.data.repository

import com.hussein.alarmpro.data.db.TimerDao
import com.hussein.alarmpro.data.model.TimerItem
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TimerRepository @Inject constructor(private val dao: TimerDao) {
    val allTimers: Flow<List<TimerItem>> = dao.allTimers()
    suspend fun insert(t: TimerItem): Long = dao.insert(t)
    suspend fun update(t: TimerItem) = dao.update(t)
    suspend fun delete(t: TimerItem) = dao.delete(t)
    suspend fun resetAll() = dao.resetAll()
}
