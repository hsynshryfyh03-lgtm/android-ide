package com.hussein.alarmpro.data.db

import androidx.room.*
import com.hussein.alarmpro.data.model.TimerItem
import kotlinx.coroutines.flow.Flow

@Dao
interface TimerDao {
    @Query("SELECT * FROM timers ORDER BY createdAt ASC")
    fun allTimers(): Flow<List<TimerItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(timer: TimerItem): Long

    @Update
    suspend fun update(timer: TimerItem)

    @Delete
    suspend fun delete(timer: TimerItem)

    @Query("UPDATE timers SET state=0, remainingMillis=totalMillis")
    suspend fun resetAll()
}
