package com.hussein.alarmpro.ui.screens

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.hussein.alarmpro.admin.AlarmDeviceAdmin
import com.hussein.alarmpro.data.datastore.AlarmTemplateStore
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.ExportImport
import com.hussein.alarmpro.util.TimeUtils
import com.hussein.alarmpro.util.XiaomiHelper
import com.hussein.alarmpro.viewmodel.AlarmViewModel
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.TopAppBar
import top.yukonga.miuix.kmp.basic.MiuixScrollBehavior
import top.yukonga.miuix.kmp.basic.rememberTopAppBarState
import top.yukonga.miuix.kmp.extra.SuperArrow
import top.yukonga.miuix.kmp.extra.SuperSwitch
import top.yukonga.miuix.kmp.extra.SuperDropdown

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: AlarmViewModel,
    onBack: () -> Unit,
    onAlarmGroups: () -> Unit = {},
    onVacationMode: () -> Unit = {}
) {
    val isAr     = TimeUtils.isArabic()
    val ctx      = LocalContext.current
    val template by viewModel.template.collectAsState()
    var local    by remember(template) { mutableStateOf(template) }

    var showImportDialog by remember { mutableStateOf(false) }
    var importJson       by remember { mutableStateOf<String?>(null) }

    val adminLauncher  = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {}
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) ExportImport.writeToUri(ctx, uri, viewModel.exportJson())
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val json = ExportImport.readFromUri(ctx, uri)
            if (json != null) { importJson = json; showImportDialog = true }
        }
    }

    if (showImportDialog && importJson != null) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            containerColor   = HyperSurface,
            title = { Text(if (isAr) "استيراد؟" else "Import?", color = HyperTextPrimary) },
            text  = {
                val count = runCatching { ExportImport.importFromJson(importJson!!).size }.getOrDefault(0)
                Text(if (isAr) "سيتم إضافة $count منبه" else "Will add $count alarms", color = HyperTextSecondary)
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.importFromJson(importJson!!); showImportDialog = false },
                    colors  = ButtonDefaults.buttonColors(containerColor = MiBlue)
                ) { Text(if (isAr) "استيراد" else "Import") }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text(if (isAr) "إلغاء" else "Cancel", color = HyperTextSecondary)
                }
            }
        )
    }

    val scrollBehavior = MiuixScrollBehavior(rememberTopAppBarState())

    Scaffold(
        containerColor = HyperBg,
        topBar = {
            TopAppBar(
                title              = if (isAr) "الإعدادات" else "Settings",
                scrollBehavior     = scrollBehavior,
                navigationIcon     = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Rounded.ArrowBackIosNew, null, tint = MiBlue)
                    }
                },
                color = HyperBg
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .background(HyperBg)
                .padding(bottom = 32.dp)
        ) {

            // ── Default alarm settings ────────────────────────────────────
            SectionHeader(if (isAr) "إعدادات المنبه الافتراضية" else "Default Alarm Settings")
            Card(modifier = Modifier.padding(horizontal = 16.dp)) {
                Column {
                    // Gradual volume
                    SuperSwitch(
                        title    = if (isAr) "تصاعد الصوت" else "Gradual Volume",
                        summary  = if (isAr) "يبدأ هادئاً ويتصاعد تدريجياً" else "Starts quiet, builds up gradually",
                        checked  = local.gradualVolume,
                        onCheckedChange = { local = local.copy(gradualVolume = it); viewModel.saveTemplate(local) }
                    )
                    MiuixDivider()
                    // Vibration
                    SuperSwitch(
                        title    = if (isAr) "الاهتزاز" else "Vibration",
                        summary  = if (isAr) "اهتزاز افتراضي مع المنبه" else "Vibrate with alarm by default",
                        checked  = local.isVibrate,
                        onCheckedChange = { local = local.copy(isVibrate = it); viewModel.saveTemplate(local) }
                    )
                    MiuixDivider()
                    // Bypass DND
                    SuperSwitch(
                        title    = if (isAr) "تجاوز عدم الإزعاج" else "Bypass Do Not Disturb",
                        summary  = if (isAr) "يُنبّه حتى في وضع صامت" else "Ring even in silent mode",
                        checked  = local.bypassDnd,
                        onCheckedChange = { local = local.copy(bypassDnd = it); viewModel.saveTemplate(local) }
                    )
                    MiuixDivider()
                    // Snooze
                    SuperSwitch(
                        title    = if (isAr) "الغفوة" else "Snooze",
                        summary  = if (isAr) "تأجيل المنبه" else "Allow alarm snooze",
                        checked  = local.isSnoozeEnabled,
                        onCheckedChange = { local = local.copy(isSnoozeEnabled = it); viewModel.saveTemplate(local) }
                    )
                }
            }

            // ── Organization ──────────────────────────────────────────────
            SectionHeader(if (isAr) "التنظيم" else "Organization")
            Card(modifier = Modifier.padding(horizontal = 16.dp)) {
                Column {
                    SuperArrow(
                        title   = if (isAr) "مجموعات المنبهات" else "Alarm Groups",
                        summary = if (isAr) "تنظيم المنبهات في مجموعات" else "Organize alarms into groups",
                        onClick = onAlarmGroups
                    )
                    MiuixDivider()
                    SuperArrow(
                        title   = if (isAr) "وضع الإجازة" else "Vacation Mode",
                        summary = if (isAr) "تعطيل المنبهات خلال فترة محددة" else "Disable alarms for a period",
                        onClick = onVacationMode
                    )
                }
            }

            // ── Backup & Restore ──────────────────────────────────────────
            SectionHeader(if (isAr) "النسخ الاحتياطي" else "Backup & Restore")
            Card(modifier = Modifier.padding(horizontal = 16.dp)) {
                Column {
                    SuperArrow(
                        title   = if (isAr) "تصدير المنبهات" else "Export Alarms",
                        summary = if (isAr) "حفظ كملف JSON" else "Save as JSON file",
                        onClick = { exportLauncher.launch("alarms_backup.json") }
                    )
                    MiuixDivider()
                    SuperArrow(
                        title   = if (isAr) "استيراد المنبهات" else "Import Alarms",
                        summary = if (isAr) "استعادة من ملف JSON" else "Restore from JSON file",
                        onClick = { importLauncher.launch(arrayOf("application/json", "*/*")) }
                    )
                }
            }

            // ── Xiaomi / MIUI ─────────────────────────────────────────────
            val isXiaomi = remember { XiaomiHelper.isMiui() }
            if (isXiaomi) {
                SectionHeader(if (isAr) "إعدادات شاومي" else "Xiaomi Settings")
                Card(modifier = Modifier.padding(horizontal = 16.dp)) {
                    Column {
                        SuperArrow(
                            title   = if (isAr) "إعدادات البطارية (MIUI)" else "Battery Settings (MIUI)",
                            summary = if (isAr) "تعطيل تحسين البطارية لضمان عمل المنبه" else "Disable battery optimization for reliable alarms",
                            onClick = { XiaomiHelper.openBatterySettings(ctx) }
                        )
                        MiuixDivider()
                        SuperArrow(
                            title   = if (isAr) "إعدادات الإشعارات (MIUI)" else "Notification Settings (MIUI)",
                            summary = if (isAr) "السماح للتطبيق بالعمل في الخلفية" else "Allow app to run in background",
                            onClick = { XiaomiHelper.openNotificationSettings(ctx) }
                        )
                    }
                }
            }

            // ── Advanced / Strict Mode ────────────────────────────────────
            SectionHeader(if (isAr) "متقدم" else "Advanced")
            Card(modifier = Modifier.padding(horizontal = 16.dp)) {
                Column {
                    // Device Admin
                    val dpm     = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                    val compName = ComponentName(ctx, AlarmDeviceAdmin::class.java)
                    val isAdmin  = dpm.isAdminActive(compName)
                    SuperSwitch(
                        title    = if (isAr) "صلاحية مدير الجهاز" else "Device Admin Permission",
                        summary  = if (isAr) "مطلوب لوضع الصارم" else "Required for strict mode",
                        checked  = isAdmin,
                        onCheckedChange = { enabled ->
                            if (enabled) {
                                adminLauncher.launch(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                                    putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, compName)
                                })
                            } else {
                                dpm.removeActiveAdmin(compName)
                            }
                        }
                    )
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun SectionHeader(text: String) {
    SmallTitle(
        text     = text,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 4.dp)
    )
}

@Composable
private fun MiuixDivider() {
    HorizontalDivider(
        modifier  = Modifier.padding(horizontal = 16.dp),
        thickness = 0.5.dp,
        color     = HyperSeparator
    )
}
