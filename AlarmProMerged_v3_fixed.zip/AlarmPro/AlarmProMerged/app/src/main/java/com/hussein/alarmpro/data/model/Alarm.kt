package com.hussein.alarmpro.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * days bitmask: bit0=Sun bit1=Mon bit2=Tue bit3=Wed bit4=Thu bit5=Fri bit6=Sat
 * days=0 → one-time alarm  |  days=-1 → specific date (use scheduledDate)
 */
@Entity(tableName = "alarms")
data class Alarm(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val hour: Int = 7,
    val minute: Int = 0,
    val label: String = "",
    val isEnabled: Boolean = true,
    val days: Int = 0,
    val scheduledDate: Long = 0L,
    val soundUri: String = "",
    val soundName: String = "",
    val volumePercent: Int = 80,
    val bypassDnd: Boolean = true,
    val gradualVolume: Boolean = true,
    val gradualVolumeDurationSec: Int = 30,
    val isVibrate: Boolean = true,
    val vibrationPattern: Int = 1,
    val isSnoozeEnabled: Boolean = true,
    val snoozeMinutes: Int = 9,
    val snoozeReduceMinutes: Int = 0,
    val snoozeMaxCount: Int = -1,
    val autoSnoozeMinutes: Int = -1,
    val dismissType: Int = 0,
    val dismissTask: Int = 0,
    val dismissTaskDifficulty: Int = 1,
    val autoDissmissMinutes: Int = -1,
    val wakeCheckEnabled: Boolean = false,
    val wakeCheckDelayMinutes: Int = 5,
    val wakeCheckCountdownMinutes: Int = 2,
    val ringBgUri: String = "",
    val preAlarmNotifyMinutes: Int = 5,
    val skipToday: Boolean = false,
    val bedtimeEnabled: Boolean = false,
    val sleepHours: Int = 8,
    val groupId: Int = 0,
    val vacationExempt: Boolean = false,
    // ── Strict Mode ──────────────────────────────────────────────────────────
    // When true: task mandatory, volume guarded, settings blocked, screen guarded
    val strictMode: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
