package com.hussein.alarmpro.ui.nav

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.*
import androidx.navigation.compose.*
import com.hussein.alarmpro.MainActivity
import com.hussein.alarmpro.ui.screens.*
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.AlarmScheduler
import com.hussein.alarmpro.util.TimeUtils
import com.hussein.alarmpro.viewmodel.*

// ─────────────────────────────────────────────────────────────────────────────
// Route definitions
// ─────────────────────────────────────────────────────────────────────────────
sealed class Screen(val route: String) {
    // Main tabs
    object Alarms      : Screen("alarms")
    object Stopwatch   : Screen("stopwatch")
    object Timer       : Screen("timer")
    object WorldClock  : Screen("world_clock")

    // Sub-screens (pushed onto back-stack from Alarms tab)
    object AddAlarm    : Screen("add_alarm")
    object EditAlarm   : Screen("edit_alarm/{alarmId}") {
        fun createRoute(id: Int) = "edit_alarm/$id"
    }
    object Settings    : Screen("settings")
    object AlarmGroups : Screen("alarm_groups")
    object VacationMode: Screen("vacation_mode")

    // Legacy alias used by older screens
    object Home        : Screen("alarms")
}

// ─────────────────────────────────────────────────────────────────────────────
// Bottom tab model
// ─────────────────────────────────────────────────────────────────────────────
private data class TabItem(
    val label: String,
    val labelAr: String,
    val icon: ImageVector,
    val iconSelected: ImageVector = icon,
    val route: String
)

private val tabs = listOf(
    TabItem("Alarm",    "منبه",      Icons.Rounded.Alarm,    Icons.Rounded.Alarm,     Screen.Alarms.route),
    TabItem("Stopwatch","كرونومتر",  Icons.Rounded.Timer,    Icons.Rounded.Timer,     Screen.Stopwatch.route),
    TabItem("Timer",    "مؤقت",      Icons.Rounded.HourglassTop, Icons.Rounded.HourglassTop, Screen.Timer.route),
    TabItem("World",    "عالمي",     Icons.Rounded.Public,   Icons.Rounded.Public,    Screen.WorldClock.route),
)

// ─────────────────────────────────────────────────────────────────────────────
// Root composable
// ─────────────────────────────────────────────────────────────────────────────
@OptIn(ExperimentalAnimationApi::class)
@Composable
fun NavGraph(
    scheduler: AlarmScheduler,
    startTab: Int = 0
) {
    val navController = rememberNavController()
    val isAr          = TimeUtils.isArabic()
    val alarmVm: AlarmViewModel      = hiltViewModel()
    val timerVm: TimerViewModel      = hiltViewModel()
    val worldVm: WorldClockViewModel = hiltViewModel()

    // Observe import intent
    val pendingImport by MainActivity.pendingImportJson.collectAsState()
    var showImportDialog by remember { mutableStateOf(false) }
    var importJson       by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(pendingImport) {
        if (pendingImport != null) { importJson = pendingImport; showImportDialog = true }
    }

    // Navigate to correct tab from notification/tile deeplink
    LaunchedEffect(startTab) {
        if (startTab in 1..3) {
            val route = tabs[startTab].route
            navController.navigate(route) { launchSingleTop = true }
        }
    }

    // Which routes have the bottom bar visible
    val tabRoutes = tabs.map { it.route }.toSet()
    val currentBack by navController.currentBackStackEntryAsState()
    val currentRoute = currentBack?.destination?.route
    val showBottomBar = currentRoute in tabRoutes

    // Import dialog
    if (showImportDialog && importJson != null) {
        val count = remember(importJson) {
            runCatching {
                com.hussein.alarmpro.util.ExportImport.importFromJson(importJson!!).size
            }.getOrDefault(0)
        }
        AlertDialog(
            onDismissRequest = { showImportDialog = false; MainActivity.clearPendingImport() },
            containerColor = HyperSurface,
            title = { Text(if (isAr) "استيراد المنبهات؟" else "Import Alarms?", color = HyperTextPrimary) },
            text  = {
                Text(
                    if (isAr) "سيتم إضافة $count منبه" else "Will add $count alarms",
                    color = HyperTextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = { alarmVm.importFromJson(importJson!!); showImportDialog = false; MainActivity.clearPendingImport() },
                    colors = ButtonDefaults.buttonColors(containerColor = MiBlue)
                ) { Text(if (isAr) "استيراد" else "Import") }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false; MainActivity.clearPendingImport() }) {
                    Text(if (isAr) "إلغاء" else "Cancel", color = HyperTextSecondary)
                }
            }
        )
    }

    Scaffold(
        containerColor = HyperBg,
        bottomBar = {
            AnimatedVisibility(
                visible = showBottomBar,
                enter   = slideInVertically { it } + fadeIn(),
                exit    = slideOutVertically { it } + fadeOut()
            ) {
                MiuixBottomNavBar(
                    tabs      = tabs,
                    current   = currentRoute ?: Screen.Alarms.route,
                    isAr      = isAr,
                    onSelect  = { route ->
                        navController.navigate(route) {
                            popUpTo(navController.graph.startDestinationId) { saveState = true }
                            launchSingleTop = true
                            restoreState    = true
                        }
                    }
                )
            }
        }
    ) { padding ->
        NavHost(
            navController        = navController,
            startDestination     = Screen.Alarms.route,
            modifier             = Modifier.padding(padding),
            enterTransition      = { fadeIn(tween(200)) + slideInHorizontally { it / 4 } },
            exitTransition       = { fadeOut(tween(150)) },
            popEnterTransition   = { fadeIn(tween(200)) + slideInHorizontally { -it / 4 } },
            popExitTransition    = { fadeOut(tween(150)) + slideOutHorizontally { it / 4 } }
        ) {
            // ── TAB 1: Alarms ──────────────────────────────────────────────
            composable(Screen.Alarms.route) {
                HomeScreen(
                    viewModel  = alarmVm,
                    scheduler  = scheduler,
                    onAddAlarm = { navController.navigate(Screen.AddAlarm.route) },
                    onEditAlarm = { alarm -> navController.navigate(Screen.EditAlarm.createRoute(alarm.id)) },
                    onSettings = { navController.navigate(Screen.Settings.route) }
                )
            }

            // ── TAB 2: Stopwatch ───────────────────────────────────────────
            composable(Screen.Stopwatch.route) {
                val stopVm: StopwatchViewModel = hiltViewModel()
                StopwatchScreen(vm = stopVm)
            }

            // ── TAB 3: Timer ───────────────────────────────────────────────
            composable(Screen.Timer.route) {
                TimerScreen(vm = timerVm)
            }

            // ── TAB 4: World Clock ─────────────────────────────────────────
            composable(Screen.WorldClock.route) {
                WorldClockScreen(vm = worldVm)
            }

            // ── Sub-screens (no bottom bar) ────────────────────────────────
            composable(Screen.AddAlarm.route) {
                EditAlarmScreen(
                    alarm     = null,
                    viewModel = alarmVm,
                    onBack    = { navController.popBackStack() }
                )
            }

            composable(
                Screen.EditAlarm.route,
                arguments = listOf(navArgument("alarmId") { type = NavType.IntType })
            ) { back ->
                val id    = back.arguments?.getInt("alarmId") ?: return@composable
                val alarms by alarmVm.alarms.collectAsState()
                val alarm = alarms.find { it.id == id }
                EditAlarmScreen(alarm = alarm, viewModel = alarmVm, onBack = { navController.popBackStack() })
            }

            composable(Screen.Settings.route) {
                SettingsScreen(
                    viewModel      = alarmVm,
                    onBack         = { navController.popBackStack() },
                    onAlarmGroups  = { navController.navigate(Screen.AlarmGroups.route) },
                    onVacationMode = { navController.navigate(Screen.VacationMode.route) }
                )
            }

            composable(Screen.AlarmGroups.route) {
                AlarmGroupsScreen(viewModel = alarmVm, onBack = { navController.popBackStack() })
            }

            composable(Screen.VacationMode.route) {
                VacationModeScreen(viewModel = alarmVm, onBack = { navController.popBackStack() })
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Miuix-style Bottom Navigation Bar
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun MiuixBottomNavBar(
    tabs: List<TabItem>,
    current: String,
    isAr: Boolean,
    onSelect: (String) -> Unit
) {
    NavigationBar(
        containerColor    = HyperSurface,
        contentColor      = HyperTextSecondary,
        tonalElevation    = 0.dp,
        modifier          = Modifier
    ) {
        tabs.forEach { tab ->
            val selected = current == tab.route
            NavigationBarItem(
                selected = selected,
                onClick  = { onSelect(tab.route) },
                icon = {
                    Icon(
                        imageVector = if (selected) tab.iconSelected else tab.icon,
                        contentDescription = null,
                        modifier = Modifier.size(24.dp)
                    )
                },
                label = {
                    Text(
                        text       = if (isAr) tab.labelAr else tab.label,
                        fontSize   = 11.sp,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                        maxLines   = 1
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor       = MiBlue,
                    selectedTextColor       = MiBlue,
                    unselectedIconColor     = HyperTextTertiary,
                    unselectedTextColor     = HyperTextTertiary,
                    indicatorColor          = MiBlue.copy(alpha = 0.15f)
                )
            )
        }
    }
}
