package com.hussein.alarmpro.util

import android.content.Context
import android.content.res.AssetFileDescriptor
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

const val ASSET_SOUND_PREFIX = "asset://"
private const val SOUNDS_DIR = "sounds"
private const val TAG = "SoundManager"
private val SUPPORTED_EXTENSIONS = setOf("mp3", "ogg", "wav", "m4a", "aac", "flac")

data class BuiltinSound(
    val fileName: String,   // actual file name in assets/sounds/  e.g. "morning.mp3"
    val displayName: String // friendly name shown in UI (derived from file name)
) {
    val uri: String get() = "$ASSET_SOUND_PREFIX$fileName"
}

/**
 * Scans assets/sounds/ at runtime — no manual registration needed.
 * Just drop any audio file in the folder and it appears automatically.
 */
fun loadBuiltinSounds(context: Context): List<BuiltinSound> {
    val result = mutableListOf(
        BuiltinSound("default", if (TimeUtils.isArabic()) "النغمة الافتراضية" else "Default Ringtone")
    )
    runCatching {
        val files = context.assets.list(SOUNDS_DIR) ?: return@runCatching
        files
            .filter { file ->
                val ext = file.substringAfterLast('.', "").lowercase()
                ext in SUPPORTED_EXTENSIONS
            }
            .sorted()
            .forEach { file ->
                val name = file
                    .substringBeforeLast('.')
                    .replace('_', ' ')
                    .replace('-', ' ')
                    .split(' ')
                    .joinToString(" ") { word -> word.replaceFirstChar { it.uppercaseChar() } }
                result.add(BuiltinSound(fileName = file, displayName = name))
            }
    }
    return result
}

@Singleton
class SoundManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var mediaPlayer: MediaPlayer? = null
    private val audioManager: AudioManager =
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var focusRequest: AudioFocusRequest? = null

    /** Volume that was set before we changed it – restored when alarm stops */
    private var savedAlarmVolume: Int = -1

    /** Lazily loaded list of all sounds found in assets/sounds/ */
    val builtinSounds: List<BuiltinSound> by lazy { loadBuiltinSounds(context) }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Start playing alarm sound at the given volume percent.
     * Saves the current system alarm-stream volume so [stop] can restore it.
     * Ensures alarm stream is never muted, even in DND/silent mode.
     */
    fun play(soundUri: String, volumePercent: Int) {
        safeStop()                       // stop any previous playback first
        saveAndBoostAlarmVolume(volumePercent)
        requestAudioFocus()
        mediaPlayer = buildPlayer(soundUri)
        Log.d(TAG, "play() → volumePercent=$volumePercent soundUri=$soundUri player=$mediaPlayer")
    }

    /**
     * Update the system alarm-stream volume in real time (for gradual ramp).
     * Safe to call at any time.
     */
    fun setVolume(percent: Int) {
        setStreamVolume(percent)
    }

    /**
     * Stop playback, abandon audio focus, and restore the alarm-stream volume
     * to whatever it was before [play] was called.
     */
    fun stop() {
        safeStop()
        abandonAudioFocus()
        restoreAlarmVolume()
        Log.d(TAG, "stop() complete")
    }

    val isPlaying: Boolean
        get() = runCatching { mediaPlayer?.isPlaying == true }.getOrDefault(false)

    // ── Internal helpers ──────────────────────────────────────────────────────

    /** Release MediaPlayer safely regardless of its internal state. */
    private fun safeStop() {
        runCatching {
            mediaPlayer?.let { mp ->
                runCatching { mp.stop() }
                runCatching { mp.reset() }
                runCatching { mp.release() }
            }
        }
        mediaPlayer = null
    }

    /**
     * Save current alarm stream volume, then set it to [percent] % of max.
     * If the stream was muted (vol == 0), we still save 0 but play at [percent].
     * On stop, we'll restore the saved value so the user's preference is kept.
     */
    private fun saveAndBoostAlarmVolume(percent: Int) {
        savedAlarmVolume = audioManager.getStreamVolume(AudioManager.STREAM_ALARM)
        setStreamVolume(percent)
    }

    private fun setStreamVolume(percent: Int) {
        runCatching {
            val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            val target = (max * percent / 100).coerceIn(1, max) // never 0 during alarm
            audioManager.setStreamVolume(AudioManager.STREAM_ALARM, target, 0)
        }
    }

    private fun restoreAlarmVolume() {
        if (savedAlarmVolume < 0) return
        runCatching {
            val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            // Restore but keep at least 1 so future alarms aren't silent by accident
            val restore = savedAlarmVolume.coerceIn(0, max)
            audioManager.setStreamVolume(AudioManager.STREAM_ALARM, restore, 0)
        }
        savedAlarmVolume = -1
    }

    // ── MediaPlayer builders (all use prepareAsync to avoid blocking) ─────────

    private fun buildPlayer(soundUri: String): MediaPlayer? {
        return when {
            soundUri.startsWith(ASSET_SOUND_PREFIX) -> {
                val fileName = soundUri.removePrefix(ASSET_SOUND_PREFIX)
                if (fileName == "default") buildDefaultPlayer()
                else buildAssetPlayer("$SOUNDS_DIR/$fileName")
            }
            soundUri.isNotBlank() -> buildUriPlayer(Uri.parse(soundUri))
            else -> buildDefaultPlayer()
        }
    }

    private fun buildAssetPlayer(assetPath: String): MediaPlayer? = runCatching {
        val afd: AssetFileDescriptor = context.assets.openFd(assetPath)
        buildBasePlayer().apply {
            setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            setOnPreparedListener { it.start() }
            setOnErrorListener { _, what, extra ->
                Log.w(TAG, "MediaPlayer error (asset) what=$what extra=$extra – falling back")
                safeStop()
                mediaPlayer = buildDefaultPlayer()
                true
            }
            prepareAsync()
        }
    }.getOrElse {
        Log.w(TAG, "buildAssetPlayer failed: $it")
        buildDefaultPlayer()
    }

    private fun buildUriPlayer(uri: Uri): MediaPlayer? = runCatching {
        buildBasePlayer().apply {
            setDataSource(context, uri)
            setOnPreparedListener { it.start() }
            setOnErrorListener { _, what, extra ->
                Log.w(TAG, "MediaPlayer error (uri) what=$what extra=$extra – falling back")
                safeStop()
                mediaPlayer = buildDefaultPlayer()
                true
            }
            prepareAsync()
        }
    }.getOrElse {
        Log.w(TAG, "buildUriPlayer failed: $it")
        buildDefaultPlayer()
    }

    private fun buildDefaultPlayer(): MediaPlayer? = runCatching {
        buildBasePlayer().apply {
            setDataSource(context, Settings.System.DEFAULT_ALARM_ALERT_URI)
            setOnPreparedListener { it.start() }
            setOnErrorListener { _, what, extra ->
                Log.e(TAG, "Default player error what=$what extra=$extra")
                true
            }
            prepareAsync()
        }
    }.getOrElse {
        Log.e(TAG, "buildDefaultPlayer failed: $it")
        null
    }

    private fun buildBasePlayer(): MediaPlayer = MediaPlayer().apply {
        setAudioAttributes(alarmAudioAttrs())
        isLooping = true
    }

    private fun alarmAudioAttrs() = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ALARM)
        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
        .build()

    // ── Audio focus ───────────────────────────────────────────────────────────

    private fun requestAudioFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            focusRequest = AudioFocusRequest
                .Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                .setAudioAttributes(alarmAudioAttrs())
                .setWillPauseWhenDucked(false)
                .setAcceptsDelayedFocusGain(false)
                .build()
            audioManager.requestAudioFocus(focusRequest!!)
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(
                null, AudioManager.STREAM_ALARM,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE
            )
        }
    }

    private fun abandonAudioFocus() {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && focusRequest != null) {
                audioManager.abandonAudioFocusRequest(focusRequest!!)
                focusRequest = null
            } else {
                @Suppress("DEPRECATION")
                audioManager.abandonAudioFocus(null)
            }
        }
    }
}
