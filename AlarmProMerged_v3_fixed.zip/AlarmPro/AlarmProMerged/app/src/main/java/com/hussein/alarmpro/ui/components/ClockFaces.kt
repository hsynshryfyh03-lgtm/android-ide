package com.hussein.alarmpro.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.hussein.alarmpro.ui.theme.*
import kotlinx.coroutines.delay
import java.util.Calendar
import kotlin.math.*

enum class ClockFaceStyle { CLASSIC, MODERN, DIGITAL, MINIMAL }

@Composable
fun AnalogClockWithFace(
    face: ClockFaceStyle = ClockFaceStyle.CLASSIC,
    size: Dp = 200.dp,
    modifier: Modifier = Modifier
) {
    var cal by remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) { while (true) { cal = Calendar.getInstance(); delay(1000) } }

    val infiniteTransition = rememberInfiniteTransition(label = "ring")
    val ringRotation by infiniteTransition.animateFloat(
        0f, 360f,
        animationSpec = infiniteRepeatable(tween(20_000, easing = LinearEasing)),
        label = "ring"
    )

    when (face) {
        ClockFaceStyle.CLASSIC -> ClassicClock(cal, ringRotation, size, modifier)
        ClockFaceStyle.MODERN  -> ModernClock(cal, size, modifier)
        ClockFaceStyle.DIGITAL -> DigitalClockFace(cal, size, modifier)
        ClockFaceStyle.MINIMAL -> MinimalClock(cal, size, modifier)
    }
}

// ── CLASSIC ──────────────────────────────────────────────────────────────────
@Composable
private fun ClassicClock(cal: Calendar, ringRot: Float, size: Dp, modifier: Modifier) {
    Canvas(modifier = modifier.size(size)) {
        val cx = this.size.width / 2f; val cy = this.size.height / 2f
        val r = this.size.minDimension / 2f * 0.92f
        drawClockBase(cx, cy, r, ringRot)
        drawTicksClassic(cx, cy, r)
        drawHandsAll(cx, cy, r, cal)
        drawCenterDot(cx, cy, OrbBlue)
    }
}

// ── MODERN ───────────────────────────────────────────────────────────────────
@Composable
private fun ModernClock(cal: Calendar, size: Dp, modifier: Modifier) {
    Canvas(modifier = modifier.size(size)) {
        val cx = this.size.width / 2f; val cy = this.size.height / 2f
        val r = this.size.minDimension / 2f * 0.90f

        // Glowing ring segments for each 5-minute mark
        for (i in 0 until 12) {
            val angle = Math.toRadians(i * 30.0 - 90.0)
            val x = cx + r * 0.92f * cos(angle).toFloat()
            val y = cy + r * 0.92f * sin(angle).toFloat()
            drawCircle(
                color = OrbBlue.copy(alpha = if (i == 0) 0.9f else 0.4f),
                radius = if (i == 0) 6f else 3f,
                center = Offset(x, y)
            )
        }

        // Clean hour + minute arcs
        val hour   = cal.get(Calendar.HOUR).toFloat()
        val minute = cal.get(Calendar.MINUTE).toFloat()
        val second = cal.get(Calendar.SECOND).toFloat()

        // Minute arc
        drawArc(
            color = OrbBlue.copy(alpha = 0.8f),
            startAngle = -90f,
            sweepAngle = (minute + second / 60f) * 6f,
            useCenter = false,
            style = Stroke(width = 3f, cap = StrokeCap.Round),
            topLeft = Offset(cx - r * 0.85f, cy - r * 0.85f),
            size = androidx.compose.ui.geometry.Size(r * 1.7f, r * 1.7f)
        )
        // Hour arc
        drawArc(
            color = OrbPurple.copy(alpha = 0.7f),
            startAngle = -90f,
            sweepAngle = (hour + minute / 60f) * 30f,
            useCenter = false,
            style = Stroke(width = 5f, cap = StrokeCap.Round),
            topLeft = Offset(cx - r * 0.68f, cy - r * 0.68f),
            size = androidx.compose.ui.geometry.Size(r * 1.36f, r * 1.36f)
        )
        // Second dot
        val secAngle = Math.toRadians(second * 6.0 - 90.0)
        drawCircle(
            color = ClockSecHand,
            radius = 5f,
            center = Offset(
                cx + r * 0.95f * cos(secAngle).toFloat(),
                cy + r * 0.95f * sin(secAngle).toFloat()
            )
        )
        drawCenterDot(cx, cy, OrbPurple)
    }
}

// ── DIGITAL ──────────────────────────────────────────────────────────────────
@Composable
private fun DigitalClockFace(cal: Calendar, size: Dp, modifier: Modifier) {
    // Analog base with digital-style tick marks (no numbers, just dots)
    Canvas(modifier = modifier.size(size)) {
        val cx = this.size.width / 2f; val cy = this.size.height / 2f
        val r = this.size.minDimension / 2f * 0.90f

        // Outer ring
        drawCircle(
            brush = Brush.sweepGradient(
                listOf(OrbBlue.copy(0.6f), OrbCyan.copy(0.3f), OrbBlue.copy(0.6f)),
                center = Offset(cx, cy)
            ),
            radius = r, center = Offset(cx, cy),
            style = Stroke(width = 2f)
        )
        // Grid lines (digital feel)
        for (i in 0 until 60) {
            val angle = Math.toRadians(i * 6.0 - 90.0)
            val isHour = i % 5 == 0
            val start = if (isHour) r * 0.78f else r * 0.88f
            drawLine(
                color = if (isHour) OrbCyan.copy(0.8f) else OrbBlue.copy(0.25f),
                start = Offset(cx + start * cos(angle).toFloat(), cy + start * sin(angle).toFloat()),
                end   = Offset(cx + r * 0.95f * cos(angle).toFloat(), cy + r * 0.95f * sin(angle).toFloat()),
                strokeWidth = if (isHour) 2.5f else 1f,
                cap = StrokeCap.Square
            )
        }
        drawHandsAll(cx, cy, r, cal)
        drawCenterDot(cx, cy, OrbCyan)
    }
}

// ── MINIMAL ──────────────────────────────────────────────────────────────────
@Composable
private fun MinimalClock(cal: Calendar, size: Dp, modifier: Modifier) {
    Canvas(modifier = modifier.size(size)) {
        val cx = this.size.width / 2f; val cy = this.size.height / 2f
        val r = this.size.minDimension / 2f * 0.85f

        // Just a thin circle
        drawCircle(
            color = Color.White.copy(alpha = 0.12f),
            radius = r, center = Offset(cx, cy),
            style = Stroke(width = 0.8f)
        )
        // 4 cardinal dots only
        listOf(0, 90, 180, 270).forEach { deg ->
            val angle = Math.toRadians(deg.toDouble() - 90.0)
            drawCircle(
                color = Color.White.copy(0.5f),
                radius = 3f,
                center = Offset(cx + r * 0.88f * cos(angle).toFloat(),
                                cy + r * 0.88f * sin(angle).toFloat())
            )
        }
        // Thin hands only
        val hour   = cal.get(Calendar.HOUR).toFloat()
        val minute = cal.get(Calendar.MINUTE).toFloat()
        val second = cal.get(Calendar.SECOND).toFloat()
        drawHand(cx, cy, r * 0.48f, r * 0.08f, (hour + minute / 60f) * 30f - 90f,
            Color.White.copy(0.9f), 3f)
        drawHand(cx, cy, r * 0.70f, r * 0.10f, (minute + second / 60f) * 6f - 90f,
            Color.White.copy(0.75f), 2f)
        drawHand(cx, cy, r * 0.78f, r * 0.15f, second * 6f - 90f,
            ClockSecHand, 1f)
        drawCenterDot(cx, cy, Color.White)
    }
}

// ── SHARED DRAW UTILS ─────────────────────────────────────────────────────────
private fun DrawScope.drawClockBase(cx: Float, cy: Float, r: Float, ringRot: Float) {
    drawCircle(
        brush = Brush.radialGradient(
            listOf(OrbBlue.copy(0.12f), Color.Transparent),
            center = Offset(cx, cy), radius = r * 1.3f
        ), radius = r * 1.3f, center = Offset(cx, cy)
    )
    drawCircle(
        brush = Brush.radialGradient(
            listOf(Color.White.copy(0.07f), ClockFaceColor),
            center = Offset(cx, cy - r * 0.3f), radius = r
        ), radius = r, center = Offset(cx, cy)
    )
    drawCircle(color = ClockRing, radius = r, center = Offset(cx, cy), style = Stroke(1.5f))
    rotate(ringRot, Offset(cx, cy)) {
        drawCircle(
            brush = Brush.sweepGradient(
                listOf(OrbBlue.copy(0f), OrbBlue.copy(0.5f), OrbPurple.copy(0.3f), OrbBlue.copy(0f)),
                center = Offset(cx, cy)
            ),
            radius = r + 6f, center = Offset(cx, cy), style = Stroke(2.5f)
        )
    }
}

private fun DrawScope.drawTicksClassic(cx: Float, cy: Float, r: Float) {
    for (i in 0 until 60) {
        val angle = Math.toRadians(i * 6.0 - 90.0)
        val isHour = i % 5 == 0
        val startR = if (isHour) r * 0.82f else r * 0.88f
        drawLine(
            color = Color.White.copy(if (isHour) 0.85f else 0.3f),
            start = Offset(cx + startR * cos(angle).toFloat(), cy + startR * sin(angle).toFloat()),
            end   = Offset(cx + r * 0.95f * cos(angle).toFloat(), cy + r * 0.95f * sin(angle).toFloat()),
            strokeWidth = if (isHour) 2f else 1f, cap = StrokeCap.Round
        )
        if (isHour && i % 15 == 0) {
            val nr = r * 0.68f
            drawCircle(OrbBlue.copy(0.6f), 3f,
                Offset(cx + nr * cos(angle).toFloat(), cy + nr * sin(angle).toFloat()))
        }
    }
}

private fun DrawScope.drawHandsAll(cx: Float, cy: Float, r: Float, cal: Calendar) {
    val h = cal.get(Calendar.HOUR).toFloat()
    val m = cal.get(Calendar.MINUTE).toFloat()
    val s = cal.get(Calendar.SECOND).toFloat()
    drawHand(cx, cy, r * 0.50f, r * 0.10f, (h + m / 60f) * 30f - 90f, ClockHourHand, 5f)
    drawHand(cx, cy, r * 0.72f, r * 0.12f, (m + s / 60f) * 6f  - 90f, ClockMinHand,  3.5f)
    drawHand(cx, cy, r * 0.80f, r * 0.18f, s * 6f - 90f, ClockSecHand, 1.5f)
}

private fun DrawScope.drawHand(cx: Float, cy: Float, len: Float, back: Float,
    deg: Float, color: Color, width: Float) {
    val angle = Math.toRadians(deg.toDouble())
    val tx = cx + len  * cos(angle).toFloat(); val ty = cy + len  * sin(angle).toFloat()
    val bx = cx - back * cos(angle).toFloat(); val by = cy - back * sin(angle).toFloat()
    drawLine(Color.Black.copy(0.3f), Offset(bx+1,by+1), Offset(tx+1,ty+1), width+1f, cap=StrokeCap.Round)
    drawLine(color, Offset(bx, by), Offset(tx, ty), width, cap=StrokeCap.Round)
}

private fun DrawScope.drawCenterDot(cx: Float, cy: Float, color: Color) {
    drawCircle(color, 8f, Offset(cx, cy))
    drawCircle(Color.White.copy(0.9f), 4f, Offset(cx, cy))
    drawCircle(color.copy(0.5f), 12f, Offset(cx, cy), style = Stroke(1.5f))
}
