package com.hussein.alarmpro.di

import android.content.Context
import com.hussein.alarmpro.data.db.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): AlarmDatabase =
        AlarmDatabase.getInstance(ctx)

    @Provides @Singleton
    fun provideAlarmDao(db: AlarmDatabase): AlarmDao = db.alarmDao()

    @Provides @Singleton
    fun provideGroupDao(db: AlarmDatabase): AlarmGroupDao = db.groupDao()

    @Provides @Singleton
    fun provideTimerDao(db: AlarmDatabase): TimerDao = db.timerDao()

    @Provides @Singleton
    fun provideWorldClockDao(db: AlarmDatabase): WorldClockDao = db.worldClockDao()
}
