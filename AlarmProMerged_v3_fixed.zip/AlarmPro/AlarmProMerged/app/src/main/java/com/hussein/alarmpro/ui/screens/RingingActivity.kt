package com.hussein.alarmpro.ui.screens

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import com.hussein.alarmpro.data.model.Alarm
import com.hussein.alarmpro.service.AlarmService
import com.hussein.alarmpro.ui.components.*
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.*
import com.hussein.alarmpro.viewmodel.AlarmViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random
import javax.inject.Inject

@AndroidEntryPoint
class RingingActivity : ComponentActivity() {

    private val viewModel: AlarmViewModel by viewModels()
    @Inject lateinit var wakeLockManager: WakeLockManager
    @Inject lateinit var strictModeManager: StrictModeManager
    private var alarmId: Int = -1
    private var dismissType: Int = 0

    private val closeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) { finish() }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // In strict mode, block volume/power keys here too (double layer with A11y)
        if (StrictModeManager.isStrictActive) {
            when (keyCode) {
                KeyEvent.KEYCODE_VOLUME_DOWN,
                KeyEvent.KEYCODE_VOLUME_MUTE -> {
                    strictModeManager.forceMaxAlarmVolume()
                    return true
                }
                KeyEvent.KEYCODE_POWER -> return true // block power off
            }
        }
        return when {
            dismissType == 2 && keyCode == KeyEvent.KEYCODE_POWER -> {
                triggerDismiss(); true
            }
            dismissType == 3 && (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN
                    || keyCode == KeyEvent.KEYCODE_VOLUME_UP) -> {
                triggerDismiss(); true
            }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    private fun triggerDismiss() {
        startService(Intent(this, AlarmService::class.java).apply {
            action = AlarmService.ACTION_DISMISS
            putExtra("alarm_id", alarmId)
        })
        cleanup()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        alarmId = intent.getIntExtra("alarm_id", -1)
        dismissType = intent.getIntExtra("dismiss_type", 0)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        wakeLockManager.acquire()
        lockSystemUI()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(closeReceiver,
                IntentFilter("com.hussein.alarmpro.ACTION_CLOSE_RING"), RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(closeReceiver, IntentFilter("com.hussein.alarmpro.ACTION_CLOSE_RING"))
        }

        setContent {
            AlarmProTheme {
                val alarms by viewModel.alarms.collectAsState()
                val alarm = remember(alarms, alarmId) { alarms.find { it.id == alarmId } }
                if (alarm != null) {
                    RingingScreen(
                        alarm    = alarm,
                        onSnooze = {
                            startService(Intent(this, AlarmService::class.java).apply {
                                action = AlarmService.ACTION_SNOOZE
                                putExtra("alarm_id", alarmId)
                            })
                            cleanup()
                        },
                        onDismiss = {
                            startService(Intent(this, AlarmService::class.java).apply {
                                action = AlarmService.ACTION_DISMISS
                                putExtra("alarm_id", alarmId)
                            })
                            cleanup()
                        }
                    )
                }
            }
        }
    }

    private fun cleanup() {
        unlockSystemUI()
        wakeLockManager.release()
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { unregisterReceiver(closeReceiver) }
        wakeLockManager.release()
    }

    @Deprecated("Deprecated")
    override fun onBackPressed() { /* blocked */ }
}

// ═══════════════════════════════════════════════════════════════════════════════
// RINGING SCREEN
// ═══════════════════════════════════════════════════════════════════════════════
@Composable
private fun RingingScreen(alarm: Alarm, onSnooze: () -> Unit, onDismiss: () -> Unit) {
    val isAr = TimeUtils.isArabic()
    var showTask by remember { mutableStateOf(false) }

    // Strict mode: if dismissTask == 0, default to Math (task 1) so there's always a task
    val effectiveDismissTask = when {
        alarm.strictMode && alarm.dismissTask == 0 -> 1
        else -> alarm.dismissTask
    }

    val inf = rememberInfiniteTransition(label = "ring")
    val ring1 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1400, easing = EaseOut), RepeatMode.Restart), "r1")
    val ring2 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1400, 400, easing = EaseOut), RepeatMode.Restart), "r2")
    val ring3 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(1400, 800, easing = EaseOut), RepeatMode.Restart), "r3")
    val bellPulse by inf.animateFloat(0.93f, 1.07f, infiniteRepeatable(tween(500, easing = EaseInOutSine), RepeatMode.Reverse), "bell")
    val bellRotate by inf.animateFloat(-6f, 6f, infiniteRepeatable(tween(180, easing = EaseInOutSine), RepeatMode.Reverse), "rot")
    val glowA by inf.animateFloat(0.35f, 0.75f, infiniteRepeatable(tween(900, easing = EaseInOutSine), RepeatMode.Reverse), "glow")

    Box(Modifier.fillMaxSize()) {
        LiquidGlassBackground(Modifier.fillMaxSize()) {}
        if (alarm.ringBgUri.isNotBlank()) {
            BlurredRingBackground(imageUri = alarm.ringBgUri, blurRadius = 28f, modifier = Modifier.fillMaxSize())
        }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(0.45f)))

        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // ── TOP ──────────────────────────────────────────────────────────
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 72.dp)) {

                // Strict Mode badge
                if (alarm.strictMode) {
                    StrictModeBadge(isAr = isAr)
                    Spacer(Modifier.height(8.dp))
                }

                // Status pill
                GlassPill(color = if (alarm.strictMode) OrbPink else OrbPink) {
                    Row(verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(OrbPink)
                            .drawBehind { drawCircle(OrbPink.copy(glowA * 0.6f), radius = size.minDimension * 1.4f) })
                        Spacer(Modifier.width(8.dp))
                        Text(if (isAr) "المنبه يرن الآن" else "Alarm Ringing",
                            style = MaterialTheme.typography.labelMedium.copy(color = OrbPink, fontWeight = FontWeight.SemiBold, fontSize = 12.sp))
                    }
                }

                Spacer(Modifier.height(24.dp))
                Text(
                    text = TimeUtils.formatTime(alarm.hour, alarm.minute),
                    style = MaterialTheme.typography.displayLarge.copy(fontSize = 88.sp, fontWeight = FontWeight.Thin, color = TextPrimary, letterSpacing = (-2).sp)
                )
                if (alarm.label.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(alarm.label, style = MaterialTheme.typography.headlineSmall.copy(color = TextSecondary, fontWeight = FontWeight.Light))
                }
            }

            // ── BELL ─────────────────────────────────────────────────────────
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(240.dp)) {
                listOf(ring1 to 0.90f, ring2 to 0.75f, ring3 to 0.55f).forEach { (r, maxA) ->
                    Box(Modifier.size(200.dp)
                        .graphicsLayer(scaleX = 0.4f + r * 1.2f, scaleY = 0.4f + r * 1.2f, alpha = (1f - r) * maxA)
                        .clip(CircleShape)
                        .background(Brush.radialGradient(listOf(
                            if (alarm.strictMode) OrbPink.copy(0.5f) else OrbBlue.copy(0.4f),
                            if (alarm.strictMode) OrbPink.copy(0.2f) else OrbPurple.copy(0.15f),
                            Color.Transparent
                        ))))
                }
                Box(
                    Modifier.size(120.dp)
                        .graphicsLayer(scaleX = bellPulse, scaleY = bellPulse)
                        .clip(CircleShape)
                        .background(Brush.verticalGradient(listOf(
                            Color.White.copy(0.22f),
                            if (alarm.strictMode) OrbPink.copy(0.40f) else OrbBlue.copy(0.30f)
                        )))
                        .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(0.55f), Color.White.copy(0.10f))), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Alarm, null, tint = Color.White,
                        modifier = Modifier.size(56.dp).graphicsLayer(rotationZ = bellRotate))
                }
            }

            // ── BUTTONS ───────────────────────────────────────────────────────
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(bottom = 52.dp)
            ) {
                if (!showTask) {
                    // Dismiss button
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.85f).height(58.dp)
                            .clip(RoundedCornerShape(29.dp))
                            .background(Brush.verticalGradient(listOf(OrbPink.copy(0.80f), SystemRed.copy(0.70f))))
                            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(0.45f), Color.White.copy(0.08f))), RoundedCornerShape(29.dp))
                            .drawBehind { drawRect(Brush.verticalGradient(listOf(Color.White.copy(0.15f), Color.Transparent), endY = size.height * 0.45f)) }
                            .clickable {
                                // Strict mode: ALWAYS show task regardless of dismissTask setting
                                if (alarm.strictMode || effectiveDismissTask > 0) showTask = true
                                else onDismiss()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (alarm.strictMode || effectiveDismissTask > 0) Icons.Filled.Lock else Icons.Filled.AlarmOff,
                                null, tint = Color.White, modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                when {
                                    alarm.strictMode -> if (isAr) "إيقاف — يتطلب المهمة 🔒" else "Stop — Task Required 🔒"
                                    effectiveDismissTask > 0 -> if (isAr) "إيقاف (يتطلب مهمة)" else "Dismiss (task required)"
                                    else -> if (isAr) "إيقاف المنبه" else "Stop Alarm"
                                },
                                style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.SemiBold)
                            )
                        }
                    }

                    // Snooze button (hidden in strict mode)
                    if (alarm.isSnoozeEnabled && !alarm.strictMode) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.65f).height(50.dp)
                                .clip(RoundedCornerShape(25.dp))
                                .background(Color.White.copy(0.10f))
                                .border(1.dp, Color.White.copy(0.25f), RoundedCornerShape(25.dp))
                                .clickable { onSnooze() },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Snooze, null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(if (isAr) "غفوة ${alarm.snoozeMinutes} دقيقة" else "Snooze ${alarm.snoozeMinutes}m",
                                    style = MaterialTheme.typography.titleSmall.copy(color = TextSecondary))
                            }
                        }
                    }

                    // Strict mode: no-snooze notice
                    if (alarm.strictMode) {
                        Text(
                            if (isAr) "⚠️ الوضع الصارم — لا توجد غفوة. أكمل المهمة للإيقاف."
                            else "⚠️ Strict Mode — No snooze. Complete the task to stop.",
                            style = MaterialTheme.typography.bodySmall.copy(color = OrbPink.copy(0.8f), fontSize = 11.sp),
                            textAlign = TextAlign.Center
                        )
                    }

                } else {
                    when (effectiveDismissTask) {
                        1 -> MathTask(alarm.dismissTaskDifficulty, isAr) { onDismiss() }
                        2 -> RewriteTask(alarm.dismissTaskDifficulty, isAr) { onDismiss() }
                        3 -> QRTask(isAr) { onDismiss() }
                        4 -> WalkTask(isAr) { onDismiss() }
                        else -> MathTask(1, isAr) { onDismiss() }
                    }
                }
            }
        }
    }
}

// ── Strict Mode Badge ──────────────────────────────────────────────────────────
@Composable
private fun StrictModeBadge(isAr: Boolean) {
    val inf = rememberInfiniteTransition(label = "badge")
    val glowA by inf.animateFloat(0.4f, 1f, infiniteRepeatable(tween(800, easing = EaseInOutSine), RepeatMode.Reverse), "ga")

    Box(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(OrbPink.copy(0.20f))
            .border(1.5.dp, Brush.linearGradient(listOf(OrbPink.copy(glowA), OrbPink.copy(0.3f))), RoundedCornerShape(12.dp))
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Filled.Lock, null, tint = OrbPink, modifier = Modifier.size(14.dp))
            Text(
                if (isAr) "الوضع الصارم — لا مفر بدون المهمة"
                else "STRICT MODE — No escape without task",
                style = MaterialTheme.typography.labelMedium.copy(
                    color = OrbPink, fontWeight = FontWeight.Bold, fontSize = 11.sp
                )
            )
            Icon(Icons.Filled.Lock, null, tint = OrbPink, modifier = Modifier.size(14.dp))
        }
    }
}

// ─── DISMISS TASKS ───────────────────────────────────────────────────────────
@Composable
private fun MathTask(difficulty: Int, isAr: Boolean, onSuccess: () -> Unit) {
    val scope = rememberCoroutineScope()
    val (question, answer) = remember(difficulty) {
        when (difficulty) {
            0 -> { val a = Random.nextInt(1,20); val b = Random.nextInt(1,20); Pair("$a + $b = ?", a + b) }
            2 -> { val a = Random.nextInt(2,12); val b = Random.nextInt(2,12); val c = Random.nextInt(1,20)
                   Pair("($a × $b) + $c = ?", a * b + c) }
            else -> { val a = Random.nextInt(5,30); val b = Random.nextInt(2, a); Pair("$a − $b = ?", a - b) }
        }
    }
    var input by remember { mutableStateOf("") }
    var error  by remember { mutableStateOf(false) }

    GlassCard(Modifier.fillMaxWidth(), cornerRadius = 24.dp) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (isAr) "حلّ المسألة للإيقاف" else "Solve to Dismiss",
                style = MaterialTheme.typography.titleMedium.copy(color = OrbBlue, fontWeight = FontWeight.SemiBold))
            Spacer(Modifier.height(14.dp))
            GlassCard(cornerRadius = 16.dp) {
                Text(question, style = MaterialTheme.typography.displaySmall.copy(fontSize = 40.sp, fontWeight = FontWeight.Light),
                    modifier = Modifier.padding(horizontal = 32.dp, vertical = 16.dp))
            }
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(
                value = input, onValueChange = { input = it.filter { c -> c.isDigit() || c == '-' } },
                label = { Text(if (isAr) "الجواب" else "Answer", color = TextTertiary) },
                isError = error, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextSecondary,
                    focusedBorderColor = OrbBlue, unfocusedBorderColor = GlassBorder, errorBorderColor = OrbPink, cursorColor = OrbBlue),
                modifier = Modifier.fillMaxWidth()
            )
            if (error) Text(if (isAr) "إجابة خاطئة!" else "Wrong answer!", color = OrbPink, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(14.dp))
            Box(modifier = Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(25.dp))
                .background(Brush.verticalGradient(listOf(OrbBlue.copy(0.80f), OrbPurple.copy(0.60f))))
                .clickable { if (input.toIntOrNull() == answer) onSuccess() else { error = true; scope.launch { delay(700); error = false } } },
                contentAlignment = Alignment.Center) {
                Text(if (isAr) "تحقق" else "Check", style = MaterialTheme.typography.titleSmall.copy(color = Color.White, fontWeight = FontWeight.SemiBold))
            }
        }
    }
}

@Composable
private fun RewriteTask(difficulty: Int, isAr: Boolean, onSuccess: () -> Unit) {
    val phrases = if (isAr) listOf("أنا مستيقظ الآن","الصباح نور وخير","سأبدأ يومي بنشاط وحيوية")
                  else listOf("I am fully awake","Good morning, rise and shine","Today will be productive")
    val phrase = remember(difficulty) { phrases[difficulty.coerceIn(0, phrases.lastIndex)] }
    var input by remember { mutableStateOf("") }
    var error  by remember { mutableStateOf(false) }

    GlassCard(Modifier.fillMaxWidth(), cornerRadius = 24.dp) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (isAr) "اكتب العبارة" else "Type This Phrase",
                style = MaterialTheme.typography.titleMedium.copy(color = OrbBlue, fontWeight = FontWeight.SemiBold))
            Spacer(Modifier.height(14.dp))
            GlassPill(color = OrbPurple) {
                Text(phrase, style = MaterialTheme.typography.bodyLarge.copy(color = TextPrimary, fontWeight = FontWeight.Medium),
                    textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp))
            }
            Spacer(Modifier.height(14.dp))
            OutlinedTextField(value = input, onValueChange = { input = it }, isError = error,
                label = { Text(if (isAr) "اكتب هنا" else "Type here", color = TextTertiary) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextSecondary,
                    focusedBorderColor = OrbBlue, unfocusedBorderColor = GlassBorder, cursorColor = OrbBlue, errorBorderColor = OrbPink))
            if (error) Text(if (isAr) "النص غير مطابق" else "Text doesn't match", color = OrbPink, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(14.dp))
            Box(modifier = Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(25.dp))
                .background(Brush.verticalGradient(listOf(OrbPurple.copy(0.80f), OrbBlue.copy(0.60f))))
                .clickable { if (input.trim() == phrase.trim()) onSuccess() else error = true },
                contentAlignment = Alignment.Center) {
                Text(if (isAr) "تحقق" else "Verify", style = MaterialTheme.typography.titleSmall.copy(color = Color.White, fontWeight = FontWeight.SemiBold))
            }
        }
    }
}

@Composable
private fun QRTask(isAr: Boolean, onSuccess: () -> Unit) {
    val scope = rememberCoroutineScope()
    var taps by remember { mutableStateOf(0) }
    val required = 20
    val progress = taps.toFloat() / required
    val inf = rememberInfiniteTransition(label = "qr")
    val ringScale by inf.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(600, easing = EaseInOutSine), RepeatMode.Reverse), "rs")

    GlassCard(Modifier.fillMaxWidth(), cornerRadius = 24.dp) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (isAr) "اضغط $required مرة" else "Tap $required Times",
                style = MaterialTheme.typography.titleMedium.copy(color = OrbBlue, fontWeight = FontWeight.SemiBold))
            Spacer(Modifier.height(16.dp))
            Box(contentAlignment = Alignment.Center) {
                CircularProgressIndicator(progress = { progress },
                    modifier = Modifier.size(88.dp).graphicsLayer(scaleX = ringScale, scaleY = ringScale),
                    color = OrbBlue, trackColor = GlassBorder, strokeWidth = 5.dp)
                Text("$taps", style = MaterialTheme.typography.headlineMedium.copy(
                    color = if (progress >= 1f) ToggleOn else OrbBlue, fontWeight = FontWeight.Bold))
            }
            Spacer(Modifier.height(4.dp))
            Text("/ $required", style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary))
            Spacer(Modifier.height(16.dp))
            Box(modifier = Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(28.dp))
                .background(Brush.verticalGradient(listOf(
                    if (progress >= 1f) ToggleOn.copy(0.80f) else OrbBlue.copy(0.80f),
                    if (progress >= 1f) OrbMint.copy(0.60f) else OrbPurple.copy(0.60f))))
                .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(0.45f), Color.White.copy(0.08f))), RoundedCornerShape(28.dp))
                .clickable {
                    taps = (taps + 1).coerceAtMost(required)
                    if (taps >= required) scope.launch { delay(300); onSuccess() }
                }, contentAlignment = Alignment.Center) {
                Text(if (progress >= 1f) (if (isAr) "✓ تم!" else "✓ Done!") else if (isAr) "اضغط هنا!" else "Tap here!",
                    style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold))
            }
        }
    }
}

@Composable
private fun WalkTask(isAr: Boolean, onSuccess: () -> Unit) {
    val ctx = LocalContext.current
    val required = 20
    var steps by remember { mutableStateOf(0) }
    var available by remember { mutableStateOf(true) }
    val progress = steps.toFloat() / required
    val helper = remember { AccelerometerHelper(ctx) }

    DisposableEffect(Unit) {
        available = helper.isAvailable
        if (available) helper.start { count -> steps = count.coerceAtMost(required) }
        onDispose { helper.stop() }
    }

    LaunchedEffect(steps) { if (steps >= required) { delay(300); onSuccess() } }

    val inf = rememberInfiniteTransition(label = "walk")
    val bounce by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(600, easing = EaseInOutSine), RepeatMode.Reverse), "b")

    GlassCard(Modifier.fillMaxWidth(), cornerRadius = 24.dp) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (isAr) "امشِ $required خطوة للإيقاف" else "Walk $required Steps to Dismiss",
                style = MaterialTheme.typography.titleMedium.copy(color = OrbMint, fontWeight = FontWeight.SemiBold))
            Spacer(Modifier.height(18.dp))
            if (!available) {
                Icon(Icons.Filled.SensorsOff, null, tint = OrbPink, modifier = Modifier.size(48.dp))
                Spacer(Modifier.height(8.dp))
                Text(if (isAr) "المستشعر غير متاح\nاضغط للتخطي" else "Sensor unavailable\nTap to skip",
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextTertiary), textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Box(modifier = Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(25.dp))
                    .background(OrbPink.copy(0.25f)).border(1.dp, OrbPink.copy(0.6f), RoundedCornerShape(25.dp))
                    .clickable { onSuccess() }, contentAlignment = Alignment.Center) {
                    Text(if (isAr) "تخطي" else "Skip",
                        style = MaterialTheme.typography.titleSmall.copy(color = OrbPink, fontWeight = FontWeight.SemiBold))
                }
            } else {
                Box(Modifier.size(96.dp).graphicsLayer(translationY = bounce * (-6f)), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(progress = { progress }, modifier = Modifier.size(96.dp),
                        color = OrbMint, trackColor = GlassBorder, strokeWidth = 6.dp)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.DirectionsWalk, null,
                            tint = if (progress >= 1f) ToggleOn else OrbMint, modifier = Modifier.size(32.dp))
                        Text("$steps", style = MaterialTheme.typography.titleMedium.copy(
                            color = if (progress >= 1f) ToggleOn else TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp))
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text(if (isAr) "$steps / $required خطوة" else "$steps / $required steps",
                    style = MaterialTheme.typography.bodyMedium.copy(color = if (progress >= 1f) ToggleOn else TextSecondary))
                Spacer(Modifier.height(6.dp))
                Text(if (isAr) "ضع الهاتف في يدك وامشِ" else "Hold phone and walk",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextTertiary), textAlign = TextAlign.Center)
            }
        }
    }
}
