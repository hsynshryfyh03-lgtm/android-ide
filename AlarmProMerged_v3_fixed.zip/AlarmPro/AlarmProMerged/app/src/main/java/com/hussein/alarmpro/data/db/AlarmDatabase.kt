package com.hussein.alarmpro.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.hussein.alarmpro.data.model.Alarm
import com.hussein.alarmpro.data.model.AlarmGroup
import com.hussein.alarmpro.data.model.TimerItem
import com.hussein.alarmpro.data.model.WorldClockCity

@Database(
    entities = [Alarm::class, AlarmGroup::class, TimerItem::class, WorldClockCity::class],
    version = 4,
    exportSchema = false
)
abstract class AlarmDatabase : RoomDatabase() {
    abstract fun alarmDao(): AlarmDao
    abstract fun groupDao(): AlarmGroupDao
    abstract fun timerDao(): TimerDao
    abstract fun worldClockDao(): WorldClockDao

    companion object {
        @Volatile private var INSTANCE: AlarmDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE alarms ADD COLUMN scheduledDate INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE alarms ADD COLUMN bypassDnd INTEGER NOT NULL DEFAULT 1")
                database.execSQL("ALTER TABLE alarms ADD COLUMN gradualVolume INTEGER NOT NULL DEFAULT 1")
                database.execSQL("ALTER TABLE alarms ADD COLUMN gradualVolumeDurationSec INTEGER NOT NULL DEFAULT 30")
                database.execSQL("ALTER TABLE alarms ADD COLUMN bedtimeEnabled INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE alarms ADD COLUMN sleepHours INTEGER NOT NULL DEFAULT 8")
                database.execSQL("ALTER TABLE alarms ADD COLUMN groupId INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE alarms ADD COLUMN vacationExempt INTEGER NOT NULL DEFAULT 0")
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS alarm_groups (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        name TEXT NOT NULL DEFAULT '',
                        colorHex TEXT NOT NULL DEFAULT '#1296DB',
                        isEnabled INTEGER NOT NULL DEFAULT 1,
                        createdAt INTEGER NOT NULL DEFAULT 0
                    )
                """.trimIndent())
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE alarms ADD COLUMN strictMode INTEGER NOT NULL DEFAULT 0")
            }
        }

        /** Migration 3 → 4: add timers and world_clocks tables */
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS `timers` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `label` TEXT NOT NULL DEFAULT '',
                        `totalMillis` INTEGER NOT NULL DEFAULT 60000,
                        `remainingMillis` INTEGER NOT NULL DEFAULT 60000,
                        `state` INTEGER NOT NULL DEFAULT 0,
                        `soundUri` TEXT NOT NULL DEFAULT '',
                        `vibrate` INTEGER NOT NULL DEFAULT 1,
                        `createdAt` INTEGER NOT NULL DEFAULT 0
                    )
                """.trimIndent())
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS `world_clocks` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `cityName` TEXT NOT NULL,
                        `countryName` TEXT NOT NULL,
                        `timeZoneId` TEXT NOT NULL,
                        `sortOrder` INTEGER NOT NULL DEFAULT 0
                    )
                """.trimIndent())
            }
        }

        fun getInstance(context: Context): AlarmDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext, AlarmDatabase::class.java, "alarm_db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
