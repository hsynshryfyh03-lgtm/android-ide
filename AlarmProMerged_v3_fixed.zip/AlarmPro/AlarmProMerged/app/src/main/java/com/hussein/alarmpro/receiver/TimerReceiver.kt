package com.hussein.alarmpro.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.hussein.alarmpro.service.TimerService

class TimerReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val timerId = intent.getIntExtra("timerId", -1)
        context.startService(
            Intent(context, TimerService::class.java)
                .putExtra("timerId", timerId)
                .setAction("STOP")
        )
    }
}
