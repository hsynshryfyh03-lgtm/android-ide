package com.hussein.alarmpro.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.hussein.alarmpro.R
import com.hussein.alarmpro.data.model.Alarm
import com.hussein.alarmpro.receiver.AlarmReceiver
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        const val CH_ALARM = "ch_alarm"
        const val CH_PRE   = "ch_pre_alarm"
        const val CH_SVC   = "ch_fg_service"
        const val FG_ID    = 9001
        const val PRE_ID   = 9002
    }

    fun createChannels() {
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_ALARM, "منبه / Alarm", NotificationManager.IMPORTANCE_HIGH).apply {
                setBypassDnd(true)
                enableVibration(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_PRE, "تذكير / Pre-alarm", NotificationManager.IMPORTANCE_DEFAULT)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_SVC, "خدمة / Service", NotificationManager.IMPORTANCE_LOW)
        )
    }

    /** Minimal notification used immediately when startForeground is called before alarm data loads */
    fun buildPlaceholderNotification(): Notification =
        NotificationCompat.Builder(context, CH_SVC)
            .setSmallIcon(R.drawable.ic_alarm_notif)
            .setContentTitle(if (TimeUtils.isArabic()) "جاري تشغيل المنبه..." else "Starting alarm...")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()

    fun buildAlarmNotification(alarm: Alarm): Notification {
        val isAr = TimeUtils.isArabic()
        val label = alarm.label.ifBlank { if (isAr) "منبه" else "Alarm" }
        val time  = TimeUtils.formatTime(alarm.hour, alarm.minute)

        val snoozePi = pendingBroadcast(
            alarm.id + 5000, "com.hussein.alarmpro.ACTION_ALARM_SNOOZE", alarm.id
        )
        val dismissPi = pendingBroadcast(
            alarm.id + 6000, "com.hussein.alarmpro.ACTION_ALARM_DISMISS", alarm.id
        )
        val fullScreenIntent = PendingIntent.getActivity(
            context, alarm.id,
            Intent(context, com.hussein.alarmpro.ui.screens.RingingActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("alarm_id", alarm.id)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(context, CH_ALARM)
            .setSmallIcon(R.drawable.ic_alarm_notif)
            .setContentTitle("$label — $time")
            .setContentText(if (isAr) "المنبه يرن الآن 🔔" else "Alarm ringing 🔔")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setFullScreenIntent(fullScreenIntent, true)
            .addAction(R.drawable.ic_snooze, if (isAr) "غفوة" else "Snooze", snoozePi)
            .addAction(R.drawable.ic_dismiss, if (isAr) "إيقاف" else "Dismiss", dismissPi)
            .build()
    }

    fun showPreAlarm(alarm: Alarm, minutes: Int) {
        val isAr = TimeUtils.isArabic()
        val skipPi = pendingBroadcast(
            alarm.id + 7000, "com.hussein.alarmpro.ACTION_SKIP_TODAY", alarm.id
        )
        val label = alarm.label.ifBlank { if (isAr) "منبه" else "Alarm" }
        val notif = NotificationCompat.Builder(context, CH_PRE)
            .setSmallIcon(R.drawable.ic_alarm_notif)
            .setContentTitle(if (isAr) "⏰ تذكير: $label" else "⏰ Reminder: $label")
            .setContentText(if (isAr) "المنبه بعد $minutes دقيقة" else "Alarm in $minutes min")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .addAction(0, if (isAr) "تخطي اليوم" else "Skip today", skipPi)
            .build()
        context.getSystemService(NotificationManager::class.java)
            .notify(PRE_ID + alarm.id, notif)
    }

    private fun pendingBroadcast(reqCode: Int, action: String, alarmId: Int): PendingIntent =
        PendingIntent.getBroadcast(
            context, reqCode,
            Intent(context, AlarmReceiver::class.java).apply {
                this.action = action
                putExtra("alarm_id", alarmId)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
}
