package com.hussein.alarmpro.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import top.yukonga.miuix.kmp.theme.MiuixTheme
import top.yukonga.miuix.kmp.utils.MiuixPopupUtils

// Material3 dark scheme — used by components not yet migrated to Miuix
private val HyperOSDarkColors = darkColorScheme(
    primary          = MiBlue,
    onPrimary        = Color.White,
    secondary        = MiOrange,
    onSecondary      = Color.White,
    tertiary         = StopwatchAccent,
    background       = HyperBg,
    onBackground     = HyperTextPrimary,
    surface          = HyperSurface,
    onSurface        = HyperTextPrimary,
    surfaceVariant   = HyperSurface2,
    onSurfaceVariant = HyperTextSecondary,
    outline          = HyperSeparator,
    error            = MiRed,
    onError          = Color.White
)

@Composable
fun AlarmProTheme(content: @Composable () -> Unit) {
    MiuixTheme {
        MaterialTheme(
            colorScheme = HyperOSDarkColors,
            typography  = AlarmTypography,
            content     = content
        )
    }
}
