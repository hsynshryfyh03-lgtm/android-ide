package com.hussein.alarmpro.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "world_clocks")
data class WorldClockCity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val cityName: String,
    val countryName: String,
    val timeZoneId: String,       // e.g. "America/New_York"
    val sortOrder: Int = 0
)

/** All time zones bundled in the app */
data class CityInfo(
    val city: String,
    val country: String,
    val timeZoneId: String,
    val flag: String = ""
)
