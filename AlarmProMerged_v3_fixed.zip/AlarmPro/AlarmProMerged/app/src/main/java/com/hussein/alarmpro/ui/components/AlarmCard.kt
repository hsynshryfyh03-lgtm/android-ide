package com.hussein.alarmpro.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.hussein.alarmpro.data.model.Alarm
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.TimeUtils

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AlarmCard(
    alarm: Alarm,
    nextTriggerMillis: Long?,
    onToggle: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isAr = TimeUtils.isArabic()
    var showDelete by remember { mutableStateOf(false) }

    val cardAlpha by animateFloatAsState(
        targetValue = if (alarm.isEnabled) 1f else 0.48f,
        animationSpec = spring(stiffness = Spring.StiffnessMedium),
        label = "alpha"
    )

    // Enabled alarms get a subtle blue accent glow
    val glowAlpha by animateFloatAsState(
        targetValue = if (alarm.isEnabled) 0.10f else 0f,
        animationSpec = tween(400),
        label = "glow"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .drawBehind {
                if (glowAlpha > 0f) {
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            listOf(OrbBlue.copy(glowAlpha), OrbPurple.copy(glowAlpha * 0.5f), Color.Transparent)
                        ),
                        cornerRadius = CornerRadius(24.dp.toPx()),
                        topLeft = Offset(-4.dp.toPx(), -2.dp.toPx()),
                        size = size.copy(
                            width = size.width + 8.dp.toPx(),
                            height = size.height + 4.dp.toPx()
                        )
                    )
                }
            }
    ) {
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .alpha(cardAlpha)
                .combinedClickable(
                    onClick = onEdit,
                    onLongClick = { showDelete = !showDelete }
                ),
            cornerRadius = 22.dp,
            tint = if (alarm.isEnabled) OrbBlue.copy(0.08f) + Color.White else Color.White
        ) {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 18.dp)) {

                // ── Row 1: Time + Toggle ──────────────────────────────────
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        // Hour display — thin weight, large (iOS clock app style)
                        Text(
                            text = TimeUtils.formatTime(alarm.hour, alarm.minute),
                            style = MaterialTheme.typography.displayMedium.copy(
                                fontSize = 46.sp,
                                fontWeight = FontWeight.Thin,
                                color = if (alarm.isEnabled) TextPrimary else TextTertiary,
                                letterSpacing = (-1).sp
                            )
                        )
                        if (alarm.label.isNotBlank()) {
                            Spacer(Modifier.height(2.dp))
                            Text(
                                text = alarm.label,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = if (alarm.isEnabled) TextSecondary else TextTertiary
                                )
                            )
                        }
                    }

                    IosSwitch(checked = alarm.isEnabled, onCheckedChange = onToggle)
                }

                Spacer(Modifier.height(12.dp))

                // ── Row 2: Days + Next trigger ────────────────────────────
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val daysLabel = TimeUtils.daysLabel(alarm.days, isAr)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Outlined.Repeat, null,
                            tint = if (alarm.isEnabled) TextTertiary else TextQuaternary,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            daysLabel,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = if (alarm.isEnabled) TextTertiary else TextQuaternary,
                                fontSize = 12.sp
                            )
                        )
                    }

                    if (alarm.isEnabled && nextTriggerMillis != null) {
                        val remaining = TimeUtils.timeUntilLabel(nextTriggerMillis, isAr)
                        if (remaining.isNotBlank()) {
                            GlassPill(color = OrbBlue) {
                                Text(
                                    remaining,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = OrbBlue, fontSize = 11.sp, fontWeight = FontWeight.Medium
                                    ),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                // ── Row 3: Feature badges ──────────────────────────────────
                val hasBadges = alarm.isSnoozeEnabled || alarm.isVibrate || alarm.dismissTask > 0 || alarm.soundName.isNotBlank()
                if (hasBadges) {
                    Spacer(Modifier.height(10.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(5.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (alarm.isSnoozeEnabled) {
                            SmallBadge(
                                icon = Icons.Filled.Snooze,
                                label = if (isAr) "غفوة ${alarm.snoozeMinutes}د" else "${alarm.snoozeMinutes}m",
                                color = OrbPurple
                            )
                        }
                        if (alarm.isVibrate) {
                            SmallBadge(Icons.Filled.Vibration, if (isAr) "اهتزاز" else "Vibrate", OrbCyan)
                        }
                        if (alarm.dismissTask > 0) {
                            val t = when (alarm.dismissTask) {
                                1 -> if (isAr) "رياضيات" else "Math"
                                2 -> if (isAr) "كتابة" else "Write"
                                3 -> "QR"
                                else -> ""
                            }
                            SmallBadge(Icons.Filled.Calculate, t, OrbOrange)
                        }
                        if (alarm.soundName.isNotBlank()) {
                            SmallBadge(Icons.Filled.MusicNote, alarm.soundName.take(10), OrbMint)
                        }
                        if (alarm.strictMode) {
                            SmallBadge(Icons.Filled.Lock, if (isAr) "صارم" else "Strict", OrbPink)
                        }
                    }
                }

                // ── Delete row ────────────────────────────────────────────
                AnimatedVisibility(
                    visible = showDelete,
                    enter = expandVertically(spring(stiffness = Spring.StiffnessLow)) + fadeIn(tween(200)),
                    exit  = shrinkVertically(tween(150)) + fadeOut(tween(150))
                ) {
                    Column {
                        Spacer(Modifier.height(12.dp))
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(0.5.dp)
                                .background(Separator)
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Cancel
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(0.07f))
                                    .border(0.5.dp, Color.White.copy(0.15f), RoundedCornerShape(12.dp))
                                    .clickable { showDelete = false },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    if (isAr) "إلغاء" else "Cancel",
                                    style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary)
                                )
                            }
                            // Delete
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(OrbPink.copy(0.20f))
                                    .border(0.5.dp, OrbPink.copy(0.45f), RoundedCornerShape(12.dp))
                                    .clickable { showDelete = false; onDelete() },
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.DeleteOutline, null, tint = OrbPink, modifier = Modifier.size(14.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        if (isAr) "حذف" else "Delete",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            color = OrbPink, fontWeight = FontWeight.SemiBold
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SmallBadge(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    color: Color
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(0.12f))
            .border(0.5.dp, color.copy(0.35f), RoundedCornerShape(8.dp))
            .padding(horizontal = 7.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = color.copy(0.85f), modifier = Modifier.size(10.dp))
        Spacer(Modifier.width(3.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 9.5.sp, color = color.copy(0.85f), fontWeight = FontWeight.Medium
            )
        )
    }
}

private operator fun Color.plus(other: Color): Color {
    return Color(
        red   = (this.red   * 0.5f + other.red   * 0.5f).coerceIn(0f, 1f),
        green = (this.green * 0.5f + other.green * 0.5f).coerceIn(0f, 1f),
        blue  = (this.blue  * 0.5f + other.blue  * 0.5f).coerceIn(0f, 1f),
        alpha = this.alpha
    )
}

@Composable
fun IosSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        modifier = modifier,
        colors = SwitchDefaults.colors(
            checkedThumbColor   = Color.White,
            checkedTrackColor   = ToggleOn,
            uncheckedThumbColor = Color.White.copy(0.85f),
            uncheckedTrackColor = ToggleOff,
            uncheckedBorderColor = Color.Transparent,
            checkedBorderColor  = Color.Transparent
        )
    )
}
