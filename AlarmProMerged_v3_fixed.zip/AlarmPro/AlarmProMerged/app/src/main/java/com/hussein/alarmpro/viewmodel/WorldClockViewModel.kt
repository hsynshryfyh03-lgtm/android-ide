package com.hussein.alarmpro.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hussein.alarmpro.data.model.WorldClockCity
import com.hussein.alarmpro.data.repository.WorldClockRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class WorldClockViewModel @Inject constructor(
    private val repo: WorldClockRepository
) : ViewModel() {

    val cities: StateFlow<List<WorldClockCity>> = repo.allCities
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addCity(city: WorldClockCity) = viewModelScope.launch { repo.insert(city) }
    fun removeCity(city: WorldClockCity) = viewModelScope.launch { repo.delete(city) }
}
