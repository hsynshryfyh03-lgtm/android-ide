package com.hussein.alarmpro.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.hussein.alarmpro.ui.theme.*
import kotlin.math.sin
import kotlin.math.cos

// ═══════════════════════════════════════════════════════════════════════════════
// iOS 26 LIQUID GLASS BACKGROUND
// Three animated orbs create the signature deep-space luminance
// ═══════════════════════════════════════════════════════════════════════════════
@Composable
fun LiquidGlassBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val transition = rememberInfiniteTransition(label = "orbs")

    val t1 by transition.animateFloat(
        0f, (2f * Math.PI).toFloat(),
        infiniteRepeatable(tween(18_000, easing = LinearEasing)), label = "t1"
    )
    val t2 by transition.animateFloat(
        (Math.PI).toFloat(), (3f * Math.PI).toFloat(),
        infiniteRepeatable(tween(24_000, easing = LinearEasing)), label = "t2"
    )
    val t3 by transition.animateFloat(
        (Math.PI / 2f).toFloat(), (5f * Math.PI / 2f).toFloat(),
        infiniteRepeatable(tween(15_000, easing = LinearEasing)), label = "t3"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .drawBehind {
                val w = size.width
                val h = size.height

                // ── Base: pure OLED black
                drawRect(DeepBlack)

                // ── Subtle radial dark-navy vignette
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(DarkNavy.copy(alpha = 0.9f), Color.Transparent),
                        center = Offset(w * 0.5f, h * 0.4f),
                        radius = w * 0.85f
                    ),
                    radius = w * 0.85f,
                    center = Offset(w * 0.5f, h * 0.4f)
                )

                // ── Orb 1: Blue (iOS 26 signature blue — top-left drift)
                val o1x = (0.15f + 0.30f * sin(t1)) * w
                val o1y = (0.20f + 0.18f * cos(t1 * 0.7f)) * h
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(OrbBlue.copy(alpha = 0.52f), OrbBlue.copy(alpha = 0.12f), Color.Transparent),
                        center = Offset(o1x, o1y), radius = w * 0.55f
                    ),
                    radius = w * 0.55f, center = Offset(o1x, o1y)
                )

                // ── Orb 2: Purple/Indigo (bottom-right drift)
                val o2x = (0.65f + 0.28f * sin(t2)) * w
                val o2y = (0.60f + 0.20f * cos(t2 * 0.8f)) * h
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(OrbPurple.copy(alpha = 0.48f), OrbIndigo.copy(alpha = 0.10f), Color.Transparent),
                        center = Offset(o2x, o2y), radius = w * 0.50f
                    ),
                    radius = w * 0.50f, center = Offset(o2x, o2y)
                )

                // ── Orb 3: Cyan accent (center bottom)
                val o3x = (0.40f + 0.18f * sin(t3)) * w
                val o3y = (0.82f + 0.10f * cos(t3 * 1.2f)) * h
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(OrbCyan.copy(alpha = 0.22f), Color.Transparent),
                        center = Offset(o3x, o3y), radius = w * 0.38f
                    ),
                    radius = w * 0.38f, center = Offset(o3x, o3y)
                )

                // ── Subtle top horizon glow
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(OrbBlue.copy(alpha = 0.04f), Color.Transparent),
                        endY = h * 0.18f
                    )
                )
            },
        content = content
    )
}

// ═══════════════════════════════════════════════════════════════════════════════
// iOS 26 GLASS CARD — The core material component
// Simulates: frosted backdrop + specular top highlight + luminous border
// ═══════════════════════════════════════════════════════════════════════════════
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 22.dp,
    alpha: Float = 1f,
    tint: Color = Color.White,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .clip(shape)
            // Layer 1: base fill (simulated frosted glass)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        tint.copy(alpha = 0.18f * alpha),
                        tint.copy(alpha = 0.09f * alpha)
                    )
                )
            )
            // Layer 2: luminous border (iOS 26 signature — bright top, dark bottom)
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.45f * alpha),
                        Color.White.copy(alpha = 0.20f * alpha),
                        Color.White.copy(alpha = 0.06f * alpha),
                        OrbBlue.copy(alpha = 0.18f * alpha)
                    ),
                    start = Offset(0f, 0f),
                    end   = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
                ),
                shape = shape
            )
            // Layer 3: inner specular top-edge highlight
            .drawBehind {
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.10f * alpha),
                            Color.Transparent
                        ),
                        endY = size.height * 0.35f
                    )
                )
                // Bottom inner shadow
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.12f * alpha)),
                        startY = size.height * 0.72f
                    )
                )
            },
        content = content
    )
}

// ═══════════════════════════════════════════════════════════════════════════════
// iOS 26 GLASS PILL — Capsule-shaped glass element (iOS 26 control style)
// ═══════════════════════════════════════════════════════════════════════════════
@Composable
fun GlassPill(
    modifier: Modifier = Modifier,
    color: Color = OrbBlue,
    alpha: Float = 1f,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(
                brush = Brush.verticalGradient(
                    listOf(
                        color.copy(alpha = 0.22f * alpha),
                        color.copy(alpha = 0.10f * alpha)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    listOf(
                        color.copy(alpha = 0.65f * alpha),
                        color.copy(alpha = 0.20f * alpha),
                        color.copy(alpha = 0.10f * alpha)
                    )
                ),
                shape = RoundedCornerShape(50)
            ),
        content = content
    )
}

// ═══════════════════════════════════════════════════════════════════════════════
// iOS 26 FLOATING NAV BAR — The signature pill-shaped bottom bar
// Floats above content, uses deepest glass material
// ═══════════════════════════════════════════════════════════════════════════════
@Composable
fun GlassNavBar(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(30.dp))
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.24f),
                        Color.White.copy(alpha = 0.12f)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.55f),
                        Color.White.copy(alpha = 0.08f)
                    )
                ),
                shape = RoundedCornerShape(30.dp)
            )
            .drawBehind {
                // Top specular line (most prominent feature of iOS 26 glass)
                drawRect(
                    brush = Brush.verticalGradient(
                        listOf(
                            Color.White.copy(alpha = 0.18f),
                            Color.Transparent
                        ),
                        endY = size.height * 0.25f
                    )
                )
            },
        content = content
    )
}
