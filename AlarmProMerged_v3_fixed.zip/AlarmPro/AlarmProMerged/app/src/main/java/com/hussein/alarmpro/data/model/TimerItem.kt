package com.hussein.alarmpro.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "timers")
data class TimerItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val label: String = "",
    val totalMillis: Long = 60_000L,    // original duration
    val remainingMillis: Long = 60_000L,
    val state: Int = TimerState.IDLE,   // 0=idle 1=running 2=paused 3=expired
    val soundUri: String = "",
    val vibrate: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

object TimerState {
    const val IDLE    = 0
    const val RUNNING = 1
    const val PAUSED  = 2
    const val EXPIRED = 3
}
