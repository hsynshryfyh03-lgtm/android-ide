package com.hussein.alarmpro.util

import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.database.ContentObserver
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import com.hussein.alarmpro.admin.AlarmDeviceAdmin
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Timer
import java.util.TimerTask
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Strict Mode Manager — The warden.
 *
 * Three concentric enforcement rings:
 *   Ring 1 (Always)  : Force task, no snooze bypass
 *   Ring 2 (Service) : Volume guardian + screen-off re-launch
 *   Ring 3 (A11y)    : Intercept volume keys + block settings navigation
 *
 * Uses @Volatile companion object so AccessibilityService (different lifecycle)
 * can read state without Hilt injection.
 */
@Singleton
class StrictModeManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        /** Static state — read by StrictAccessibilityService directly */
        @Volatile var isStrictActive: Boolean = false
        @Volatile var strictAlarmId: Int = -1
    }

    private var volumeObserver: VolumeGuardObserver? = null
    private var volumeTimer: Timer? = null
    private var screenOffReceiver: BroadcastReceiver? = null

    // ── Prerequisites ─────────────────────────────────────────────────────────

    fun isDeviceAdminActive(): Boolean = runCatching {
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val comp = ComponentName(context, AlarmDeviceAdmin::class.java)
        dpm.isAdminActive(comp)
    }.getOrDefault(false)

    fun isAccessibilityServiceEnabled(): Boolean = runCatching {
        val target = "${context.packageName}/com.hussein.alarmpro.service.StrictAccessibilityService"
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return@runCatching false
        enabled.split(':').any { it.trim().equals(target, ignoreCase = true) }
    }.getOrDefault(false)

    /** Both prerequisites met → full strict mode protection */
    fun isFullyArmed(): Boolean = isDeviceAdminActive() && isAccessibilityServiceEnabled()

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    /**
     * Engage strict mode when a strict-mode alarm fires.
     * Called from AlarmService immediately after startForeground().
     */
    fun engage(alarmId: Int) {
        isStrictActive = true
        strictAlarmId = alarmId
        startVolumeGuard()
        startScreenGuard()
        // Accessibility service reads the static vars directly — no IPC needed
    }

    /**
     * Disengage when alarm is dismissed after successful task completion.
     * Also called on snooze (alarms re-engages when it fires again).
     */
    fun disengage() {
        isStrictActive = false
        strictAlarmId = -1
        stopVolumeGuard()
        stopScreenGuard()
    }

    // ── Volume Guardian ───────────────────────────────────────────────────────

    private fun startVolumeGuard() {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        forceMaxAlarmVolume(am)

        // Layer A: ContentObserver — fires when Settings.System changes (includes volume)
        volumeObserver = VolumeGuardObserver(
            handler = Handler(Looper.getMainLooper()),
            onVolumeChanged = { forceMaxAlarmVolume(am) }
        )
        context.contentResolver.registerContentObserver(
            Settings.System.CONTENT_URI, true, volumeObserver!!
        )

        // Layer B: Timer polling every 500ms — bulletproof fallback
        volumeTimer = Timer("VolumeGuard", true).apply {
            schedule(object : TimerTask() {
                override fun run() {
                    if (isStrictActive) forceMaxAlarmVolume(am)
                    else cancel()
                }
            }, 500L, 500L)
        }
    }

    private fun stopVolumeGuard() {
        volumeObserver?.let { runCatching { context.contentResolver.unregisterContentObserver(it) } }
        volumeObserver = null
        volumeTimer?.cancel()
        volumeTimer = null
    }

    fun forceMaxAlarmVolume(am: AudioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager) {
        runCatching {
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            if (am.getStreamVolume(AudioManager.STREAM_ALARM) < max) {
                am.setStreamVolume(AudioManager.STREAM_ALARM, max, 0)
            }
        }
    }

    // ── Screen Guardian ───────────────────────────────────────────────────────

    private fun startScreenGuard() {
        screenOffReceiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                if (!isStrictActive || intent.action != Intent.ACTION_SCREEN_OFF) return

                // Acquire a FULL wakelock — turns the screen back on instantly
                val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
                @Suppress("DEPRECATION")
                val wl = pm.newWakeLock(
                    PowerManager.FULL_WAKE_LOCK or
                    PowerManager.ACQUIRE_CAUSES_WAKEUP or
                    PowerManager.ON_AFTER_RELEASE,
                    "AlarmPro::StrictScreenGuard"
                )
                wl.acquire(90_000L) // hold 90s — alarm task shouldn't take longer

                // Re-launch RingingActivity on top of whatever closed it
                runCatching {
                    ctx.startActivity(
                        Intent(ctx, com.hussein.alarmpro.ui.screens.RingingActivity::class.java)
                            .apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                                        Intent.FLAG_ACTIVITY_SINGLE_TOP
                                putExtra("alarm_id", strictAlarmId)
                                putExtra("strict_relaunch", true)
                            }
                    )
                }
                // Release after activity is on screen
                Handler(Looper.getMainLooper()).postDelayed({ wl.release() }, 4000L)
            }
        }
        context.registerReceiver(screenOffReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    private fun stopScreenGuard() {
        screenOffReceiver?.let { runCatching { context.unregisterReceiver(it) } }
        screenOffReceiver = null
    }
}

// ── Volume ContentObserver ────────────────────────────────────────────────────

private class VolumeGuardObserver(
    handler: Handler,
    private val onVolumeChanged: () -> Unit
) : ContentObserver(handler) {
    override fun onChange(selfChange: Boolean) {
        super.onChange(selfChange)
        if (StrictModeManager.isStrictActive) onVolumeChanged()
    }
}
