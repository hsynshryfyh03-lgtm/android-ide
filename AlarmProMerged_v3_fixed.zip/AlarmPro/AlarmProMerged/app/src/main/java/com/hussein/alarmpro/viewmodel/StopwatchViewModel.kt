package com.hussein.alarmpro.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

data class LapEntry(val lapNumber: Int, val lapTime: Long, val totalTime: Long)

data class StopwatchUiState(
    val elapsedMs: Long = 0L,
    val isRunning: Boolean = false,
    val laps: List<LapEntry> = emptyList()
)

@HiltViewModel
class StopwatchViewModel @Inject constructor() : ViewModel() {

    private val _state = MutableStateFlow(StopwatchUiState())
    val state: StateFlow<StopwatchUiState> = _state.asStateFlow()

    private var tickJob: Job? = null
    private var startTimeMs: Long = 0L
    private var accumulatedMs: Long = 0L

    fun start() {
        if (_state.value.isRunning) return
        startTimeMs = System.currentTimeMillis()
        _state.update { it.copy(isRunning = true) }
        tickJob = viewModelScope.launch {
            while (isActive) {
                val elapsed = accumulatedMs + (System.currentTimeMillis() - startTimeMs)
                _state.update { it.copy(elapsedMs = elapsed) }
                delay(16L)
            }
        }
    }

    fun pause() {
        tickJob?.cancel()
        accumulatedMs += System.currentTimeMillis() - startTimeMs
        _state.update { it.copy(isRunning = false, elapsedMs = accumulatedMs) }
    }

    fun reset() {
        tickJob?.cancel()
        accumulatedMs = 0L
        _state.value = StopwatchUiState()
    }

    fun lap() {
        val current = _state.value
        if (!current.isRunning) return
        val totalTime = current.elapsedMs
        val prevTotal = current.laps.lastOrNull()?.totalTime ?: 0L
        val lapTime   = totalTime - prevTotal
        val newLap    = LapEntry(current.laps.size + 1, lapTime, totalTime)
        _state.update { it.copy(laps = it.laps + newLap) }
    }
}
