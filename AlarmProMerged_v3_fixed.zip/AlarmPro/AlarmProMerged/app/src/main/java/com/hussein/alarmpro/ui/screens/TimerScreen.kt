package com.hussein.alarmpro.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.*
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import com.hussein.alarmpro.data.model.TimerItem
import com.hussein.alarmpro.data.model.TimerState
import com.hussein.alarmpro.ui.theme.*
import com.hussein.alarmpro.util.TimeUtils
import com.hussein.alarmpro.viewmodel.TimerViewModel
import top.yukonga.miuix.kmp.basic.SmallTitle
import top.yukonga.miuix.kmp.basic.Card
import java.util.Locale
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.Canvas

@Composable
fun TimerScreen(vm: TimerViewModel = hiltViewModel()) {
    val timers by vm.timers.collectAsState()
    val isAr = TimeUtils.isArabic()
    var showAddDialog by remember { mutableStateOf(false) }

    if (showAddDialog) {
        AddTimerDialog(isAr = isAr, onAdd = { h, m, s, label ->
            vm.addTimer(h, m, s, label)
            showAddDialog = false
        }, onDismiss = { showAddDialog = false })
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HyperBg)
            .navigationBarsPadding()
    ) {
        Spacer(Modifier.height(12.dp))

        if (timers.isEmpty()) {
            // Empty state
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Rounded.Timer, contentDescription = null,
                        tint = HyperTextTertiary, modifier = Modifier.size(64.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        if (isAr) "لا توجد مؤقتات" else "No timers",
                        color = HyperTextTertiary, fontSize = 16.sp
                    )
                    Spacer(Modifier.height(24.dp))
                    Button(
                        onClick = { showAddDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = TimerAccent)
                    ) {
                        Icon(Icons.Rounded.Add, null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (isAr) "مؤقت جديد" else "New Timer")
                    }
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(timers, key = { it.id }) { timer ->
                    TimerCard(
                        timer = timer,
                        isAr = isAr,
                        onStart  = { vm.startTimer(timer) },
                        onPause  = { vm.pauseTimer(timer) },
                        onReset  = { vm.resetTimer(timer) },
                        onDelete = { vm.deleteTimer(timer) }
                    )
                }
                item {
                    OutlinedButton(
                        onClick = { showAddDialog = true },
                        modifier = Modifier.fillMaxWidth(),
                        border = BorderStroke(1.dp, HyperSurface2),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Rounded.Add, null, tint = TimerAccent)
                        Spacer(Modifier.width(8.dp))
                        Text(if (isAr) "إضافة مؤقت" else "Add Timer", color = TimerAccent)
                    }
                }
            }
        }
    }
}

@Composable
private fun TimerCard(
    timer: TimerItem,
    isAr: Boolean,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onReset: () -> Unit,
    onDelete: () -> Unit
) {
    val progress = if (timer.totalMillis > 0) timer.remainingMillis.toFloat() / timer.totalMillis else 0f
    val animProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(200, easing = LinearEasing),
        label = "progress"
    )
    val accentColor = when (timer.state) {
        TimerState.EXPIRED  -> TimerExpired
        TimerState.RUNNING  -> TimerAccent
        else                -> HyperTextSecondary
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Label
            if (timer.label.isNotBlank()) {
                Text(timer.label, color = HyperTextSecondary, fontSize = 13.sp)
                Spacer(Modifier.height(6.dp))
            }
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Time display
                Text(
                    text = formatTimerTime(timer.remainingMillis),
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Light,
                    color = accentColor,
                    fontFamily = FontFamily.Monospace
                )
                // Action buttons
                Row {
                    if (timer.state == TimerState.RUNNING) {
                        IconButton(onClick = onPause) {
                            Icon(Icons.Rounded.Pause, null, tint = MiOrange)
                        }
                    } else {
                        IconButton(
                            onClick = onStart,
                            enabled = timer.state != TimerState.EXPIRED
                        ) {
                            Icon(Icons.Rounded.PlayArrow, null, tint = TimerAccent)
                        }
                    }
                    IconButton(onClick = onReset) {
                        Icon(Icons.Rounded.RestartAlt, null, tint = HyperTextSecondary)
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Rounded.DeleteOutline, null, tint = MiRed.copy(alpha = 0.7f))
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            // Progress bar
            LinearProgressIndicator(
                progress = { animProgress },
                modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                color = accentColor,
                trackColor = HyperSurface2
            )
            if (timer.state == TimerState.EXPIRED) {
                Spacer(Modifier.height(6.dp))
                Text(
                    if (isAr) "⏰ انتهى الوقت!" else "⏰ Time's up!",
                    color = TimerExpired,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun AddTimerDialog(
    isAr: Boolean,
    onAdd: (Int, Int, Int, String) -> Unit,
    onDismiss: () -> Unit
) {
    var hours   by remember { mutableIntStateOf(0) }
    var minutes by remember { mutableIntStateOf(5) }
    var seconds by remember { mutableIntStateOf(0) }
    var label   by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor  = HyperSurface,
        title = {
            Text(
                if (isAr) "مؤقت جديد" else "New Timer",
                color = HyperTextPrimary
            )
        },
        text = {
            Column {
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text(if (isAr) "التسمية (اختياري)" else "Label (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TimerAccent,
                        focusedLabelColor  = TimerAccent
                    )
                )
                Spacer(Modifier.height(16.dp))
                // H : M : S picker row
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NumberPicker(
                        value = hours, range = 0..23,
                        label = if (isAr) "س" else "H",
                        onValueChange = { hours = it }
                    )
                    Text(":", color = HyperTextPrimary, fontSize = 28.sp)
                    NumberPicker(
                        value = minutes, range = 0..59,
                        label = if (isAr) "د" else "M",
                        onValueChange = { minutes = it }
                    )
                    Text(":", color = HyperTextPrimary, fontSize = 28.sp)
                    NumberPicker(
                        value = seconds, range = 0..59,
                        label = if (isAr) "ث" else "S",
                        onValueChange = { seconds = it }
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onAdd(hours, minutes, seconds, label) },
                colors = ButtonDefaults.buttonColors(containerColor = TimerAccent),
                enabled = (hours + minutes + seconds) > 0
            ) {
                Text(if (isAr) "إضافة" else "Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isAr) "إلغاء" else "Cancel", color = HyperTextSecondary)
            }
        }
    )
}

@Composable
private fun NumberPicker(
    value: Int, range: IntRange, label: String,
    onValueChange: (Int) -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = {
            onValueChange(if (value >= range.last) range.first else value + 1)
        }) {
            Icon(Icons.Rounded.KeyboardArrowUp, null, tint = TimerAccent)
        }
        Text(
            text = value.toString().padStart(2, '0'),
            fontSize = 28.sp,
            fontWeight = FontWeight.Medium,
            color = HyperTextPrimary,
            fontFamily = FontFamily.Monospace
        )
        Text(label, fontSize = 11.sp, color = HyperTextTertiary)
        IconButton(onClick = {
            onValueChange(if (value <= range.first) range.last else value - 1)
        }) {
            Icon(Icons.Rounded.KeyboardArrowDown, null, tint = HyperTextTertiary)
        }
    }
}

private fun formatTimerTime(ms: Long): String {
    val h = ms / 3_600_000
    val m = (ms % 3_600_000) / 60_000
    val s = (ms % 60_000) / 1_000
    return if (h > 0) String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%02d:%02d", m, s)
}
