package com.hussein.alarmpro.widget

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.*
import androidx.glance.action.clickable
import androidx.glance.appwidget.*
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.background
import androidx.glance.layout.*
import androidx.glance.text.*
import androidx.glance.unit.ColorProvider
import com.hussein.alarmpro.MainActivity
import com.hussein.alarmpro.R
import com.hussein.alarmpro.data.db.AlarmDatabase
import com.hussein.alarmpro.data.model.Alarm
import com.hussein.alarmpro.util.TimeUtils
import kotlinx.coroutines.flow.first

class AlarmWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val alarms = AlarmDatabase.getInstance(context).alarmDao().getAllAlarms().first()
        val enabled = alarms.filter { it.isEnabled }.sortedBy { it.hour * 60 + it.minute }
        val isAr = TimeUtils.isArabic()
        provideContent {
            WidgetContent(alarms = enabled.take(3), isAr = isAr, context = context)
        }
    }
}

@Composable
private fun WidgetContent(alarms: List<Alarm>, isAr: Boolean, context: Context) {
    Box(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(Color(0xCC0D0D1A))
            .cornerRadius(20.dp)
            .clickable(actionStartActivity(Intent(context, MainActivity::class.java)))
    ) {
        Column(modifier = GlanceModifier.fillMaxSize().padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    provider = ImageProvider(R.drawable.ic_alarm_notif),
                    contentDescription = null,
                    modifier = GlanceModifier.size(16.dp)
                )
                Spacer(GlanceModifier.width(6.dp))
                Text(
                    text = if (isAr) "المنبهات" else "Alarms",
                    style = TextStyle(
                        color = ColorProvider(Color(0xFF0A84FF)),
                        fontSize = 13.sp, fontWeight = FontWeight.Bold
                    )
                )
            }
            Spacer(GlanceModifier.height(8.dp))
            if (alarms.isEmpty()) {
                Text(
                    text = if (isAr) "لا توجد منبهات" else "No active alarms",
                    style = TextStyle(color = ColorProvider(Color(0x99FFFFFF)), fontSize = 12.sp)
                )
            } else {
                alarms.forEach { alarm ->
                    Row(
                        modifier = GlanceModifier
                            .fillMaxWidth()
                            .background(Color(0x22FFFFFF))
                            .cornerRadius(10.dp)
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = TimeUtils.formatTime(alarm.hour, alarm.minute),
                            style = TextStyle(
                                color = ColorProvider(Color.White),
                                fontSize = 18.sp, fontWeight = FontWeight.Bold
                            ),
                            modifier = GlanceModifier.defaultWeight()
                        )
                        Text(
                            text = TimeUtils.daysLabel(alarm.days, isAr),
                            style = TextStyle(
                                color = ColorProvider(Color(0xFF0A84FF)),
                                fontSize = 10.sp
                            )
                        )
                    }
                    Spacer(GlanceModifier.height(4.dp))
                }
            }
            Spacer(GlanceModifier.defaultWeight())
            Text(
                text = if (isAr) "برمجة - حسين حميد الشريفي" else "AlarmPro",
                style = TextStyle(color = ColorProvider(Color(0x44FFFFFF)), fontSize = 9.sp)
            )
        }
    }
}

class AlarmWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = AlarmWidget()
}
