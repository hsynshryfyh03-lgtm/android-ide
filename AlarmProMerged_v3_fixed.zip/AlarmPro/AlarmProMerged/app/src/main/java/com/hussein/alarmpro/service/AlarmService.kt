package com.hussein.alarmpro.service

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.*
import android.util.Log
import androidx.core.app.ServiceCompat
import com.hussein.alarmpro.data.repository.AlarmRepository
import com.hussein.alarmpro.receiver.AlarmReceiver
import com.hussein.alarmpro.util.*
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import javax.inject.Inject

@AndroidEntryPoint
class AlarmService : Service() {

    companion object {
        const val ACTION_START   = "com.hussein.alarmpro.START"
        const val ACTION_SNOOZE  = "com.hussein.alarmpro.SNOOZE"
        const val ACTION_DISMISS = "com.hussein.alarmpro.DISMISS"
        private const val TAG = "AlarmService"

        // Auto-escalation defaults when gradualVolume is OFF
        private const val AUTO_ESCALATION_DURATION_SEC = 20
        private const val AUTO_ESCALATION_MIN_PERCENT  = 15   // start at 15%
    }

    @Inject lateinit var repository: AlarmRepository
    @Inject lateinit var scheduler: AlarmScheduler
    @Inject lateinit var preAlarmScheduler: PreAlarmScheduler
    @Inject lateinit var notifHelper: NotificationHelper
    @Inject lateinit var soundManager: SoundManager
    @Inject lateinit var wakeLock: WakeLockManager
    @Inject lateinit var dndHelper: DndHelper
    @Inject lateinit var ringingState: RingingStateHolder
    @Inject lateinit var strictModeManager: StrictModeManager

    private var vibrator: Vibrator? = null
    private var gradualJob: Job? = null
    private var autoSnoozeJob: Job? = null
    private var autoDismissJob: Job? = null
    private var snoozeCount = 0
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        notifHelper.createChannels()
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION") getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getIntExtra("alarm_id", -1) ?: return START_NOT_STICKY
        val isWakeCheck = intent.getBooleanExtra("is_wake_check", false)

        when (intent.action) {
            ACTION_START -> {
                // Call startForeground within 5 seconds with explicit type for Android 14+
                ServiceCompat.startForeground(
                    this,
                    NotificationHelper.FG_ID,
                    notifHelper.buildPlaceholderNotification(),
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                        android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                    else 0
                )
                startAlarm(id, isWakeCheck)
            }
            ACTION_SNOOZE  -> handleSnooze(id)
            ACTION_DISMISS -> handleDismiss(id)
        }
        return START_NOT_STICKY
    }

    private fun startAlarm(alarmId: Int, isWakeCheck: Boolean = false) {
        scope.launch {
            val alarm = repository.getById(alarmId) ?: run { stopSelf(); return@launch }

            ringingState.setRinging(alarmId)
            wakeLock.acquire()

            // Always bypass DND to ensure alarm is audible
            dndHelper.prepareForAlarm()

            // Strict Mode: engage fortress
            if (alarm.strictMode) {
                strictModeManager.engage(alarmId)
            }

            withContext(Dispatchers.Main) {
                // Update notification with real alarm info
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                nm.notify(NotificationHelper.FG_ID, notifHelper.buildAlarmNotification(alarm))

                startActivity(
                    Intent(this@AlarmService,
                        com.hussein.alarmpro.ui.screens.RingingActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                        putExtra("alarm_id", alarmId)
                        putExtra("dismiss_type", alarm.dismissType)
                    }
                )

                // ── UNIVERSAL AUTO-VOLUME ESCALATION ──────────────────────────────────
                // Volume ALWAYS ramps up from a minimum to the target — regardless of
                // the gradualVolume setting. This guarantees the alarm is heard even if:
                //   - The phone was in silent/DND mode
                //   - The alarm stream volume was set to 0 by the user
                //   - gradualVolume is disabled in settings
                // ─────────────────────────────────────────────────────────────────────
                val targetVol = alarm.volumePercent.coerceIn(1, 100)

                // Strict mode: never start too quietly; otherwise respect gradual setting
                val startVol = when {
                    alarm.strictMode       -> 40                    // strict: always loud start
                    alarm.gradualVolume    -> 5                     // gradual: soft start
                    else                   -> AUTO_ESCALATION_MIN_PERCENT
                }

                // Duration: use configured value if gradual is ON, else use default
                val durationSec = when {
                    alarm.gradualVolume -> alarm.gradualVolumeDurationSec.coerceAtLeast(1)
                    else               -> AUTO_ESCALATION_DURATION_SEC
                }

                Log.d(TAG, "Auto-escalation: startVol=$startVol → targetVol=$targetVol over ${durationSec}s")

                // Start playing at minimum volume
                soundManager.play(alarm.soundUri, startVol)
                if (alarm.strictMode) strictModeManager.forceMaxAlarmVolume()

                // Ramp up to target volume over durationSec
                if (startVol < targetVol) {
                    gradualJob = scope.launch {
                        val range = targetVol - startVol
                        for (step in 1..durationSec) {
                            delay(1000L)
                            if (!isActive) break
                            val vol = startVol + (range * step / durationSec)
                            soundManager.setVolume(vol.coerceIn(startVol, targetVol))
                            if (alarm.strictMode) strictModeManager.forceMaxAlarmVolume()
                        }
                        // Ensure we hit exactly the target at the end
                        soundManager.setVolume(targetVol)
                        if (alarm.strictMode) strictModeManager.forceMaxAlarmVolume()
                        Log.d(TAG, "Auto-escalation complete at vol=$targetVol")
                    }
                }

                if (alarm.isVibrate) vibrate(alarm.vibrationPattern)
            }

            // Auto-snooze (disabled in strict mode)
            if (!alarm.strictMode && !isWakeCheck && alarm.autoSnoozeMinutes > 0) {
                autoSnoozeJob = scope.launch {
                    delay(alarm.autoSnoozeMinutes * 60_000L)
                    handleSnooze(alarmId)
                }
            }

            // Auto-dismiss
            val autoDismissAfterMin = when {
                isWakeCheck && alarm.wakeCheckCountdownMinutes > 0 -> alarm.wakeCheckCountdownMinutes
                !isWakeCheck && alarm.autoDissmissMinutes > 0      -> alarm.autoDissmissMinutes
                else -> -1
            }
            if (autoDismissAfterMin > 0) {
                autoDismissJob = scope.launch {
                    delay(autoDismissAfterMin * 60_000L)
                    handleDismiss(alarmId, skipWakeCheck = true)
                }
            }
        }
    }

    private fun handleSnooze(alarmId: Int) {
        scope.launch {
            val alarm = repository.getById(alarmId) ?: run { stopSelf(); return@launch }

            if (alarm.snoozeMaxCount != -1 && snoozeCount >= alarm.snoozeMaxCount) {
                handleDismiss(alarmId)
                return@launch
            }

            cancelJobs()
            soundManager.stop()
            vibrator?.cancel()
            wakeLock.release()
            dndHelper.restore()
            ringingState.clearRinging()

            if (alarm.strictMode) strictModeManager.disengage()

            snoozeCount++
            val min = maxOf(1, alarm.snoozeMinutes - alarm.snoozeReduceMinutes * (snoozeCount - 1))
            val triggerAt = System.currentTimeMillis() + min * 60_000L
            val pi = PendingIntent.getBroadcast(
                this@AlarmService, alarmId + 99000,
                Intent(this@AlarmService, AlarmReceiver::class.java).apply {
                    action = "com.hussein.alarmpro.ACTION_ALARM_FIRE"
                    putExtra("alarm_id", alarmId)
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            (getSystemService(Context.ALARM_SERVICE) as AlarmManager)
                .setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)

            withContext(Dispatchers.Main) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                sendBroadcast(Intent("com.hussein.alarmpro.ACTION_CLOSE_RING"))
                stopSelf()
            }
        }
    }

    private fun handleDismiss(alarmId: Int, skipWakeCheck: Boolean = false) {
        scope.launch {
            val alarm = repository.getById(alarmId)
            cancelJobs()
            soundManager.stop()
            vibrator?.cancel()
            wakeLock.release()
            dndHelper.restore()
            ringingState.clearRinging()

            if (alarm?.strictMode == true) strictModeManager.disengage()

            if (alarm != null) {
                if (alarm.days == 0 && alarm.scheduledDate == 0L) {
                    repository.update(alarm.copy(isEnabled = false))
                } else {
                    repository.update(alarm.copy(skipToday = false))
                    scheduler.schedule(alarm)
                    preAlarmScheduler.schedule(alarm)
                }
                if (!skipWakeCheck && alarm.wakeCheckEnabled && alarm.wakeCheckDelayMinutes > 0) {
                    val wakeCheckTrigger = System.currentTimeMillis() + alarm.wakeCheckDelayMinutes * 60_000L
                    val wakeCheckPi = PendingIntent.getBroadcast(
                        this@AlarmService, alarmId + 88000,
                        Intent(this@AlarmService, AlarmReceiver::class.java).apply {
                            action = "com.hussein.alarmpro.ACTION_WAKE_CHECK_FIRE"
                            putExtra("alarm_id", alarmId)
                        },
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                    (getSystemService(Context.ALARM_SERVICE) as AlarmManager)
                        .setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, wakeCheckTrigger, wakeCheckPi)
                }
            }
            withContext(Dispatchers.Main) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                sendBroadcast(Intent("com.hussein.alarmpro.ACTION_CLOSE_RING"))
                stopSelf()
            }
        }
    }

    private fun vibrate(pattern: Int) {
        val p = when (pattern) {
            0 -> return
            2 -> longArrayOf(0, 200, 100, 200, 100, 400)
            3 -> longArrayOf(0, 100, 100, 200, 100, 400, 100, 800)
            else -> longArrayOf(0, 500, 200, 500)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            vibrator?.vibrate(VibrationEffect.createWaveform(p, 0))
        else @Suppress("DEPRECATION") vibrator?.vibrate(p, 0)
    }

    /** Cancel all running jobs — call before releasing resources. */
    private fun cancelJobs() {
        gradualJob?.cancel()
        autoSnoozeJob?.cancel()
        autoDismissJob?.cancel()
    }

    override fun onDestroy() {
        super.onDestroy()
        // IMPORTANT: stop sound BEFORE cancelling scope so the stop() call runs
        cancelJobs()
        soundManager.stop()
        vibrator?.cancel()
        wakeLock.release()
        dndHelper.restore()
        ringingState.clearRinging()
        if (StrictModeManager.isStrictActive) strictModeManager.disengage()
        scope.cancel()
        Log.d(TAG, "onDestroy")
    }
}
