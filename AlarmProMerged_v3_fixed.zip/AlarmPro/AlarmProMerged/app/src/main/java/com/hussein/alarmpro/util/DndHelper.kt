package com.hussein.alarmpro.util

import android.app.NotificationManager
import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.util.Log
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Ensures alarm audio plays in ALL conditions:
 *   - Silent / vibrate-only ringer mode
 *   - DND (Do Not Disturb) mode
 *   - Alarm stream manually muted by user
 *
 * STREAM_ALARM is technically separate from STREAM_RING and bypasses silent mode
 * by Android design, but we still guard against edge cases on OEM ROMs.
 *
 * Called unconditionally from AlarmService (not gated by bypassDnd flag).
 */
@Singleton
class DndHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val notifManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    /** Saved values – restored after alarm finishes. */
    private var savedRingerMode: Int = AudioManager.RINGER_MODE_NORMAL
    private var savedAlarmVolume: Int = -1
    private var prepared: Boolean = false

    // ── Public API ────────────────────────────────────────────────────────────

    /** Call before playing the alarm sound. Idempotent – safe to call multiple times. */
    fun prepareForAlarm() {
        if (prepared) return
        prepared = true

        // 1. Save current state
        savedRingerMode  = audioManager.ringerMode
        savedAlarmVolume = audioManager.getStreamVolume(AudioManager.STREAM_ALARM)

        // 2. Ensure alarm stream is audible (never 0)
        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
        if (audioManager.getStreamVolume(AudioManager.STREAM_ALARM) == 0) {
            runCatching {
                audioManager.setStreamVolume(AudioManager.STREAM_ALARM, maxVol, 0)
            }
            Log.d("DndHelper", "Alarm stream was 0 → boosted to max ($maxVol)")
        }

        // 3. Temporarily switch DND to "alarms only" so our sound cuts through
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && isDndPermissionGranted) {
            runCatching {
                val current = notifManager.currentInterruptionFilter
                if (current != NotificationManager.INTERRUPTION_FILTER_ALL &&
                    current != NotificationManager.INTERRUPTION_FILTER_ALARMS
                ) {
                    notifManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALARMS)
                    Log.d("DndHelper", "DND → INTERRUPTION_FILTER_ALARMS (was $current)")
                }
            }
        }
    }

    /** Call after alarm is dismissed / snoozed. Restores pre-alarm state. */
    fun restore() {
        if (!prepared) return
        prepared = false

        runCatching {
            // Restore DND filter
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && isDndPermissionGranted) {
                notifManager.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
            }
            // Restore alarm volume (only if we have a saved value)
            if (savedAlarmVolume >= 0) {
                val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
                audioManager.setStreamVolume(
                    AudioManager.STREAM_ALARM,
                    savedAlarmVolume.coerceIn(0, max),
                    0
                )
                Log.d("DndHelper", "Restored alarm volume to $savedAlarmVolume")
            }
        }
        savedAlarmVolume = -1
    }

    val isDndPermissionGranted: Boolean
        get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            notifManager.isNotificationPolicyAccessGranted else true
}
