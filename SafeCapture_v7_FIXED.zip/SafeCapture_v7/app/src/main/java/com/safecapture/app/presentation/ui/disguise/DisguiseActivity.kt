package com.safecapture.app.presentation.ui.disguise

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.safecapture.app.MainActivity
import com.safecapture.app.presentation.ui.theme.SafeCaptureTheme

/**
 * A fully functional calculator that disguises SafeCapture.
 * Secret: Enter "911" and press "=" to launch SafeCapture.
 */
class DisguiseActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SafeCaptureTheme {
                DisguiseCalculatorScreen(
                    onSecretUnlocked = {
                        startActivity(Intent(this, MainActivity::class.java))
                    }
                )
            }
        }
    }
}

@Composable
fun DisguiseCalculatorScreen(onSecretUnlocked: () -> Unit) {
    var display    by remember { mutableStateOf("0") }
    var expression by remember { mutableStateOf("") }
    var result     by remember { mutableStateOf("") }
    var justResult by remember { mutableStateOf(false) }

    // Secret code tracking
    var inputBuffer by remember { mutableStateOf("") }

    fun appendDisplay(ch: String) {
        inputBuffer += ch
        // Detect secret: expression contains "911" when "=" is pressed
        if (justResult) {
            display    = ch
            expression = ch
            justResult = false
        } else {
            display    = if (display == "0") ch else display + ch
            expression += ch
        }
    }

    fun appendOp(op: String) {
        inputBuffer = ""
        if (justResult) { expression = result; justResult = false }
        display    = op
        expression += op
    }

    fun clear() {
        display    = "0"
        expression = ""
        result     = ""
        inputBuffer = ""
        justResult = false
    }

    fun calculate(triggerSecret: Boolean) {
        if (triggerSecret && inputBuffer == "911") {
            onSecretUnlocked()
            clear()
            return
        }
        try {
            val expr = expression
                .replace("×", "*")
                .replace("÷", "/")
                .replace("−", "-")   // FIX BUG-2: U+2212 MINUS SIGN → ASCII '-' (tokenizer only knows '-')
                .replace("%", "/100.0")
            val res = evalExpression(expr)
            result     = formatResult(res)
            display    = result
            expression = result
            justResult = true
            inputBuffer = ""
        } catch (e: Exception) {
            display    = "خطأ"
            justResult = true
        }
    }

    val bg = Color(0xFF1C1C1E)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bg)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.Bottom,
    ) {
        // ── Display ──
        Column(
            modifier            = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.End,
        ) {
            if (expression.isNotEmpty() && !justResult) {
                Text(
                    text       = expression,
                    fontSize   = 20.sp,
                    color      = Color.Gray,
                    textAlign  = TextAlign.End,
                    maxLines   = 1,
                    overflow   = TextOverflow.Ellipsis,
                )
            }
            Spacer(Modifier.height(8.dp))
            AnimatedContent(
                targetState = display,
                transitionSpec = { fadeIn(tween(100)) togetherWith fadeOut(tween(80)) },
                label = "display"
            ) { d ->
                Text(
                    text       = d,
                    fontSize   = if (d.length > 10) 40.sp else 64.sp,
                    fontWeight = FontWeight.Light,
                    color      = Color.White,
                    textAlign  = TextAlign.End,
                    maxLines   = 1,
                    overflow   = TextOverflow.Ellipsis,
                    modifier   = Modifier.fillMaxWidth(),
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        // ── Button grid ──
        val buttonRows = listOf(
            listOf("AC", "+/-", "%", "÷"),
            listOf("7",  "8",   "9", "×"),
            listOf("4",  "5",   "6", "−"),
            listOf("1",  "2",   "3", "+"),
            listOf("0",  ".",   "⌫", "="),
        )

        buttonRows.forEach { row ->
            Row(
                modifier              = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 5.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                row.forEach { label ->
                    CalcButton(
                        label    = label,
                        modifier = Modifier.weight(if (label == "0") 1f else 1f),
                        onClick  = {
                            when (label) {
                                "AC"  -> clear()
                                "+/-" -> {
                                    // FIX BUG-2: update both display and expression for negation
                                    if (display.startsWith("-")) {
                                        display    = display.drop(1)
                                        expression = expression.drop(1)
                                    } else {
                                        display    = "-$display"
                                        expression = "-$expression"
                                    }
                                }
                                "%"   -> appendOp("%")
                                "÷"   -> appendOp("÷")
                                "×"   -> appendOp("×")
                                "−"   -> appendOp("-")
                                "+"   -> appendOp("+")
                                "="   -> calculate(true)
                                "⌫"  -> {
                                    if (display.length > 1) {
                                        display = display.dropLast(1)
                                        if (expression.isNotEmpty()) expression = expression.dropLast(1)
                                        if (inputBuffer.isNotEmpty()) inputBuffer = inputBuffer.dropLast(1)
                                    } else {
                                        display = "0"
                                    }
                                }
                                "."   -> if (!display.contains(".")) appendDisplay(".")
                                else  -> appendDisplay(label)
                            }
                        }
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun CalcButton(
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val isOperator = label in listOf("÷", "×", "−", "+", "=")
    val isFunction = label in listOf("AC", "+/-", "%")
    val isAction   = label == "⌫"

    val bgColor = when {
        label     == "=" -> Color(0xFFFF9F0A)
        isOperator       -> Color(0xFFFF9F0A)
        isFunction       -> Color(0xFF636366)
        isAction         -> Color(0xFF636366)
        else             -> Color(0xFF2C2C2E)
    }
    val textColor = when {
        isFunction -> Color.Black
        isAction   -> Color.White
        else       -> Color.White
    }

    Box(
        modifier = modifier
            .aspectRatio(1f)
            .clip(CircleShape)
            .background(bgColor)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text       = label,
            fontSize   = if (label.length > 2) 22.sp else 28.sp,
            fontWeight = FontWeight.Medium,
            color      = textColor,
        )
    }
}

// ── Simple expression evaluator (no external lib needed) ─────────
private fun evalExpression(expr: String): Double {
    val tokens = tokenize(expr)
    return parseExpr(tokens, 0).first
}

private fun tokenize(expr: String): List<String> {
    val tokens = mutableListOf<String>()
    var i = 0
    while (i < expr.length) {
        val c = expr[i]
        if (c.isDigit() || c == '.') {
            var num = ""
            while (i < expr.length && (expr[i].isDigit() || expr[i] == '.')) {
                num += expr[i++]
            }
            tokens.add(num)
        } else if (c in listOf('+', '-', '*', '/')) {
            tokens.add(c.toString()); i++
        } else i++
    }
    return tokens
}

private fun parseExpr(tokens: List<String>, pos: Int): Pair<Double, Int> {
    var (left, p) = parseTerm(tokens, pos)
    while (p < tokens.size && tokens[p] in listOf("+", "-")) {
        val op = tokens[p++]
        val (right, np) = parseTerm(tokens, p)
        left = if (op == "+") left + right else left - right
        p = np
    }
    return Pair(left, p)
}

private fun parseTerm(tokens: List<String>, pos: Int): Pair<Double, Int> {
    var (left, p) = parseFactor(tokens, pos)
    while (p < tokens.size && tokens[p] in listOf("*", "/")) {
        val op = tokens[p++]
        val (right, np) = parseFactor(tokens, p)
        left = if (op == "*") left * right else left / right
        p = np
    }
    return Pair(left, p)
}

private fun parseFactor(tokens: List<String>, pos: Int): Pair<Double, Int> {
    if (pos >= tokens.size) return Pair(0.0, pos)
    return Pair(tokens[pos].toDouble(), pos + 1)
}

private fun formatResult(d: Double): String {
    return if (d == d.toLong().toDouble()) d.toLong().toString() else "%.6f".format(d).trimEnd('0')
}
