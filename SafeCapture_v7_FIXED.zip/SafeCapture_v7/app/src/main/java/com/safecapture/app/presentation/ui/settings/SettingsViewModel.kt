package com.safecapture.app.presentation.ui.settings

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.safecapture.app.data.local.datastore.SettingsDataStore
import com.safecapture.app.domain.model.AppSettings
import com.safecapture.app.presentation.ui.disguise.DisguiseActivity
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

// FIX #7: Type-safe data class instead of List<Any>
private data class TelegramFormState(
    val expanded: Boolean  = false,
    val token:    String   = "",
    val chatId:   String   = "",
    val saved:    Boolean  = false,
)

data class SettingsUiState(
    val settings         : AppSettings = AppSettings(),
    val darkMode         : Boolean     = false,
    val stealthMode      : Boolean     = false,
    val pinEnabled       : Boolean     = false,
    val telegramExpanded : Boolean     = false,
    val tokenInput       : String      = "",
    val chatIdInput      : String      = "",
    val tokenSaved       : Boolean     = false,
)

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val dataStore: SettingsDataStore,
    @ApplicationContext private val context: Context,
) : ViewModel() {

    private val _tgForm = MutableStateFlow(TelegramFormState())

    val uiState: StateFlow<SettingsUiState> = combine(
        dataStore.settingsFlow,
        dataStore.darkModeFlow,
        dataStore.stealthModeFlow,
        dataStore.pinEnabledFlow,
        _tgForm,                         // FIX #7: typed, no casts
    ) { settings, dark, stealth, pin, tg ->
        SettingsUiState(
            settings         = settings,
            darkMode         = dark,
            stealthMode      = stealth,
            pinEnabled       = pin,
            telegramExpanded = tg.expanded,
            tokenInput       = tg.token.ifEmpty { settings.telegramBotToken },
            chatIdInput      = tg.chatId.ifEmpty { settings.telegramChatId },
            tokenSaved       = tg.saved,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SettingsUiState())

    fun setDoublePressDelay(ms: Int)          = viewModelScope.launch { dataStore.updateDoublePressDelay(ms) }
    fun setVibration(enabled: Boolean)        = viewModelScope.launch { dataStore.updateVibration(enabled) }
    fun setVideoQuality(q: String)            = viewModelScope.launch { dataStore.updateVideoQuality(q) }
    fun setCameraFacing(f: String)            = viewModelScope.launch { dataStore.updateCameraFacing(f) }
    fun setMaxDuration(m: Int)                = viewModelScope.launch { dataStore.updateMaxDuration(m) }
    fun setAutoDelete(days: Int)              = viewModelScope.launch { dataStore.updateAutoDeleteDays(days) }
    fun setAudioEnabled(enabled: Boolean)     = viewModelScope.launch { dataStore.updateAudioEnabled(enabled) }
    fun setDarkMode(enabled: Boolean)         = viewModelScope.launch { dataStore.updateDarkMode(enabled) }
    fun setStealthMode(enabled: Boolean)      = viewModelScope.launch { dataStore.updateStealthMode(enabled) }
    fun setTimestampOverlay(enabled: Boolean) = viewModelScope.launch { dataStore.updateTimestampOverlay(enabled) }

    fun setDisguiseMode(enabled: Boolean) = viewModelScope.launch {
        dataStore.updateDisguiseMode(enabled)
        // FIX: Actually enable/disable DisguiseActivity in Launcher via PackageManager.
        // Without this the setting was saved but the icon never appeared/disappeared.
        val state = if (enabled)
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED
        else
            PackageManager.COMPONENT_ENABLED_STATE_DISABLED
        context.packageManager.setComponentEnabledSetting(
            ComponentName(context, DisguiseActivity::class.java),
            state,
            PackageManager.DONT_KILL_APP
        )
    }

    fun setTelegramExpanded(v: Boolean) { _tgForm.update { it.copy(expanded = v) } }
    fun onTokenInput(v: String)         { _tgForm.update { it.copy(token = v, saved = false) } }
    fun onChatIdInput(v: String)        { _tgForm.update { it.copy(chatId = v, saved = false) } }

    fun saveTelegramConfig() = viewModelScope.launch {
        val form = _tgForm.value
        dataStore.updateTelegramToken(form.token.trim())
        dataStore.updateTelegramChatId(form.chatId.trim())
        _tgForm.update { it.copy(saved = true) }
    }

    fun setTelegramAutoUpload(enabled: Boolean) =
        viewModelScope.launch { dataStore.updateTelegramAutoUpload(enabled) }

    fun enablePin() = viewModelScope.launch {
        // Persist pinEnabled=true with blank hash → PinViewModel enters setup mode.
        // The actual PIN hash is written by PinViewModel.handleSetup() after user enters PIN.
        dataStore.updatePin(enabled = true, pinHash = "")
    }

    fun disablePin() = viewModelScope.launch {
        dataStore.updatePin(enabled = false, pinHash = "")
    }
}
