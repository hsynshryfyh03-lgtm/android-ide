package com.safecapture.app.presentation.ui.pin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.safecapture.app.data.local.datastore.SettingsDataStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import javax.inject.Inject

data class PinUiState(
    val pinEnabled      : Boolean = false,
    val isUnlocked      : Boolean = false,
    val enteredPin      : String  = "",
    val isError         : Boolean = false,
    val errorMessage    : String  = "",
    val isSetupMode     : Boolean = false,
    val confirmPin      : String  = "",
    val awaitingConfirm : Boolean = false,
)

@HiltViewModel
class PinViewModel @Inject constructor(
    private val settingsDataStore: SettingsDataStore,
) : ViewModel() {

    private val _uiState = MutableStateFlow(PinUiState())
    val uiState: StateFlow<PinUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            val pinEnabled = settingsDataStore.pinEnabledFlow.first()
            val pinHash    = settingsDataStore.pinHashFlow.first()
            _uiState.update {
                it.copy(
                    pinEnabled  = pinEnabled,
                    isSetupMode = pinEnabled && pinHash.isBlank(),
                    isUnlocked  = !pinEnabled,
                )
            }
        }
    }

    // ── Input ──────────────────────────────────────────────────────

    fun onDigit(digit: String) {
        if (_uiState.value.isError) clearError()
        val s = _uiState.value
        if (s.isSetupMode && s.awaitingConfirm) {
            if (s.confirmPin.length < 6) _uiState.update { it.copy(confirmPin = it.confirmPin + digit) }
        } else {
            if (s.enteredPin.length < 6) _uiState.update { it.copy(enteredPin = it.enteredPin + digit) }
        }
    }

    fun onBackspace() {
        if (_uiState.value.isError) { clearError(); return }
        val s = _uiState.value
        if (s.isSetupMode && s.awaitingConfirm)
            _uiState.update { it.copy(confirmPin = it.confirmPin.dropLast(1)) }
        else
            _uiState.update { it.copy(enteredPin = it.enteredPin.dropLast(1)) }
    }

    fun onConfirm() {
        val s = _uiState.value
        if (s.isSetupMode) handleSetup(s) else handleUnlock(s)
    }

    // ── Setup ──────────────────────────────────────────────────────

    private fun handleSetup(s: PinUiState) {
        if (!s.awaitingConfirm) {
            if (s.enteredPin.length < 4) { showError("أدخل 4 أرقام على الأقل"); return }
            _uiState.update { it.copy(awaitingConfirm = true, isError = false) }
        } else {
            if (s.confirmPin != s.enteredPin) {
                showError("الأرقام غير متطابقة")
                _uiState.update { it.copy(confirmPin = "", awaitingConfirm = false) }
                return
            }
            viewModelScope.launch {
                // FIX BUG-1: PBKDF2 (100k iterations) must run on IO — calling it on Main causes ANR
                val hash = withContext(Dispatchers.IO) { hashPin(s.enteredPin) }
                settingsDataStore.updatePin(enabled = true, pinHash = hash)
                _uiState.update { it.copy(isUnlocked = true, isSetupMode = false) }
            }
        }
    }

    // ── Unlock ─────────────────────────────────────────────────────

    private fun handleUnlock(s: PinUiState) {
        if (s.enteredPin.length < 4) { showError("أدخل الرقم السري"); return }
        viewModelScope.launch {
            val stored = settingsDataStore.pinHashFlow.first()
            // FIX BUG-1: verifyPin runs PBKDF2 (100k iterations) — must be on IO to avoid ANR
            val valid = withContext(Dispatchers.IO) { verifyPin(s.enteredPin, stored) }
            if (valid) {
                _uiState.update { it.copy(isUnlocked = true, isError = false) }
            } else {
                showError("رقم سري خاطئ")
                _uiState.update { it.copy(enteredPin = "") }
            }
        }
    }

    // ── PIN management (from Settings) ────────────────────────────

    fun enablePin()  { _uiState.update { it.copy(pinEnabled = true, isSetupMode = true, isUnlocked = true, enteredPin = "", confirmPin = "", awaitingConfirm = false) } }
    fun disablePin() { viewModelScope.launch { settingsDataStore.updatePin(enabled = false, pinHash = ""); _uiState.update { it.copy(pinEnabled = false, isSetupMode = false) } } }

    // ── Helpers ────────────────────────────────────────────────────

    private fun showError(msg: String) {
        _uiState.update { it.copy(isError = true, errorMessage = msg) }
        viewModelScope.launch { delay(2_000); clearError() }
    }

    private fun clearError() { _uiState.update { it.copy(isError = false, errorMessage = "") } }

    /**
     * FIX: PBKDF2 + random salt replaces plain SHA-256.
     * Format stored: "salt_hex:hash_hex"
     * A 4-6 digit PIN with plain SHA-256 is crackable in milliseconds via rainbow table.
     */
    private fun hashPin(pin: String): String {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val spec  = PBEKeySpec(pin.toCharArray(), salt, 100_000, 256)
        val key   = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(spec).encoded
        return salt.toHex() + ":" + key.toHex()
    }

    private fun verifyPin(pin: String, stored: String): Boolean {
        return try {
            // Support legacy plain SHA-256 hashes (no colon separator)
            if (!stored.contains(":")) {
                return MessageDigest.getInstance("SHA-256")
                    .digest(pin.toByteArray())
                    .joinToString("") { "%02x".format(it) } == stored
            }
            val (saltHex, hashHex) = stored.split(":")
            val salt = saltHex.hexToBytes()
            val spec = PBEKeySpec(pin.toCharArray(), salt, 100_000, 256)
            val key  = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(spec).encoded
            key.toHex() == hashHex
        } catch (e: Exception) { false }
    }

    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }
    private fun String.hexToBytes() = chunked(2).map { it.toInt(16).toByte() }.toByteArray()
}
