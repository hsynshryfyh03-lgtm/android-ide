package com.safecapture.app.service

import android.content.Context
import android.util.Log
import androidx.hilt.work.HiltWorker
import androidx.work.*
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.asRequestBody
import com.safecapture.app.data.local.datastore.SettingsDataStore
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

@HiltWorker
class TelegramUploadWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted workerParams: WorkerParameters,
    private val settingsDataStore: SettingsDataStore,
) : CoroutineWorker(context, workerParams) {

    companion object {
        private const val TAG              = "TelegramUploadWorker"
        const val KEY_FILE_PATH            = "file_path"
        const val KEY_FILE_NAME            = "file_name"
        const val KEY_DURATION_FORMATTED   = "duration_formatted"
        const val KEY_SIZE_FORMATTED       = "size_formatted"
        const val KEY_TIMESTAMP_FORMATTED  = "timestamp_formatted"
        private const val TELEGRAM_API     = "https://api.telegram.org/bot"

        // FIX #13: Singleton OkHttpClient — reuses thread pool and connection pool across uploads
        private val httpClient by lazy {
            OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(120, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .build()
        }

        fun enqueue(
            context: Context,
            filePath: String,
            fileName: String,
            durationFormatted: String,
            sizeFormatted: String,
            timestampFormatted: String,
        ) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val inputData = workDataOf(
                KEY_FILE_PATH           to filePath,
                KEY_FILE_NAME           to fileName,
                KEY_DURATION_FORMATTED  to durationFormatted,
                KEY_SIZE_FORMATTED      to sizeFormatted,
                KEY_TIMESTAMP_FORMATTED to timestampFormatted,
            )

            val request = OneTimeWorkRequestBuilder<TelegramUploadWorker>()
                .setConstraints(constraints)
                .setInputData(inputData)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .addTag("telegram_upload")
                .addTag("file:$fileName")
                .build()

            WorkManager.getInstance(context)
                .enqueueUniqueWork("tg_upload_$fileName", ExistingWorkPolicy.KEEP, request)

            Log.d(TAG, "Enqueued upload: $fileName (deferred if offline)")
        }
    }

    override suspend fun doWork(): Result {
        val filePath  = inputData.getString(KEY_FILE_PATH)  ?: return Result.failure()
        val fileName  = inputData.getString(KEY_FILE_NAME)  ?: "recording.mp4"
        val duration  = inputData.getString(KEY_DURATION_FORMATTED) ?: ""
        val size      = inputData.getString(KEY_SIZE_FORMATTED)     ?: ""
        val timestamp = inputData.getString(KEY_TIMESTAMP_FORMATTED) ?: ""

        val settings  = settingsDataStore.settingsFlow.first()
        val token     = settings.telegramBotToken
        val chatId    = settings.telegramChatId

        if (token.isBlank() || chatId.isBlank()) {
            Log.w(TAG, "Telegram not configured — skipping upload")
            return Result.failure()
        }

        val file = File(filePath)
        if (!file.exists()) {
            Log.w(TAG, "File not found: $filePath")
            return Result.failure()
        }

        Log.d(TAG, "Uploading $fileName (${file.length() / 1024}KB) to Telegram…")

        return try {
            // FIX BUG-3: uploadToTelegram uses OkHttp blocking execute().
            // CoroutineWorker.doWork() runs on Dispatchers.Default (CPU pool).
            // Blocking I/O on Default steals CPU threads → must dispatch to IO.
            withContext(Dispatchers.IO) {
                uploadToTelegram(token, chatId, file, fileName, duration, size, timestamp)
            }
            Log.d(TAG, "Upload successful: $fileName")
            Result.success()
        } catch (e: IOException) {
            Log.e(TAG, "Upload failed (attempt ${runAttemptCount + 1}): ${e.message}")
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        } catch (e: Exception) {
            Log.e(TAG, "Upload error: ${e.message}")
            Result.failure()
        }
    }

    private fun uploadToTelegram(
        token: String, chatId: String, file: File,
        fileName: String, duration: String, size: String, timestamp: String,
    ) {
        val caption = buildCaption(fileName, duration, size, timestamp)

        val requestBody = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("chat_id", chatId)
            .addFormDataPart("caption", caption)
            .addFormDataPart("parse_mode", "HTML")
            .addFormDataPart("video", fileName, file.asRequestBody("video/mp4".toMediaTypeOrNull()))
            .build()

        val request = Request.Builder()
            .url("$TELEGRAM_API$token/sendVideo")
            .post(requestBody)
            .build()

        // FIX #13: Use singleton httpClient instead of creating new instance per upload
        httpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val body = response.body?.string() ?: ""
                throw IOException("HTTP ${response.code}: $body")
            }
        }
    }

    private fun buildCaption(fileName: String, duration: String, size: String, timestamp: String): String = """
        🔴 <b>SafeCapture — تسجيل طارئ</b>

        📁 <code>$fileName</code>
        🕐 <b>وقت التسجيل:</b> $timestamp
        ⏱ <b>المدة:</b> $duration
        💾 <b>الحجم:</b> $size

        📱 <i>تم الإرسال تلقائياً</i>
    """.trimIndent()
}
