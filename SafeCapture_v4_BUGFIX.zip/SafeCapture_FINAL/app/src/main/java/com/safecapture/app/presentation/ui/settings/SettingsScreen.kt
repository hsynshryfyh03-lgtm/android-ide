package com.safecapture.app.presentation.ui.settings

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.safecapture.app.R
import com.safecapture.app.presentation.ui.components.neoBackground
import com.safecapture.app.presentation.ui.components.neoCard
import com.safecapture.app.presentation.ui.theme.NeoColors

@Composable
fun SettingsScreen(viewModel: SettingsViewModel = hiltViewModel()) {
    val state   = viewModel.uiState.collectAsStateWithLifecycle().value
    val context = LocalContext.current
    val bg      = neoBackground()
    val scroll  = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bg)
            .verticalScroll(scroll)
            .padding(horizontal = 20.dp),
    ) {
        Spacer(Modifier.height(48.dp))

        // ── Page header ─────────────────────────────────────
        Text(
            stringResource(R.string.settings_title),
            fontSize   = 24.sp,
            fontWeight = FontWeight.Bold,
            color      = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            "ضبط التطبيق حسب تفضيلاتك",
            fontSize = 13.sp,
            color    = NeoColors.TextSecondary,
        )

        Spacer(Modifier.height(28.dp))

        // ══════════════════════════════════════════════════
        // SECTION 1 — Trigger
        // ══════════════════════════════════════════════════
        SectionHeader("التفعيل", Icons.Filled.TouchApp, NeoColors.Primary)
        Spacer(Modifier.height(10.dp))
        SettingsCard {
            // Double-press delay
            var delayExp by remember { mutableStateOf(false) }
            val delayVals   = listOf(400, 600, 800)
            val delayLabels = listOf("400ms — سريع", "600ms — متوسط", "800ms — بطيء")
            DropdownRow(
                icon      = Icons.Filled.Speed,
                iconColor = NeoColors.Primary,
                label     = "حساسية الضغط المزدوج",
                sublabel  = "الفاصل الزمني بين الضغطتين",
                value     = delayLabels.getOrElse(delayVals.indexOf(state.settings.doublePressDelayMs)) { delayLabels[1] },
                expanded  = delayExp,
                onExpand  = { delayExp = true },
                onDismiss = { delayExp = false },
                items     = delayLabels,
                onSelect  = { i -> viewModel.setDoublePressDelay(delayVals[i]); delayExp = false },
            )
            Divider()
            // Vibration
            SwitchRow(
                icon     = Icons.Filled.Vibration,
                iconColor= NeoColors.Secondary,
                label    = "اهتزاز التأكيد",
                sublabel = "اهتزاز خفيف عند بدء/إيقاف التسجيل",
                checked  = state.settings.vibrationEnabled,
                onToggle = { viewModel.setVibration(it) },
            )
            Divider()
            // Accessibility service
            val a11yOn = isA11yEnabled(context)
            ActionRow(
                icon     = Icons.Filled.Accessibility,
                iconColor= if (a11yOn) NeoColors.Success else NeoColors.Warning,
                label    = "خدمة إمكانية الوصول",
                sublabel = if (a11yOn) "مفعّلة ✓ — الزر يعمل حتى مع الشاشة المطفأة"
                           else        "غير مفعّلة — مطلوبة للتسجيل بالزر",
                onClick  = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            )
        }

        Spacer(Modifier.height(20.dp))

        // ══════════════════════════════════════════════════
        // SECTION 2 — Recording
        // ══════════════════════════════════════════════════
        SectionHeader("التسجيل", Icons.Filled.Videocam, NeoColors.Recording)
        Spacer(Modifier.height(10.dp))
        SettingsCard {
            // Video quality
            var qualExp by remember { mutableStateOf(false) }
            val qualities = listOf("480p", "720p", "1080p")
            DropdownRow(
                icon     = Icons.Filled.HighQuality,
                iconColor= NeoColors.Recording,
                label    = "جودة الفيديو",
                sublabel = "الدقة الحالية: ${state.settings.videoQuality}",
                value    = state.settings.videoQuality,
                expanded = qualExp,
                onExpand = { qualExp = true },
                onDismiss= { qualExp = false },
                items    = qualities,
                onSelect = { i -> viewModel.setVideoQuality(qualities[i]); qualExp = false },
            )
            Divider()
            // Camera
            var camExp by remember { mutableStateOf(false) }
            val camVals   = listOf("back", "front")
            val camLabels = listOf("خلفية", "أمامية")
            DropdownRow(
                icon     = Icons.Filled.CameraAlt,
                iconColor= NeoColors.Primary,
                label    = "الكاميرا المستخدمة",
                sublabel = if (state.settings.cameraFacing == "back") "الكاميرا الخلفية" else "الكاميرا الأمامية",
                value    = camLabels.getOrElse(camVals.indexOf(state.settings.cameraFacing)) { camLabels[0] },
                expanded = camExp,
                onExpand = { camExp = true },
                onDismiss= { camExp = false },
                items    = camLabels,
                onSelect = { i -> viewModel.setCameraFacing(camVals[i]); camExp = false },
            )
            Divider()
            // Audio
            SwitchRow(
                icon     = Icons.Filled.Mic,
                iconColor= NeoColors.Secondary,
                label    = "تسجيل الصوت",
                sublabel = "تضمين صوت الميكروفون في الفيديو",
                checked  = state.settings.audioEnabled,
                onToggle = { viewModel.setAudioEnabled(it) },
            )
            Divider()
            // Max duration
            var durExp by remember { mutableStateOf(false) }
            val durVals   = listOf(5, 15, 30, 60, 0)
            val durLabels = listOf("5 دقائق", "15 دقيقة", "30 دقيقة", "60 دقيقة", "غير محدود")
            DropdownRow(
                icon     = Icons.Filled.Timer,
                iconColor= NeoColors.Warning,
                label    = "أقصى مدة تسجيل",
                sublabel = "يتوقف تلقائياً بعد انتهاء المدة",
                value    = durLabels.getOrElse(durVals.indexOf(state.settings.maxDurationMinutes)) { durLabels[2] },
                expanded = durExp,
                onExpand = { durExp = true },
                onDismiss= { durExp = false },
                items    = durLabels,
                onSelect = { i -> viewModel.setMaxDuration(durVals[i]); durExp = false },
            )
        }

        Spacer(Modifier.height(20.dp))

        // ══════════════════════════════════════════════════
        // SECTION 3 — Timestamp Overlay (Surveillance Style)
        // ══════════════════════════════════════════════════
        SectionHeader("ختم التاريخ والوقت", Icons.Filled.DateRange, Color(0xFF0EA5E9))
        Spacer(Modifier.height(10.dp))
        SettingsCard {
            SwitchRow(
                icon     = Icons.Filled.Videocam,
                iconColor= Color(0xFF0EA5E9),
                label    = "ختم الوقت على الفيديو",
                sublabel = "يضيف تاريخ ووقت بنمط كاميرات المراقبة",
                checked  = state.settings.timestampOverlay,
                onToggle = { viewModel.setTimestampOverlay(it) },
            )
            // Preview row
            AnimatedVisibility(visible = state.settings.timestampOverlay) {
                Column {
                    Divider()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0A0A0A))
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment     = Alignment.CenterVertically,
                    ) {
                        // Simulated surveillance timestamp
                        val now = remember { java.util.Date() }
                        val dateFmt = remember { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()) }
                        val timeFmt = remember { java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()) }
                        Column {
                            Text(
                                timeFmt.format(now),
                                fontSize   = 18.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                color      = Color(0xFF00DC64),
                            )
                            Text(
                                dateFmt.format(now),
                                fontSize   = 12.sp,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                color      = Color(0xFF00A046),
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(androidx.compose.foundation.shape.CircleShape)
                                    .background(Color(0xFFFF2828))
                            )
                            Spacer(Modifier.width(5.dp))
                            Text(
                                "REC",
                                fontSize   = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                color      = Color(0xFFFF2828),
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "معاينة — سيظهر هكذا في الزاوية السفلية اليسرى",
                        fontSize = 11.sp,
                        color    = NeoColors.TextHint,
                        modifier = Modifier.padding(horizontal = 16.dp).padding(bottom = 10.dp),
                    )
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        // ══════════════════════════════════════════════════
        // SECTION 4 — Telegram Smart Upload
        // ══════════════════════════════════════════════════
        SectionHeader("رفع تيليغرام", Icons.Filled.Send, Color(0xFF2AABEE))
        Spacer(Modifier.height(10.dp))
        SettingsCard {
            // Auto-upload toggle
            SwitchRow(
                icon     = Icons.Filled.CloudUpload,
                iconColor= Color(0xFF2AABEE),
                label    = "رفع تلقائي بعد التسجيل",
                sublabel = "يُرفع فور اكتمال التسجيل — يُؤجَّل تلقائياً إذا لا يوجد إنترنت",
                checked  = state.settings.telegramAutoUpload,
                onToggle = { viewModel.setTelegramAutoUpload(it) },
            )
            Divider()
            // Expandable config section
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.setTelegramExpanded(!state.telegramExpanded) }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                SettingIcon(Icons.Filled.Settings, Color(0xFF2AABEE))
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("إعداد البوت", fontSize = 14.sp, fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onBackground)
                    val configured = state.settings.telegramBotToken.isNotBlank() && state.settings.telegramChatId.isNotBlank()
                    Text(
                        if (configured) "✓ مُعدَّد — اضغط لتعديل" else "لم يتم الإعداد بعد",
                        fontSize = 11.sp,
                        color    = if (configured) NeoColors.Success else NeoColors.TextSecondary,
                    )
                }
                Icon(
                    if (state.telegramExpanded) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                    null,
                    tint     = NeoColors.TextHint,
                    modifier = Modifier.size(20.dp),
                )
            }
            AnimatedVisibility(
                visible = state.telegramExpanded,
                enter   = expandVertically() + fadeIn(),
                exit    = shrinkVertically() + fadeOut(),
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp).padding(bottom = 16.dp)) {
                    Divider(modifier = Modifier.padding(bottom = 14.dp))

                    // Bot token hint
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF2AABEE).copy(alpha = 0.08f))
                            .border(1.dp, Color(0xFF2AABEE).copy(alpha = 0.2f), RoundedCornerShape(10.dp))
                            .padding(12.dp),
                    ) {
                        Icon(Icons.Filled.Info, null, tint = Color(0xFF2AABEE), modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "أنشئ بوتاً عبر @BotFather ثم أضف البوت للقناة/المجموعة كمشرف",
                            fontSize = 11.sp,
                            color    = NeoColors.TextSecondary,
                        )
                    }

                    Spacer(Modifier.height(14.dp))

                    // Bot Token field
                    var tokenVisible by remember { mutableStateOf(false) }
                    OutlinedTextField(
                        value         = state.tokenInput,
                        onValueChange = { viewModel.onTokenInput(it) },
                        label         = { Text("Bot Token", fontSize = 13.sp) },
                        placeholder   = { Text("123456789:ABCdef…", fontSize = 12.sp) },
                        leadingIcon   = { Icon(Icons.Filled.Key, null, tint = Color(0xFF2AABEE), modifier = Modifier.size(18.dp)) },
                        trailingIcon  = {
                            IconButton(onClick = { tokenVisible = !tokenVisible }) {
                                Icon(
                                    if (tokenVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                    null, tint = NeoColors.TextHint, modifier = Modifier.size(18.dp),
                                )
                            }
                        },
                        visualTransformation = if (tokenVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        modifier     = Modifier.fillMaxWidth(),
                        shape        = RoundedCornerShape(12.dp),
                        singleLine   = true,
                        colors       = outlinedFieldColors(),
                    )

                    Spacer(Modifier.height(10.dp))

                    // Chat ID field
                    OutlinedTextField(
                        value         = state.chatIdInput,
                        onValueChange = { viewModel.onChatIdInput(it) },
                        label         = { Text("Chat ID / Channel", fontSize = 13.sp) },
                        placeholder   = { Text("-100123456789 أو @channel", fontSize = 12.sp) },
                        leadingIcon   = { Icon(Icons.Filled.Tag, null, tint = Color(0xFF2AABEE), modifier = Modifier.size(18.dp)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                        modifier     = Modifier.fillMaxWidth(),
                        shape        = RoundedCornerShape(12.dp),
                        singleLine   = true,
                        colors       = outlinedFieldColors(),
                    )

                    Spacer(Modifier.height(14.dp))

                    // Save button
                    Button(
                        onClick  = { viewModel.saveTelegramConfig() },
                        modifier = Modifier.fillMaxWidth(),
                        shape    = RoundedCornerShape(12.dp),
                        colors   = ButtonDefaults.buttonColors(containerColor = Color(0xFF2AABEE)),
                    ) {
                        if (state.tokenSaved) {
                            Icon(Icons.Filled.CheckCircle, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("تم الحفظ ✓", fontWeight = FontWeight.SemiBold)
                        } else {
                            Icon(Icons.Filled.Save, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("حفظ الإعدادات", fontWeight = FontWeight.SemiBold)
                        }
                    }

                    // Upload queue info
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(NeoColors.Success.copy(alpha = 0.08f))
                            .padding(12.dp),
                    ) {
                        Icon(Icons.Filled.WifiOff, null, tint = NeoColors.Success, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "ذكي: إذا انقطع الإنترنت يُضاف الفيديو لقائمة انتظار ويُرفع تلقائياً حين العودة",
                            fontSize = 11.sp,
                            color    = NeoColors.Success,
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        // ══════════════════════════════════════════════════
        // SECTION 5 — Appearance
        // ══════════════════════════════════════════════════
        SectionHeader("المظهر", Icons.Filled.Palette, NeoColors.Secondary)
        Spacer(Modifier.height(10.dp))
        SettingsCard {
            SwitchRow(
                icon     = Icons.Filled.DarkMode,
                iconColor= Color(0xFF7C3AED),
                label    = "الوضع الليلي",
                sublabel = "تفعيل المظهر الداكن (اختياري)",
                checked  = state.darkMode,
                onToggle = { viewModel.setDarkMode(it) },
            )
        }

        Spacer(Modifier.height(20.dp))

        // ══════════════════════════════════════════════════
        // SECTION 6 — PIN Lock
        // ══════════════════════════════════════════════════
        SectionHeader("قفل الرقم السري", Icons.Filled.Lock, Color(0xFF7C3AED))
        Spacer(Modifier.height(10.dp))
        SettingsCard {
            SwitchRow(
                icon     = Icons.Filled.Lock,
                iconColor= Color(0xFF7C3AED),
                label    = "تفعيل قفل PIN",
                sublabel = if (state.pinEnabled) "مُفعَّل — يُطلب عند فتح التطبيق"
                           else "حماية التطبيق برقم سري عند كل فتح",
                checked  = state.pinEnabled,
                onToggle = { enabled ->
                    if (!enabled) viewModel.disablePin()
                    // تفعيل PIN يتم عبر شاشة PinScreen في MainActivity
                },
            )
            AnimatedVisibility(visible = state.pinEnabled) {
                Column {
                    Divider()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF7C3AED).copy(alpha = 0.08f))
                            .padding(12.dp),
                    ) {
                        Icon(Icons.Filled.Info, null, tint = Color(0xFF7C3AED),
                            modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "لتغيير الرقم السري: أوقف التفعيل ثم أعد تشغيله",
                            fontSize = 11.sp,
                            color    = Color(0xFF7C3AED),
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        // ══════════════════════════════════════════════════
        // SECTION 7 — Disguise Mode
        // ══════════════════════════════════════════════════
        SectionHeader("وضع التمويه", Icons.Filled.TheaterComedy, Color(0xFF64748B))
        Spacer(Modifier.height(10.dp))
        SettingsCard {
            SwitchRow(
                icon     = Icons.Filled.Calculate,
                iconColor= Color(0xFF64748B),
                label    = "تمويه التطبيق كحاسبة",
                sublabel = "يُعرَض التطبيق كحاسبة عادية — معطّل افتراضياً",
                checked  = state.settings.disguiseModeEnabled,
                onToggle = { viewModel.setDisguiseMode(it) },
            )
            AnimatedVisibility(visible = state.settings.disguiseModeEnabled) {
                Column {
                    Divider()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF64748B).copy(alpha = 0.08f))
                            .padding(12.dp),
                    ) {
                        Icon(Icons.Filled.Lock, null, tint = Color(0xFF64748B), modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "الوصول السري: افتح الحاسبة، اكتب 911 ثم اضغط =",
                            fontSize = 11.sp,
                            color    = Color(0xFF64748B),
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        // ══════════════════════════════════════════════════
        // SECTION 8 — Storage
        // ══════════════════════════════════════════════════
        SectionHeader("التخزين", Icons.Filled.Storage, NeoColors.TextSecondary)
        Spacer(Modifier.height(10.dp))
        SettingsCard {
            var delDaysExp by remember { mutableStateOf(false) }
            val delDayVals  = listOf(0, 7, 14, 30, 90)
            val delDayLabels= listOf("أبداً", "7 أيام", "14 يوماً", "30 يوماً", "90 يوماً")
            DropdownRow(
                icon     = Icons.Filled.DeleteSweep,
                iconColor= NeoColors.Recording,
                label    = "الحذف التلقائي",
                sublabel = "حذف التسجيلات القديمة تلقائياً",
                value    = delDayLabels.getOrElse(delDayVals.indexOf(state.settings.autoDeleteDays)) { delDayLabels[0] },
                expanded = delDaysExp,
                onExpand = { delDaysExp = true },
                onDismiss= { delDaysExp = false },
                items    = delDayLabels,
                onSelect = { i -> viewModel.setAutoDelete(delDayVals[i]); delDaysExp = false },
            )
        }

        Spacer(Modifier.height(20.dp))

        // ══════════════════════════════════════════════════
        // SECTION 9 — About
        // ══════════════════════════════════════════════════
        SectionHeader("حول التطبيق", Icons.Filled.Info, NeoColors.TextSecondary)
        Spacer(Modifier.height(10.dp))
        SettingsCard {
            InfoRow(Icons.Filled.Apps,    "SafeCapture",    "تطبيق تسجيل طارئ صامت")
            Divider()
            InfoRow(Icons.Filled.Code,    "الإصدار",        "1.0.0 — Build 1")
            Divider()
            InfoRow(Icons.Filled.Android, "الحد الأدنى",   "Android 8.0 (API 26)+")
        }

        Spacer(Modifier.height(40.dp))
    }
}

// ─── Reusable Components ─────────────────────────────────────────

@Composable
private fun SectionHeader(label: String, icon: ImageVector, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(color.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(14.dp))
        }
        Spacer(Modifier.width(10.dp))
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = NeoColors.TextSecondary)
    }
}

@Composable
private fun SettingsCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .neoCard(cornerRadius = 20.dp, elevation = 7.dp)
            .padding(vertical = 4.dp),
        content  = content,
    )
}

@Composable
private fun Divider() {
    HorizontalDivider(
        modifier = Modifier.padding(horizontal = 16.dp),
        color    = NeoColors.ShadowDark.copy(alpha = 0.18f),
    )
}

@Composable
private fun SwitchRow(
    icon: ImageVector, iconColor: Color,
    label: String, sublabel: String,
    checked: Boolean, onToggle: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle(!checked) }
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SettingIcon(icon, iconColor)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(label,    fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onBackground)
            Text(sublabel, fontSize = 11.sp, color = NeoColors.TextSecondary)
        }
        Switch(
            checked         = checked,
            onCheckedChange = onToggle,
            colors          = SwitchDefaults.colors(
                checkedThumbColor   = Color.White,
                checkedTrackColor   = iconColor,
                uncheckedThumbColor = NeoColors.TextHint,
                uncheckedTrackColor = NeoColors.ShadowDark.copy(alpha = 0.3f),
            ),
        )
    }
}

@Composable
private fun DropdownRow(
    icon: ImageVector, iconColor: Color,
    label: String, sublabel: String, value: String,
    expanded: Boolean, onExpand: () -> Unit, onDismiss: () -> Unit,
    items: List<String>, onSelect: (Int) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onExpand)
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SettingIcon(icon, iconColor)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(label,    fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onBackground)
            Text(sublabel, fontSize = 11.sp, color = NeoColors.TextSecondary)
        }
        Text(value, fontSize = 12.sp, color = iconColor, fontWeight = FontWeight.Medium)
        Spacer(Modifier.width(4.dp))
        Icon(Icons.Filled.ExpandMore, null, tint = NeoColors.TextHint, modifier = Modifier.size(18.dp))
        DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
            items.forEachIndexed { idx, item ->
                DropdownMenuItem(
                    text    = { Text(item, fontSize = 13.sp) },
                    onClick = { onSelect(idx) },
                )
            }
        }
    }
}

@Composable
private fun ActionRow(
    icon: ImageVector, iconColor: Color,
    label: String, sublabel: String,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SettingIcon(icon, iconColor)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(label,    fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onBackground)
            Text(sublabel, fontSize = 11.sp, color = NeoColors.TextSecondary)
        }
        Icon(Icons.Filled.ChevronRight, null, tint = NeoColors.TextHint, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun InfoRow(icon: ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        SettingIcon(icon, NeoColors.TextSecondary)
        Spacer(Modifier.width(14.dp))
        Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.weight(1f))
        Text(value, fontSize = 12.sp, color = NeoColors.TextSecondary)
    }
}

@Composable
fun SettingIcon(icon: ImageVector, color: Color) {
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(color.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun outlinedFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor      = Color(0xFF2AABEE),
    unfocusedBorderColor    = NeoColors.ShadowDark.copy(alpha = 0.35f),
    focusedContainerColor   = neoBackground(),
    unfocusedContainerColor = neoBackground(),
    focusedLabelColor       = Color(0xFF2AABEE),
)

private fun isA11yEnabled(context: android.content.Context): Boolean {
    val am = context.getSystemService(android.content.Context.ACCESSIBILITY_SERVICE)
            as android.view.accessibility.AccessibilityManager
    return am.getEnabledAccessibilityServiceList(
        android.accessibilityservice.AccessibilityServiceInfo.FEEDBACK_ALL_MASK
    ).any { it.resolveInfo.serviceInfo.packageName == context.packageName }
}
