package com.safecapture.app.service

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.media.MediaRecorder
import android.os.*
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.safecapture.app.MainActivity
import com.safecapture.app.R
import com.safecapture.app.data.local.datastore.SettingsDataStore
import com.safecapture.app.domain.model.AppSettings
import com.safecapture.app.domain.model.videoBitrate
import com.safecapture.app.domain.model.videoWidthHeight
import com.safecapture.app.domain.model.hasTelegramConfig
import com.safecapture.app.domain.repository.RecordingRepository
import com.safecapture.app.domain.model.Recording
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@AndroidEntryPoint
class RecordingService : Service() {

    companion object {
        const val ACTION_START    = "com.safecapture.app.ACTION_START_RECORDING"
        const val ACTION_STOP     = "com.safecapture.app.ACTION_STOP_RECORDING"
        const val ACTION_TOGGLE   = "com.safecapture.app.ACTION_TOGGLE_RECORDING"

        const val CHANNEL_ID      = "safe_capture_recording_channel"
        const val NOTIF_ID        = 1001

        const val EXTRA_IS_RECORDING = "is_recording"

        private const val TAG = "RecordingService"

        // Singleton state observable by UI
        @Volatile var isRecording    = false
        @Volatile var recordingStart = 0L   // epoch ms

        fun start(context: Context)  = context.startForegroundService(Intent(context, RecordingService::class.java).apply { action = ACTION_START })
        fun stop(context: Context)   = context.startService(Intent(context, RecordingService::class.java).apply { action = ACTION_STOP })
        fun toggle(context: Context) = context.startForegroundService(Intent(context, RecordingService::class.java).apply { action = ACTION_TOGGLE })
    }

    @Inject lateinit var repository: RecordingRepository
    @Inject lateinit var settingsDataStore: SettingsDataStore

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var cameraManager: CameraManager? = null
    private var cameraDevice: CameraDevice? = null
    private var captureSession: CameraCaptureSession? = null
    private var mediaRecorder: MediaRecorder? = null
    private var dummySurfaceTexture: SurfaceTexture? = null

    // ── Timestamp GL renderer (used when timestampOverlay = true) ──
    private var glRenderer: TimestampOverlayRenderer? = null
    private var glThread: HandlerThread? = null
    private var glHandler: android.os.Handler? = null
    private var useTimestampOverlay = false

    private var currentFile: File? = null
    private var recordingStartMs = 0L
    private var maxDurationJob: Job? = null
    private var timerJob: Job? = null

    private lateinit var vibrator: Vibrator
    private lateinit var wakeLock: PowerManager.WakeLock

    // ─────────────────────────────────────────────────────────────
    override fun onCreate() {
        super.onCreate()
        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        vibrator      = getSystemService(VIBRATOR_SERVICE) as Vibrator
        val pm        = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock      = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "SafeCapture::RecordingWakeLock"
        )
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START  -> if (!isRecording) startRecording()
            ACTION_STOP   -> if (isRecording)  stopRecording()
            ACTION_TOGGLE -> if (isRecording) stopRecording() else startRecording()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?) = null

    override fun onDestroy() {
        super.onDestroy()
        if (isRecording) stopRecording()
        scope.cancel()
        if (wakeLock.isHeld) wakeLock.release()
    }

    // ─────────────────────────────────────────────────────────────
    // PRIVATE — START
    // ─────────────────────────────────────────────────────────────
    private fun startRecording() {
        scope.launch {
            try {
                val settings = settingsDataStore.settingsFlow.first()
                // Android 10+ (API 29) requires specifying foreground service type
                // Android 14 (API 34) throws an exception if type is missing
                ServiceCompat.startForeground(
                    this@RecordingService,
                    NOTIF_ID,
                    buildNotification(recording = true),
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                    else 0
                )
                wakeLock.acquire(4 * 60 * 60 * 1000L) // max 4h

                val outputFile = createOutputFile()
                currentFile    = outputFile
                useTimestampOverlay = settings.timestampOverlay

                setupMediaRecorder(outputFile, settings)
                openCamera(settings)

                isRecording    = true
                recordingStart = System.currentTimeMillis()
                recordingStartMs = recordingStart

                if (settings.vibrationEnabled) vibrateStart()

                // Schedule auto-stop if max duration is set
                if (settings.maxDurationMinutes > 0) {
                    maxDurationJob = scope.launch {
                        delay(settings.maxDurationMinutes * 60 * 1000L)
                        stopRecording()
                    }
                }

                // Broadcast state change
                sendBroadcast(Intent(ACTION_TOGGLE).putExtra(EXTRA_IS_RECORDING, true))
                Log.d(TAG, "Recording started → ${outputFile.absolutePath}")

            } catch (e: Exception) {
                Log.e(TAG, "Failed to start recording", e)
                cleanupCamera()
                stopSelf()
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    // PRIVATE — STOP
    // ─────────────────────────────────────────────────────────────
    private fun stopRecording() {
        scope.launch {
            try {
                maxDurationJob?.cancel()
                timerJob?.cancel()

                // Stop MediaRecorder safely
                try {
                    mediaRecorder?.apply { stop(); reset(); release() }
                } catch (e: Exception) {
                    Log.w(TAG, "MediaRecorder stop warning: ${e.message}")
                }
                mediaRecorder = null

                cleanupCamera()

                isRecording    = false
                val durationMs = System.currentTimeMillis() - recordingStartMs

                if (wakeLock.isHeld) wakeLock.release()

                val settings = settingsDataStore.settingsFlow.first()
                if (settings.vibrationEnabled) vibrateStop()

                // Save to database
                currentFile?.let { file ->
                    if (file.exists() && file.length() > 0) {
                        val recording = Recording(
                            filePath      = file.absolutePath,
                            fileName      = file.name,
                            durationMs    = durationMs,
                            fileSizeBytes = file.length(),
                            timestampMs   = recordingStartMs
                        )
                        repository.saveRecording(recording)
                        Log.d(TAG, "Recording saved: ${file.name} | ${file.length()} bytes | ${durationMs}ms")

                        // ── Smart Telegram upload (queued if offline) ──
                        if (settings.telegramAutoUpload && settings.hasTelegramConfig) {
                            val tsFormatted = java.text.SimpleDateFormat(
                                "yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()
                            ).format(java.util.Date(recordingStartMs))
                            TelegramUploadWorker.enqueue(
                                context            = applicationContext,
                                filePath           = file.absolutePath,
                                fileName           = file.name,
                                durationFormatted  = recording.durationFormatted,
                                sizeFormatted      = recording.sizeFormatted,
                                timestampFormatted = tsFormatted,
                            )
                        }
                    } else {
                        Log.w(TAG, "Recording file is empty or missing — not saved")
                    }
                }
                currentFile = null

                sendBroadcast(Intent(ACTION_TOGGLE).putExtra(EXTRA_IS_RECORDING, false))
                updateNotification(recording = false)

            } catch (e: Exception) {
                Log.e(TAG, "Error stopping recording", e)
            }
        }
    }

    // ─────────────────────────────────────────────────────────────
    // Camera2 setup
    // ─────────────────────────────────────────────────────────────
    @SuppressLint("MissingPermission")
    @Throws(CameraAccessException::class)
    private fun openCamera(settings: AppSettings) {
        val facing = if (settings.cameraFacing == "front")
            CameraCharacteristics.LENS_FACING_FRONT
        else
            CameraCharacteristics.LENS_FACING_BACK

        val cameraId = cameraManager!!.cameraIdList.firstOrNull { id ->
            cameraManager!!.getCameraCharacteristics(id)
                .get(CameraCharacteristics.LENS_FACING) == facing
        } ?: cameraManager!!.cameraIdList.first()

        cameraManager!!.openCamera(cameraId, object : CameraDevice.StateCallback() {
            override fun onOpened(camera: CameraDevice) {
                cameraDevice = camera
                createCaptureSession()
            }
            override fun onDisconnected(camera: CameraDevice) {
                camera.close()
                cameraDevice = null
            }
            override fun onError(camera: CameraDevice, error: Int) {
                Log.e(TAG, "Camera error: $error")
                camera.close()
                cameraDevice = null
            }
        }, null)
    }

    private fun createCaptureSession() {
        val recorderSurface = mediaRecorder!!.surface

        // When timestamp overlay is active, we route camera → GL renderer → MediaRecorder.
        // The GL renderer exposes its own SurfaceTexture as camera input.
        val (cameraSurface, surfaces) = if (useTimestampOverlay) {
            val (w, h) = Pair(1280, 720) // use 720p for GL pipeline
            val renderer = TimestampOverlayRenderer(recorderSurface, w, h)

            // Init EGL on a dedicated background thread
            glThread = HandlerThread("GLRecordThread").also { it.start() }
            glHandler = android.os.Handler(glThread!!.looper)
            glHandler!!.post { renderer.setup() }

            glRenderer = renderer

            // Set frame callback on GL thread
            renderer.inputSurfaceTexture.setOnFrameAvailableListener({
                glHandler?.post { renderer.drawFrame() }
            }, android.os.Handler(glThread!!.looper))

            Pair(renderer.inputSurface, listOf(renderer.inputSurface, recorderSurface))
        } else {
            // Standard path: dummy 1×1 preview surface
            dummySurfaceTexture = SurfaceTexture(0).also { it.setDefaultBufferSize(1, 1) }
            val dummy = android.view.Surface(dummySurfaceTexture)
            Pair(dummy, listOf(recorderSurface, dummy))
        }

        cameraDevice?.createCaptureSession(
            surfaces,
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    captureSession = session
                    val requestBuilder = cameraDevice!!
                        .createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
                        .apply {
                            addTarget(cameraSurface)
                            set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                            set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                            set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
                            set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
                        }
                    session.setRepeatingRequest(requestBuilder.build(), null, null)
                    mediaRecorder?.start()
                    Log.d(TAG, "CaptureSession configured — MediaRecorder started | GL=${useTimestampOverlay}")
                }
                override fun onConfigureFailed(session: CameraCaptureSession) {
                    Log.e(TAG, "CaptureSession configuration failed")
                    stopRecording()
                }
            },
            null
        )
    }

    private fun cleanupCamera() {
        try { captureSession?.close()        } catch (e: Exception) { /* ignore */ }
        try { cameraDevice?.close()          } catch (e: Exception) { /* ignore */ }
        try { dummySurfaceTexture?.release() } catch (e: Exception) { /* ignore */ }
        try { glRenderer?.release()          } catch (e: Exception) { /* ignore */ }
        try { glThread?.quitSafely()         } catch (e: Exception) { /* ignore */ }
        captureSession     = null
        cameraDevice       = null
        dummySurfaceTexture = null
        glRenderer         = null
        glThread           = null
        glHandler          = null
    }

    // ─────────────────────────────────────────────────────────────
    // MediaRecorder setup
    // ─────────────────────────────────────────────────────────────
    @Suppress("DEPRECATION")
    private fun setupMediaRecorder(outputFile: File, settings: AppSettings) {
        val (width, height) = settings.videoWidthHeight
        val bitrate         = settings.videoBitrate

        mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            MediaRecorder(this) else MediaRecorder()

        mediaRecorder!!.apply {
            if (settings.audioEnabled) {
                setAudioSource(MediaRecorder.AudioSource.MIC)
            }
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            if (settings.audioEnabled) {
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128_000)
                setAudioSamplingRate(44_100)
            }
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setVideoEncodingBitRate(bitrate)
            setVideoFrameRate(30)
            setVideoSize(width, height)
            setOutputFile(outputFile.absolutePath)
            setOrientationHint(90)
            prepare()
        }
        Log.d(TAG, "MediaRecorder prepared → ${width}x${height} @ ${bitrate/1000}kbps")
    }

    // ─────────────────────────────────────────────────────────────
    // File & Notification helpers
    // ─────────────────────────────────────────────────────────────
    private fun createOutputFile(): File {
        val dir = File(getExternalFilesDir(null), "SafeCapture").also { it.mkdirs() }
        val ts  = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        return File(dir, "SC_$ts.mp4")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description    = getString(R.string.notification_channel_desc)
                setSound(null, null)
                enableVibration(false)
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun buildNotification(recording: Boolean): Notification {
        val pendingFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        else PendingIntent.FLAG_UPDATE_CURRENT

        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            pendingFlags
        )
        val stopIntent = PendingIntent.getService(
            this, 1,
            Intent(this, RecordingService::class.java).apply { action = ACTION_STOP },
            pendingFlags
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(
                if (recording) getString(R.string.notification_recording_title)
                else getString(R.string.notification_idle_title)
            )
            .setContentText(
                if (recording) getString(R.string.notification_recording_text)
                else getString(R.string.notification_idle_text)
            )
            .setSmallIcon(R.drawable.ic_splash_icon)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .apply {
                if (recording) addAction(0, getString(R.string.stop_recording), stopIntent)
            }
            .build()
    }

    private fun updateNotification(recording: Boolean) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(recording))
    }

    @Suppress("DEPRECATION")
    private fun vibrateStart() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createWaveform(
                longArrayOf(0, 80, 80, 80), -1
            ))
        } else vibrator.vibrate(longArrayOf(0, 80, 80, 80), -1)
    }

    @Suppress("DEPRECATION")
    private fun vibrateStop() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE))
        } else vibrator.vibrate(120)
    }
}
