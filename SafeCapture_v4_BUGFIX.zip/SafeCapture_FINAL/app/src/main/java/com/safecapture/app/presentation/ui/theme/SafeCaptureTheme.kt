package com.safecapture.app.presentation.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.sp

// ─── Neomorphism Color Palette ───────────────────────────────────
object NeoColors {
    // Light Mode
    val Background      = Color(0xFFE8EBF0)
    val Surface         = Color(0xFFEEF0F5)
    val ShadowLight     = Color(0xFFFFFFFF)
    val ShadowDark      = Color(0xFFC2C8D4)

    // Dark Mode
    val DarkBackground  = Color(0xFF1E2130)
    val DarkSurface     = Color(0xFF252840)
    val DarkShadowLight = Color(0xFF2D3250)
    val DarkShadowDark  = Color(0xFF141624)

    // Accents
    val Primary         = Color(0xFF5E81F4)
    val PrimaryDark     = Color(0xFF7B9BFF)
    val Secondary       = Color(0xFF9B59B6)
    val Recording       = Color(0xFFE74C3C)
    val RecordingGlow   = Color(0x40E74C3C)
    val Success         = Color(0xFF2ECC71)
    val Warning         = Color(0xFFF39C12)

    // Text
    val TextPrimary     = Color(0xFF1A2035)
    val TextSecondary   = Color(0xFF6B7280)
    val TextHint        = Color(0xFF9CA3AF)

    val DarkTextPrimary   = Color(0xFFE8EBF0)
    val DarkTextSecondary = Color(0xFF9CA3AF)
}

private val LightColorScheme = lightColorScheme(
    primary         = NeoColors.Primary,
    onPrimary       = Color.White,
    secondary       = NeoColors.Secondary,
    onSecondary     = Color.White,
    background      = NeoColors.Background,
    onBackground    = NeoColors.TextPrimary,
    surface         = NeoColors.Surface,
    onSurface       = NeoColors.TextPrimary,
    surfaceVariant  = NeoColors.ShadowLight,
    onSurfaceVariant= NeoColors.TextSecondary,
    error           = NeoColors.Recording,
    onError         = Color.White,
)

private val DarkColorScheme = darkColorScheme(
    primary         = NeoColors.PrimaryDark,
    onPrimary       = Color(0xFF1A2035),
    secondary       = NeoColors.Secondary,
    onSecondary     = Color.White,
    background      = NeoColors.DarkBackground,
    onBackground    = NeoColors.DarkTextPrimary,
    surface         = NeoColors.DarkSurface,
    onSurface       = NeoColors.DarkTextPrimary,
    surfaceVariant  = NeoColors.DarkShadowLight,
    onSurfaceVariant= NeoColors.DarkTextSecondary,
    error           = NeoColors.Recording,
    onError         = Color.White,
)

val AppTypography = Typography(
    displayLarge  = TextStyle(fontSize = 36.sp, fontWeight = FontWeight.Bold,   letterSpacing = (-0.5).sp),
    displayMedium = TextStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold,   letterSpacing = (-0.3).sp),
    headlineLarge = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.SemiBold),
    headlineMedium= TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
    titleLarge    = TextStyle(fontSize = 18.sp, fontWeight = FontWeight.Medium),
    titleMedium   = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium),
    bodyLarge     = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Normal),
    bodyMedium    = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Normal),
    bodySmall     = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Normal),
    labelLarge    = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Medium),
    labelSmall    = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.5.sp),
)

// ─── IsRecording ambient ──────────────────────────────────────────
val LocalIsDarkTheme = compositionLocalOf { false }

@Composable
fun SafeCaptureTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    CompositionLocalProvider(LocalIsDarkTheme provides darkTheme) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography  = AppTypography,
            content     = content
        )
    }
}
