package com.safecapture.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.safecapture.app.data.local.datastore.SettingsDataStore
import com.safecapture.app.presentation.navigation.AppNavigation
import com.safecapture.app.presentation.ui.pin.PinScreen
import com.safecapture.app.presentation.ui.pin.PinViewModel
import com.safecapture.app.presentation.ui.theme.SafeCaptureTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var settingsDataStore: SettingsDataStore

    private val pinViewModel: PinViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val isDark   by settingsDataStore.darkModeFlow
                .collectAsStateWithLifecycle(initialValue = false)
            val pinState by pinViewModel.uiState.collectAsStateWithLifecycle()

            SafeCaptureTheme(darkTheme = isDark) {
                when {
                    pinState.pinEnabled && !pinState.isUnlocked ->
                        PinScreen(viewModel = pinViewModel)
                    else ->
                        AppNavigation()
                }
            }
        }
    }
}
