package com.safecapture.app.presentation.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.safecapture.app.presentation.ui.theme.LocalIsDarkTheme
import com.safecapture.app.presentation.ui.theme.NeoColors

// ─── Neomorphism elevation modifier ─────────────────────────────
@Composable
fun Modifier.neoShadow(
    shape: Shape       = RoundedCornerShape(16.dp),
    elevation: Dp      = 8.dp,
    pressed: Boolean   = false,
): Modifier {
    val isDark = LocalIsDarkTheme.current
    val bg     = if (isDark) NeoColors.DarkSurface else NeoColors.Surface

    return if (pressed) {
        this
            .shadow(elevation = 0.dp, shape = shape)
            .background(bg, shape)
    } else {
        this
            .shadow(elevation = elevation,       shape = shape, ambientColor = if (isDark) NeoColors.DarkShadowDark  else NeoColors.ShadowDark,  spotColor = if (isDark) NeoColors.DarkShadowDark  else NeoColors.ShadowDark)
            .shadow(elevation = elevation / 2,   shape = shape, ambientColor = if (isDark) NeoColors.DarkShadowLight else NeoColors.ShadowLight, spotColor = if (isDark) NeoColors.DarkShadowLight else NeoColors.ShadowLight)
            .background(bg, shape)
    }
}

@Composable
fun Modifier.neoCard(
    cornerRadius: Dp  = 20.dp,
    elevation: Dp     = 8.dp,
): Modifier = neoShadow(RoundedCornerShape(cornerRadius), elevation)

@Composable
fun Modifier.neoCircle(elevation: Dp = 8.dp): Modifier = neoShadow(CircleShape, elevation)

/** Background surface color shortcut */
@Composable
fun neoBackground(): Color =
    if (LocalIsDarkTheme.current) NeoColors.DarkBackground else NeoColors.Background

@Composable
fun neoSurface(): Color =
    if (LocalIsDarkTheme.current) NeoColors.DarkSurface else NeoColors.Surface
