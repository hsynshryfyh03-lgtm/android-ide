package com.safecapture.app.data.local.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.safecapture.app.domain.model.Recording

@Entity(tableName = "recordings")
data class RecordingEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id: Long = 0L,

    @ColumnInfo(name = "file_path")
    val filePath: String,

    @ColumnInfo(name = "file_name")
    val fileName: String,

    @ColumnInfo(name = "duration_ms")
    val durationMs: Long,

    @ColumnInfo(name = "file_size_bytes")
    val fileSizeBytes: Long,

    @ColumnInfo(name = "timestamp_ms")
    val timestampMs: Long,

    @ColumnInfo(name = "is_protected")
    val isProtected: Boolean = false
)

fun RecordingEntity.toDomain() = Recording(
    id            = id,
    filePath      = filePath,
    fileName      = fileName,
    durationMs    = durationMs,
    fileSizeBytes = fileSizeBytes,
    timestampMs   = timestampMs,
    isProtected   = isProtected
)

fun Recording.toEntity() = RecordingEntity(
    id            = id,
    filePath      = filePath,
    fileName      = fileName,
    durationMs    = durationMs,
    fileSizeBytes = fileSizeBytes,
    timestampMs   = timestampMs,
    isProtected   = isProtected
)
