package com.safecapture.app.data.local.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities  = [RecordingEntity::class],
    version   = 1,
    exportSchema = true
)
abstract class SafeCaptureDatabase : RoomDatabase() {
    abstract fun recordingDao(): RecordingDao
}
