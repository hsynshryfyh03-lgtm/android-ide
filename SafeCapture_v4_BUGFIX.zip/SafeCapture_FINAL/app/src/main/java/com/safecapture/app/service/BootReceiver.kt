package com.safecapture.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Ensures SafeCapture's foreground service restarts after a device reboot.
 * The Accessibility Service re-registers itself automatically — we only need
 * to restore the idle foreground service so volume-key handling works even
 * before the user opens the app.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED) return

        Log.d("BootReceiver", "Device booted — SafeCapture service will be accessible via AccessibilityService")
        // Note: We do NOT auto-start the recording service on boot.
        // The Accessibility Service (which Android re-enables automatically
        // after boot) will trigger RecordingService.toggle() on double-press.
        // This approach respects user privacy: recording only starts on intent.
    }
}
