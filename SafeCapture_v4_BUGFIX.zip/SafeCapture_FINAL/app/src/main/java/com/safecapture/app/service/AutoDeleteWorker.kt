package com.safecapture.app.service

import android.content.Context
import android.util.Log
import androidx.hilt.work.HiltWorker
import androidx.work.*
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first
import com.safecapture.app.data.local.datastore.SettingsDataStore
import com.safecapture.app.domain.repository.RecordingRepository
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Periodic WorkManager worker — runs every 24 h.
 * Deletes recordings (file + DB row) older than [AppSettings.autoDeleteDays].
 * Protected recordings ([Recording.isProtected] == true) are never touched.
 * If [autoDeleteDays] == 0 the worker exits immediately (feature disabled).
 */
@HiltWorker
class AutoDeleteWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted workerParams: WorkerParameters,
    private val settingsDataStore: SettingsDataStore,
    private val repository: RecordingRepository,
) : CoroutineWorker(context, workerParams) {

    companion object {
        private const val TAG       = "AutoDeleteWorker"
        private const val WORK_NAME = "auto_delete_recordings"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<AutoDeleteWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(1, TimeUnit.HOURS)
                .setConstraints(
                    Constraints.Builder().setRequiresBatteryNotLow(true).build()
                )
                .addTag(TAG)
                .build()

            WorkManager.getInstance(context)
                .enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, request)

            Log.d(TAG, "AutoDeleteWorker scheduled (24h)")
        }
    }

    override suspend fun doWork(): Result {
        val settings = settingsDataStore.settingsFlow.first()

        if (settings.autoDeleteDays <= 0) {
            Log.d(TAG, "Auto-delete disabled — skipping")
            return Result.success()
        }

        val cutoffMs = System.currentTimeMillis() -
                (settings.autoDeleteDays.toLong() * 24 * 60 * 60 * 1000L)

        return try {
            val all      = repository.getAllRecordings().first()
            val toDelete = all.filter { !it.isProtected && it.timestampMs < cutoffMs }

            if (toDelete.isEmpty()) {
                Log.d(TAG, "No recordings to delete")
                return Result.success()
            }

            var count = 0; var freed = 0L
            toDelete.forEach { rec ->
                try {
                    val file = File(rec.filePath)
                    if (file.exists()) { freed += file.length(); file.delete() }
                    repository.deleteRecording(rec.id)
                    count++
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to delete ${rec.fileName}: ${e.message}")
                }
            }
            Log.d(TAG, "Auto-delete: $count files removed, ${freed / 1_048_576}MB freed")
            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "Auto-delete error: ${e.message}")
            Result.retry()
        }
    }
}
