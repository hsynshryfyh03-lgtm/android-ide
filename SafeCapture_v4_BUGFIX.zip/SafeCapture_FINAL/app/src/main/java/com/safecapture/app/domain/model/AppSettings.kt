package com.safecapture.app.domain.model

data class AppSettings(
    /** Milliseconds between double-press events (400 / 600 / 800) */
    val doublePressDelayMs: Int = 600,

    /** Whether to vibrate on recording start/stop */
    val vibrationEnabled: Boolean = true,

    /** Video quality: "480p", "720p", "1080p" */
    val videoQuality: String = "720p",

    /** Camera: "back" or "front" */
    val cameraFacing: String = "back",

    /** Maximum recording duration in minutes; 0 = unlimited */
    val maxDurationMinutes: Int = 30,

    /** Auto-delete recordings older than N days; 0 = never */
    val autoDeleteDays: Int = 0,

    /** Whether audio is enabled in recordings */
    val audioEnabled: Boolean = true,

    // ── Telegram Upload ──────────────────────────────────────
    /** Telegram bot token e.g. "123456:ABCdef…" */
    val telegramBotToken: String = "",

    /** Telegram chat/channel ID e.g. "123456789" or "@channel" */
    val telegramChatId: String = "",

    /** Auto-upload recordings to Telegram after saving */
    val telegramAutoUpload: Boolean = false,

    // ── Timestamp Overlay ────────────────────────────────────
    /** Burn surveillance-camera style date/time watermark into video */
    val timestampOverlay: Boolean = true,

    // ── Disguise ─────────────────────────────────────────────
    /** Show app as "Calculator" in recents and launcher */
    val disguiseModeEnabled: Boolean = false,
)

/** Convenience extensions */
val AppSettings.videoWidthHeight: Pair<Int, Int>
    get() = when (videoQuality) {
        "1080p" -> Pair(1920, 1080)
        "480p"  -> Pair(854,  480)
        else    -> Pair(1280, 720) // 720p default
    }

val AppSettings.videoBitrate: Int
    get() = when (videoQuality) {
        "1080p" -> 8_000_000
        "480p"  -> 2_000_000
        else    -> 4_000_000
    }

val AppSettings.hasTelegramConfig: Boolean
    get() = telegramBotToken.isNotBlank() && telegramChatId.isNotBlank()
