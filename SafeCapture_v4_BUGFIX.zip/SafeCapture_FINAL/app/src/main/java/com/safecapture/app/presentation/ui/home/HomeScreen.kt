package com.safecapture.app.presentation.ui.home

import android.accessibilityservice.AccessibilityServiceInfo
import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.accompanist.permissions.*
import com.safecapture.app.R
import com.safecapture.app.presentation.ui.components.neoBackground
import com.safecapture.app.presentation.ui.components.neoCard
import com.safecapture.app.presentation.ui.theme.NeoColors
import kotlinx.coroutines.delay

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun HomeScreen(viewModel: HomeViewModel = hiltViewModel()) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // ─── Permissions ─────────────────────────────────────────────
    val cameraPermission = rememberPermissionState(Manifest.permission.CAMERA)
    val audioPermission  = rememberPermissionState(Manifest.permission.RECORD_AUDIO)
    val notifPermission  = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
        rememberPermissionState(Manifest.permission.POST_NOTIFICATIONS) else null

    val allGranted = cameraPermission.status.isGranted && audioPermission.status.isGranted

    val bg = neoBackground()

    // Check accessibility service
    val isAccessibilityEnabled = remember {
        mutableStateOf(isAccessibilityServiceEnabled(context))
    }
    LaunchedEffect(Unit) {
        while (true) {
            isAccessibilityEnabled.value = isAccessibilityServiceEnabled(context)
            delay(2_000)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bg)
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(48.dp))

        // ─── App Title ─────────────────────────────────────────
        Text(
            text       = "SafeCapture",
            fontSize   = 28.sp,
            fontWeight = FontWeight.Bold,
            color      = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            text     = "تسجيل طارئ صامت",
            fontSize = 14.sp,
            color    = NeoColors.TextSecondary,
        )

        Spacer(Modifier.height(40.dp))

        // ─── Recording Button ────────────────────────────────
        RecordButton(
            isRecording = uiState.isRecording,
            enabled     = allGranted,
            onClick     = { viewModel.toggleRecording() }
        )

        Spacer(Modifier.height(20.dp))

        // ─── Status & Timer ─────────────────────────────────
        StatusDisplay(
            isRecording    = uiState.isRecording,
            elapsedSeconds = uiState.elapsedSeconds
        )

        Spacer(Modifier.height(8.dp))

        Text(
            text     = if (uiState.isRecording) stringResource(R.string.tap_to_stop)
                       else                     stringResource(R.string.double_press_hint),
            fontSize = 13.sp,
            color    = NeoColors.TextHint,
            textAlign= TextAlign.Center,
        )

        Spacer(Modifier.height(36.dp))

        // ─── Stats Row ───────────────────────────────────────
        Row(
            modifier            = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            StatCard(
                modifier = Modifier.weight(1f),
                icon     = Icons.Filled.VideoFile,
                label    = stringResource(R.string.recordings_count),
                value    = "${uiState.stats.totalCount}",
                color    = NeoColors.Primary,
            )
            StatCard(
                modifier = Modifier.weight(1f),
                icon     = Icons.Filled.Timer,
                label    = stringResource(R.string.total_duration),
                value    = formatDuration(uiState.stats.totalDurationMs / 1000),
                color    = NeoColors.Secondary,
            )
            StatCard(
                modifier = Modifier.weight(1f),
                icon     = Icons.Filled.Storage,
                label    = stringResource(R.string.storage_used),
                value    = formatSize(uiState.stats.totalSizeBytes),
                color    = NeoColors.Success,
            )
        }

        Spacer(Modifier.height(24.dp))

        // ─── Permissions Banner ──────────────────────────────
        if (!allGranted) {
            PermissionBanner {
                cameraPermission.launchPermissionRequest()
                audioPermission.launchPermissionRequest()
            }
        }

        // ─── Accessibility Banner ────────────────────────────
        if (!isAccessibilityEnabled.value) {
            Spacer(Modifier.height(12.dp))
            AccessibilityBanner {
                context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
    }
}

// ─── Animated Record Button ──────────────────────────────────────
@Composable
private fun RecordButton(
    isRecording: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
) {
    val bg = neoBackground()

    // Pulse animation when recording
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue  = if (isRecording) 1.12f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Box(contentAlignment = Alignment.Center) {
        // Outer glow ring when recording
        AnimatedVisibility(
            visible = isRecording,
            enter   = scaleIn(tween(400)) + fadeIn(tween(400)),
            exit    = scaleOut(tween(300)) + fadeOut(tween(300))
        ) {
            Box(
                modifier = Modifier
                    .size(180.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(NeoColors.RecordingGlow)
            )
        }

        // Main button
        Box(
            modifier = Modifier
                .size(140.dp)
                .neoCircle(elevation = if (isRecording) 4.dp else 12.dp)
                .clickable(enabled = enabled) { onClick() },
            contentAlignment = Alignment.Center
        ) {
            // Inner gradient
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = if (isRecording)
                                listOf(NeoColors.Recording, Color(0xFFB71C1C))
                            else
                                listOf(NeoColors.Primary, Color(0xFF3A5FD4))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                AnimatedContent(
                    targetState = isRecording,
                    transitionSpec = {
                        scaleIn(tween(250)) + fadeIn(tween(250)) togetherWith
                        scaleOut(tween(200)) + fadeOut(tween(200))
                    },
                    label = "icon"
                ) { recording ->
                    Icon(
                        imageVector        = if (recording) Icons.Filled.Stop else Icons.Filled.FiberManualRecord,
                        contentDescription = null,
                        tint               = Color.White,
                        modifier           = Modifier.size(40.dp)
                    )
                }
            }
        }
    }
}

// ─── Status Display ──────────────────────────────────────────────
@Composable
private fun StatusDisplay(isRecording: Boolean, elapsedSeconds: Long) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        AnimatedContent(
            targetState  = isRecording,
            transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(200)) },
            label        = "status"
        ) { recording ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (recording) {
                    // Blinking dot
                    val alpha by rememberInfiniteTransition(label = "blink")
                        .animateFloat(1f, 0f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "alpha")
                    Box(
                        Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(NeoColors.Recording.copy(alpha = alpha))
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Text(
                    text       = if (recording) stringResource(R.string.status_recording)
                                 else           stringResource(R.string.status_idle),
                    fontSize   = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color      = if (recording) NeoColors.Recording else NeoColors.TextSecondary,
                )
            }
        }

        AnimatedVisibility(visible = isRecording) {
            Text(
                text       = formatDuration(elapsedSeconds),
                fontSize   = 32.sp,
                fontWeight = FontWeight.Bold,
                color      = MaterialTheme.colorScheme.onBackground,
                modifier   = Modifier.padding(top = 4.dp)
            )
        }
    }
}

// ─── Stat Card ───────────────────────────────────────────────────
@Composable
private fun StatCard(
    modifier: Modifier = Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    color: Color,
) {
    Column(
        modifier           = modifier
            .neoCard(cornerRadius = 16.dp, elevation = 6.dp)
            .padding(vertical = 14.dp, horizontal = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(color.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
        }
        Text(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Text(label, fontSize = 10.sp, color = NeoColors.TextHint, textAlign = TextAlign.Center)
    }
}

// ─── Permission Banner ───────────────────────────────────────────
@Composable
private fun PermissionBanner(onGrant: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(NeoColors.Warning.copy(alpha = 0.12f))
            .border(1.dp, NeoColors.Warning.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
            .clickable(onClick = onGrant)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Warning, null, tint = NeoColors.Warning, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(stringResource(R.string.permission_required_title), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = NeoColors.Warning)
            Text(stringResource(R.string.permission_required_body), fontSize = 11.sp, color = NeoColors.TextSecondary)
        }
        Icon(Icons.Filled.ChevronRight, null, tint = NeoColors.Warning, modifier = Modifier.size(18.dp))
    }
}

// ─── Accessibility Banner ────────────────────────────────────────
@Composable
private fun AccessibilityBanner(onEnable: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(NeoColors.Primary.copy(alpha = 0.10f))
            .border(1.dp, NeoColors.Primary.copy(alpha = 0.25f), RoundedCornerShape(14.dp))
            .clickable(onClick = onEnable)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Accessibility, null, tint = NeoColors.Primary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(stringResource(R.string.accessibility_service), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = NeoColors.Primary)
            Text(stringResource(R.string.accessibility_service_sub), fontSize = 11.sp, color = NeoColors.TextSecondary)
        }
        Icon(Icons.Filled.ChevronRight, null, tint = NeoColors.Primary, modifier = Modifier.size(18.dp))
    }
}

// ─── Helpers ────────────────────────────────────────────────────
private fun formatDuration(totalSeconds: Long): String {
    val h = totalSeconds / 3600
    val m = (totalSeconds % 3600) / 60
    val s = totalSeconds % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s)
           else       "%02d:%02d".format(m, s)
}

private fun formatSize(bytes: Long): String = when {
    bytes >= 1_073_741_824 -> "%.1fGB".format(bytes / 1_073_741_824.0)
    bytes >= 1_048_576     -> "%.1fMB".format(bytes / 1_048_576.0)
    bytes >= 1_024         -> "%.1fKB".format(bytes / 1_024.0)
    else                   -> "${bytes}B"
}

private fun isAccessibilityServiceEnabled(context: Context): Boolean {
    val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
    val enabled = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
    return enabled.any { it.resolveInfo.serviceInfo.packageName == context.packageName }
}

@Composable
private fun Modifier.neoCircle(elevation: androidx.compose.ui.unit.Dp): Modifier {
    return this
        .clip(CircleShape)
        .background(neoBackground())
}
