package com.safecapture.app.service

import android.graphics.*
import android.graphics.SurfaceTexture
import android.opengl.*
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.text.SimpleDateFormat
import java.util.*

/**
 * Renders camera frames from a [SurfaceTexture] (OES texture) onto an EGL surface
 * with a surveillance-camera style timestamp overlay burned directly into the stream.
 *
 * Pipeline:
 *   Camera2 → [inputSurfaceTexture] → GL (OES → 2D + timestamp) → [outputSurface (MediaRecorder)]
 */
class TimestampOverlayRenderer(
    private val outputSurface: Surface,
    private val width: Int,
    private val height: Int,
) {

    companion object {
        private const val TAG = "TimestampRenderer"

        // ── Vertex shader: renders a fullscreen quad ──
        private const val VERTEX_SHADER = """
            attribute vec4 aPosition;
            attribute vec2 aTexCoord;
            varying   vec2 vTexCoord;
            void main() {
                gl_Position = aPosition;
                vTexCoord   = aTexCoord;
            }
        """

        // ── Fragment shader: samples OES (camera) texture ──
        private const val FRAGMENT_SHADER = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float;
            uniform samplerExternalOES uTexture;
            varying vec2 vTexCoord;
            void main() {
                gl_FragColor = texture2D(uTexture, vTexCoord);
            }
        """

        // Fullscreen quad: position (x,y) + texcoord (u,v)
        private val QUAD_VERTICES = floatArrayOf(
            // x,    y,   u,   v
            -1f,  -1f,  0f,  0f,
             1f,  -1f,  1f,  0f,
            -1f,   1f,  0f,  1f,
             1f,   1f,  1f,  1f,
        )
        private const val FLOAT_SIZE = 4
        private const val VERTEX_STRIDE = 4 * FLOAT_SIZE // 4 floats per vertex
    }

    // ── EGL ──────────────────────────────────────────────────────
    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE

    // ── GL ───────────────────────────────────────────────────────
    private var program     = 0
    private var oesTextureId= 0
    private var quadVbo     = 0
    private var aPosition   = 0
    private var aTexCoord   = 0
    private var uTexture    = 0

    // ── Input surface for camera ─────────────────────────────────
    lateinit var inputSurfaceTexture: SurfaceTexture
        private set
    lateinit var inputSurface: Surface
        private set

    // ── Timestamp overlay ────────────────────────────────────────
    private var overlayBitmap: Bitmap? = null
    private var overlayTexId = 0
    private var overlayProgram = 0
    private var overlayVbo = 0

    private val overlayVertexShader = """
        attribute vec4 aPosition;
        attribute vec2 aTexCoord;
        varying   vec2 vTexCoord;
        void main() { gl_Position = aPosition; vTexCoord = aTexCoord; }
    """
    private val overlayFragShader = """
        precision mediump float;
        uniform sampler2D uOverlay;
        varying vec2 vTexCoord;
        void main() { gl_FragColor = texture2D(uOverlay, vTexCoord); }
    """

    private val transformMatrix = FloatArray(16)

    // ── Formats ──────────────────────────────────────────────────
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    // ─────────────────────────────────────────────────────────────
    // PUBLIC API
    // ─────────────────────────────────────────────────────────────

    fun setup() {
        initEgl()
        initGl()
        initOverlay()
        Log.d(TAG, "TimestampOverlayRenderer ready — ${width}x${height}")
    }

    /** Called on each camera frame. Draws camera + timestamp then swaps buffers. */
    fun drawFrame() {
        inputSurfaceTexture.updateTexImage()
        inputSurfaceTexture.getTransformMatrix(transformMatrix)

        GLES20.glViewport(0, 0, width, height)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        // ── Draw camera frame ──
        GLES20.glUseProgram(program)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, quadVbo)
        GLES20.glEnableVertexAttribArray(aPosition)
        GLES20.glEnableVertexAttribArray(aTexCoord)
        GLES20.glVertexAttribPointer(aPosition, 2, GLES20.GL_FLOAT, false, VERTEX_STRIDE, 0)
        GLES20.glVertexAttribPointer(aTexCoord, 2, GLES20.GL_FLOAT, false, VERTEX_STRIDE, 2 * FLOAT_SIZE)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTextureId)
        GLES20.glUniform1i(uTexture, 0)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPosition)
        GLES20.glDisableVertexAttribArray(aTexCoord)

        // ── Draw timestamp overlay ──
        updateOverlayTexture()
        drawOverlay()

        EGL14.eglSwapBuffers(eglDisplay, eglSurface)
    }

    fun release() {
        overlayBitmap?.recycle()
        overlayBitmap = null
        if (overlayTexId != 0) GLES20.glDeleteTextures(1, intArrayOf(overlayTexId), 0)
        if (oesTextureId != 0) GLES20.glDeleteTextures(1, intArrayOf(oesTextureId), 0)
        if (quadVbo != 0)      GLES20.glDeleteBuffers(1, intArrayOf(quadVbo), 0)
        if (overlayVbo != 0)   GLES20.glDeleteBuffers(1, intArrayOf(overlayVbo), 0)
        if (program != 0)      GLES20.glDeleteProgram(program)
        if (overlayProgram != 0) GLES20.glDeleteProgram(overlayProgram)
        if (::inputSurface.isInitialized) inputSurface.release()
        if (::inputSurfaceTexture.isInitialized) inputSurfaceTexture.release()
        EGL14.eglDestroySurface(eglDisplay, eglSurface)
        EGL14.eglDestroyContext(eglDisplay, eglContext)
        EGL14.eglTerminate(eglDisplay)
        Log.d(TAG, "Released")
    }

    // ─────────────────────────────────────────────────────────────
    // PRIVATE — EGL Init
    // ─────────────────────────────────────────────────────────────
    private fun initEgl() {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        check(eglDisplay != EGL14.EGL_NO_DISPLAY) { "eglGetDisplay failed" }

        val version = IntArray(2)
        EGL14.eglInitialize(eglDisplay, version, 0, version, 1)

        val configAttribs = intArrayOf(
            EGL14.EGL_RED_SIZE,        8,
            EGL14.EGL_GREEN_SIZE,      8,
            EGL14.EGL_BLUE_SIZE,       8,
            EGL14.EGL_ALPHA_SIZE,      8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE,    EGL14.EGL_WINDOW_BIT,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val numConfigs = IntArray(1)
        EGL14.eglChooseConfig(eglDisplay, configAttribs, 0, configs, 0, 1, numConfigs, 0)

        val contextAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
        eglContext = EGL14.eglCreateContext(eglDisplay, configs[0]!!, EGL14.EGL_NO_CONTEXT, contextAttribs, 0)

        val surfaceAttribs = intArrayOf(EGL14.EGL_NONE)
        eglSurface = EGL14.eglCreateWindowSurface(eglDisplay, configs[0]!!, outputSurface, surfaceAttribs, 0)

        EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)
    }

    // ─────────────────────────────────────────────────────────────
    // PRIVATE — GL Init
    // ─────────────────────────────────────────────────────────────
    private fun initGl() {
        program = createProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        aPosition = GLES20.glGetAttribLocation(program, "aPosition")
        aTexCoord = GLES20.glGetAttribLocation(program, "aTexCoord")
        uTexture  = GLES20.glGetUniformLocation(program, "uTexture")

        // OES texture for camera
        val texIds = IntArray(1)
        GLES20.glGenTextures(1, texIds, 0)
        oesTextureId = texIds[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTextureId)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)

        // Vertex buffer
        val vbos = IntArray(1)
        GLES20.glGenBuffers(1, vbos, 0)
        quadVbo = vbos[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, quadVbo)
        val vb: FloatBuffer = ByteBuffer.allocateDirect(QUAD_VERTICES.size * FLOAT_SIZE)
            .order(ByteOrder.nativeOrder()).asFloatBuffer().also {
                it.put(QUAD_VERTICES); it.position(0)
            }
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, QUAD_VERTICES.size * FLOAT_SIZE, vb, GLES20.GL_STATIC_DRAW)

        // Attach camera to SurfaceTexture
        inputSurfaceTexture = SurfaceTexture(oesTextureId)
        inputSurfaceTexture.setDefaultBufferSize(width, height)
        inputSurface = Surface(inputSurfaceTexture)
    }

    // ─────────────────────────────────────────────────────────────
    // PRIVATE — Overlay Init & Draw
    // ─────────────────────────────────────────────────────────────
    private fun initOverlay() {
        overlayProgram = createProgram(overlayVertexShader, overlayFragShader)

        // Overlay texture
        val texIds = IntArray(1)
        GLES20.glGenTextures(1, texIds, 0)
        overlayTexId = texIds[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, overlayTexId)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)

        // Overlay VBO — bottom-left corner quad
        // NDC: x from -1..1, y from -1..1. We place overlay at bottom-left.
        val overlayW = 0.55f   // NDC width  (~27% of screen)
        val overlayH = 0.10f   // NDC height (~5% of screen)
        val x0 = -1f + 0.03f
        val y0 = -1f + 0.03f
        val x1 = x0 + overlayW
        val y1 = y0 + overlayH
        val overlayVerts = floatArrayOf(
            x0, y0,  0f, 1f,
            x1, y0,  1f, 1f,
            x0, y1,  0f, 0f,
            x1, y1,  1f, 0f,
        )
        val vbos = IntArray(1)
        GLES20.glGenBuffers(1, vbos, 0)
        overlayVbo = vbos[0]
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, overlayVbo)
        val vb = ByteBuffer.allocateDirect(overlayVerts.size * FLOAT_SIZE)
            .order(ByteOrder.nativeOrder()).asFloatBuffer().also { it.put(overlayVerts); it.position(0) }
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, overlayVerts.size * FLOAT_SIZE, vb, GLES20.GL_STATIC_DRAW)
    }

    /** Re-draws the timestamp bitmap and uploads to GL texture. */
    private fun updateOverlayTexture() {
        val overlayW = 512
        val overlayH = 80
        val bmp = overlayBitmap ?: Bitmap.createBitmap(overlayW, overlayH, Bitmap.Config.ARGB_8888)
            .also { overlayBitmap = it }

        val canvas = Canvas(bmp)
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)

        val now = Date()
        val dateStr = dateFormat.format(now)
        val timeStr = timeFormat.format(now)

        // Semi-transparent background
        val bgPaint = Paint().apply {
            color = Color.argb(160, 0, 0, 0)
            isAntiAlias = true
        }
        canvas.drawRoundRect(4f, 4f, overlayW - 4f, overlayH - 4f, 6f, 6f, bgPaint)

        // Amber / green surveillance color
        val textColor = Color.rgb(0, 220, 100)     // Matrix green
        val dimColor  = Color.rgb(0, 160, 70)

        // Time (large)
        val timePaint = Paint().apply {
            color      = textColor
            textSize   = 42f
            typeface   = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            isAntiAlias = true
        }
        canvas.drawText(timeStr, 14f, 56f, timePaint)

        // Date (small, right side)
        val datePaint = Paint().apply {
            color      = dimColor
            textSize   = 26f
            typeface   = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            isAntiAlias = true
        }
        // Measure time text width to position date after it
        val timeWidth = timePaint.measureText(timeStr)
        canvas.drawText("  $dateStr", 14f + timeWidth, 52f, datePaint)

        // Blinking REC dot
        val recVisible = (System.currentTimeMillis() / 700) % 2 == 0L
        if (recVisible) {
            val recPaint = Paint().apply {
                color = Color.rgb(255, 40, 40)
                isAntiAlias = true
            }
            canvas.drawCircle(overlayW - 22f, 28f, 9f, recPaint)
            val recTextPaint = Paint().apply {
                color = Color.rgb(255, 40, 40)
                textSize = 20f
                typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                isAntiAlias = true
            }
            canvas.drawText("REC", overlayW - 60f, 34f, recTextPaint)
        }

        // Upload bitmap to GL texture
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, overlayTexId)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
    }

    private fun drawOverlay() {
        val aPosLoc   = GLES20.glGetAttribLocation(overlayProgram,  "aPosition")
        val aTexLoc   = GLES20.glGetAttribLocation(overlayProgram,  "aTexCoord")
        val uOvLoc    = GLES20.glGetUniformLocation(overlayProgram, "uOverlay")

        GLES20.glUseProgram(overlayProgram)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, overlayVbo)
        GLES20.glEnableVertexAttribArray(aPosLoc)
        GLES20.glEnableVertexAttribArray(aTexLoc)
        GLES20.glVertexAttribPointer(aPosLoc, 2, GLES20.GL_FLOAT, false, VERTEX_STRIDE, 0)
        GLES20.glVertexAttribPointer(aTexLoc, 2, GLES20.GL_FLOAT, false, VERTEX_STRIDE, 2 * FLOAT_SIZE)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, overlayTexId)
        GLES20.glUniform1i(uOvLoc, 1)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPosLoc)
        GLES20.glDisableVertexAttribArray(aTexLoc)
        GLES20.glDisable(GLES20.GL_BLEND)
    }

    // ─────────────────────────────────────────────────────────────
    // PRIVATE — GL helpers
    // ─────────────────────────────────────────────────────────────
    private fun compileShader(type: Int, src: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, src.trimIndent())
        GLES20.glCompileShader(shader)
        val status = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            Log.e(TAG, "Shader compile error: ${GLES20.glGetShaderInfoLog(shader)}")
            GLES20.glDeleteShader(shader)
            return 0
        }
        return shader
    }

    private fun createProgram(vertSrc: String, fragSrc: String): Int {
        val vert = compileShader(GLES20.GL_VERTEX_SHADER,   vertSrc)
        val frag = compileShader(GLES20.GL_FRAGMENT_SHADER, fragSrc)
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vert)
        GLES20.glAttachShader(prog, frag)
        GLES20.glLinkProgram(prog)
        val status = IntArray(1)
        GLES20.glGetProgramiv(prog, GLES20.GL_LINK_STATUS, status, 0)
        if (status[0] == 0) Log.e(TAG, "Program link error: ${GLES20.glGetProgramInfoLog(prog)}")
        GLES20.glDeleteShader(vert)
        GLES20.glDeleteShader(frag)
        return prog
    }
}
