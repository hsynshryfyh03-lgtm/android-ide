package com.safecapture.app.presentation.ui.pin

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.safecapture.app.presentation.ui.components.neoBackground
import com.safecapture.app.presentation.ui.components.neoCard
import com.safecapture.app.presentation.ui.theme.NeoColors

@Composable
fun PinScreen(viewModel: PinViewModel = hiltViewModel()) {
    val state  = viewModel.uiState.collectAsStateWithLifecycle().value
    val haptic = LocalHapticFeedback.current
    val bg     = neoBackground()

    // Shake animation on error
    val shakeOffset by animateFloatAsState(
        targetValue   = if (state.isError) 1f else 0f,
        animationSpec = if (state.isError)
            keyframes {
                durationMillis = 400
                0f at 0; -12f at 50; 12f at 100; -10f at 150
                10f at 200; -6f at 250; 6f at 300; 0f at 400
            }
        else spring(),
        label = "shake"
    )

    Box(
        modifier = Modifier.fillMaxSize().background(bg),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(32.dp),
        ) {
            // ── Icon ──
            Box(
                modifier = Modifier.size(72.dp).clip(CircleShape)
                    .background(NeoColors.Primary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = if (state.isError) Icons.Filled.Lock else Icons.Filled.LockOpen,
                    contentDescription = null,
                    tint = if (state.isError) NeoColors.Recording else NeoColors.Primary,
                    modifier = Modifier.size(32.dp),
                )
            }

            // ── Title ──
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = when {
                        state.isSetupMode && state.awaitingConfirm -> "أكّد الرقم السري"
                        state.isSetupMode                          -> "أنشئ رقماً سرياً"
                        else                                       -> "أدخل الرقم السري"
                    },
                    fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                )
                AnimatedVisibility(visible = state.isError) {
                    Text(
                        text = state.errorMessage, fontSize = 13.sp,
                        color = NeoColors.Recording,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                }
            }

            // ── PIN Dots ──
            val displayPin = if (state.isSetupMode && state.awaitingConfirm)
                state.confirmPin else state.enteredPin

            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.offset(x = shakeOffset.dp),
            ) {
                repeat(6) { index ->
                    val filled = index < displayPin.length
                    Box(
                        modifier = Modifier
                            .size(14.dp).clip(CircleShape)
                            .background(
                                when {
                                    state.isError && filled -> NeoColors.Recording
                                    filled                  -> NeoColors.Primary
                                    else -> NeoColors.Primary.copy(alpha = 0.2f)
                                }
                            )
                            .border(
                                1.5.dp,
                                if (filled) Color.Transparent
                                else NeoColors.Primary.copy(alpha = 0.35f),
                                CircleShape,
                            )
                    )
                }
            }

            // ── Numpad ──
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf(
                    listOf("1","2","3"),
                    listOf("4","5","6"),
                    listOf("7","8","9"),
                    listOf("","0","⌫"),
                ).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        row.forEach { label ->
                            NumpadKey(
                                label       = label,
                                isBackspace = label == "⌫",
                                isEmpty     = label.isEmpty(),
                                onPress     = {
                                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                    when (label) {
                                        "⌫"  -> viewModel.onBackspace()
                                        ""   -> {}
                                        else -> viewModel.onDigit(label)
                                    }
                                },
                            )
                        }
                    }
                }
            }

            // ── Confirm Button ──
            Button(
                onClick  = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    viewModel.onConfirm()
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape    = RoundedCornerShape(16.dp),
                colors   = ButtonDefaults.buttonColors(
                    containerColor         = NeoColors.Primary,
                    disabledContainerColor = NeoColors.Primary.copy(alpha = 0.4f),
                ),
                enabled  = displayPin.length >= 4,
            ) {
                Text(
                    text = when {
                        state.isSetupMode && state.awaitingConfirm -> "تأكيد"
                        state.isSetupMode                          -> "التالي"
                        else                                       -> "دخول"
                    },
                    fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                )
            }
        }
    }
}

@Composable
private fun NumpadKey(
    label      : String,
    isBackspace: Boolean,
    isEmpty    : Boolean,
    onPress    : () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(76.dp).clip(CircleShape)
            .then(
                if (isEmpty) Modifier.background(Color.Transparent)
                else Modifier
                    .neoCard(cornerRadius = 38.dp, elevation = if (isBackspace) 2.dp else 6.dp)
                    .clickable(enabled = true, onClick = onPress)
            ),
        contentAlignment = Alignment.Center,
    ) {
        if (!isEmpty) {
            if (isBackspace) {
                Icon(
                    Icons.Filled.Backspace, "حذف",
                    tint = NeoColors.TextSecondary,
                    modifier = Modifier.size(22.dp),
                )
            } else {
                Text(
                    text = label, fontSize = 26.sp,
                    fontWeight = FontWeight.Medium,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onBackground,
                )
            }
        }
    }
}
