package com.safecapture.app.presentation.ui.recordings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.safecapture.app.domain.model.Recording
import com.safecapture.app.domain.repository.RecordingRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

data class RecordingsUiState(
    val recordings  : List<Recording> = emptyList(),
    val searchQuery : String          = "",
    val isLoading   : Boolean         = true,
)

@HiltViewModel
class RecordingsViewModel @Inject constructor(
    private val repository: RecordingRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")

    val uiState: StateFlow<RecordingsUiState> = combine(
        repository.getAllRecordings(),
        _searchQuery,
    ) { recordings, query ->
        val filtered = if (query.isBlank()) recordings
        else recordings.filter { it.fileName.contains(query, ignoreCase = true) }
        RecordingsUiState(filtered, query, isLoading = false)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000),
        RecordingsUiState(isLoading = true))

    fun setQuery(q: String) { _searchQuery.value = q }

    fun deleteRecording(recording: Recording) {
        viewModelScope.launch {
            // Delete file from disk first
            val file = File(recording.filePath)
            if (file.exists()) file.delete()
            repository.deleteRecording(recording.id)
        }
    }

    fun deleteAll(recordings: List<Recording>) {
        viewModelScope.launch {
            recordings.forEach { r ->
                val file = File(r.filePath)
                if (file.exists()) file.delete()
            }
            repository.deleteAllRecordings()
        }
    }

    fun toggleProtection(recording: Recording) {
        viewModelScope.launch {
            repository.toggleProtection(recording.id, !recording.isProtected)
        }
    }
}
