package com.safecapture.app.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.util.Log
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.safecapture.app.data.local.datastore.SettingsDataStore
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import javax.inject.Inject

@AndroidEntryPoint
class VolumeKeyAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "VolumeKeyA11y"
    }

    @Inject lateinit var settingsDataStore: SettingsDataStore

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    /** Timestamp of the last volume-up key DOWN event */
    private var lastVolumeUpTime = 0L

    /** Pending job that resets the counter if second press doesn't arrive */
    private var resetJob: Job? = null

    /** Whether we're waiting for the second press */
    private var waitingForSecond = false

    // ─────────────────────────────────────────────────────────────
    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_UP) return false
        if (event.action  != KeyEvent.ACTION_DOWN)       return false

        scope.launch {
            val delayMs = settingsDataStore.settingsFlow.first().doublePressDelayMs.toLong()
            val now     = SystemClock.elapsedRealtime()

            if (waitingForSecond && (now - lastVolumeUpTime) <= delayMs) {
                // ── DOUBLE PRESS DETECTED ──
                resetJob?.cancel()
                waitingForSecond = false
                lastVolumeUpTime = 0L
                Log.d(TAG, "Double volume-up detected — toggling recording")
                RecordingService.toggle(applicationContext)
            } else {
                // First press — start wait window
                lastVolumeUpTime = now
                waitingForSecond = true
                resetJob?.cancel()
                resetJob = scope.launch {
                    delay(delayMs + 100)
                    waitingForSecond = false
                    lastVolumeUpTime = 0L
                }
            }
        }
        // Return false so the system still handles volume change normally
        return false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* not used */ }
    override fun onInterrupt() { Log.d(TAG, "Accessibility service interrupted") }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "VolumeKeyAccessibilityService connected")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        scope.cancel()
        return super.onUnbind(intent)
    }
}
