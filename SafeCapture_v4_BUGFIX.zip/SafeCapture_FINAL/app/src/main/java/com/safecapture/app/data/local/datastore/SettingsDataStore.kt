package com.safecapture.app.data.local.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.safecapture.app.domain.model.AppSettings
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "safe_capture_prefs")

@Singleton
class SettingsDataStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val DOUBLE_PRESS_DELAY   = intPreferencesKey("double_press_delay_ms")
        val VIBRATION_ENABLED    = booleanPreferencesKey("vibration_enabled")
        val VIDEO_QUALITY        = stringPreferencesKey("video_quality")
        val CAMERA_FACING        = stringPreferencesKey("camera_facing")
        val MAX_DURATION         = intPreferencesKey("max_duration_minutes")
        val AUTO_DELETE_DAYS     = intPreferencesKey("auto_delete_days")
        val AUDIO_ENABLED        = booleanPreferencesKey("audio_enabled")
        val DARK_MODE            = booleanPreferencesKey("dark_mode")
        val PIN_ENABLED          = booleanPreferencesKey("pin_enabled")
        val PIN_HASH             = stringPreferencesKey("pin_hash")
        val STEALTH_MODE         = booleanPreferencesKey("stealth_mode")
        // Telegram
        val TELEGRAM_TOKEN       = stringPreferencesKey("telegram_bot_token")
        val TELEGRAM_CHAT_ID     = stringPreferencesKey("telegram_chat_id")
        val TELEGRAM_AUTO_UPLOAD = booleanPreferencesKey("telegram_auto_upload")
        // Timestamp overlay
        val TIMESTAMP_OVERLAY    = booleanPreferencesKey("timestamp_overlay")
        // Disguise
        val DISGUISE_MODE        = booleanPreferencesKey("disguise_mode")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data
        .catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { prefs ->
            AppSettings(
                doublePressDelayMs   = prefs[Keys.DOUBLE_PRESS_DELAY]   ?: 600,
                vibrationEnabled     = prefs[Keys.VIBRATION_ENABLED]    ?: true,
                videoQuality         = prefs[Keys.VIDEO_QUALITY]         ?: "720p",
                cameraFacing         = prefs[Keys.CAMERA_FACING]         ?: "back",
                maxDurationMinutes   = prefs[Keys.MAX_DURATION]          ?: 30,
                autoDeleteDays       = prefs[Keys.AUTO_DELETE_DAYS]      ?: 0,
                audioEnabled         = prefs[Keys.AUDIO_ENABLED]         ?: true,
                telegramBotToken     = prefs[Keys.TELEGRAM_TOKEN]        ?: "",
                telegramChatId       = prefs[Keys.TELEGRAM_CHAT_ID]      ?: "",
                telegramAutoUpload   = prefs[Keys.TELEGRAM_AUTO_UPLOAD]  ?: false,
                timestampOverlay     = prefs[Keys.TIMESTAMP_OVERLAY]     ?: true,
                disguiseModeEnabled  = prefs[Keys.DISGUISE_MODE]         ?: false,
            )
        }

    val darkModeFlow: Flow<Boolean> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { it[Keys.DARK_MODE] ?: false }

    val stealthModeFlow: Flow<Boolean> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { it[Keys.STEALTH_MODE] ?: false }

    val pinEnabledFlow: Flow<Boolean> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { it[Keys.PIN_ENABLED] ?: false }

    val pinHashFlow: Flow<String> = context.dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { it[Keys.PIN_HASH] ?: "" }

    suspend fun updateDoublePressDelay(ms: Int) =
        context.dataStore.edit { it[Keys.DOUBLE_PRESS_DELAY] = ms }

    suspend fun updateVibration(enabled: Boolean) =
        context.dataStore.edit { it[Keys.VIBRATION_ENABLED] = enabled }

    suspend fun updateVideoQuality(quality: String) =
        context.dataStore.edit { it[Keys.VIDEO_QUALITY] = quality }

    suspend fun updateCameraFacing(facing: String) =
        context.dataStore.edit { it[Keys.CAMERA_FACING] = facing }

    suspend fun updateMaxDuration(minutes: Int) =
        context.dataStore.edit { it[Keys.MAX_DURATION] = minutes }

    suspend fun updateAutoDeleteDays(days: Int) =
        context.dataStore.edit { it[Keys.AUTO_DELETE_DAYS] = days }

    suspend fun updateAudioEnabled(enabled: Boolean) =
        context.dataStore.edit { it[Keys.AUDIO_ENABLED] = enabled }

    suspend fun updateDarkMode(enabled: Boolean) =
        context.dataStore.edit { it[Keys.DARK_MODE] = enabled }

    suspend fun updateStealthMode(enabled: Boolean) =
        context.dataStore.edit { it[Keys.STEALTH_MODE] = enabled }

    suspend fun updatePin(enabled: Boolean, pinHash: String = "") {
        context.dataStore.edit {
            it[Keys.PIN_ENABLED] = enabled
            it[Keys.PIN_HASH]    = pinHash
        }
    }

    // ── Telegram ────────────────────────────────────────────
    suspend fun updateTelegramToken(token: String) =
        context.dataStore.edit { it[Keys.TELEGRAM_TOKEN] = token }

    suspend fun updateTelegramChatId(chatId: String) =
        context.dataStore.edit { it[Keys.TELEGRAM_CHAT_ID] = chatId }

    suspend fun updateTelegramAutoUpload(enabled: Boolean) =
        context.dataStore.edit { it[Keys.TELEGRAM_AUTO_UPLOAD] = enabled }

    // ── Timestamp ───────────────────────────────────────────
    suspend fun updateTimestampOverlay(enabled: Boolean) =
        context.dataStore.edit { it[Keys.TIMESTAMP_OVERLAY] = enabled }

    // ── Disguise ────────────────────────────────────────────
    suspend fun updateDisguiseMode(enabled: Boolean) =
        context.dataStore.edit { it[Keys.DISGUISE_MODE] = enabled }
}
