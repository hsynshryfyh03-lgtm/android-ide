package com.safecapture.app.domain.model

data class Recording(
    val id: Long = 0L,
    val filePath: String,
    val fileName: String,
    val durationMs: Long,        // milliseconds
    val fileSizeBytes: Long,
    val timestampMs: Long,       // epoch millis
    val isProtected: Boolean = false
) {
    /** Human-readable duration: HH:MM:SS */
    val durationFormatted: String get() {
        val totalSec = durationMs / 1000
        val h = totalSec / 3600
        val m = (totalSec % 3600) / 60
        val s = totalSec % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
    }

    /** Human-readable file size */
    val sizeFormatted: String get() = when {
        fileSizeBytes >= 1_073_741_824 -> "%.1f GB".format(fileSizeBytes / 1_073_741_824.0)
        fileSizeBytes >= 1_048_576     -> "%.1f MB".format(fileSizeBytes / 1_048_576.0)
        fileSizeBytes >= 1_024         -> "%.1f KB".format(fileSizeBytes / 1_024.0)
        else                           -> "$fileSizeBytes B"
    }
}
