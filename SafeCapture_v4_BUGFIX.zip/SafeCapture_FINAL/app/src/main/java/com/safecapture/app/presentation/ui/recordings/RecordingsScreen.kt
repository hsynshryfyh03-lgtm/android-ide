package com.safecapture.app.presentation.ui.recordings

import android.content.Intent
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.VideoFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.safecapture.app.R
import com.safecapture.app.domain.model.Recording
import com.safecapture.app.presentation.ui.components.neoBackground
import com.safecapture.app.presentation.ui.components.neoCard
import com.safecapture.app.presentation.ui.theme.NeoColors
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun RecordingsScreen(viewModel: RecordingsViewModel = hiltViewModel()) {
    val uiState = viewModel.uiState.collectAsStateWithLifecycle().value
    val context = LocalContext.current
    val bg = neoBackground()

    var showDeleteAllDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bg)
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(48.dp))

        // Header
        Row(
            modifier              = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment     = Alignment.CenterVertically
        ) {
            Column {
                Text("التسجيلات", fontSize = 24.sp, fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground)
                Text("${uiState.recordings.size} ${stringResource(R.string.recordings_count)}",
                    fontSize = 13.sp, color = NeoColors.TextSecondary)
            }
            if (uiState.recordings.isNotEmpty()) {
                IconButton(
                    onClick  = { showDeleteAllDialog = true },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(NeoColors.Recording.copy(alpha = 0.10f))
                ) {
                    Icon(Icons.Filled.DeleteSweep, null, tint = NeoColors.Recording, modifier = Modifier.size(20.dp))
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // Search bar
        OutlinedTextField(
            value         = uiState.searchQuery,
            onValueChange = { viewModel.setQuery(it) },
            modifier      = Modifier.fillMaxWidth(),
            placeholder   = { Text(stringResource(R.string.search_hint), fontSize = 13.sp) },
            leadingIcon   = { Icon(Icons.Filled.Search, null, tint = NeoColors.TextSecondary, modifier = Modifier.size(18.dp)) },
            trailingIcon  = {
                if (uiState.searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.setQuery("") }) {
                        Icon(Icons.Filled.Clear, null, tint = NeoColors.TextSecondary, modifier = Modifier.size(16.dp))
                    }
                }
            },
            shape  = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor   = NeoColors.Primary,
                unfocusedBorderColor = NeoColors.ShadowDark.copy(alpha = 0.4f),
                focusedContainerColor   = bg,
                unfocusedContainerColor = bg,
            ),
            singleLine = true,
        )

        Spacer(Modifier.height(16.dp))

        // List or empty state
        if (uiState.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = NeoColors.Primary)
            }
        } else if (uiState.recordings.isEmpty()) {
            EmptyState()
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(uiState.recordings, key = { it.id }) { recording ->
                    AnimatedVisibility(
                        visible      = true,
                        enter        = fadeIn(tween(300)) + slideInVertically(tween(300)),
                    ) {
                        RecordingCard(
                            recording       = recording,
                            onDelete        = { viewModel.deleteRecording(recording) },
                            onShare         = {
                                val file = File(recording.filePath)
                                if (file.exists()) {
                                    val uri = FileProvider.getUriForFile(
                                        context, "${context.packageName}.fileprovider", file)
                                    context.startActivity(Intent.createChooser(
                                        Intent(Intent.ACTION_SEND).apply {
                                            type    = "video/mp4"
                                            putExtra(Intent.EXTRA_STREAM, uri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }, null
                                    ))
                                }
                            },
                            onToggleProtect = { viewModel.toggleProtection(recording) },
                        )
                    }
                }
                item { Spacer(Modifier.height(8.dp)) }
            }
        }
    }

    // Delete all confirmation dialog
    if (showDeleteAllDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteAllDialog = false },
            title   = { Text(stringResource(R.string.delete_all)) },
            text    = { Text(stringResource(R.string.delete_confirm)) },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteAll(uiState.recordings)
                    showDeleteAllDialog = false
                }) { Text(stringResource(R.string.confirm), color = NeoColors.Recording) }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteAllDialog = false }) {
                    Text(stringResource(R.string.cancel))
                }
            },
            shape = RoundedCornerShape(20.dp)
        )
    }
}

@Composable
private fun RecordingCard(
    recording       : Recording,
    onDelete        : () -> Unit,
    onShare         : () -> Unit,
    onToggleProtect : () -> Unit,
) {
    var showDeleteDialog by remember { mutableStateOf(false) }
    val dateStr = remember(recording.timestampMs) {
        SimpleDateFormat("dd MMM yyyy  •  HH:mm", Locale.getDefault())
            .format(Date(recording.timestampMs))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .neoCard(cornerRadius = 18.dp, elevation = 6.dp)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Icon
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(NeoColors.Primary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.VideoFile, null, tint = NeoColors.Primary, modifier = Modifier.size(24.dp))
        }

        Spacer(Modifier.width(12.dp))

        // Info
        Column(Modifier.weight(1f)) {
            Text(
                text     = recording.fileName,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color    = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(3.dp))
            Text(dateStr, fontSize = 11.sp, color = NeoColors.TextSecondary)
            Spacer(Modifier.height(3.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(text = recording.durationFormatted, color = NeoColors.Primary)
                Chip(text = recording.sizeFormatted,     color = NeoColors.Secondary)
                if (recording.isProtected)
                    Chip(text = "🔒", color = NeoColors.Success)
            }
        }

        // Actions
        Row {
            SmallIconButton(Icons.Filled.Share, NeoColors.Primary)   { onShare() }
            SmallIconButton(Icons.Filled.Lock, if (recording.isProtected) NeoColors.Success else NeoColors.TextHint) { onToggleProtect() }
            SmallIconButton(Icons.Filled.Delete, NeoColors.Recording) { showDeleteDialog = true }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title   = { Text(stringResource(R.string.delete_recording)) },
            text    = { Text(stringResource(R.string.delete_confirm)) },
            confirmButton = {
                TextButton(onClick = { onDelete(); showDeleteDialog = false }) {
                    Text(stringResource(R.string.confirm), color = NeoColors.Recording)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text(stringResource(R.string.cancel))
                }
            },
            shape = RoundedCornerShape(20.dp)
        )
    }
}

@Composable
private fun Chip(text: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 7.dp, vertical = 2.dp)
    ) {
        Text(text, fontSize = 10.sp, color = color, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun SmallIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    onClick: () -> Unit
) {
    IconButton(onClick = onClick, modifier = Modifier.size(36.dp)) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun EmptyState() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(NeoColors.Primary.copy(alpha = 0.10f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.VideoFile, null, tint = NeoColors.Primary, modifier = Modifier.size(36.dp))
            }
            Spacer(Modifier.height(20.dp))
            Text(stringResource(R.string.no_recordings), fontSize = 18.sp, fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onBackground)
            Spacer(Modifier.height(8.dp))
            Text(stringResource(R.string.no_recordings_sub), fontSize = 13.sp, color = NeoColors.TextSecondary,
                textAlign = TextAlign.Center)
        }
    }
}
