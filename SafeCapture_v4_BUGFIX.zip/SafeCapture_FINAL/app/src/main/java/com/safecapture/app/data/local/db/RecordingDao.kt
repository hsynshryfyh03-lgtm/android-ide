package com.safecapture.app.data.local.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface RecordingDao {

    @Query("SELECT * FROM recordings ORDER BY timestamp_ms DESC")
    fun getAllRecordings(): Flow<List<RecordingEntity>>

    @Query("SELECT * FROM recordings WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): RecordingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: RecordingEntity): Long

    @Query("DELETE FROM recordings WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM recordings")
    suspend fun deleteAll()

    @Query("UPDATE recordings SET is_protected = :protect WHERE id = :id")
    suspend fun updateProtection(id: Long, protect: Boolean)

    @Query("""
        SELECT 
            COUNT(*) as totalCount,
            COALESCE(SUM(duration_ms), 0) as totalDurationMs,
            COALESCE(SUM(file_size_bytes), 0) as totalSizeBytes
        FROM recordings
    """)
    fun getStats(): Flow<StatsResult>

    @Query("DELETE FROM recordings WHERE timestamp_ms < :beforeMs AND is_protected = 0")
    suspend fun deleteOlderThan(beforeMs: Long)
}

data class StatsResult(
    val totalCount: Int,
    val totalDurationMs: Long,
    val totalSizeBytes: Long
)
